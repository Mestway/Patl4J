package com.mediaymedia.gdata.service;
import com.mediaymedia.gdata.model.CalendarioEntry;
import com.mediaymedia.gdata.errors.GoogleProblema;
import com.google.gdata.data.calendar.CalendarEventFeed;
import com.google.gdata.data.calendar.CalendarEventEntry;
import com.google.gdata.data.DateTime;
import com.google.gdata.client.calendar.CalendarService;
import com.google.gdata.client.calendar.CalendarQuery;
import com.google.gdata.util.AuthenticationException;
import com.google.gdata.util.ServiceException;
import java.util.List;
import java.util.ArrayList;
import java.util.Date;
import java.net.URL;
import java.io.IOException;
/** 
 * User: juan Date: 15-oct-2007 Time: 12:41:38
 */
public class CalendarioServiceImpl extends GData implements CalendarioService {
  public CalendarService createCalendarService(  String usuarioGmail,  String clave) throws GoogleProblema {
    java.lang.String genVar33;
    genVar33="exampleCo-exampleApp-3";
    CalendarService myServiceCalBis;
    myServiceCalBis=new CalendarService(genVar33);
    try {
      myServiceCalBis.setUserCredentials(usuarioGmail,clave);
    }
 catch (    AuthenticationException e) {
      java.lang.String genVar34;
      genVar34=e.getMessage();
      com.mediaymedia.gdata.errors.GoogleProblema genVar35;
      genVar35=new GoogleProblema(genVar34,e);
      throw genVar35;
    }
    return myServiceCalBis;
  }
  public CalendarEventFeed createCalendarFeed(  CalendarService myServiceCalBis,  String url) throws GoogleProblema {
    try {
      java.net.URL genVar36;
      genVar36=new URL(url);
      java.lang.Class<com.google.gdata.data.calendar.CalendarEventFeed> genVar37;
      genVar37=CalendarEventFeed.class;
      com.google.gdata.data.calendar.CalendarEventFeed genVar38;
      genVar38=myServiceCalBis.getFeed(genVar36,genVar37);
      return genVar38;
    }
 catch (    IOException e) {
      java.lang.String genVar39;
      genVar39=e.getMessage();
      com.mediaymedia.gdata.errors.GoogleProblema genVar40;
      genVar40=new GoogleProblema(genVar39,e);
      throw genVar40;
    }
catch (    ServiceException e) {
      java.lang.String genVar41;
      genVar41=e.getMessage();
      com.mediaymedia.gdata.errors.GoogleProblema genVar42;
      genVar42=new GoogleProblema(genVar41,e);
      throw genVar42;
    }
  }
  public CalendarEventFeed createCalendarFeed(  CalendarService myServiceCalBis,  String url,  Date inicio,  Date fin) throws GoogleProblema {
    try {
      CalendarioServiceImpl genVar43;
      genVar43=this;
      URL feedUrl;
      feedUrl=genVar43.dameFeedURL(url);
      CalendarQuery myQuery;
      myQuery=new CalendarQuery(feedUrl);
      com.google.gdata.data.DateTime genVar44;
      genVar44=new DateTime(inicio);
      myQuery.setMinimumStartTime(genVar44);
      com.google.gdata.data.DateTime genVar45;
      genVar45=new DateTime(fin);
      myQuery.setMaximumStartTime(genVar45);
      java.lang.Class<com.google.gdata.data.calendar.CalendarEventFeed> genVar46;
      genVar46=CalendarEventFeed.class;
      com.google.gdata.data.calendar.CalendarEventFeed genVar47;
      genVar47=myServiceCalBis.query(myQuery,genVar46);
      return genVar47;
    }
 catch (    IOException e) {
      java.lang.String genVar48;
      genVar48=e.getMessage();
      com.mediaymedia.gdata.errors.GoogleProblema genVar49;
      genVar49=new GoogleProblema(genVar48,e);
      throw genVar49;
    }
catch (    ServiceException e) {
      java.lang.String genVar50;
      genVar50=e.getMessage();
      com.mediaymedia.gdata.errors.GoogleProblema genVar51;
      genVar51=new GoogleProblema(genVar50,e);
      throw genVar51;
    }
  }
  private URL dameFeedURL(  String url){
    return null;
  }
  public List<CalendarioEntry> dameEventosCalendario(  GoogleProperties googleProperties) throws GoogleProblema {
    List<CalendarioEntry> entradas;
    entradas=new ArrayList<CalendarioEntry>();
    CalendarioServiceImpl genVar52;
    genVar52=this;
    java.lang.String genVar53;
    genVar53=googleProperties.getUsuarioGmail();
    java.lang.String genVar54;
    genVar54=googleProperties.getClave();
    com.google.gdata.client.calendar.CalendarService myServiceCalBis;
    myServiceCalBis=genVar52.createCalendarService(genVar53,genVar54);
    String url;
    url="http://www.google.com/calendar/feeds/m70o2l3viisdbh7ra2v2utbl0k@group.calendar.google.com/private/full";
    CalendarioServiceImpl genVar55;
    genVar55=this;
    CalendarEventFeed myFeed;
    myFeed=genVar55.createCalendarFeed(myServiceCalBis,url);
    java.util.List<com.google.gdata.data.calendar.CalendarEventEntry> genVar56;
    genVar56=myFeed.getEntries();
    for (    CalendarEventEntry cita : genVar56) {
      CalendarioEntry calendarEntry;
      calendarEntry=new CalendarioEntry(cita);
      entradas.add(calendarEntry);
    }
    return entradas;
  }
  public List<CalendarioEntry> dameEventosCalendario(  Date inicio,  Date fin,  GoogleProperties googleProperties) throws GoogleProblema {
    List<CalendarioEntry> entradas;
    entradas=new ArrayList<CalendarioEntry>();
    CalendarioServiceImpl genVar57;
    genVar57=this;
    java.lang.String genVar58;
    genVar58=googleProperties.getUsuarioGmail();
    java.lang.String genVar59;
    genVar59=googleProperties.getClave();
    CalendarService myServiceCalBis;
    myServiceCalBis=genVar57.createCalendarService(genVar58,genVar59);
    String url;
    url="http://www.google.com/calendar/feeds/m70o2l3viisdbh7ra2v2utbl0k@group.calendar.google.com/private/full";
    CalendarioServiceImpl genVar60;
    genVar60=this;
    CalendarEventFeed myFeed;
    myFeed=genVar60.createCalendarFeed(myServiceCalBis,url,inicio,fin);
    java.util.List<com.google.gdata.data.calendar.CalendarEventEntry> genVar61;
    genVar61=myFeed.getEntries();
    for (    CalendarEventEntry cita : genVar61) {
      CalendarioEntry calendarEntry;
      calendarEntry=new CalendarioEntry(cita);
      entradas.add(calendarEntry);
    }
    return entradas;
  }
  public void updateCalendarEntry(  CalendarEventEntry entry,  GoogleProperties googleProperties) throws IOException, GoogleProblema, ServiceException {
    CalendarioServiceImpl genVar62;
    genVar62=this;
    java.lang.String genVar63;
    genVar63=googleProperties.getUsuarioGmail();
    java.lang.String genVar64;
    genVar64=googleProperties.getClave();
    CalendarService calendarService;
    calendarService=genVar62.createCalendarService(genVar63,genVar64);
    com.google.gdata.data.Link genVar65;
    genVar65=entry.getEditLink();
    java.lang.String genVar66;
    genVar66=genVar65.getHref();
    java.net.URL genVar67;
    genVar67=new URL(genVar66);
    calendarService.update(genVar67,entry);
  }
}
