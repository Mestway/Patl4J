package com.mediaymedia.gdata.service;
public class GoogleProperties {
  public String getUsuarioGmail(){
    return null;
  }
  public String getClave(){
    return null;
  }
}
