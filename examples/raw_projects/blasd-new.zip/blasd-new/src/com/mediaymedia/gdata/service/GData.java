package com.mediaymedia.gdata.service;
public class GData {
}
