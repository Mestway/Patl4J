package com.mediaymedia.gdata.model;
import com.google.gdata.data.calendar.CalendarEventEntry;
import com.google.gdata.data.DateTime;
import com.google.gdata.data.TextContent;
import com.google.gdata.data.TextConstruct;
import java.util.Date;
import java.util.Calendar;
/** 
 * User: juan Date: 15-oct-2007 Time: 12:35:13
 */
public class CalendarioEntry {
  Date startTime;
  Date endTime;
  String titulo;
  String contenido;
  String lugar;
  CalendarEventEntry entry;
  String id;
  public CalendarioEntry(  CalendarEventEntry entry){
    com.mediaymedia.gdata.model.CalendarioEntry genVar0;
    genVar0=this;
    genVar0.id=entry.getId();
    com.mediaymedia.gdata.model.CalendarioEntry genVar1;
    genVar1=this;
    genVar1.entry=entry;
    com.google.gdata.data.TextConstruct genVar2;
    genVar2=entry.getTitle();
    titulo=genVar2.getPlainText();
    CalendarioEntry genVar3;
    genVar3=this;
    contenido=genVar3.obteinHtml(entry);
    System.out.println(titulo);
    java.util.List<com.google.gdata.data.extensions.When> genVar4;
    genVar4=entry.getTimes();
    int genVar5;
    genVar5=genVar4.size();
    int genVar6;
    genVar6=0;
    boolean genVar7;
    genVar7=genVar5 > genVar6;
    if (genVar7) {
      CalendarioEntry genVar8;
      genVar8=this;
      java.util.List<com.google.gdata.data.extensions.When> genVar9;
      genVar9=entry.getTimes();
      int genVar10;
      genVar10=0;
      com.google.gdata.data.extensions.When genVar11;
      genVar11=genVar9.get(genVar10);
      com.google.gdata.data.DateTime genVar12;
      genVar12=genVar11.getStartTime();
      startTime=genVar8.generaDate(genVar12);
      CalendarioEntry genVar13;
      genVar13=this;
      java.util.List<com.google.gdata.data.extensions.When> genVar14;
      genVar14=entry.getTimes();
      int genVar15;
      genVar15=0;
      com.google.gdata.data.extensions.When genVar16;
      genVar16=genVar14.get(genVar15);
      com.google.gdata.data.DateTime genVar17;
      genVar17=genVar16.getEndTime();
      endTime=genVar13.generaDate(genVar17);
    }
 else {
      ;
    }
    java.util.List<com.google.gdata.data.extensions.Where> genVar18;
    genVar18=entry.getLocations();
    int genVar19;
    genVar19=genVar18.size();
    int genVar20;
    genVar20=0;
    boolean genVar21;
    genVar21=genVar19 > genVar20;
    if (genVar21) {
      java.util.List<com.google.gdata.data.extensions.Where> genVar22;
      genVar22=entry.getLocations();
      int genVar23;
      genVar23=0;
      com.google.gdata.data.extensions.Where genVar24;
      genVar24=genVar22.get(genVar23);
      lugar=genVar24.getValueString();
    }
 else {
      ;
    }
  }
  public CalendarEventEntry getEntry(){
    return entry;
  }
  private Date generaDate(  DateTime start){
    Calendar calendar;
    calendar=Calendar.getInstance();
    long genVar25;
    genVar25=start.getValue();
    calendar.setTimeInMillis(genVar25);
    java.util.Date genVar26;
    genVar26=calendar.getTime();
    return genVar26;
  }
  private String obteinHtml(  CalendarEventEntry entry){
    com.google.gdata.data.Content genVar27;
    genVar27=entry.getContent();
    com.google.gdata.data.TextContent genVar28;
    genVar28=(TextContent)genVar27;
    TextContent content;
    content=(genVar28);
    com.google.gdata.data.TextConstruct genVar29;
    genVar29=content.getContent();
    TextConstruct ptc;
    ptc=(TextConstruct)genVar29;
    java.lang.String genVar30;
    genVar30=ptc.getPlainText();
    return genVar30;
  }
  public String getContenido(){
    return contenido;
  }
  public Date getEndTime(){
    return endTime;
  }
  public Date getStartTime(){
    return startTime;
  }
  public String getTitulo(){
    return titulo;
  }
  public String getLugar(){
    return lugar;
  }
  public String getId(){
    return id;
  }
  public void setTitulo(  String titulo){
    com.mediaymedia.gdata.model.CalendarioEntry genVar31;
    genVar31=this;
    genVar31.titulo=titulo;
  }
  public void setContenido(  String contenido){
    com.mediaymedia.gdata.model.CalendarioEntry genVar32;
    genVar32=this;
    genVar32.contenido=contenido;
  }
}
