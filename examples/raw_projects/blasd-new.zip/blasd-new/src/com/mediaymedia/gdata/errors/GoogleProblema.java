package com.mediaymedia.gdata.errors;
public class GoogleProblema extends Exception {
  /** 
 */
  private static final long serialVersionUID=1L;
  public GoogleProblema(  String message,  Exception e){
  }
}
