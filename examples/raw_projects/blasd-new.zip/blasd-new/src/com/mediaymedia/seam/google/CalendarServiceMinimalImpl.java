package com.mediaymedia.seam.google;
import com.mediaymedia.gdata.service.CalendarioService;
import com.mediaymedia.gdata.service.CalendarioServiceImpl;
import com.mediaymedia.gdata.service.GoogleProperties;
import com.mediaymedia.gdata.model.CalendarioEntry;
import com.mediaymedia.gdata.errors.GoogleProblema;
import com.google.gdata.data.calendar.CalendarEventEntry;
import com.google.gdata.util.ServiceException;
import java.util.List;
import java.util.Date;
import java.io.IOException;
/** 
 * User: juan Date: 15-oct-2007 Time: 13:15:03
 */
public class CalendarServiceMinimalImpl extends GDataSeam implements CalendarServiceMinimal {
  GoogleProperties googleProperties;
  CalendarioService calendarioService=new CalendarioServiceImpl();
  public void updateCalendarEntry(  CalendarEventEntry entry) throws IOException, GoogleProblema, ServiceException {
    calendarioService.updateCalendarEntry(entry,googleProperties);
  }
  public List<CalendarioEntry> dameEventosCalendario(  Date inicio,  Date fin) throws GoogleProblema {
    java.util.List<com.mediaymedia.gdata.model.CalendarioEntry> genVar68;
    genVar68=calendarioService.dameEventosCalendario(inicio,fin,googleProperties);
    return genVar68;
  }
  public List<CalendarioEntry> dameEventosCalendario() throws GoogleProblema {
    java.util.List<com.mediaymedia.gdata.model.CalendarioEntry> genVar69;
    genVar69=calendarioService.dameEventosCalendario(googleProperties);
    return genVar69;
  }
}
