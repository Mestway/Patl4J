package com.mediaymedia.seam.google;
public class GDataSeam {
}
