package goofs;
public class GoofsProperties {
  public static final GoofsProperties INSTANCE=new GoofsProperties();
  public String getProperty(  String string){
    return null;
  }
}
