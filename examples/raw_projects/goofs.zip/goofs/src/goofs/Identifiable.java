package goofs;
public interface Identifiable {
}
