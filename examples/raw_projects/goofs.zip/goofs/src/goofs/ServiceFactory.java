package goofs;
import goofs.calendar.ICalendar;
public class ServiceFactory {
  public static ICalendar getService(  Class<ICalendar> class1){
    return null;
  }
}
