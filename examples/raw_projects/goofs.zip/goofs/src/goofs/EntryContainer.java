package goofs;
public interface EntryContainer {
}
