package goofs.calendar;
import java.net.URL;
import java.util.Date;
import java.util.List;
import com.google.gdata.client.calendar.CalendarQuery;
import com.google.gdata.client.calendar.CalendarService;
import com.google.gdata.data.DateTime;
import com.google.gdata.data.ExtensionProfile;
import com.google.gdata.data.PlainTextConstruct;
import com.google.gdata.data.calendar.CalendarEntry;
import com.google.gdata.data.calendar.CalendarEventEntry;
import com.google.gdata.data.calendar.CalendarEventFeed;
import com.google.gdata.data.calendar.CalendarFeed;
import com.google.gdata.data.extensions.Reminder;
import com.google.gdata.data.extensions.Reminder.Method;
import com.google.gdata.util.AuthenticationException;
public class Calendar implements ICalendar {
  private static final String APP_NAME=null;
  protected CalendarService realService;
  public Calendar(  String userName,  String password) throws AuthenticationException {
    realService=new CalendarService(APP_NAME);
    realService.setUserCredentials(userName,password);
  }
  public CalendarService getRealService(){
    return realService;
  }
  public void acquireSessionTokens(  String username,  String password) throws AuthenticationException {
    Calendar genVar0;
    genVar0=this;
    com.google.gdata.client.calendar.CalendarService genVar1;
    genVar1=genVar0.getRealService();
    genVar1.setUserCredentials(username,password);
  }
  public List<CalendarEntry> getCalendars() throws Exception {
    java.lang.String genVar2;
    genVar2="http://www.google.com/calendar/feeds/default/allcalendars/full";
    URL feedUrl;
    feedUrl=new URL(genVar2);
    Calendar genVar3;
    genVar3=this;
    com.google.gdata.client.calendar.CalendarService genVar4;
    genVar4=genVar3.getRealService();
    java.lang.Class<com.google.gdata.data.calendar.CalendarFeed> genVar5;
    genVar5=CalendarFeed.class;
    CalendarFeed resultFeed;
    resultFeed=genVar4.getFeed(feedUrl,genVar5);
    java.util.List<com.google.gdata.data.calendar.CalendarEntry> genVar6;
    genVar6=resultFeed.getEntries();
    return genVar6;
  }
  protected String getCalendarId(  CalendarEntry entry){
    java.lang.String genVar7;
    genVar7=entry.getId();
    java.lang.String genVar8;
    genVar8="/";
    String[] parts;
    parts=genVar7.split(genVar8);
    int genVar9;
    genVar9=1;
    int genVar10;
    genVar10=parts.length - genVar9;
    java.lang.String genVar11;
    genVar11=parts[genVar10];
    return genVar11;
  }
  public CalendarEntry createCalendar(  String title) throws Exception {
    CalendarEntry calendar;
    calendar=new CalendarEntry();
    com.google.gdata.data.PlainTextConstruct genVar12;
    genVar12=new PlainTextConstruct(title);
    calendar.setTitle(genVar12);
    java.lang.String genVar13;
    genVar13="http://www.google.com/calendar/feeds/default/owncalendars/full";
    URL postUrl;
    postUrl=new URL(genVar13);
    Calendar genVar14;
    genVar14=this;
    com.google.gdata.client.calendar.CalendarService genVar15;
    genVar15=genVar14.getRealService();
    com.google.gdata.data.calendar.CalendarEntry genVar16;
    genVar16=genVar15.insert(postUrl,calendar);
    return genVar16;
  }
  public CalendarEntry getCalendarById(  String id) throws Exception {
    Calendar genVar17;
    genVar17=this;
    com.google.gdata.client.calendar.CalendarService genVar18;
    genVar18=genVar17.getRealService();
    java.net.URL genVar19;
    genVar19=new URL(id);
    java.lang.Class<com.google.gdata.data.calendar.CalendarEntry> genVar20;
    genVar20=CalendarEntry.class;
    com.google.gdata.data.calendar.CalendarEntry genVar21;
    genVar21=genVar18.getEntry(genVar19,genVar20);
    return genVar21;
  }
  public CalendarEventEntry getCalendarEventById(  String id) throws Exception {
    Calendar genVar22;
    genVar22=this;
    com.google.gdata.client.calendar.CalendarService genVar23;
    genVar23=genVar22.getRealService();
    java.net.URL genVar24;
    genVar24=new URL(id);
    java.lang.Class<com.google.gdata.data.calendar.CalendarEventEntry> genVar25;
    genVar25=CalendarEventEntry.class;
    com.google.gdata.data.calendar.CalendarEventEntry genVar26;
    genVar26=genVar23.getEntry(genVar24,genVar25);
    return genVar26;
  }
  public CalendarEntry updateCalendar(  String id,  CalendarEntry in) throws Exception {
    Calendar genVar27;
    genVar27=this;
    CalendarEntry current;
    current=genVar27.getCalendarById(id);
    com.google.gdata.data.TextConstruct genVar28;
    genVar28=in.getTitle();
    boolean genVar29;
    genVar29=genVar28 != null;
    if (genVar29) {
      com.google.gdata.data.TextConstruct genVar30;
      genVar30=in.getTitle();
      current.setTitle(genVar30);
    }
 else {
      ;
    }
    com.google.gdata.data.TextConstruct genVar31;
    genVar31=in.getSummary();
    boolean genVar32;
    genVar32=genVar31 != null;
    if (genVar32) {
      com.google.gdata.data.TextConstruct genVar33;
      genVar33=in.getSummary();
      current.setSummary(genVar33);
    }
 else {
      ;
    }
    com.google.gdata.data.calendar.AccessLevelProperty genVar34;
    genVar34=in.getAccessLevel();
    boolean genVar35;
    genVar35=genVar34 != null;
    if (genVar35) {
      com.google.gdata.data.calendar.AccessLevelProperty genVar36;
      genVar36=in.getAccessLevel();
      current.setAccessLevel(genVar36);
    }
 else {
      ;
    }
    com.google.gdata.data.calendar.ColorProperty genVar37;
    genVar37=in.getColor();
    boolean genVar38;
    genVar38=genVar37 != null;
    if (genVar38) {
      com.google.gdata.data.calendar.ColorProperty genVar39;
      genVar39=in.getColor();
      current.setColor(genVar39);
    }
 else {
      ;
    }
    com.google.gdata.data.calendar.CalendarEntry genVar40;
    genVar40=current.update();
    return genVar40;
  }
  public CalendarEventEntry updateCalendarEvent(  String id,  CalendarEventEntry in) throws Exception {
    Calendar genVar41;
    genVar41=this;
    CalendarEventEntry current;
    current=genVar41.getCalendarEventById(id);
    com.google.gdata.data.TextConstruct genVar42;
    genVar42=in.getTitle();
    boolean genVar43;
    genVar43=genVar42 != null;
    if (genVar43) {
      com.google.gdata.data.TextConstruct genVar44;
      genVar44=in.getTitle();
      current.setTitle(genVar44);
    }
 else {
      ;
    }
    com.google.gdata.data.TextConstruct genVar45;
    genVar45=in.getSummary();
    boolean genVar46;
    genVar46=genVar45 != null;
    if (genVar46) {
      com.google.gdata.data.TextConstruct genVar47;
      genVar47=in.getSummary();
      current.setSummary(genVar47);
    }
 else {
      ;
    }
    com.google.gdata.data.calendar.CalendarEventEntry genVar48;
    genVar48=current.update();
    return genVar48;
  }
  public void deleteCalendar(  String id) throws Exception {
    Calendar genVar49;
    genVar49=this;
    CalendarEntry current;
    current=genVar49.getCalendarById(id);
    current.delete();
  }
  public void deleteCalendarEvent(  String id) throws Exception {
    Calendar genVar50;
    genVar50=this;
    CalendarEventEntry current;
    current=genVar50.getCalendarEventById(id);
    current.delete();
  }
  public CalendarEntry subscribeToCalendar(  String id) throws Exception {
    CalendarEntry calendar;
    calendar=new CalendarEntry();
    calendar.setId(id);
    java.lang.String genVar51;
    genVar51="http://www.google.com/calendar/feeds/default/allcalendars/full";
    URL feedUrl;
    feedUrl=new URL(genVar51);
    Calendar genVar52;
    genVar52=this;
    com.google.gdata.client.calendar.CalendarService genVar53;
    genVar53=genVar52.getRealService();
    com.google.gdata.data.calendar.CalendarEntry genVar54;
    genVar54=genVar53.insert(feedUrl,calendar);
    return genVar54;
  }
  protected URL getCalendarEventUrl(  CalendarEntry cal) throws Exception {
    java.lang.String genVar55;
    genVar55="http://www.google.com/calendar/feeds/";
    Calendar genVar56;
    genVar56=this;
    java.lang.String genVar57;
    genVar57=genVar56.getCalendarId(cal);
    java.lang.String genVar58;
    genVar58="/private/full";
    java.lang.String genVar59;
    genVar59=genVar55 + genVar57 + genVar58;
    URL feedUrl;
    feedUrl=new URL(genVar59);
    return feedUrl;
  }
  public List<CalendarEventEntry> getEvents(  CalendarEntry cal) throws Exception {
    Calendar genVar60;
    genVar60=this;
    com.google.gdata.client.calendar.CalendarService genVar61;
    genVar61=genVar60.getRealService();
    Calendar genVar62;
    genVar62=this;
    java.net.URL genVar63;
    genVar63=genVar62.getCalendarEventUrl(cal);
    java.lang.Class<com.google.gdata.data.calendar.CalendarEventFeed> genVar64;
    genVar64=CalendarEventFeed.class;
    CalendarEventFeed feed;
    feed=genVar61.getFeed(genVar63,genVar64);
    java.util.List<com.google.gdata.data.calendar.CalendarEventEntry> genVar65;
    genVar65=feed.getEntries();
    return genVar65;
  }
  public List<CalendarEventEntry> getEvents(  CalendarEntry cal,  Date start,  Date end) throws Exception {
    Calendar genVar66;
    genVar66=this;
    java.net.URL genVar67;
    genVar67=genVar66.getCalendarEventUrl(cal);
    CalendarQuery q;
    q=new CalendarQuery(genVar67);
    DateTime min;
    min=new DateTime(start);
    boolean genVar68;
    genVar68=false;
    min.setDateOnly(genVar68);
    DateTime max;
    max=new DateTime(end);
    boolean genVar69;
    genVar69=false;
    max.setDateOnly(genVar69);
    q.setMinimumStartTime(min);
    q.setMaximumStartTime(max);
    Calendar genVar70;
    genVar70=this;
    com.google.gdata.client.calendar.CalendarService genVar71;
    genVar71=genVar70.getRealService();
    java.lang.Class<com.google.gdata.data.calendar.CalendarEventFeed> genVar72;
    genVar72=CalendarEventFeed.class;
    CalendarEventFeed feed;
    feed=genVar71.query(q,genVar72);
    java.util.List<com.google.gdata.data.calendar.CalendarEventEntry> genVar73;
    genVar73=feed.getEntries();
    return genVar73;
  }
  public List<CalendarEventEntry> getEvents(  CalendarEntry cal,  String query) throws Exception {
    Calendar genVar74;
    genVar74=this;
    java.net.URL genVar75;
    genVar75=genVar74.getCalendarEventUrl(cal);
    CalendarQuery q;
    q=new CalendarQuery(genVar75);
    q.setFullTextQuery(query);
    Calendar genVar76;
    genVar76=this;
    com.google.gdata.client.calendar.CalendarService genVar77;
    genVar77=genVar76.getRealService();
    java.lang.Class<com.google.gdata.data.calendar.CalendarEventFeed> genVar78;
    genVar78=CalendarEventFeed.class;
    CalendarEventFeed feed;
    feed=genVar77.query(q,genVar78);
    java.util.List<com.google.gdata.data.calendar.CalendarEventEntry> genVar79;
    genVar79=feed.getEntries();
    return genVar79;
  }
  public CalendarEventEntry createQuickEvent(  CalendarEntry cal,  String event) throws Exception {
    CalendarEventEntry e;
    e=new CalendarEventEntry();
    Reminder reminder;
    reminder=new Reminder();
    reminder.setMethod(Method.ALL);
    java.util.List<com.google.gdata.data.extensions.Reminder> genVar80;
    genVar80=e.getReminder();
    genVar80.add(reminder);
    com.google.gdata.data.PlainTextConstruct genVar81;
    genVar81=new PlainTextConstruct(event);
    e.setContent(genVar81);
    boolean genVar82;
    genVar82=true;
    e.setQuickAdd(genVar82);
    Calendar genVar83;
    genVar83=this;
    com.google.gdata.client.calendar.CalendarService genVar84;
    genVar84=genVar83.getRealService();
    Calendar genVar85;
    genVar85=this;
    java.net.URL genVar86;
    genVar86=genVar85.getCalendarEventUrl(cal);
    com.google.gdata.data.calendar.CalendarEventEntry genVar87;
    genVar87=genVar84.insert(genVar86,e);
    return genVar87;
  }
  public ExtensionProfile getExtensionProfile(){
    Calendar genVar88;
    genVar88=this;
    com.google.gdata.client.calendar.CalendarService genVar89;
    genVar89=genVar88.getRealService();
    com.google.gdata.data.ExtensionProfile genVar90;
    genVar90=genVar89.getExtensionProfile();
    return genVar90;
  }
}
