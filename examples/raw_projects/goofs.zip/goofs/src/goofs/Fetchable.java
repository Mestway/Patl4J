package goofs;
public interface Fetchable {
}
