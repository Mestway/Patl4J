package goofs;
public interface GoofsService {
}
