package goofs.fs.calendar;
import fuse.Errno;
import goofs.GoofsProperties;
import goofs.calendar.ICalendar;
import goofs.fs.Dir;
import goofs.fs.File;
import java.io.StringWriter;
import com.google.gdata.data.calendar.CalendarEventEntry;
import com.google.gdata.data.extensions.When;
import com.google.gdata.util.common.xml.XmlWriter;
public class CalendarEventWhenFile extends File {
  public CalendarEventWhenFile(  Dir parent,  CalendarEventEntry event) throws Exception {
    super(parent,GoofsProperties.INSTANCE.getProperty("goofs.calendar.when"),0777,"");
    CalendarEventWhenFile genVar132;
    genVar132=this;
    CalendarEventWhenFile genVar133;
    genVar133=this;
    java.lang.String genVar134;
    genVar134=genVar133.getWhen(event);
    byte[] genVar135;
    genVar135=genVar134.getBytes();
    genVar132.setContent(genVar135);
  }
  protected ICalendar getCalendarService(){
    CalendarEventWhenFile genVar136;
    genVar136=this;
    goofs.fs.Dir genVar137;
    genVar137=genVar136.getParent();
    goofs.fs.calendar.CalendarEventDir genVar138;
    genVar138=(CalendarEventDir)genVar137;
    CalendarEventDir genVar139;
    genVar139=(genVar138);
    goofs.calendar.ICalendar genVar140;
    genVar140=genVar139.getCalendarService();
    return genVar140;
  }
  protected String getWhen(  CalendarEventEntry event) throws Exception {
    StringWriter sw;
    sw=new StringWriter();
    XmlWriter writer;
    writer=new XmlWriter(sw);
    java.util.List<com.google.gdata.data.extensions.When> genVar141;
    genVar141=event.getTimes();
    boolean genVar142;
    genVar142=genVar141 != null;
    if (genVar142) {
      java.util.List<com.google.gdata.data.extensions.When> genVar143;
      genVar143=event.getTimes();
      for (      When w : genVar143) {
        CalendarEventWhenFile genVar144;
        genVar144=this;
        goofs.calendar.ICalendar genVar145;
        genVar145=genVar144.getCalendarService();
        com.google.gdata.data.ExtensionProfile genVar146;
        genVar146=genVar145.getExtensionProfile();
        w.generate(writer,genVar146);
      }
    }
 else {
      ;
    }
    java.lang.StringBuffer genVar147;
    genVar147=sw.getBuffer();
    String when;
    when=genVar147.toString();
    writer.close();
    return when;
  }
  @Override public int save(){
    return Errno.EROFS;
  }
  @Override public int delete(){
    return Errno.EROFS;
  }
  @Override public int rename(  Dir newParent,  String name){
    return Errno.EROFS;
  }
}
