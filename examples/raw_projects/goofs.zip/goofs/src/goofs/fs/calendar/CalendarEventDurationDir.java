package goofs.fs.calendar;
import fuse.Errno;
import goofs.EntryContainer;
import goofs.calendar.ICalendar;
import goofs.fs.Dir;
import goofs.fs.Node;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import com.google.gdata.data.calendar.CalendarEntry;
import com.google.gdata.data.calendar.CalendarEventEntry;
public class CalendarEventDurationDir extends Dir implements EntryContainer {
  protected Date start;
  protected Date end;
  protected Set<String> entryIds=new HashSet<String>();
  public CalendarEventDurationDir(  Dir parent,  String name,  CalendarEntry cal,  Date start,  Date end) throws Exception {
    super(parent,name,0777);
    CalendarEventDurationDir genVar368;
    genVar368=this;
    genVar368.setStart(start);
    CalendarEventDurationDir genVar369;
    genVar369=this;
    genVar369.setEnd(end);
    CalendarEventDurationDir genVar370;
    genVar370=this;
    goofs.calendar.ICalendar genVar371;
    genVar371=genVar370.getCalendarService();
    List<CalendarEventEntry> events;
    events=genVar371.getEvents(cal,start,end);
    for (    CalendarEventEntry event : events) {
      goofs.fs.calendar.CalendarEventDurationDir genVar372;
      genVar372=this;
      CalendarEventDir eventDir;
      eventDir=new CalendarEventDir(genVar372,event);
      CalendarEventDurationDir genVar373;
      genVar373=this;
      genVar373.add(eventDir);
      CalendarEventDurationDir genVar374;
      genVar374=this;
      java.util.Set<java.lang.String> genVar375;
      genVar375=genVar374.getEntryIds();
      com.google.gdata.data.Link genVar376;
      genVar376=event.getSelfLink();
      java.lang.String genVar377;
      genVar377=genVar376.getHref();
      genVar375.add(genVar377);
    }
  }
  public Set<String> getEntryIds(){
    return entryIds;
  }
  public void addNewEntryById(  String entryId) throws Exception {
    CalendarEventDurationDir genVar378;
    genVar378=this;
    goofs.calendar.ICalendar genVar379;
    genVar379=genVar378.getCalendarService();
    CalendarEventEntry event;
    event=genVar379.getCalendarEventById(entryId);
    goofs.fs.calendar.CalendarEventDurationDir genVar380;
    genVar380=this;
    CalendarEventDir eventDir;
    eventDir=new CalendarEventDir(genVar380,event);
    CalendarEventDurationDir genVar381;
    genVar381=this;
    genVar381.add(eventDir);
    CalendarEventDurationDir genVar382;
    genVar382=this;
    java.util.Set<java.lang.String> genVar383;
    genVar383=genVar382.getEntryIds();
    com.google.gdata.data.Link genVar384;
    genVar384=event.getSelfLink();
    java.lang.String genVar385;
    genVar385=genVar384.getHref();
    genVar383.add(genVar385);
  }
  public Set<String> getCurrentEntryIds() throws Exception {
    Set<String> ids;
    ids=new HashSet<String>();
    CalendarEventDurationDir genVar386;
    genVar386=this;
    goofs.calendar.ICalendar genVar387;
    genVar387=genVar386.getCalendarService();
    CalendarEventDurationDir genVar388;
    genVar388=this;
    com.google.gdata.data.calendar.CalendarEntry genVar389;
    genVar389=genVar388.getCalendar();
    List<CalendarEventEntry> events;
    events=genVar387.getEvents(genVar389,start,end);
    for (    CalendarEventEntry event : events) {
      com.google.gdata.data.Link genVar390;
      genVar390=event.getSelfLink();
      java.lang.String genVar391;
      genVar391=genVar390.getHref();
      ids.add(genVar391);
    }
    return ids;
  }
  protected ICalendar getCalendarService(){
    CalendarEventDurationDir genVar392;
    genVar392=this;
    goofs.fs.Dir genVar393;
    genVar393=genVar392.getParent();
    goofs.fs.Dir genVar394;
    genVar394=genVar393.getParent();
    goofs.fs.calendar.CalendarsDir genVar395;
    genVar395=(CalendarsDir)genVar394;
    CalendarsDir genVar396;
    genVar396=(genVar395);
    goofs.calendar.ICalendar genVar397;
    genVar397=genVar396.getCalendarService();
    return genVar397;
  }
  protected CalendarEntry getCalendar() throws Exception {
    CalendarEventDurationDir genVar398;
    genVar398=this;
    goofs.fs.Dir genVar399;
    genVar399=genVar398.getParent();
    goofs.fs.calendar.CalendarDir genVar400;
    genVar400=(CalendarDir)genVar399;
    CalendarDir genVar401;
    genVar401=(genVar400);
    com.google.gdata.data.calendar.CalendarEntry genVar402;
    genVar402=genVar401.getCalendar();
    return genVar402;
  }
  protected Date getStart(){
    return start;
  }
  protected void setStart(  Date start){
    goofs.fs.calendar.CalendarEventDurationDir genVar403;
    genVar403=this;
    genVar403.start=start;
  }
  protected Date getEnd(){
    return end;
  }
  protected void setEnd(  Date end){
    goofs.fs.calendar.CalendarEventDurationDir genVar404;
    genVar404=this;
    genVar404.end=end;
  }
  @Override public int createChild(  String name,  boolean isDir){
    return Errno.EROFS;
  }
  @Override public int createChildFromExisting(  String name,  Node child){
    return Errno.EROFS;
  }
  @Override public int createTempChild(  String name){
    return Errno.EROFS;
  }
  @Override public int delete(){
    CalendarEventDurationDir genVar405;
    genVar405=this;
    genVar405.remove();
    int genVar406;
    genVar406=0;
    return genVar406;
  }
  @Override public int rename(  Dir newParent,  String name){
    CalendarEventDurationDir genVar407;
    genVar407=this;
    goofs.fs.Dir genVar408;
    genVar408=genVar407.getParent();
    boolean genVar409;
    genVar409=genVar408 == newParent;
    if (genVar409) {
      goofs.fs.calendar.CalendarDir genVar410;
      genVar410=(CalendarDir)parent;
      CalendarDir genVar411;
      genVar411=(genVar410);
      boolean genVar412;
      genVar412=true;
      genVar411.createChild(name,genVar412);
      CalendarEventDurationDir genVar413;
      genVar413=this;
      genVar413.remove();
    }
 else {
      ;
    }
    int genVar414;
    genVar414=0;
    return genVar414;
  }
}
