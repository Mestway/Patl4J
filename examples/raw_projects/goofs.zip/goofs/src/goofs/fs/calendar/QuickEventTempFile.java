package goofs.fs.calendar;
import com.google.gdata.data.calendar.CalendarEntry;
import goofs.calendar.ICalendar;
import goofs.fs.Dir;
import goofs.fs.SimpleFile;
public class QuickEventTempFile extends SimpleFile {
  public QuickEventTempFile(  Dir parent,  String name) throws Exception {
    super(parent,name);
  }
  protected ICalendar getCalendarService(){
    QuickEventTempFile genVar99;
    genVar99=this;
    goofs.fs.Dir genVar100;
    genVar100=genVar99.getParent();
    goofs.fs.Dir genVar101;
    genVar101=genVar100.getParent();
    goofs.fs.calendar.CalendarsDir genVar102;
    genVar102=(CalendarsDir)genVar101;
    CalendarsDir genVar103;
    genVar103=(genVar102);
    goofs.calendar.ICalendar genVar104;
    genVar104=genVar103.getCalendarService();
    return genVar104;
  }
  protected CalendarEntry getCalendar() throws Exception {
    QuickEventTempFile genVar105;
    genVar105=this;
    goofs.fs.Dir genVar106;
    genVar106=genVar105.getParent();
    goofs.fs.calendar.CalendarDir genVar107;
    genVar107=(CalendarDir)genVar106;
    CalendarDir genVar108;
    genVar108=(genVar107);
    com.google.gdata.data.calendar.CalendarEntry genVar109;
    genVar109=genVar108.getCalendar();
    return genVar109;
  }
  @Override public int rename(  Dir newParent,  String name){
    int rt;
    rt=super.rename(newParent,name);
    java.lang.String genVar110;
    genVar110="quick";
    QuickEventTempFile genVar111;
    genVar111=this;
    java.lang.String genVar112;
    genVar112=genVar111.getName();
    boolean genVar113;
    genVar113=genVar110.equals(genVar112);
    if (genVar113) {
      try {
        QuickEventTempFile genVar114;
        genVar114=this;
        goofs.calendar.ICalendar genVar115;
        genVar115=genVar114.getCalendarService();
        QuickEventTempFile genVar116;
        genVar116=this;
        com.google.gdata.data.calendar.CalendarEntry genVar117;
        genVar117=genVar116.getCalendar();
        QuickEventTempFile genVar118;
        genVar118=this;
        java.lang.String genVar119;
        genVar119=genVar118.getContent();
        java.lang.String genVar120;
        genVar120=new String(genVar119);
        genVar115.createQuickEvent(genVar117,genVar120);
        QuickEventTempFile genVar121;
        genVar121=this;
        genVar121.remove();
      }
 catch (      Exception e) {
        e.printStackTrace();
      }
      int genVar122;
      genVar122=0;
      return genVar122;
    }
 else {
      ;
    }
    return rt;
  }
}
