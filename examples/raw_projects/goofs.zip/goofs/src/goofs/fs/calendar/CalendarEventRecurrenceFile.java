package goofs.fs.calendar;
import fuse.Errno;
import goofs.GoofsProperties;
import goofs.calendar.ICalendar;
import goofs.fs.Dir;
import goofs.fs.File;
import java.io.StringWriter;
import com.google.gdata.data.calendar.CalendarEventEntry;
import com.google.gdata.util.common.xml.XmlWriter;
public class CalendarEventRecurrenceFile extends File {
  public CalendarEventRecurrenceFile(  Dir parent,  CalendarEventEntry event) throws Exception {
    super(parent,GoofsProperties.INSTANCE.getProperty("goofs.calendar.recurrence"),0777,"");
    CalendarEventRecurrenceFile genVar152;
    genVar152=this;
    CalendarEventRecurrenceFile genVar153;
    genVar153=this;
    java.lang.String genVar154;
    genVar154=genVar153.getRecurrence(event);
    byte[] genVar155;
    genVar155=genVar154.getBytes();
    genVar152.setContent(genVar155);
  }
  protected ICalendar getCalendarService(){
    CalendarEventRecurrenceFile genVar156;
    genVar156=this;
    goofs.fs.Dir genVar157;
    genVar157=genVar156.getParent();
    goofs.fs.calendar.CalendarEventDir genVar158;
    genVar158=(CalendarEventDir)genVar157;
    CalendarEventDir genVar159;
    genVar159=(genVar158);
    goofs.calendar.ICalendar genVar160;
    genVar160=genVar159.getCalendarService();
    return genVar160;
  }
  protected String getRecurrence(  CalendarEventEntry event) throws Exception {
    StringWriter sw;
    sw=new StringWriter();
    XmlWriter writer;
    writer=new XmlWriter(sw);
    com.google.gdata.data.extensions.Recurrence genVar161;
    genVar161=event.getRecurrence();
    boolean genVar162;
    genVar162=genVar161 != null;
    if (genVar162) {
      com.google.gdata.data.extensions.Recurrence genVar163;
      genVar163=event.getRecurrence();
      CalendarEventRecurrenceFile genVar164;
      genVar164=this;
      goofs.calendar.ICalendar genVar165;
      genVar165=genVar164.getCalendarService();
      com.google.gdata.data.ExtensionProfile genVar166;
      genVar166=genVar165.getExtensionProfile();
      genVar163.generate(writer,genVar166);
    }
 else {
      ;
    }
    java.lang.StringBuffer genVar167;
    genVar167=sw.getBuffer();
    String when;
    when=genVar167.toString();
    writer.close();
    return when;
  }
  @Override public int save(){
    return Errno.EROFS;
  }
  @Override public int delete(){
    return Errno.EROFS;
  }
  @Override public int rename(  Dir newParent,  String name){
    return Errno.EROFS;
  }
}
