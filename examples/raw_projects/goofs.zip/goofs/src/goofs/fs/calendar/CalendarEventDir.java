package goofs.fs.calendar;
import fuse.Errno;
import goofs.Fetchable;
import goofs.Identifiable;
import goofs.calendar.ICalendar;
import goofs.fs.Dir;
import goofs.fs.Node;
import com.google.gdata.data.PlainTextConstruct;
import com.google.gdata.data.calendar.CalendarEventEntry;
public class CalendarEventDir extends Dir implements Identifiable, Fetchable {
  protected String calendarEventId;
  public CalendarEventDir(  Dir parent,  CalendarEventEntry event) throws Exception {
    super(parent,event.getTitle().getPlainText(),0777);
    CalendarEventDir genVar418;
    genVar418=this;
    com.google.gdata.data.Link genVar419;
    genVar419=event.getSelfLink();
    java.lang.String genVar420;
    genVar420=genVar419.getHref();
    genVar418.setCalendarEventId(genVar420);
    java.util.List<com.google.gdata.data.extensions.When> genVar421;
    genVar421=event.getTimes();
    boolean genVar422;
    genVar422=genVar421 != null;
    java.util.List<com.google.gdata.data.extensions.When> genVar423;
    genVar423=event.getTimes();
    boolean genVar424;
    genVar424=genVar423.isEmpty();
    boolean genVar425;
    genVar425=!genVar424;
    boolean genVar426;
    genVar426=genVar422 && genVar425;
    if (genVar426) {
      CalendarEventDir genVar427;
      genVar427=this;
      goofs.fs.calendar.CalendarEventDir genVar428;
      genVar428=this;
      goofs.fs.calendar.CalendarEventWhenFile genVar429;
      genVar429=new CalendarEventWhenFile(genVar428,event);
      genVar427.add(genVar429);
    }
 else {
      ;
    }
    com.google.gdata.data.extensions.Recurrence genVar430;
    genVar430=event.getRecurrence();
    boolean genVar431;
    genVar431=genVar430 != null;
    if (genVar431) {
      CalendarEventDir genVar432;
      genVar432=this;
      goofs.fs.calendar.CalendarEventDir genVar433;
      genVar433=this;
      goofs.fs.calendar.CalendarEventRecurrenceFile genVar434;
      genVar434=new CalendarEventRecurrenceFile(genVar433,event);
      genVar432.add(genVar434);
    }
 else {
      ;
    }
    java.util.List<com.google.gdata.data.extensions.Where> genVar435;
    genVar435=event.getLocations();
    boolean genVar436;
    genVar436=genVar435 != null;
    if (genVar436) {
      CalendarEventDir genVar437;
      genVar437=this;
      goofs.fs.calendar.CalendarEventDir genVar438;
      genVar438=this;
      goofs.fs.calendar.CalendarEventWhereFile genVar439;
      genVar439=new CalendarEventWhereFile(genVar438,event);
      genVar437.add(genVar439);
    }
 else {
      ;
    }
    com.google.gdata.data.TextConstruct genVar440;
    genVar440=event.getSummary();
    boolean genVar441;
    genVar441=genVar440 != null;
    if (genVar441) {
      CalendarEventDir genVar442;
      genVar442=this;
      goofs.fs.calendar.CalendarEventDir genVar443;
      genVar443=this;
      goofs.fs.calendar.CalendarEventSummaryFile genVar444;
      genVar444=new CalendarEventSummaryFile(genVar443,event);
      genVar442.add(genVar444);
    }
 else {
      ;
    }
  }
  private void add(  CalendarEventSummaryFile calendarEventSummaryFile){
  }
  private void add(  CalendarEventWhereFile calendarEventWhereFile){
  }
  private void add(  CalendarEventRecurrenceFile calendarEventRecurrenceFile){
  }
  private void add(  CalendarEventWhenFile calendarEventWhenFile){
  }
  public String getId(){
    CalendarEventDir genVar445;
    genVar445=this;
    java.lang.String genVar446;
    genVar446=genVar445.getCalendarEventId();
    return genVar446;
  }
  public Object fetch() throws Exception {
    CalendarEventDir genVar447;
    genVar447=this;
    com.google.gdata.data.calendar.CalendarEventEntry genVar448;
    genVar448=genVar447.getCalendarEvent();
    return genVar448;
  }
  protected CalendarEventEntry getCalendarEvent() throws Exception {
    CalendarEventDir genVar449;
    genVar449=this;
    goofs.calendar.ICalendar genVar450;
    genVar450=genVar449.getCalendarService();
    CalendarEventDir genVar451;
    genVar451=this;
    java.lang.String genVar452;
    genVar452=genVar451.getCalendarEventId();
    com.google.gdata.data.calendar.CalendarEventEntry genVar453;
    genVar453=genVar450.getCalendarEventById(genVar452);
    return genVar453;
  }
  protected ICalendar getCalendarService(){
    CalendarEventDir genVar454;
    genVar454=this;
    goofs.fs.Dir genVar455;
    genVar455=genVar454.getParent();
    goofs.fs.Dir genVar456;
    genVar456=genVar455.getParent();
    goofs.fs.Dir genVar457;
    genVar457=genVar456.getParent();
    goofs.fs.calendar.CalendarsDir genVar458;
    genVar458=(CalendarsDir)genVar457;
    CalendarsDir genVar459;
    genVar459=(genVar458);
    goofs.calendar.ICalendar genVar460;
    genVar460=genVar459.getCalendarService();
    return genVar460;
  }
  protected String getCalendarEventId(){
    return calendarEventId;
  }
  protected void setCalendarEventId(  String calendarEventId){
    goofs.fs.calendar.CalendarEventDir genVar461;
    genVar461=this;
    genVar461.calendarEventId=calendarEventId;
  }
  @Override public int createChild(  String name,  boolean isDir){
    return Errno.EROFS;
  }
  @Override public int createChildFromExisting(  String name,  Node child){
    return Errno.EROFS;
  }
  @Override public int createTempChild(  String name){
    return Errno.EROFS;
  }
  @Override public int delete(){
    try {
      CalendarEventDir genVar462;
      genVar462=this;
      goofs.calendar.ICalendar genVar463;
      genVar463=genVar462.getCalendarService();
      CalendarEventDir genVar464;
      genVar464=this;
      java.lang.String genVar465;
      genVar465=genVar464.getCalendarEventId();
      genVar463.deleteCalendarEvent(genVar465);
      CalendarEventDir genVar466;
      genVar466=this;
      genVar466.remove();
      int genVar467;
      genVar467=0;
      return genVar467;
    }
 catch (    Exception e) {
      e.printStackTrace();
    }
    return Errno.EROFS;
  }
  @Override public int rename(  Dir newParent,  String name){
    CalendarEventDir genVar468;
    genVar468=this;
    goofs.fs.Dir genVar469;
    genVar469=genVar468.getParent();
    boolean genVar470;
    genVar470=genVar469 == newParent;
    if (genVar470) {
      try {
        CalendarEventEntry e;
        e=new CalendarEventEntry();
        com.google.gdata.data.PlainTextConstruct genVar471;
        genVar471=new PlainTextConstruct(name);
        e.setTitle(genVar471);
        CalendarEventDir genVar472;
        genVar472=this;
        goofs.calendar.ICalendar genVar473;
        genVar473=genVar472.getCalendarService();
        CalendarEventDir genVar474;
        genVar474=this;
        java.lang.String genVar475;
        genVar475=genVar474.getCalendarEventId();
        genVar473.updateCalendarEvent(genVar475,e);
        CalendarEventDir genVar476;
        genVar476=this;
        genVar476.setName(name);
        int genVar477;
        genVar477=0;
        return genVar477;
      }
 catch (      Exception e) {
        e.printStackTrace();
      }
    }
 else {
      ;
    }
    return Errno.EROFS;
  }
}
