package goofs.fs.calendar;
import fuse.Errno;
import goofs.Fetchable;
import goofs.GoofsProperties;
import goofs.Identifiable;
import goofs.calendar.ICalendar;
import goofs.fs.Dir;
import goofs.fs.Node;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import com.google.gdata.data.PlainTextConstruct;
import com.google.gdata.data.calendar.CalendarEntry;
public class CalendarDir extends Dir implements Identifiable, Fetchable {
  protected String calendarId;
  protected static final DateFormat DF=new SimpleDateFormat("yyyyMMdd");
  public CalendarDir(  Dir parent,  CalendarEntry cal) throws Exception {
    super(parent,cal.getTitle().getPlainText(),0777);
    CalendarDir genVar259;
    genVar259=this;
    com.google.gdata.data.Link genVar260;
    genVar260=cal.getSelfLink();
    java.lang.String genVar261;
    genVar261=genVar260.getHref();
    genVar259.setCalendarId(genVar261);
    java.util.Calendar start;
    start=java.util.Calendar.getInstance();
    java.util.Calendar end;
    end=java.util.Calendar.getInstance();
    int genVar262;
    genVar262=23;
    end.set(java.util.Calendar.HOUR_OF_DAY,genVar262);
    int genVar263;
    genVar263=59;
    end.set(java.util.Calendar.MINUTE,genVar263);
    int genVar264;
    genVar264=59;
    end.set(java.util.Calendar.SECOND,genVar264);
    int genVar265;
    genVar265=999;
    end.set(java.util.Calendar.MILLISECOND,genVar265);
    goofs.fs.calendar.CalendarDir genVar266;
    genVar266=this;
    java.lang.String genVar267;
    genVar267="goofs.calendar.today";
    java.lang.String genVar268;
    genVar268=GoofsProperties.INSTANCE.getProperty(genVar267);
    java.util.Date genVar269;
    genVar269=start.getTime();
    java.util.Date genVar270;
    genVar270=end.getTime();
    CalendarEventDurationDir next;
    next=new CalendarEventDurationDir(genVar266,genVar268,cal,genVar269,genVar270);
    CalendarDir genVar271;
    genVar271=this;
    genVar271.add(next);
    java.util.Date genVar272;
    genVar272=end.getTime();
    start.setTime(genVar272);
    int genVar273;
    genVar273=6;
    end.add(java.util.Calendar.DATE,genVar273);
    goofs.fs.calendar.CalendarDir genVar274;
    genVar274=this;
    java.lang.String genVar275;
    genVar275="goofs.calendar.next7";
    java.lang.String genVar276;
    genVar276=GoofsProperties.INSTANCE.getProperty(genVar275);
    java.util.Date genVar277;
    genVar277=start.getTime();
    java.util.Date genVar278;
    genVar278=end.getTime();
    next=new CalendarEventDurationDir(genVar274,genVar276,cal,genVar277,genVar278);
    CalendarDir genVar279;
    genVar279=this;
    genVar279.add(next);
    java.util.Date genVar280;
    genVar280=end.getTime();
    start.setTime(genVar280);
    int genVar281;
    genVar281=23;
    end.add(java.util.Calendar.DATE,genVar281);
    goofs.fs.calendar.CalendarDir genVar282;
    genVar282=this;
    java.lang.String genVar283;
    genVar283="goofs.calendar.next30";
    java.lang.String genVar284;
    genVar284=GoofsProperties.INSTANCE.getProperty(genVar283);
    java.util.Date genVar285;
    genVar285=start.getTime();
    java.util.Date genVar286;
    genVar286=end.getTime();
    next=new CalendarEventDurationDir(genVar282,genVar284,cal,genVar285,genVar286);
    CalendarDir genVar287;
    genVar287=this;
    genVar287.add(next);
  }
  public Object fetch() throws Exception {
    CalendarDir genVar288;
    genVar288=this;
    com.google.gdata.data.calendar.CalendarEntry genVar289;
    genVar289=genVar288.getCalendar();
    return genVar289;
  }
  public String getId(){
    CalendarDir genVar290;
    genVar290=this;
    java.lang.String genVar291;
    genVar291=genVar290.getCalendarId();
    return genVar291;
  }
  protected ICalendar getCalendarService(){
    CalendarDir genVar292;
    genVar292=this;
    goofs.fs.Dir genVar293;
    genVar293=genVar292.getParent();
    goofs.fs.calendar.CalendarsDir genVar294;
    genVar294=(CalendarsDir)genVar293;
    CalendarsDir genVar295;
    genVar295=(genVar294);
    goofs.calendar.ICalendar genVar296;
    genVar296=genVar295.getCalendarService();
    return genVar296;
  }
  protected CalendarEntry getCalendar() throws Exception {
    CalendarDir genVar297;
    genVar297=this;
    goofs.calendar.ICalendar genVar298;
    genVar298=genVar297.getCalendarService();
    CalendarDir genVar299;
    genVar299=this;
    java.lang.String genVar300;
    genVar300=genVar299.getCalendarId();
    com.google.gdata.data.calendar.CalendarEntry genVar301;
    genVar301=genVar298.getCalendarById(genVar300);
    return genVar301;
  }
  protected String getCalendarId(){
    return calendarId;
  }
  protected void setCalendarId(  String calendarId){
    goofs.fs.calendar.CalendarDir genVar302;
    genVar302=this;
    genVar302.calendarId=calendarId;
  }
  @Override public int createChild(  String name,  boolean isDir){
    boolean genVar303;
    genVar303=!isDir;
    java.lang.String genVar304;
    genVar304="quick";
    boolean genVar305;
    genVar305=genVar304.equals(name);
    boolean genVar306;
    genVar306=genVar303 && genVar305;
    if (genVar306) {
      try {
        CalendarDir genVar307;
        genVar307=this;
        goofs.fs.calendar.CalendarDir genVar308;
        genVar308=this;
        goofs.fs.calendar.QuickEventFile genVar309;
        genVar309=new QuickEventFile(genVar308,name);
        genVar307.add(genVar309);
        int genVar310;
        genVar310=0;
        return genVar310;
      }
 catch (      Exception e) {
        e.printStackTrace();
      }
    }
 else {
      if (isDir) {
        int genVar311;
        genVar311=name.length();
        int genVar312;
        genVar312=17;
        boolean genVar313;
        genVar313=genVar311 == genVar312;
        char genVar314;
        genVar314='-';
        int genVar315;
        genVar315=name.indexOf(genVar314);
        int genVar316;
        genVar316=8;
        boolean genVar317;
        genVar317=genVar315 == genVar316;
        boolean genVar318;
        genVar318=genVar313 && genVar317;
        if (genVar318) {
          try {
            int genVar319;
            genVar319=0;
            int genVar320;
            genVar320=8;
            String s1;
            s1=name.substring(genVar319,genVar320);
            int genVar321;
            genVar321=9;
            int genVar322;
            genVar322=17;
            String s2;
            s2=name.substring(genVar321,genVar322);
            java.util.Calendar start;
            start=java.util.Calendar.getInstance();
            java.util.Calendar end;
            end=java.util.Calendar.getInstance();
            java.util.Date genVar323;
            genVar323=DF.parse(s1);
            start.setTime(genVar323);
            java.util.Date genVar324;
            genVar324=DF.parse(s2);
            end.setTime(genVar324);
            int genVar325;
            genVar325=0;
            start.set(java.util.Calendar.HOUR_OF_DAY,genVar325);
            int genVar326;
            genVar326=0;
            start.set(java.util.Calendar.MINUTE,genVar326);
            int genVar327;
            genVar327=0;
            start.set(java.util.Calendar.SECOND,genVar327);
            int genVar328;
            genVar328=0;
            start.set(java.util.Calendar.MILLISECOND,genVar328);
            int genVar329;
            genVar329=23;
            end.set(java.util.Calendar.HOUR_OF_DAY,genVar329);
            int genVar330;
            genVar330=59;
            end.set(java.util.Calendar.MINUTE,genVar330);
            int genVar331;
            genVar331=59;
            end.set(java.util.Calendar.SECOND,genVar331);
            int genVar332;
            genVar332=999;
            end.set(java.util.Calendar.MILLISECOND,genVar332);
            CalendarDir genVar333;
            genVar333=this;
            goofs.fs.calendar.CalendarDir genVar334;
            genVar334=this;
            CalendarDir genVar335;
            genVar335=this;
            com.google.gdata.data.calendar.CalendarEntry genVar336;
            genVar336=genVar335.getCalendar();
            java.util.Date genVar337;
            genVar337=start.getTime();
            java.util.Date genVar338;
            genVar338=end.getTime();
            goofs.fs.calendar.CalendarEventDurationDir genVar339;
            genVar339=new CalendarEventDurationDir(genVar334,name,genVar336,genVar337,genVar338);
            genVar333.add(genVar339);
            int genVar340;
            genVar340=0;
            return genVar340;
          }
 catch (          Exception e) {
            e.printStackTrace();
          }
        }
 else {
          ;
        }
        try {
          CalendarDir genVar341;
          genVar341=this;
          goofs.fs.calendar.CalendarDir genVar342;
          genVar342=this;
          CalendarDir genVar343;
          genVar343=this;
          com.google.gdata.data.calendar.CalendarEntry genVar344;
          genVar344=genVar343.getCalendar();
          goofs.fs.calendar.CalendarEventByTextDir genVar345;
          genVar345=new CalendarEventByTextDir(genVar342,name,genVar344);
          genVar341.add(genVar345);
          int genVar346;
          genVar346=0;
          return genVar346;
        }
 catch (        Exception e) {
          e.printStackTrace();
        }
      }
 else {
        ;
      }
    }
    return Errno.EROFS;
  }
  @Override public int createChildFromExisting(  String name,  Node child){
    return Errno.EROFS;
  }
  @Override public int createTempChild(  String name){
    try {
      CalendarDir genVar347;
      genVar347=this;
      goofs.fs.calendar.CalendarDir genVar348;
      genVar348=this;
      goofs.fs.calendar.QuickEventTempFile genVar349;
      genVar349=new QuickEventTempFile(genVar348,name);
      genVar347.add(genVar349);
      int genVar350;
      genVar350=0;
      return genVar350;
    }
 catch (    Exception e) {
      e.printStackTrace();
    }
    return Errno.EROFS;
  }
  @Override public int delete(){
    try {
      CalendarDir genVar351;
      genVar351=this;
      goofs.calendar.ICalendar genVar352;
      genVar352=genVar351.getCalendarService();
      CalendarDir genVar353;
      genVar353=this;
      java.lang.String genVar354;
      genVar354=genVar353.getCalendarId();
      genVar352.deleteCalendar(genVar354);
      CalendarDir genVar355;
      genVar355=this;
      genVar355.remove();
      int genVar356;
      genVar356=0;
      return genVar356;
    }
 catch (    Exception e) {
      e.printStackTrace();
    }
    return Errno.EROFS;
  }
  @Override public int rename(  Dir newParent,  String name){
    CalendarDir genVar357;
    genVar357=this;
    goofs.fs.Dir genVar358;
    genVar358=genVar357.getParent();
    boolean genVar359;
    genVar359=genVar358 == newParent;
    if (genVar359) {
      try {
        CalendarEntry c;
        c=new CalendarEntry();
        com.google.gdata.data.PlainTextConstruct genVar360;
        genVar360=new PlainTextConstruct(name);
        c.setTitle(genVar360);
        CalendarDir genVar361;
        genVar361=this;
        goofs.calendar.ICalendar genVar362;
        genVar362=genVar361.getCalendarService();
        CalendarDir genVar363;
        genVar363=this;
        java.lang.String genVar364;
        genVar364=genVar363.getCalendarId();
        genVar362.updateCalendar(genVar364,c);
        CalendarDir genVar365;
        genVar365=this;
        genVar365.setName(name);
        int genVar366;
        genVar366=0;
        return genVar366;
      }
 catch (      Exception e) {
        e.printStackTrace();
      }
    }
 else {
      ;
    }
    return Errno.EROFS;
  }
}
