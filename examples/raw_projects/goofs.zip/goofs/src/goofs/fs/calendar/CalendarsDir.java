package goofs.fs.calendar;
import fuse.Errno;
import goofs.EntryContainer;
import goofs.GoofsProperties;
import goofs.ServiceFactory;
import goofs.calendar.ICalendar;
import goofs.fs.Dir;
import goofs.fs.Node;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import com.google.gdata.data.calendar.CalendarEntry;
public class CalendarsDir extends Dir implements EntryContainer {
  private ICalendar calendarService;
  protected Set<String> entryIds=new HashSet<String>();
  public CalendarsDir(  Dir parent) throws Exception {
    super(parent,GoofsProperties.INSTANCE.getProperty("goofs.calendar.calendars"),0777);
    java.lang.Class<goofs.calendar.ICalendar> genVar481;
    genVar481=ICalendar.class;
    goofs.calendar.ICalendar genVar482;
    genVar482=ServiceFactory.getService(genVar481);
    calendarService=(ICalendar)genVar482;
    List<CalendarEntry> cals;
    cals=calendarService.getCalendars();
    for (    CalendarEntry e : cals) {
      goofs.fs.calendar.CalendarsDir genVar483;
      genVar483=this;
      CalendarDir dir;
      dir=new CalendarDir(genVar483,e);
      CalendarsDir genVar484;
      genVar484=this;
      genVar484.add(dir);
      CalendarsDir genVar485;
      genVar485=this;
      java.util.Set<java.lang.String> genVar486;
      genVar486=genVar485.getEntryIds();
      com.google.gdata.data.Link genVar487;
      genVar487=e.getSelfLink();
      java.lang.String genVar488;
      genVar488=genVar487.getHref();
      genVar486.add(genVar488);
    }
  }
  public Set<String> getEntryIds(){
    return entryIds;
  }
  public void addNewEntryById(  String entryId) throws Exception {
    CalendarsDir genVar489;
    genVar489=this;
    goofs.calendar.ICalendar genVar490;
    genVar490=genVar489.getCalendarService();
    CalendarEntry cal;
    cal=genVar490.getCalendarById(entryId);
    goofs.fs.calendar.CalendarsDir genVar491;
    genVar491=this;
    CalendarDir calDir;
    calDir=new CalendarDir(genVar491,cal);
    CalendarsDir genVar492;
    genVar492=this;
    genVar492.add(calDir);
    CalendarsDir genVar493;
    genVar493=this;
    java.util.Set<java.lang.String> genVar494;
    genVar494=genVar493.getEntryIds();
    com.google.gdata.data.Link genVar495;
    genVar495=cal.getSelfLink();
    java.lang.String genVar496;
    genVar496=genVar495.getHref();
    genVar494.add(genVar496);
  }
  public Set<String> getCurrentEntryIds() throws Exception {
    Set<String> ids;
    ids=new HashSet<String>();
    CalendarsDir genVar497;
    genVar497=this;
    goofs.calendar.ICalendar genVar498;
    genVar498=genVar497.getCalendarService();
    List<CalendarEntry> cals;
    cals=genVar498.getCalendars();
    for (    CalendarEntry e : cals) {
      com.google.gdata.data.Link genVar499;
      genVar499=e.getSelfLink();
      java.lang.String genVar500;
      genVar500=genVar499.getHref();
      ids.add(genVar500);
    }
    return ids;
  }
  protected ICalendar getCalendarService(){
    return calendarService;
  }
  protected void setCalendarService(  ICalendar calendarService){
    goofs.fs.calendar.CalendarsDir genVar501;
    genVar501=this;
    genVar501.calendarService=calendarService;
  }
  @Override public int createChild(  String name,  boolean isDir){
    return Errno.EROFS;
  }
  @Override public int createChildFromExisting(  String name,  Node child){
    return Errno.EROFS;
  }
  @Override public int createTempChild(  String name){
    return Errno.EROFS;
  }
  @Override public int delete(){
    return Errno.EROFS;
  }
  @Override public int rename(  Dir newParent,  String name){
    return Errno.EROFS;
  }
}
