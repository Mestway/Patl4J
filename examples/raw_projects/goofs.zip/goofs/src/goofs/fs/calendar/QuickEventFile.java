package goofs.fs.calendar;
import com.google.gdata.data.calendar.CalendarEntry;
import goofs.calendar.ICalendar;
import goofs.fs.Dir;
import goofs.fs.SimpleFile;
public class QuickEventFile extends SimpleFile {
  public QuickEventFile(  Dir parent,  String name) throws Exception {
    super(parent,name);
  }
  protected ICalendar getCalendarService(){
    QuickEventFile genVar188;
    genVar188=this;
    goofs.fs.Dir genVar189;
    genVar189=genVar188.getParent();
    goofs.fs.Dir genVar190;
    genVar190=genVar189.getParent();
    goofs.fs.calendar.CalendarsDir genVar191;
    genVar191=(CalendarsDir)genVar190;
    CalendarsDir genVar192;
    genVar192=(genVar191);
    goofs.calendar.ICalendar genVar193;
    genVar193=genVar192.getCalendarService();
    return genVar193;
  }
  protected CalendarEntry getCalendar() throws Exception {
    QuickEventFile genVar194;
    genVar194=this;
    goofs.fs.Dir genVar195;
    genVar195=genVar194.getParent();
    goofs.fs.calendar.CalendarDir genVar196;
    genVar196=(CalendarDir)genVar195;
    CalendarDir genVar197;
    genVar197=(genVar196);
    com.google.gdata.data.calendar.CalendarEntry genVar198;
    genVar198=genVar197.getCalendar();
    return genVar198;
  }
  @Override public int save(){
    try {
      QuickEventFile genVar199;
      genVar199=this;
      goofs.calendar.ICalendar genVar200;
      genVar200=genVar199.getCalendarService();
      QuickEventFile genVar201;
      genVar201=this;
      com.google.gdata.data.calendar.CalendarEntry genVar202;
      genVar202=genVar201.getCalendar();
      QuickEventFile genVar203;
      genVar203=this;
      java.lang.String genVar204;
      genVar204=genVar203.getContent();
      java.lang.String genVar205;
      genVar205=new String(genVar204);
      genVar200.createQuickEvent(genVar202,genVar205);
      QuickEventFile genVar206;
      genVar206=this;
      genVar206.remove();
    }
 catch (    Exception e) {
      e.printStackTrace();
    }
    int genVar207;
    genVar207=0;
    return genVar207;
  }
}
