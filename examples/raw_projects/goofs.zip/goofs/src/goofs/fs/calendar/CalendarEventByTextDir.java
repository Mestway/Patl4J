package goofs.fs.calendar;
import fuse.Errno;
import goofs.EntryContainer;
import goofs.calendar.ICalendar;
import goofs.fs.Dir;
import goofs.fs.Node;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import com.google.gdata.data.calendar.CalendarEntry;
import com.google.gdata.data.calendar.CalendarEventEntry;
public class CalendarEventByTextDir extends Dir implements EntryContainer {
  protected Set<String> entryIds=new HashSet<String>();
  private CalendarDir parent;
  public CalendarEventByTextDir(  Dir parent,  String name,  CalendarEntry cal) throws Exception {
    super(parent,name,0777);
    CalendarEventByTextDir genVar209;
    genVar209=this;
    goofs.calendar.ICalendar genVar210;
    genVar210=genVar209.getCalendarService();
    CalendarEventByTextDir genVar211;
    genVar211=this;
    java.lang.String genVar212;
    genVar212=genVar211.getName();
    List<CalendarEventEntry> events;
    events=genVar210.getEvents(cal,genVar212);
    for (    CalendarEventEntry event : events) {
      goofs.fs.calendar.CalendarEventByTextDir genVar213;
      genVar213=this;
      CalendarEventDir eventDir;
      eventDir=new CalendarEventDir(genVar213,event);
      CalendarEventByTextDir genVar214;
      genVar214=this;
      genVar214.add(eventDir);
      CalendarEventByTextDir genVar215;
      genVar215=this;
      java.util.Set<java.lang.String> genVar216;
      genVar216=genVar215.getEntryIds();
      com.google.gdata.data.Link genVar217;
      genVar217=event.getSelfLink();
      java.lang.String genVar218;
      genVar218=genVar217.getHref();
      genVar216.add(genVar218);
    }
  }
  public Set<String> getEntryIds(){
    return entryIds;
  }
  public void addNewEntryById(  String entryId) throws Exception {
    CalendarEventByTextDir genVar219;
    genVar219=this;
    goofs.calendar.ICalendar genVar220;
    genVar220=genVar219.getCalendarService();
    CalendarEventEntry event;
    event=genVar220.getCalendarEventById(entryId);
    goofs.fs.calendar.CalendarEventByTextDir genVar221;
    genVar221=this;
    CalendarEventDir eventDir;
    eventDir=new CalendarEventDir(genVar221,event);
    CalendarEventByTextDir genVar222;
    genVar222=this;
    genVar222.add(eventDir);
    CalendarEventByTextDir genVar223;
    genVar223=this;
    java.util.Set<java.lang.String> genVar224;
    genVar224=genVar223.getEntryIds();
    com.google.gdata.data.Link genVar225;
    genVar225=event.getSelfLink();
    java.lang.String genVar226;
    genVar226=genVar225.getHref();
    genVar224.add(genVar226);
  }
  public Set<String> getCurrentEntryIds() throws Exception {
    Set<String> ids;
    ids=new HashSet<String>();
    CalendarEventByTextDir genVar227;
    genVar227=this;
    goofs.calendar.ICalendar genVar228;
    genVar228=genVar227.getCalendarService();
    CalendarEventByTextDir genVar229;
    genVar229=this;
    com.google.gdata.data.calendar.CalendarEntry genVar230;
    genVar230=genVar229.getCalendar();
    CalendarEventByTextDir genVar231;
    genVar231=this;
    java.lang.String genVar232;
    genVar232=genVar231.getName();
    List<CalendarEventEntry> events;
    events=genVar228.getEvents(genVar230,genVar232);
    for (    CalendarEventEntry event : events) {
      com.google.gdata.data.Link genVar233;
      genVar233=event.getSelfLink();
      java.lang.String genVar234;
      genVar234=genVar233.getHref();
      ids.add(genVar234);
    }
    return ids;
  }
  protected ICalendar getCalendarService(){
    CalendarEventByTextDir genVar235;
    genVar235=this;
    goofs.fs.Dir genVar236;
    genVar236=genVar235.getParent();
    goofs.fs.Dir genVar237;
    genVar237=genVar236.getParent();
    goofs.fs.calendar.CalendarsDir genVar238;
    genVar238=(CalendarsDir)genVar237;
    CalendarsDir genVar239;
    genVar239=(genVar238);
    goofs.calendar.ICalendar genVar240;
    genVar240=genVar239.getCalendarService();
    return genVar240;
  }
  protected CalendarEntry getCalendar() throws Exception {
    CalendarEventByTextDir genVar241;
    genVar241=this;
    goofs.fs.Dir genVar242;
    genVar242=genVar241.getParent();
    goofs.fs.calendar.CalendarDir genVar243;
    genVar243=(CalendarDir)genVar242;
    CalendarDir genVar244;
    genVar244=(genVar243);
    com.google.gdata.data.calendar.CalendarEntry genVar245;
    genVar245=genVar244.getCalendar();
    return genVar245;
  }
  @Override public int createChild(  String name,  boolean isDir){
    return Errno.EROFS;
  }
  @Override public int createChildFromExisting(  String name,  Node child){
    return Errno.EROFS;
  }
  @Override public int createTempChild(  String name){
    return Errno.EROFS;
  }
  @Override public int delete(){
    CalendarEventByTextDir genVar246;
    genVar246=this;
    genVar246.remove();
    int genVar247;
    genVar247=0;
    return genVar247;
  }
  @Override public int rename(  Dir newParent,  String name){
    CalendarEventByTextDir genVar248;
    genVar248=this;
    goofs.fs.Dir genVar249;
    genVar249=genVar248.getParent();
    boolean genVar250;
    genVar250=genVar249 == newParent;
    if (genVar250) {
      goofs.fs.calendar.CalendarDir genVar251;
      genVar251=(CalendarDir)parent;
      CalendarDir genVar252;
      genVar252=(genVar251);
      boolean genVar253;
      genVar253=true;
      genVar252.createChild(name,genVar253);
      CalendarEventByTextDir genVar254;
      genVar254=this;
      genVar254.remove();
    }
 else {
      ;
    }
    int genVar255;
    genVar255=0;
    return genVar255;
  }
}
