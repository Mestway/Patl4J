package goofs.fs.calendar;
import fuse.Errno;
import goofs.GoofsProperties;
import goofs.calendar.ICalendar;
import goofs.fs.Dir;
import goofs.fs.File;
import java.io.StringWriter;
import com.google.gdata.data.calendar.CalendarEventEntry;
import com.google.gdata.data.extensions.Where;
import com.google.gdata.util.common.xml.XmlWriter;
public class CalendarEventWhereFile extends File {
  public CalendarEventWhereFile(  Dir parent,  CalendarEventEntry event) throws Exception {
    super(parent,GoofsProperties.INSTANCE.getProperty("goofs.calendar.where"),0777,"");
    CalendarEventWhereFile genVar172;
    genVar172=this;
    CalendarEventWhereFile genVar173;
    genVar173=this;
    java.lang.String genVar174;
    genVar174=genVar173.getWhere(event);
    byte[] genVar175;
    genVar175=genVar174.getBytes();
    genVar172.setContent(genVar175);
  }
  protected ICalendar getCalendarService(){
    CalendarEventWhereFile genVar176;
    genVar176=this;
    goofs.fs.Dir genVar177;
    genVar177=genVar176.getParent();
    goofs.fs.calendar.CalendarEventDir genVar178;
    genVar178=(CalendarEventDir)genVar177;
    CalendarEventDir genVar179;
    genVar179=(genVar178);
    goofs.calendar.ICalendar genVar180;
    genVar180=genVar179.getCalendarService();
    return genVar180;
  }
  protected String getWhere(  CalendarEventEntry event) throws Exception {
    StringWriter sw;
    sw=new StringWriter();
    XmlWriter writer;
    writer=new XmlWriter(sw);
    java.util.List<com.google.gdata.data.extensions.Where> genVar181;
    genVar181=event.getLocations();
    boolean genVar182;
    genVar182=genVar181 != null;
    if (genVar182) {
      java.util.List<com.google.gdata.data.extensions.Where> genVar183;
      genVar183=event.getLocations();
      for (      Where w : genVar183) {
        CalendarEventWhereFile genVar184;
        genVar184=this;
        goofs.calendar.ICalendar genVar185;
        genVar185=genVar184.getCalendarService();
        com.google.gdata.data.ExtensionProfile genVar186;
        genVar186=genVar185.getExtensionProfile();
        w.generate(writer,genVar186);
      }
    }
 else {
      ;
    }
    java.lang.StringBuffer genVar187;
    genVar187=sw.getBuffer();
    String when;
    when=genVar187.toString();
    writer.close();
    return when;
  }
  @Override public int save(){
    return Errno.EROFS;
  }
  @Override public int delete(){
    return Errno.EROFS;
  }
  @Override public int rename(  Dir newParent,  String name){
    return Errno.EROFS;
  }
}
