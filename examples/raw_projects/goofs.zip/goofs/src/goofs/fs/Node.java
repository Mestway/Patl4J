package goofs.fs;
public class Node {
}
