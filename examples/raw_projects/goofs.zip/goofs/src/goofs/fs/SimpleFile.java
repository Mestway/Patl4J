package goofs.fs;
public class SimpleFile extends File {
  public SimpleFile(  Dir parent,  String name){
  }
}
