package goofs.fs;
public class Dir extends Node {
  protected Dir parent;
  public Dir(  Dir parent,  String plainText,  int i){
  }
  public int createChild(  String name,  boolean isDir){
    int genVar91;
    genVar91=0;
    return genVar91;
  }
  public int createChildFromExisting(  String name,  Node child){
    int genVar92;
    genVar92=0;
    return genVar92;
  }
  public int createTempChild(  String name){
    int genVar93;
    genVar93=0;
    return genVar93;
  }
  public int delete(){
    int genVar94;
    genVar94=0;
    return genVar94;
  }
  public int rename(  Dir newParent,  String name){
    int genVar95;
    genVar95=0;
    return genVar95;
  }
  public void add(  SimpleFile simpleFile){
  }
  public void add(  Dir dir){
  }
  public Dir getParent(){
    return null;
  }
  public void remove(){
  }
  public String getName(){
    return null;
  }
  public void setName(  String name){
  }
}
