package goofs.fs;
public class File extends Node {
  public File(){
  }
  public File(  Dir parent,  String property,  int i,  String string){
  }
  public Dir getParent(){
    return null;
  }
  public int save(){
    int genVar96;
    genVar96=0;
    return genVar96;
  }
  public int delete(){
    int genVar97;
    genVar97=0;
    return genVar97;
  }
  public int rename(  Dir newParent,  String name){
    int genVar98;
    genVar98=0;
    return genVar98;
  }
  public void setContent(  byte[] bytes){
  }
  public void remove(){
  }
  protected String getContent(){
    return null;
  }
  public String getName(){
    return null;
  }
}
