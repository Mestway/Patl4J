package org.openfuxml.test.xml.jsfapp;
import net.sf.exlp.util.io.LoggerInit;
import net.sf.exlp.util.xml.JDomUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom2.Document;
import org.openfuxml.addon.jsfapp.factory.JsfJspxFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class TestJsfFactory {
  final static Logger logger=LoggerFactory.getLogger(TestJsfFactory.class);
  public TestJsfFactory(){
  }
  public void test(){
    Document doc;
    doc=JsfJspxFactory.createDOMjspx();
    JDomUtil.debug(doc);
  }
  public static void main(  String[] args) throws Exception {
    java.lang.String genVar1831;
    genVar1831="log4j.xml";
    LoggerInit loggerInit;
    loggerInit=new LoggerInit(genVar1831);
    java.lang.String genVar1832;
    genVar1832="resources/config";
    loggerInit.addAltPath(genVar1832);
    loggerInit.init();
    java.lang.String genVar1833;
    genVar1833="Testing Metatag";
    logger.debug(genVar1833);
    TestJsfFactory test;
    test=new TestJsfFactory();
    test.test();
  }
}
