package org.openfuxml.test.xml.wiki.processor;
import java.io.File;
import java.io.IOException;
import net.sf.exlp.util.config.ConfigLoader;
import net.sf.exlp.util.io.LoggerInit;
import net.sf.exlp.util.xml.JDomUtil;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom2.Document;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.openfuxml.addon.wiki.OfxWikiEngine;
import org.openfuxml.addon.wiki.processor.xhtml.mods.XhtmlAHxMerge;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class TextAHxMerge {
  final static Logger logger=LoggerFactory.getLogger(TextAHxMerge.class);
  public static enum Status {  txtFetched,   txtProcessed,   xhtmlRendered,   xhtmlProcessed,   xhtmlFinal,   ofx}
  private Configuration config;
  public TextAHxMerge(  Configuration config){
    org.openfuxml.test.xml.wiki.processor.TextAHxMerge genVar1872;
    genVar1872=this;
    genVar1872.config=config;
  }
  public Document merge(  Document doc){
    XhtmlAHxMerge merger;
    merger=new XhtmlAHxMerge();
    java.lang.String genVar1873;
    genVar1873="Beging merge ...";
    logger.debug(genVar1873);
    java.lang.String genVar1874;
    genVar1874=JDomUtil.docToTxt(doc);
    String txt;
    txt=merger.merge(genVar1874);
    java.lang.String genVar1875;
    genVar1875="End merge ...";
    logger.debug(genVar1875);
    try {
      doc=JDomUtil.txtToDoc(txt);
    }
 catch (    JDOMException e) {
      e.printStackTrace();
    }
    return doc;
  }
  public Document load(  String article){
    Document doc;
    doc=null;
    try {
      java.lang.String genVar1876;
      genVar1876="/ofx/dir[@type='wiki']";
      String dirWiki;
      dirWiki=config.getString(genVar1876);
      java.lang.String genVar1877;
      genVar1877="/";
      java.lang.String genVar1878;
      genVar1878="-";
      java.lang.String genVar1879;
      genVar1879=".xhtml";
      java.lang.String genVar1880;
      genVar1880=dirWiki + genVar1877 + article+ genVar1878+ OfxWikiEngine.Status.xhtmlFinal+ genVar1879;
      File f;
      f=new File(genVar1880);
      org.jdom2.input.SAXBuilder genVar1881;
      genVar1881=new SAXBuilder();
      doc=genVar1881.build(f);
    }
 catch (    JDOMException e) {
      java.lang.String genVar1882;
      genVar1882="";
      logger.error(genVar1882,e);
    }
catch (    IOException e) {
      java.lang.String genVar1883;
      genVar1883="";
      logger.error(genVar1883,e);
    }
    java.lang.String genVar1884;
    genVar1884="Doc loaded ...";
    logger.debug(genVar1884);
    return doc;
  }
  public static void main(  String[] args){
    java.lang.String genVar1885;
    genVar1885="log4j.xml";
    LoggerInit loggerInit;
    loggerInit=new LoggerInit(genVar1885);
    java.lang.String genVar1886;
    genVar1886="resources/config";
    loggerInit.addAltPath(genVar1886);
    loggerInit.init();
    java.lang.String genVar1887;
    genVar1887="resources/config/wiki/wiki.xml";
    ConfigLoader.add(genVar1887);
    Configuration config;
    config=ConfigLoader.init();
    java.lang.String genVar1888;
    genVar1888="Starting ...";
    logger.debug(genVar1888);
    TextAHxMerge testMerger;
    testMerger=new TextAHxMerge(config);
    java.lang.String genVar1889;
    genVar1889="Bellagio";
    Document doc;
    doc=testMerger.load(genVar1889);
    doc=testMerger.merge(doc);
    org.jdom2.Element genVar1890;
    genVar1890=doc.getRootElement();
    JDomUtil.debugElement(genVar1890);
  }
}
