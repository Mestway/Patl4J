package org.openfuxml.test;
import java.io.File;
public abstract class AbstractFileProcessingTest {
  public File fTest;
  public File fRef;
}
