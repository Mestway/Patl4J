package org.openfuxml.test;
public class OfxCoreTestBootstrap {
  public static void init(){
  }
}
