package org.openfuxml.test.renderer.html.table;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Collection;
import net.sf.exlp.util.io.LoggerInit;
import net.sf.exlp.util.xml.JDomUtil;
import net.sf.exlp.util.xml.JaxbUtil;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.openfuxml.content.table.Table;
import org.openfuxml.exception.OfxConfigurationException;
import org.openfuxml.exception.OfxInternalProcessingException;
import org.openfuxml.renderer.processor.html.interfaces.OfxTableRenderer;
import org.openfuxml.renderer.processor.html.table.DefaultTableRenderer;
import org.openfuxml.test.AbstractFileProcessingTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@RunWith(Parameterized.class) public class TestDefaultTableRenderer extends AbstractFileProcessingTest {
  final static Logger logger=LoggerFactory.getLogger(TestDefaultTableRenderer.class);
  private OfxTableRenderer renderer;
  public static String srcDirName="src/test/resources/data/html/table/ofx";
  public static final String dstDirName="src/test/resources/data/html/table/web";
  public TestDefaultTableRenderer(  File fTest){
    org.openfuxml.test.renderer.html.table.TestDefaultTableRenderer genVar1795;
    genVar1795=this;
    genVar1795.fTest=fTest;
    java.lang.String genVar1796;
    genVar1796=fTest.getName();
    int genVar1797;
    genVar1797=0;
    java.lang.String genVar1798;
    genVar1798=fTest.getName();
    int genVar1799;
    genVar1799=genVar1798.length();
    int genVar1800;
    genVar1800=4;
    int genVar1801;
    genVar1801=genVar1799 - genVar1800;
    String name;
    name=genVar1796.substring(genVar1797,genVar1801);
    java.lang.String genVar1802;
    genVar1802=".html";
    java.lang.String genVar1803;
    genVar1803=name + genVar1802;
    fRef=new File(dstDirName,genVar1803);
  }
  @Parameterized.Parameters public static Collection<Object[]> initFileNames(){
    java.lang.String genVar1805;
    genVar1805=".xml";
    java.util.Collection<java.lang.Object[]> genVar1806;
    genVar1806=TestDefaultTableRenderer.initFileNames(srcDirName,genVar1805);
    return genVar1806;
  }
  public static Collection<Object[]> initFileNames(  String srcDirName,  String suffix){
    return null;
  }
  @Before public void init() throws FileNotFoundException, OfxConfigurationException, OfxInternalProcessingException {
    renderer=new DefaultTableRenderer();
  }
  @After public void close(){
    renderer=null;
  }
  @Test public void render() throws OfxInternalProcessingException, FileNotFoundException {
    TestDefaultTableRenderer genVar1807;
    genVar1807=this;
    boolean genVar1808;
    genVar1808=false;
    genVar1807.render(genVar1808);
  }
  private void render(  boolean saveReference) throws FileNotFoundException {
    java.lang.String genVar1809;
    genVar1809=fTest.getAbsolutePath();
    logger.debug(genVar1809);
    java.lang.String genVar1810;
    genVar1810=fTest.getAbsolutePath();
    java.lang.Class<org.openfuxml.content.table.Table> genVar1811;
    genVar1811=Table.class;
    org.openfuxml.content.table.Table genVar1812;
    genVar1812=JaxbUtil.loadJAXB(genVar1810,genVar1811);
    Table table;
    table=(Table)genVar1812;
    java.lang.String genVar1813;
    genVar1813="html";
    Element html;
    html=new Element(genVar1813);
    java.lang.String genVar1814;
    genVar1814="body";
    Element body;
    body=new Element(genVar1814);
    org.jdom2.Element genVar1815;
    genVar1815=renderer.render(table);
    body.addContent(genVar1815);
    html.addContent(body);
    Document doc;
    doc=new Document();
    doc.setRootElement(html);
    if (saveReference) {
      org.jdom2.output.Format genVar1816;
      genVar1816=Format.getPrettyFormat();
      JDomUtil.save(doc,fRef,genVar1816);
    }
 else {
      Document docRef;
      docRef=JDomUtil.load(fRef);
      java.lang.String genVar1817;
      genVar1817=JDomUtil.toString(docRef);
      java.lang.String genVar1818;
      genVar1818=JDomUtil.toString(doc);
      Assert.assertEquals(genVar1817,genVar1818);
    }
  }
  public static void main(  String[] args) throws FileNotFoundException, OfxConfigurationException, OfxInternalProcessingException {
    java.lang.String genVar1819;
    genVar1819="log4j.xml";
    LoggerInit loggerInit;
    loggerInit=new LoggerInit(genVar1819);
    java.lang.String genVar1820;
    genVar1820="src/test/resources/config";
    loggerInit.addAltPath(genVar1820);
    loggerInit.init();
    boolean saveReference;
    saveReference=true;
    int genVar1821;
    genVar1821=1;
    int id;
    id=-genVar1821;
    int index;
    index=0;
    java.util.Collection<java.lang.Object[]> genVar1822;
    genVar1822=TestDefaultTableRenderer.initFileNames();
    for (    Object[] o : genVar1822) {
      int genVar1823;
      genVar1823=0;
      java.lang.Object genVar1824;
      genVar1824=o[genVar1823];
      File fTest;
      fTest=(File)genVar1824;
      TestDefaultTableRenderer test;
      test=new TestDefaultTableRenderer(fTest);
      test.init();
      java.lang.String genVar1825;
      genVar1825=" ";
      java.lang.String genVar1826;
      genVar1826=id + genVar1825 + index;
      logger.trace(genVar1826);
      int genVar1827;
      genVar1827=0;
      boolean genVar1828;
      genVar1828=id < genVar1827;
      boolean genVar1829;
      genVar1829=id == index;
      boolean genVar1830;
      genVar1830=genVar1828 | genVar1829;
      if (genVar1830) {
        test.render(saveReference);
      }
 else {
        ;
      }
      test.close();
      index++;
    }
  }
}
