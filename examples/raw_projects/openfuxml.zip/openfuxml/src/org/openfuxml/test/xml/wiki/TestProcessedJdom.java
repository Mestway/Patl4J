package org.openfuxml.test.xml.wiki;
import java.io.File;
import java.io.IOException;
import net.sf.exlp.util.config.ConfigLoader;
import net.sf.exlp.util.io.LoggerInit;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom2.Document;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.openfuxml.addon.wiki.OfxWikiEngine;
import org.openfuxml.addon.wiki.WikiTemplates;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class TestProcessedJdom {
  final static Logger logger=LoggerFactory.getLogger(TestProcessedJdom.class);
  private String dirName;
  private Configuration config;
  public TestProcessedJdom(  Configuration config,  String dirName){
    org.openfuxml.test.xml.wiki.TestProcessedJdom genVar1834;
    genVar1834=this;
    genVar1834.config=config;
    org.openfuxml.test.xml.wiki.TestProcessedJdom genVar1835;
    genVar1835=this;
    genVar1835.dirName=dirName;
  }
  private void testProcessedJdom(){
    java.lang.String genVar1836;
    genVar1836="wiki/article";
    String article;
    article=config.getString(genVar1836);
    Document doc;
    doc=null;
    try {
      java.lang.String genVar1837;
      genVar1837="dist/";
      java.lang.String genVar1838;
      genVar1838="-";
      java.lang.String genVar1839;
      genVar1839=".xhtml";
      java.lang.String genVar1840;
      genVar1840=genVar1837 + article + genVar1838+ OfxWikiEngine.Status.xhtmlProcessed+ genVar1839;
      File f;
      f=new File(genVar1840);
      org.jdom2.input.SAXBuilder genVar1841;
      genVar1841=new SAXBuilder();
      doc=genVar1841.build(f);
    }
 catch (    JDOMException e) {
      e.printStackTrace();
    }
catch (    IOException e) {
      java.lang.String genVar1842;
      genVar1842="";
      logger.error(genVar1842,e);
    }
  }
  public static void main(  String[] args){
    java.lang.String genVar1843;
    genVar1843="log4j.xml";
    LoggerInit loggerInit;
    loggerInit=new LoggerInit(genVar1843);
    java.lang.String genVar1844;
    genVar1844="resources/config";
    loggerInit.addAltPath(genVar1844);
    loggerInit.init();
    java.lang.String genVar1845;
    genVar1845="resources/config/wiki/wiki.xml";
    ConfigLoader.add(genVar1845);
    Configuration config;
    config=ConfigLoader.init();
    WikiTemplates.init();
    java.lang.String genVar1846;
    genVar1846="dist";
    TestProcessedJdom tw;
    tw=new TestProcessedJdom(config,genVar1846);
    tw.testProcessedJdom();
  }
}
