package org.openfuxml.test.addon.jsf;
import net.sf.exlp.util.io.LoggerInit;
import net.sf.exlp.util.xml.JDomUtil;
import net.sf.exlp.util.xml.JaxbUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom2.Document;
import org.openfuxml.addon.jsf.data.jaxb.JsfNsPrefixMapper;
import org.openfuxml.content.ofx.Emphasis;
import org.openfuxml.content.ofx.Paragraph;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class TestParagraph {
  final static Logger logger=LoggerFactory.getLogger(TestParagraph.class);
  public TestParagraph(){
  }
  public void xmlConstruct(){
    Paragraph p;
    p=new Paragraph();
    java.util.List<java.lang.Object> genVar1786;
    genVar1786=p.getContent();
    java.lang.String genVar1787;
    genVar1787="Test";
    genVar1786.add(genVar1787);
    Emphasis e;
    e=new Emphasis();
    boolean genVar1788;
    genVar1788=true;
    e.setBold(genVar1788);
    java.lang.String genVar1789;
    genVar1789="XX";
    e.setValue(genVar1789);
    java.util.List<java.lang.Object> genVar1790;
    genVar1790=p.getContent();
    genVar1790.add(e);
    Document doc;
    doc=JaxbUtil.toDocument(p);
    org.openfuxml.addon.jsf.data.jaxb.JsfNsPrefixMapper genVar1791;
    genVar1791=new JsfNsPrefixMapper();
    doc=JDomUtil.correctNsPrefixes(doc,genVar1791);
    JDomUtil.debug(doc);
  }
  public static void main(  String[] args) throws Exception {
    java.lang.String genVar1792;
    genVar1792="log4j.xml";
    LoggerInit loggerInit;
    loggerInit=new LoggerInit(genVar1792);
    java.lang.String genVar1793;
    genVar1793="resources/config";
    loggerInit.addAltPath(genVar1793);
    loggerInit.init();
    java.lang.String genVar1794;
    genVar1794="Testing XSD Taglib";
    logger.debug(genVar1794);
    TestParagraph test;
    test=new TestParagraph();
    test.xmlConstruct();
  }
}
