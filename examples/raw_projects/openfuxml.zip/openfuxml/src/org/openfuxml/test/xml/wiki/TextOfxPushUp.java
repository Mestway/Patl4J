package org.openfuxml.test.xml.wiki;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import net.sf.exlp.util.config.ConfigLoader;
import net.sf.exlp.util.io.LoggerInit;
import net.sf.exlp.util.xml.JDomUtil;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
import org.openfuxml.addon.wiki.OfxWikiEngine;
import org.openfuxml.addon.wiki.WikiTemplates;
import org.openfuxml.addon.wiki.processor.xhtml.mods.OfxPushUp;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class TextOfxPushUp {
  final static Logger logger=LoggerFactory.getLogger(TextOfxPushUp.class);
  public static enum Status {  txtFetched,   txtProcessed,   xhtmlRendered,   xhtmlProcessed,   xhtmlFinal,   ofx}
  private Configuration config;
  private String dirName;
  private Document doc;
  public TextOfxPushUp(  Configuration config,  String dirName){
    org.openfuxml.test.xml.wiki.TextOfxPushUp genVar1847;
    genVar1847=this;
    genVar1847.config=config;
    org.openfuxml.test.xml.wiki.TextOfxPushUp genVar1848;
    genVar1848=this;
    genVar1848.dirName=dirName;
  }
  public Document load(  String article){
    try {
      java.lang.String genVar1849;
      genVar1849="/";
      java.lang.String genVar1850;
      genVar1850="-";
      java.lang.String genVar1851;
      genVar1851=".xhtml";
      java.lang.String genVar1852;
      genVar1852=dirName + genVar1849 + article+ genVar1850+ OfxWikiEngine.Status.xhtmlProcessed+ genVar1851;
      File f;
      f=new File(genVar1852);
      org.jdom2.input.SAXBuilder genVar1853;
      genVar1853=new SAXBuilder();
      doc=genVar1853.build(f);
      org.jdom2.output.Format genVar1854;
      genVar1854=Format.getRawFormat();
      XMLOutputter xmlOut;
      xmlOut=new XMLOutputter(genVar1854);
      xmlOut.output(doc,System.out);
    }
 catch (    JDOMException e) {
      java.lang.String genVar1855;
      genVar1855="";
      logger.error(genVar1855,e);
    }
catch (    IOException e) {
      java.lang.String genVar1856;
      genVar1856="";
      logger.error(genVar1856,e);
    }
    return doc;
  }
  public void move(){
    try {
      OfxPushUp ofxPushUp;
      ofxPushUp=new OfxPushUp();
      org.jdom2.Element genVar1857;
      genVar1857=doc.getRootElement();
      java.lang.String genVar1858;
      genVar1858="wikiinjection";
      int genVar1859;
      genVar1859=0;
      ArrayList<Element> al;
      al=ofxPushUp.moveOfxElement(genVar1857,genVar1858,genVar1859);
      int genVar1860;
      genVar1860=al.size();
      int genVar1861;
      genVar1861=1;
      boolean genVar1862;
      genVar1862=genVar1860 > genVar1861;
      if (genVar1862) {
        java.lang.String genVar1863;
        genVar1863="Moved Elements has a size>1 !!!";
        logger.warn(genVar1863);
      }
 else {
        ;
      }
      int genVar1864;
      genVar1864=0;
      Element result;
      result=al.get(genVar1864);
      org.jdom2.output.Format genVar1865;
      genVar1865=Format.getRawFormat();
      XMLOutputter xmlOut;
      xmlOut=new XMLOutputter(genVar1865);
      xmlOut.output(result,System.out);
    }
 catch (    IOException e) {
      java.lang.String genVar1866;
      genVar1866="";
      logger.error(genVar1866,e);
    }
  }
  public static void main(  String[] args){
    java.lang.String genVar1867;
    genVar1867="log4j.xml";
    LoggerInit loggerInit;
    loggerInit=new LoggerInit(genVar1867);
    java.lang.String genVar1868;
    genVar1868="resources/config";
    loggerInit.addAltPath(genVar1868);
    loggerInit.init();
    java.lang.String genVar1869;
    genVar1869="resources/config/wiki/wiki.xml";
    ConfigLoader.add(genVar1869);
    Configuration config;
    config=ConfigLoader.init();
    WikiTemplates.init();
    java.lang.String genVar1870;
    genVar1870="dist";
    TextOfxPushUp test;
    test=new TextOfxPushUp(config,genVar1870);
    java.lang.String genVar1871;
    genVar1871="Bellagio";
    Document doc;
    doc=test.load(genVar1871);
    test.move();
    JDomUtil.dissect(doc);
  }
}
