package org.openfuxml.util.filter;
import net.sf.exlp.util.xml.JDomUtil;
import net.sf.exlp.util.xml.JaxbUtil;
import org.jdom2.Attribute;
import org.jdom2.filter.Filters;
import org.jdom2.xpath.XPathExpression;
import org.jdom2.xpath.XPathFactory;
import org.openfuxml.content.ofx.Document;
import org.openfuxml.content.ofx.Section;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class OfxClassifierFilter {
  final static Logger logger=LoggerFactory.getLogger(OfxClassifierFilter.class);
  private String[] classifiers;
  public OfxClassifierFilter(  String... classifiers){
    org.openfuxml.util.filter.OfxClassifierFilter genVar1891;
    genVar1891=this;
    genVar1891.classifiers=classifiers;
  }
  public Section filterLang(  Section section){
    org.jdom2.Document j2Doc;
    j2Doc=JaxbUtil.toDocument(section);
    OfxClassifierFilter genVar1892;
    genVar1892=this;
    genVar1892.filterLang(j2Doc);
    java.lang.Class<org.openfuxml.content.ofx.Section> genVar1893;
    genVar1893=Section.class;
    java.lang.Object genVar1894;
    genVar1894=JDomUtil.toJaxb(j2Doc,genVar1893);
    org.openfuxml.content.ofx.Section genVar1895;
    genVar1895=(Section)genVar1894;
    return genVar1895;
  }
  public void filterLang(  Document ofxDocument){
    org.jdom2.Document j2Doc;
    j2Doc=JaxbUtil.toDocument(ofxDocument);
    OfxClassifierFilter genVar1896;
    genVar1896=this;
    genVar1896.filterLang(j2Doc);
  }
  private void filterLang(  org.jdom2.Document j2Doc){
    XPathFactory xpfac;
    xpfac=XPathFactory.instance();
    java.lang.String genVar1897;
    genVar1897="//*/@classifier";
    org.jdom2.filter.Filter<org.jdom2.Attribute> genVar1898;
    genVar1898=Filters.attribute();
    XPathExpression<Attribute> xp;
    xp=xpfac.compile(genVar1897,genVar1898);
    java.util.List<org.jdom2.Attribute> genVar1899;
    genVar1899=xp.evaluate(j2Doc);
    for (    Attribute att : genVar1899) {
      boolean remove;
      remove=true;
      for (      String classifier : classifiers) {
        java.lang.String genVar1900;
        genVar1900=att.getValue();
        boolean genVar1901;
        genVar1901=genVar1900.equals(classifier);
        if (genVar1901) {
          remove=false;
        }
 else {
          ;
        }
      }
      if (remove) {
        org.jdom2.Element genVar1902;
        genVar1902=att.getParent();
        genVar1902.detach();
      }
 else {
        ;
      }
    }
  }
}
