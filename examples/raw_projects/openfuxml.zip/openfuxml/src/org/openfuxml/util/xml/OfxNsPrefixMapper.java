package org.openfuxml.util.xml;
public class OfxNsPrefixMapper {
}
