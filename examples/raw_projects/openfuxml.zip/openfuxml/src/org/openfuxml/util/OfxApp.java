package org.openfuxml.util;
public class OfxApp {
}
