package org.openfuxml.util.filter;
import net.sf.exlp.util.xml.JDomUtil;
import net.sf.exlp.util.xml.JaxbUtil;
import org.jdom2.Attribute;
import org.jdom2.filter.Filters;
import org.jdom2.xpath.XPathExpression;
import org.jdom2.xpath.XPathFactory;
import org.openfuxml.content.ofx.Document;
import org.openfuxml.content.ofx.Section;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class OfxLangFilter {
  final static Logger logger=LoggerFactory.getLogger(OfxLangFilter.class);
  private String lang;
  public OfxLangFilter(  String lang){
    org.openfuxml.util.filter.OfxLangFilter genVar1903;
    genVar1903=this;
    genVar1903.lang=lang;
  }
  public Section filterLang(  Section section){
    org.jdom2.Document j2Doc;
    j2Doc=JaxbUtil.toDocument(section);
    OfxLangFilter genVar1904;
    genVar1904=this;
    genVar1904.filterLang(j2Doc);
    java.lang.Class<org.openfuxml.content.ofx.Section> genVar1905;
    genVar1905=Section.class;
    java.lang.Object genVar1906;
    genVar1906=JDomUtil.toJaxb(j2Doc,genVar1905);
    org.openfuxml.content.ofx.Section genVar1907;
    genVar1907=(Section)genVar1906;
    return genVar1907;
  }
  public void filterLang(  Document ofxDocument){
    org.jdom2.Document j2Doc;
    j2Doc=JaxbUtil.toDocument(ofxDocument);
    OfxLangFilter genVar1908;
    genVar1908=this;
    genVar1908.filterLang(j2Doc);
  }
  private void filterLang(  org.jdom2.Document j2Doc){
    XPathFactory xpfac;
    xpfac=XPathFactory.instance();
    java.lang.String genVar1909;
    genVar1909="//*/@lang";
    org.jdom2.filter.Filter<org.jdom2.Attribute> genVar1910;
    genVar1910=Filters.attribute();
    XPathExpression<Attribute> xp;
    xp=xpfac.compile(genVar1909,genVar1910);
    java.util.List<org.jdom2.Attribute> genVar1911;
    genVar1911=xp.evaluate(j2Doc);
    for (    Attribute att : genVar1911) {
      java.lang.String genVar1912;
      genVar1912=att.getValue();
      boolean genVar1913;
      genVar1913=genVar1912.equals(lang);
      boolean genVar1914;
      genVar1914=!genVar1913;
      if (genVar1914) {
        org.jdom2.Element genVar1915;
        genVar1915=att.getParent();
        genVar1915.detach();
      }
 else {
        ;
      }
    }
  }
}
