package org.openfuxml.xml.renderer.html;
public class Template {
  public String getFileCode(){
    return null;
  }
}
