package org.openfuxml.xml.addon.chart;
import org.openfuxml.addon.chart.interfaces.ChartRenderer;
public class Chart {
  public ChartRenderer getRenderer(){
    return null;
  }
}
