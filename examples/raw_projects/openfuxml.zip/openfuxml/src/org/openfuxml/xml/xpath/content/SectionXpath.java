package org.openfuxml.xml.xpath.content;
import net.sf.exlp.exception.ExlpXpathNotFoundException;
import org.openfuxml.content.ofx.Section;
import org.openfuxml.content.ofx.Title;
public class SectionXpath {
  public static Title getTitle(  Section section) throws ExlpXpathNotFoundException {
    return null;
  }
}
