package org.openfuxml.xml.xpath;
import net.sf.exlp.xml.ns.NsPrefixMapperInterface;
import org.jdom2.Namespace;
import org.openfuxml.xml.OfxNsPrefixMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class OfxXpath {
  final static Logger logger=LoggerFactory.getLogger(OfxXpath.class);
  public static synchronized Namespace getNsHtml(){
    java.lang.String genVar1916;
    genVar1916="html";
    java.lang.String genVar1917;
    genVar1917="http://www.openfuxml.org/renderer/html";
    Namespace nsHtml;
    nsHtml=Namespace.getNamespace(genVar1916,genVar1917);
    return nsHtml;
  }
  public static synchronized NsPrefixMapperInterface getNsPrefixMapper(){
    org.openfuxml.xml.OfxNsPrefixMapper genVar1918;
    genVar1918=new OfxNsPrefixMapper();
    return genVar1918;
  }
}
