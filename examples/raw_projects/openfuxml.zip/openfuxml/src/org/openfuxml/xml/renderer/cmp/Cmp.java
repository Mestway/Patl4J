package org.openfuxml.xml.renderer.cmp;
import org.openfuxml.addon.wiki.processor.markup.WikiPreprocessor;
public class Cmp {
  public WikiPreprocessor getPreprocessor(){
    return null;
  }
}
