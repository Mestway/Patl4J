package org.openfuxml.xml.addon.jsf;
import java.util.List;
public class Component {
  public List<String> getAttribute(){
    return null;
  }
}
