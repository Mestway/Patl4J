package org.openfuxml.xml.renderer.html;
public class Renderer {
  public String getClassName(){
    return null;
  }
}
