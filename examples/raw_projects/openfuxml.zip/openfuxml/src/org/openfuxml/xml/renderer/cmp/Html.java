package org.openfuxml.xml.renderer.cmp;
import java.util.List;
import org.openfuxml.xml.renderer.html.Template;
public class Html {
  public List<Template> getTemplate(){
    return null;
  }
  public String getDir(){
    return null;
  }
}
