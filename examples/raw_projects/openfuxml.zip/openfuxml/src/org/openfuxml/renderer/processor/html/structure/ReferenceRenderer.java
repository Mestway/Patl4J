package org.openfuxml.renderer.processor.html.structure;
import org.jdom2.Content;
import org.jdom2.Element;
import org.openfuxml.content.ofx.Reference;
import org.openfuxml.renderer.processor.html.interfaces.OfxReferenceRenderer;
public class ReferenceRenderer implements OfxReferenceRenderer {
  public Content render(  Reference reference){
    java.lang.String genVar1629;
    genVar1629="a";
    Element a;
    a=new Element(genVar1629);
    java.lang.String genVar1630;
    genVar1630="href";
    java.lang.String genVar1631;
    genVar1631=reference.getTarget();
    a.setAttribute(genVar1630,genVar1631);
    java.lang.String genVar1632;
    genVar1632=reference.getValue();
    a.setText(genVar1632);
    return a;
  }
}
