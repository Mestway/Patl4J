package org.openfuxml.renderer.processor.html;
import java.io.File;
import java.io.FileNotFoundException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import net.sf.exlp.util.xml.JDomUtil;
import net.sf.exlp.util.xml.JaxbUtil;
import org.jdom2.Content;
import org.jdom2.Element;
import org.jdom2.filter.Filters;
import org.jdom2.output.Format;
import org.jdom2.xpath.XPathExpression;
import org.jdom2.xpath.XPathFactory;
import org.openfuxml.content.ofx.Document;
import org.openfuxml.content.ofx.Section;
import org.openfuxml.exception.OfxAuthoringException;
import org.openfuxml.exception.OfxConfigurationException;
import org.openfuxml.exception.OfxImplementationException;
import org.openfuxml.renderer.processor.html.interfaces.OfxHeaderRenderer;
import org.openfuxml.renderer.processor.html.interfaces.OfxNavigationRenderer;
import org.openfuxml.renderer.processor.html.interfaces.OfxSectionRenderer;
import org.openfuxml.renderer.util.OfxRenderConfiguration;
import org.openfuxml.xml.renderer.cmp.Html;
import org.openfuxml.xml.renderer.html.Renderer;
import org.openfuxml.xml.renderer.html.Template;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class OfxHtmlRenderer {
  final static Logger logger=LoggerFactory.getLogger(OfxHtmlRenderer.class);
  public static enum HtmlDir {  template,   web}
  private Html html;
  private OfxRenderConfiguration cmpConfigUtil;
  public OfxHtmlRenderer(  OfxRenderConfiguration cmpConfigUtil,  Html html){
    org.openfuxml.renderer.processor.html.OfxHtmlRenderer genVar1508;
    genVar1508=this;
    genVar1508.html=html;
    org.openfuxml.renderer.processor.html.OfxHtmlRenderer genVar1509;
    genVar1509=this;
    genVar1509.cmpConfigUtil=cmpConfigUtil;
  }
  public void render(  String ofxDocFileName) throws OfxAuthoringException, OfxConfigurationException, OfxImplementationException {
    try {
      java.lang.String genVar1510;
      genVar1510="Processing: ";
      java.lang.String genVar1511;
      genVar1511=genVar1510 + ofxDocFileName;
      logger.debug(genVar1511);
      java.lang.Class<org.openfuxml.content.ofx.Document> genVar1512;
      genVar1512=Document.class;
      Document ofxdoc;
      ofxdoc=JaxbUtil.loadJAXB(ofxDocFileName,genVar1512);
      java.util.List<org.openfuxml.xml.renderer.html.Template> genVar1513;
      genVar1513=html.getTemplate();
      for (      Template template : genVar1513) {
        org.openfuxml.content.ofx.Sections genVar1514;
        genVar1514=ofxdoc.getContent();
        java.util.List<org.openfuxml.content.ofx.Section> genVar1515;
        genVar1515=genVar1514.getContent();
        for (        Object o : genVar1515) {
          boolean genVar1516;
          genVar1516=o instanceof Section;
          if (genVar1516) {
            OfxHtmlRenderer genVar1517;
            genVar1517=this;
            org.openfuxml.content.ofx.Section genVar1518;
            genVar1518=(Section)o;
            genVar1517.processTemplate(genVar1518,ofxdoc,template);
          }
 else {
            ;
          }
        }
      }
    }
 catch (    FileNotFoundException e) {
      java.lang.String genVar1519;
      genVar1519="";
      logger.error(genVar1519,e);
    }
  }
  private void processTemplate(  Section section,  Document ofxDoc,  Template template) throws OfxConfigurationException, OfxImplementationException {
    java.lang.String genVar1520;
    genVar1520=html.getDir();
    java.lang.String genVar1521;
    genVar1521=HtmlDir.template.toString();
    java.lang.String genVar1522;
    genVar1522=template.getFileCode();
    boolean genVar1523;
    genVar1523=false;
    File fTemplate;
    fTemplate=cmpConfigUtil.getFile(genVar1520,genVar1521,genVar1522,genVar1523);
    org.jdom2.Document doc;
    doc=JDomUtil.load(fTemplate);
{
      org.jdom2.xpath.XPathFactory genVar1524;
      genVar1524=XPathFactory.instance();
      java.lang.String genVar1525;
      genVar1525="//ofx:renderer";
      org.jdom2.filter.Filter<org.jdom2.Element> genVar1526;
      genVar1526=Filters.element();
      XPathExpression<Element> xpath;
      xpath=genVar1524.compile(genVar1525,genVar1526);
      List<Element> list;
      list=xpath.evaluate(doc);
      int genVar1527;
      genVar1527=list.size();
      java.lang.String genVar1528;
      genVar1528=" <ofx:renderer/> Elements found in template";
      java.lang.String genVar1529;
      genVar1529=genVar1527 + genVar1528;
      logger.debug(genVar1529);
      for (      Element eRenderer : list) {
        java.lang.Class<org.openfuxml.xml.renderer.html.Renderer> genVar1530;
        genVar1530=Renderer.class;
        org.openfuxml.xml.renderer.html.Renderer genVar1531;
        genVar1531=JDomUtil.toJaxb(eRenderer,genVar1530);
        Renderer r;
        r=(Renderer)genVar1531;
        r=cmpConfigUtil.getHtmlRenderer(html,r);
        try {
          java.lang.String genVar1532;
          genVar1532=r.getClassName();
          Class cl;
          cl=Class.forName(genVar1532);
          java.lang.reflect.Constructor genVar1533;
          genVar1533=cl.getConstructor();
          Object oRenderer;
          oRenderer=genVar1533.newInstance();
          boolean genVar1534;
          genVar1534=oRenderer instanceof OfxNavigationRenderer;
          if (genVar1534) {
            OfxHtmlRenderer genVar1535;
            genVar1535=this;
            org.openfuxml.renderer.processor.html.interfaces.OfxNavigationRenderer genVar1536;
            genVar1536=(OfxNavigationRenderer)oRenderer;
            genVar1535.renderNav(eRenderer,genVar1536,ofxDoc,section);
          }
 else {
            boolean genVar1537;
            genVar1537=oRenderer instanceof OfxHeaderRenderer;
            if (genVar1537) {
              OfxHtmlRenderer genVar1538;
              genVar1538=this;
              org.openfuxml.renderer.processor.html.interfaces.OfxHeaderRenderer genVar1539;
              genVar1539=(OfxHeaderRenderer)oRenderer;
              genVar1538.renderHeader(eRenderer,genVar1539,ofxDoc,section);
            }
 else {
              boolean genVar1540;
              genVar1540=oRenderer instanceof OfxSectionRenderer;
              if (genVar1540) {
                OfxHtmlRenderer genVar1541;
                genVar1541=this;
                org.openfuxml.renderer.processor.html.interfaces.OfxSectionRenderer genVar1542;
                genVar1542=(OfxSectionRenderer)oRenderer;
                genVar1541.renderSection(eRenderer,genVar1542,ofxDoc,section);
              }
 else {
                ;
              }
            }
          }
        }
 catch (        ClassNotFoundException e) {
          java.lang.String genVar1543;
          genVar1543="Renderer class not found: ";
          java.lang.String genVar1544;
          genVar1544=e.getMessage();
          java.lang.String genVar1545;
          genVar1545=genVar1543 + genVar1544;
          org.openfuxml.exception.OfxConfigurationException genVar1546;
          genVar1546=new OfxConfigurationException(genVar1545);
          throw genVar1546;
        }
catch (        IllegalArgumentException e) {
          java.lang.String genVar1547;
          genVar1547="";
          logger.error(genVar1547,e);
        }
catch (        SecurityException e) {
          java.lang.String genVar1548;
          genVar1548="";
          logger.error(genVar1548,e);
        }
catch (        InstantiationException e) {
          java.lang.String genVar1549;
          genVar1549="";
          logger.error(genVar1549,e);
        }
catch (        IllegalAccessException e) {
          java.lang.String genVar1550;
          genVar1550="";
          logger.error(genVar1550,e);
        }
catch (        InvocationTargetException e) {
          java.lang.String genVar1551;
          genVar1551="";
          logger.error(genVar1551,e);
        }
catch (        NoSuchMethodException e) {
          java.lang.String genVar1552;
          genVar1552="Renderer implementation does not have a empty constructor: ";
          java.lang.String genVar1553;
          genVar1553=r.getClassName();
          java.lang.String genVar1554;
          genVar1554=genVar1552 + genVar1553;
          org.openfuxml.exception.OfxImplementationException genVar1555;
          genVar1555=new OfxImplementationException(genVar1554);
          throw genVar1555;
        }
      }
    }
    java.lang.String genVar1556;
    genVar1556=html.getDir();
    java.lang.String genVar1557;
    genVar1557=HtmlDir.web.toString();
    File fWeb;
    fWeb=cmpConfigUtil.getDir(genVar1556,genVar1557);
    java.lang.String genVar1558;
    genVar1558=section.getId();
    java.lang.String genVar1559;
    genVar1559=".html";
    java.lang.String genVar1560;
    genVar1560=genVar1558 + genVar1559;
    File fHtml;
    fHtml=new File(fWeb,genVar1560);
    org.jdom2.output.Format genVar1561;
    genVar1561=Format.getRawFormat();
    JDomUtil.save(doc,fHtml,genVar1561);
  }
  private void renderNav(  Element eRenderer,  OfxNavigationRenderer navRenderer,  Document ofxDoc,  Section section){
    Element renderedElement;
    renderedElement=navRenderer.render(ofxDoc,section);
    org.jdom2.Element genVar1562;
    genVar1562=eRenderer.getParentElement();
    int index;
    index=genVar1562.indexOf(eRenderer);
    org.jdom2.Element genVar1563;
    genVar1563=eRenderer.getParentElement();
    genVar1563.setContent(index,renderedElement);
    eRenderer.detach();
  }
  private void renderHeader(  Element eRenderer,  OfxHeaderRenderer headerRenderer,  Document ofxDoc,  Section section){
    Content content;
    content=headerRenderer.render(section);
    org.jdom2.Element genVar1564;
    genVar1564=eRenderer.getParentElement();
    int index;
    index=genVar1564.indexOf(eRenderer);
    org.jdom2.Element genVar1565;
    genVar1565=eRenderer.getParentElement();
    genVar1565.setContent(index,content);
    eRenderer.detach();
  }
  private void renderSection(  Element eRenderer,  OfxSectionRenderer sectionRenderer,  Document ofxDoc,  Section section){
    List<Content> contents;
    contents=sectionRenderer.render(section);
    org.jdom2.Element genVar1566;
    genVar1566=eRenderer.getParentElement();
    int index;
    index=genVar1566.indexOf(eRenderer);
    org.jdom2.Element genVar1567;
    genVar1567=eRenderer.getParentElement();
    genVar1567.setContent(index,contents);
    eRenderer.detach();
  }
}
