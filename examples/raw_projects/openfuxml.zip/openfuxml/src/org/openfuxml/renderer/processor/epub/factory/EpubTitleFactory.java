package org.openfuxml.renderer.processor.epub.factory;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.openfuxml.content.ofx.Title;
import org.openfuxml.processor.pre.ExternalContentEagerLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class EpubTitleFactory {
  final static Logger logger=LoggerFactory.getLogger(ExternalContentEagerLoader.class);
  private Namespace ns;
  public EpubTitleFactory(  Namespace ns){
    org.openfuxml.renderer.processor.epub.factory.EpubTitleFactory genVar1505;
    genVar1505=this;
    genVar1505.ns=ns;
  }
  public Element createTitle(  Title title){
    java.lang.String genVar1506;
    genVar1506="h1";
    Element eTitle;
    eTitle=new Element(genVar1506,ns);
    java.lang.String genVar1507;
    genVar1507=title.getValue();
    eTitle.setText(genVar1507);
    return eTitle;
  }
}
