package org.openfuxml.renderer.html.section;
import java.util.ArrayList;
import java.util.List;
import org.jdom2.Content;
import org.jdom2.Element;
import org.jdom2.Text;
import org.openfuxml.content.ofx.Paragraph;
import org.openfuxml.content.ofx.Reference;
import org.openfuxml.content.ofx.Section;
import org.openfuxml.content.ofx.Title;
import org.openfuxml.content.table.Table;
import org.openfuxml.renderer.processor.html.interfaces.OfxSectionRenderer;
import org.openfuxml.renderer.processor.html.interfaces.OfxTableRenderer;
import org.openfuxml.renderer.processor.html.section.ParagraphRenderer;
import org.openfuxml.renderer.processor.html.structure.ReferenceRenderer;
import org.openfuxml.renderer.processor.html.table.DefaultTableRenderer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class SectionRenderer implements OfxSectionRenderer {
  final static Logger logger=LoggerFactory.getLogger(SectionRenderer.class);
  private List<Content> list;
  private List<Content> subsections;
  private Element divParagraph;
  private Element eHeader;
  public SectionRenderer(){
    list=new ArrayList<Content>();
    subsections=new ArrayList<Content>();
    java.lang.String genVar1411;
    genVar1411="div";
    divParagraph=new Element(genVar1411);
    java.lang.String genVar1412;
    genVar1412="class";
    java.lang.String genVar1413;
    genVar1413="text3";
    divParagraph.setAttribute(genVar1412,genVar1413);
  }
  public List<Content> render(  Section section){
    java.util.List<org.openfuxml.content.table.Table> genVar1414;
    genVar1414=section.getContent();
    for (    Object o : genVar1414) {
      boolean genVar1415;
      genVar1415=o instanceof String;
      if (genVar1415) {
      }
 else {
        boolean genVar1416;
        genVar1416=o instanceof Title;
        if (genVar1416) {
          SectionRenderer genVar1417;
          genVar1417=this;
          org.openfuxml.content.ofx.Title genVar1418;
          genVar1418=(Title)o;
          genVar1417.createHeader(genVar1418);
        }
 else {
          boolean genVar1419;
          genVar1419=o instanceof Paragraph;
          if (genVar1419) {
            SectionRenderer genVar1420;
            genVar1420=this;
            org.openfuxml.content.ofx.Paragraph genVar1421;
            genVar1421=(Paragraph)o;
            genVar1420.addParagrah(genVar1421);
          }
 else {
            boolean genVar1422;
            genVar1422=o instanceof Section;
            if (genVar1422) {
              SectionRenderer genVar1423;
              genVar1423=this;
              org.openfuxml.content.ofx.Section genVar1424;
              genVar1424=(Section)o;
              genVar1423.addSection(genVar1424);
            }
 else {
              boolean genVar1425;
              genVar1425=o instanceof Table;
              if (genVar1425) {
                OfxTableRenderer r;
                r=new DefaultTableRenderer();
                org.openfuxml.content.table.Table genVar1426;
                genVar1426=(Table)o;
                org.jdom2.Element genVar1427;
                genVar1427=r.render(genVar1426);
                divParagraph.addContent(genVar1427);
              }
 else {
                java.lang.String genVar1428;
                genVar1428="Unknown content: ";
                java.lang.Class genVar1429;
                genVar1429=o.getClass();
                java.lang.String genVar1430;
                genVar1430=genVar1429.getSimpleName();
                java.lang.String genVar1431;
                genVar1431=genVar1428 + genVar1430;
                logger.warn(genVar1431);
              }
            }
          }
        }
      }
    }
    boolean genVar1432;
    genVar1432=eHeader != null;
    if (genVar1432) {
      list.add(eHeader);
    }
 else {
      ;
    }
    int genVar1433;
    genVar1433=divParagraph.getContentSize();
    int genVar1434;
    genVar1434=0;
    boolean genVar1435;
    genVar1435=genVar1433 > genVar1434;
    if (genVar1435) {
      list.add(divParagraph);
    }
 else {
      ;
    }
    list.addAll(subsections);
    return list;
  }
  private void addParagrah(  Paragraph ofxParagraph){
    ParagraphRenderer pR;
    pR=new ParagraphRenderer();
    Content c;
    c=pR.render(ofxParagraph);
    divParagraph.addContent(c);
  }
  private void addSection(  Section section){
    DefaultSection2Renderer render2;
    render2=new DefaultSection2Renderer();
    org.jdom2.Content genVar1436;
    genVar1436=render2.render(section);
    subsections.add(genVar1436);
  }
  private void createHeader(  Title title){
    java.lang.String genVar1437;
    genVar1437="h1";
    Element h1;
    h1=new Element(genVar1437);
    java.lang.String genVar1438;
    genVar1438=title.getValue();
    h1.setText(genVar1438);
    java.lang.String genVar1439;
    genVar1439="hgroup";
    Element hgroup;
    hgroup=new Element(genVar1439);
    hgroup.setContent(h1);
    java.lang.String genVar1440;
    genVar1440="header";
    Element header;
    header=new Element(genVar1440);
    header.setContent(hgroup);
    java.lang.String genVar1441;
    genVar1441="div";
    eHeader=new Element(genVar1441);
    java.lang.String genVar1442;
    genVar1442="class";
    java.lang.String genVar1443;
    genVar1443="text1";
    eHeader.setAttribute(genVar1442,genVar1443);
    eHeader.setContent(header);
  }
private class DefaultSection2Renderer {
    private Element divParagraph;
    public DefaultSection2Renderer(){
      java.lang.String genVar1444;
      genVar1444="div";
      divParagraph=new Element(genVar1444);
      java.lang.String genVar1445;
      genVar1445="class";
      java.lang.String genVar1446;
      genVar1446="text2";
      divParagraph.setAttribute(genVar1445,genVar1446);
    }
    public Content render(    Section section){
      java.util.List<org.openfuxml.content.table.Table> genVar1447;
      genVar1447=section.getContent();
      for (      Object o : genVar1447) {
        boolean genVar1448;
        genVar1448=o instanceof String;
        if (genVar1448) {
        }
 else {
          boolean genVar1449;
          genVar1449=o instanceof Title;
          if (genVar1449) {
            DefaultSection2Renderer genVar1450;
            genVar1450=this;
            org.openfuxml.content.ofx.Title genVar1451;
            genVar1451=(Title)o;
            genVar1450.createHeader(genVar1451);
          }
 else {
            boolean genVar1452;
            genVar1452=o instanceof Paragraph;
            if (genVar1452) {
              DefaultSection2Renderer genVar1453;
              genVar1453=this;
              org.openfuxml.content.ofx.Paragraph genVar1454;
              genVar1454=(Paragraph)o;
              genVar1453.addParagrah(genVar1454);
            }
 else {
              boolean genVar1455;
              genVar1455=o instanceof Table;
              if (genVar1455) {
                OfxTableRenderer r;
                r=new DefaultTableRenderer();
                org.openfuxml.content.table.Table genVar1456;
                genVar1456=(Table)o;
                org.jdom2.Element genVar1457;
                genVar1457=r.render(genVar1456);
                divParagraph.addContent(genVar1457);
              }
 else {
                java.lang.String genVar1458;
                genVar1458="Unknown content: ";
                java.lang.Class genVar1459;
                genVar1459=o.getClass();
                java.lang.String genVar1460;
                genVar1460=genVar1459.getSimpleName();
                java.lang.String genVar1461;
                genVar1461=genVar1458 + genVar1460;
                logger.warn(genVar1461);
              }
            }
          }
        }
      }
      return divParagraph;
    }
    private void addParagrah(    Paragraph ofxParagraph){
      java.lang.String genVar1462;
      genVar1462="p";
      Element p;
      p=new Element(genVar1462);
      java.util.List<java.lang.Object> genVar1463;
      genVar1463=ofxParagraph.getContent();
      for (      Object o : genVar1463) {
        boolean genVar1464;
        genVar1464=o instanceof String;
        if (genVar1464) {
          java.lang.String genVar1465;
          genVar1465=(String)o;
          org.jdom2.Text genVar1466;
          genVar1466=new Text(genVar1465);
          p.addContent(genVar1466);
        }
 else {
          boolean genVar1467;
          genVar1467=o instanceof Reference;
          if (genVar1467) {
            ReferenceRenderer r;
            r=new ReferenceRenderer();
            org.openfuxml.content.ofx.Reference genVar1468;
            genVar1468=(Reference)o;
            org.jdom2.Content genVar1469;
            genVar1469=r.render(genVar1468);
            p.addContent(genVar1469);
          }
 else {
            java.lang.String genVar1470;
            genVar1470="Unknown content: ";
            java.lang.Class genVar1471;
            genVar1471=o.getClass();
            java.lang.String genVar1472;
            genVar1472=genVar1471.getSimpleName();
            java.lang.String genVar1473;
            genVar1473=genVar1470 + genVar1472;
            logger.warn(genVar1473);
          }
        }
      }
      divParagraph.addContent(p);
    }
    private void createHeader(    Title title){
      java.lang.String genVar1474;
      genVar1474="h3";
      Element h1;
      h1=new Element(genVar1474);
      java.lang.String genVar1475;
      genVar1475=title.getValue();
      h1.setText(genVar1475);
      java.lang.String genVar1476;
      genVar1476="hgroup";
      Element hgroup;
      hgroup=new Element(genVar1476);
      hgroup.setContent(h1);
      java.lang.String genVar1477;
      genVar1477="header";
      Element eHeader;
      eHeader=new Element(genVar1477);
      eHeader.setContent(hgroup);
      divParagraph.addContent(eHeader);
    }
  }
}
