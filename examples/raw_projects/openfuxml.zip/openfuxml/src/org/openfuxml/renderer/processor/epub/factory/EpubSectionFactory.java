package org.openfuxml.renderer.processor.epub.factory;
import java.util.ArrayList;
import java.util.List;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.openfuxml.content.ofx.Paragraph;
import org.openfuxml.content.ofx.Section;
import org.openfuxml.content.ofx.Title;
import org.openfuxml.processor.pre.ExternalContentEagerLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class EpubSectionFactory {
  final static Logger logger=LoggerFactory.getLogger(ExternalContentEagerLoader.class);
  private EpubTitleFactory titleFactory;
  private EpubParagraphFactory paragraphFactory;
  public EpubSectionFactory(  EpubTitleFactory titleFactory,  Namespace ns){
    org.openfuxml.renderer.processor.epub.factory.EpubSectionFactory genVar1487;
    genVar1487=this;
    genVar1487.titleFactory=titleFactory;
    paragraphFactory=new EpubParagraphFactory(ns);
  }
  public List<Element> createSection(  Section section,  int depth){
    List<Element> result;
    result=new ArrayList<Element>();
    java.util.List<org.openfuxml.content.table.Table> genVar1488;
    genVar1488=section.getContent();
    for (    Object s : genVar1488) {
      boolean genVar1489;
      genVar1489=s instanceof Title;
      if (genVar1489) {
        org.openfuxml.content.ofx.Title genVar1490;
        genVar1490=(Title)s;
        org.jdom2.Element genVar1491;
        genVar1491=titleFactory.createTitle(genVar1490);
        result.add(genVar1491);
      }
 else {
        boolean genVar1492;
        genVar1492=s instanceof Section;
        if (genVar1492) {
          EpubSectionFactory genVar1493;
          genVar1493=this;
          org.openfuxml.content.ofx.Section genVar1494;
          genVar1494=(Section)s;
          int genVar1495;
          genVar1495=depth++;
          java.util.List<org.jdom2.Element> genVar1496;
          genVar1496=genVar1493.createSection(genVar1494,genVar1495);
          result.addAll(genVar1496);
        }
 else {
          boolean genVar1497;
          genVar1497=s instanceof Paragraph;
          if (genVar1497) {
            org.openfuxml.content.ofx.Paragraph genVar1498;
            genVar1498=(Paragraph)s;
            org.jdom2.Element genVar1499;
            genVar1499=paragraphFactory.createParagraph(genVar1498);
            result.add(genVar1499);
          }
 else {
            boolean genVar1500;
            genVar1500=s instanceof String;
            if (genVar1500) {
            }
 else {
              java.lang.String genVar1501;
              genVar1501="Unknwon Content: ";
              java.lang.Class genVar1502;
              genVar1502=s.getClass();
              java.lang.String genVar1503;
              genVar1503=genVar1502.getSimpleName();
              java.lang.String genVar1504;
              genVar1504=genVar1501 + genVar1503;
              logger.warn(genVar1504);
            }
          }
        }
      }
    }
    return result;
  }
}
