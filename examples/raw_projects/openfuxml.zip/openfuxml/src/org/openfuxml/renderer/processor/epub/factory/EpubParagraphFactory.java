package org.openfuxml.renderer.processor.epub.factory;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.openfuxml.content.ofx.Paragraph;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class EpubParagraphFactory {
  final static Logger logger=LoggerFactory.getLogger(EpubParagraphFactory.class);
  private Namespace ns;
  public EpubParagraphFactory(  Namespace ns){
    org.openfuxml.renderer.processor.epub.factory.EpubParagraphFactory genVar1478;
    genVar1478=this;
    genVar1478.ns=ns;
  }
  public Element createParagraph(  Paragraph p){
    java.lang.String genVar1479;
    genVar1479="p";
    Element eParagraph;
    eParagraph=new Element(genVar1479,ns);
    java.util.List<java.lang.Object> genVar1480;
    genVar1480=p.getContent();
    for (    Object s : genVar1480) {
      boolean genVar1481;
      genVar1481=s instanceof String;
      if (genVar1481) {
        java.lang.String genVar1482;
        genVar1482=(String)s;
        eParagraph.addContent(genVar1482);
      }
 else {
        java.lang.String genVar1483;
        genVar1483="Unknwon Content: ";
        java.lang.Class genVar1484;
        genVar1484=s.getClass();
        java.lang.String genVar1485;
        genVar1485=genVar1484.getSimpleName();
        java.lang.String genVar1486;
        genVar1486=genVar1483 + genVar1485;
        logger.warn(genVar1486);
      }
    }
    return eParagraph;
  }
}
