package org.openfuxml.renderer.processor.html.navigation;
import net.sf.exlp.exception.ExlpXpathNotFoundException;
import org.jdom2.Element;
import org.openfuxml.content.ofx.Document;
import org.openfuxml.content.ofx.Section;
import org.openfuxml.content.ofx.Title;
import org.openfuxml.renderer.processor.html.interfaces.OfxNavigationRenderer;
import org.openfuxml.xml.xpath.content.SectionXpath;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class NavUnorderedListRenderer implements OfxNavigationRenderer {
  final static Logger logger=LoggerFactory.getLogger(NavUnorderedListRenderer.class);
  public NavUnorderedListRenderer(){
  }
  public Element render(  Document ofxDoc,  Section actualSection){
    java.lang.String genVar1570;
    genVar1570="ul";
    Element rootElement;
    rootElement=new Element(genVar1570);
    org.openfuxml.content.ofx.Sections genVar1571;
    genVar1571=ofxDoc.getContent();
    java.util.List<org.openfuxml.content.ofx.Section> genVar1572;
    genVar1572=genVar1571.getContent();
    for (    Object o : genVar1572) {
      boolean genVar1573;
      genVar1573=o instanceof Section;
      if (genVar1573) {
        NavUnorderedListRenderer genVar1574;
        genVar1574=this;
        org.openfuxml.content.ofx.Section genVar1575;
        genVar1575=(Section)o;
        org.jdom2.Element genVar1576;
        genVar1576=genVar1574.getSection(genVar1575);
        rootElement.addContent(genVar1576);
      }
 else {
        ;
      }
    }
    return rootElement;
  }
  private Element getSection(  Section section){
    java.lang.String genVar1577;
    genVar1577="a";
    Element a;
    a=new Element(genVar1577);
    try {
      Title title;
      title=SectionXpath.getTitle(section);
      java.lang.String genVar1578;
      genVar1578="href";
      java.lang.String genVar1579;
      genVar1579=section.getId();
      java.lang.String genVar1580;
      genVar1580=".html";
      java.lang.String genVar1581;
      genVar1581=genVar1579 + genVar1580;
      a.setAttribute(genVar1578,genVar1581);
      java.lang.String genVar1582;
      genVar1582=title.getValue();
      a.setText(genVar1582);
    }
 catch (    ExlpXpathNotFoundException e) {
      java.lang.String genVar1583;
      genVar1583="";
      logger.debug(genVar1583,e);
    }
    java.lang.String genVar1584;
    genVar1584="li";
    Element li;
    li=new Element(genVar1584);
    li.setContent(a);
    return li;
  }
}
