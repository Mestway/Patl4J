package org.openfuxml.renderer.processor.html.table;
import org.jdom2.Element;
import org.jdom2.Text;
import org.openfuxml.content.ofx.Paragraph;
import org.openfuxml.content.table.Body;
import org.openfuxml.content.table.Cell;
import org.openfuxml.content.table.Content;
import org.openfuxml.content.table.Head;
import org.openfuxml.content.table.Row;
import org.openfuxml.content.table.Table;
import org.openfuxml.renderer.processor.html.interfaces.OfxTableRenderer;
import org.openfuxml.renderer.processor.html.section.ParagraphRenderer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class DefaultTableRenderer implements OfxTableRenderer {
  final static Logger logger=LoggerFactory.getLogger(DefaultTableRenderer.class);
  private Element table;
  private ParagraphRenderer paragraphRenderer;
  public DefaultTableRenderer(){
  }
  public Element render(  Table ofxTable){
    java.lang.String genVar1633;
    genVar1633="table";
    table=new Element(genVar1633);
    DefaultTableRenderer genVar1634;
    genVar1634=this;
    org.openfuxml.content.table.Content genVar1635;
    genVar1635=ofxTable.getContent();
    genVar1634.renderContent(genVar1635);
    return table;
  }
  private void renderContent(  Content content){
    DefaultTableRenderer genVar1636;
    genVar1636=this;
    org.openfuxml.content.table.Head genVar1637;
    genVar1637=content.getHead();
    genVar1636.renderHeader(genVar1637);
    java.util.List<org.openfuxml.content.table.Body> genVar1638;
    genVar1638=content.getBody();
    for (    Body body : genVar1638) {
      DefaultTableRenderer genVar1639;
      genVar1639=this;
      genVar1639.renderBody(body);
    }
  }
  private void renderHeader(  Head head){
    java.lang.String genVar1640;
    genVar1640="tr";
    Element tr;
    tr=new Element(genVar1640);
    java.util.List<org.openfuxml.content.table.Row> genVar1641;
    genVar1641=head.getRow();
    int genVar1642;
    genVar1642=0;
    org.openfuxml.content.table.Row genVar1643;
    genVar1643=genVar1641.get(genVar1642);
    java.util.List<org.openfuxml.content.table.Cell> genVar1644;
    genVar1644=genVar1643.getCell();
    for (    Cell cell : genVar1644) {
      DefaultTableRenderer genVar1645;
      genVar1645=this;
      java.lang.String genVar1646;
      genVar1646="th";
      Element tCell;
      tCell=genVar1645.renderCell(genVar1646,cell);
      tr.addContent(tCell);
    }
    java.lang.String genVar1647;
    genVar1647="thead";
    Element thead;
    thead=new Element(genVar1647);
    thead.addContent(tr);
    table.addContent(thead);
  }
  private void renderBody(  Body body){
    java.lang.String genVar1648;
    genVar1648="tbody";
    Element tbody;
    tbody=new Element(genVar1648);
    java.util.List<org.openfuxml.content.table.Row> genVar1649;
    genVar1649=body.getRow();
    for (    Row row : genVar1649) {
      DefaultTableRenderer genVar1650;
      genVar1650=this;
      org.jdom2.Element genVar1651;
      genVar1651=genVar1650.renderRow(row);
      tbody.addContent(genVar1651);
    }
    table.addContent(tbody);
  }
  private Element renderRow(  Row row){
    java.lang.String genVar1652;
    genVar1652="tr";
    Element tr;
    tr=new Element(genVar1652);
    java.util.List<org.openfuxml.content.table.Cell> genVar1653;
    genVar1653=row.getCell();
    for (    Cell cell : genVar1653) {
      DefaultTableRenderer genVar1654;
      genVar1654=this;
      java.lang.String genVar1655;
      genVar1655="td";
      Element tCell;
      tCell=genVar1654.renderCell(genVar1655,cell);
      tr.addContent(tCell);
    }
    return tr;
  }
  private Element renderCell(  String eName,  Cell cell){
    Element tCell;
    tCell=new Element(eName);
    java.util.List<java.lang.Object> genVar1656;
    genVar1656=cell.getContent();
    for (    Object o : genVar1656) {
      boolean genVar1657;
      genVar1657=o instanceof String;
      if (genVar1657) {
        java.lang.String genVar1658;
        genVar1658=(String)o;
        org.jdom2.Text genVar1659;
        genVar1659=new Text(genVar1658);
        tCell.addContent(genVar1659);
      }
 else {
        boolean genVar1660;
        genVar1660=o instanceof Paragraph;
        if (genVar1660) {
          DefaultTableRenderer genVar1661;
          genVar1661=this;
          org.openfuxml.renderer.processor.html.section.ParagraphRenderer genVar1662;
          genVar1662=genVar1661.getParagraphRenderer();
          org.openfuxml.content.ofx.Paragraph genVar1663;
          genVar1663=(Paragraph)o;
          org.jdom2.Content genVar1664;
          genVar1664=genVar1662.render(genVar1663);
          tCell.addContent(genVar1664);
        }
 else {
          java.lang.String genVar1665;
          genVar1665="Unknown content: ";
          java.lang.Class genVar1666;
          genVar1666=o.getClass();
          java.lang.String genVar1667;
          genVar1667=genVar1666.getName();
          java.lang.String genVar1668;
          genVar1668=genVar1665 + genVar1667;
          logger.warn(genVar1668);
        }
      }
    }
    return tCell;
  }
  private ParagraphRenderer getParagraphRenderer(){
    boolean genVar1669;
    genVar1669=paragraphRenderer == null;
    if (genVar1669) {
      paragraphRenderer=new ParagraphRenderer();
    }
 else {
      ;
    }
    return paragraphRenderer;
  }
}
