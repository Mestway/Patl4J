package org.openfuxml.renderer.data.exception;
public class OfxInternalProcessingException extends Exception {
}
