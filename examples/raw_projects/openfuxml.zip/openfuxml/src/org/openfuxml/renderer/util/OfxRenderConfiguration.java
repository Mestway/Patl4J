package org.openfuxml.renderer.util;
import java.io.File;
import net.sf.exlp.util.xml.JDomUtil;
import org.openfuxml.xml.renderer.cmp.Html;
import org.openfuxml.xml.renderer.html.Renderer;
public class OfxRenderConfiguration {
  public File getFile(  String htmlDir,  String htmlDirType,  String fileCode,  boolean bool){
    return null;
  }
  public Renderer getHtmlRenderer(  Html html,  Renderer renderer){
    return null;
  }
  public File getDir(  String dir,  String web){
    return null;
  }
}
