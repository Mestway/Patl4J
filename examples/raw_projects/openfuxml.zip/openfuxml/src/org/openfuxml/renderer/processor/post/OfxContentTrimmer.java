package org.openfuxml.renderer.processor.post;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.sf.exlp.util.config.ConfigLoader;
import net.sf.exlp.util.io.LoggerInit;
import net.sf.exlp.util.xml.JDomUtil;
import org.apache.commons.configuration.Configuration;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.Namespace;
import org.jdom2.xpath.XPath;
import org.openfuxml.exception.OfxInternalProcessingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class OfxContentTrimmer {
  final static Logger logger=LoggerFactory.getLogger(OfxContentTrimmer.class);
  private List<XPath> lXpath;
  public OfxContentTrimmer(){
    lXpath=new ArrayList<XPath>();
    try {
      java.lang.String genVar1670;
      genVar1670="ofx";
      java.lang.String genVar1671;
      genVar1671="http://www.openfuxml.org";
      Namespace nsOfx;
      nsOfx=Namespace.getNamespace(genVar1670,genVar1671);
      java.lang.String genVar1672;
      genVar1672="wiki";
      java.lang.String genVar1673;
      genVar1673="http://www.openfuxml.org/wiki";
      Namespace nsWiki;
      nsWiki=Namespace.getNamespace(genVar1672,genVar1673);
      java.lang.String genVar1674;
      genVar1674="//ofx:paragraph";
      XPath xpSections;
      xpSections=XPath.newInstance(genVar1674);
      xpSections.addNamespace(nsOfx);
      xpSections.addNamespace(nsWiki);
      lXpath.add(xpSections);
    }
 catch (    JDOMException e) {
      java.lang.String genVar1675;
      genVar1675="";
      logger.error(genVar1675,e);
    }
  }
  public Document trim(  Document doc) throws OfxInternalProcessingException {
    for (    XPath xpath : lXpath) {
      OfxContentTrimmer genVar1676;
      genVar1676=this;
      org.jdom2.Element genVar1677;
      genVar1677=doc.getRootElement();
      Element result;
      result=genVar1676.mergeRecursive(genVar1677,xpath);
      result.detach();
      doc.setRootElement(result);
    }
    return doc;
  }
  private Element mergeRecursive(  Element rootElement,  XPath xpath) throws OfxInternalProcessingException {
    try {
      List<?> list;
      list=xpath.selectNodes(rootElement);
      int genVar1678;
      genVar1678=list.size();
      java.lang.String genVar1679;
      genVar1679=" sections";
      java.lang.String genVar1680;
      genVar1680=genVar1678 + genVar1679;
      logger.debug(genVar1680);
      Iterator<?> iter;
      iter=list.iterator();
      for (; iter.hasNext(); ) {
        Object genVar1681;
        genVar1681=iter.next();
        Element e;
        e=(Element)genVar1681;
        java.util.List<org.jdom2.Element> genVar1682;
        genVar1682=e.getChildren();
        int genVar1683;
        genVar1683=genVar1682.size();
        int genVar1684;
        genVar1684=0;
        boolean genVar1685;
        genVar1685=genVar1683 == genVar1684;
        boolean noChilds;
        noChilds=(genVar1685);
        java.lang.String genVar1686;
        genVar1686=e.getText();
        int genVar1687;
        genVar1687=genVar1686.length();
        int genVar1688;
        genVar1688=0;
        boolean genVar1689;
        genVar1689=genVar1687 == genVar1688;
        boolean noContent;
        noContent=(genVar1689);
        java.lang.String genVar1690;
        genVar1690=e.getName();
        java.lang.String genVar1691;
        genVar1691=" ";
        java.util.List<org.jdom2.Element> genVar1692;
        genVar1692=e.getChildren();
        int genVar1693;
        genVar1693=genVar1692.size();
        java.lang.String genVar1694;
        genVar1694=" ";
        java.lang.String genVar1695;
        genVar1695=e.getText();
        int genVar1696;
        genVar1696=genVar1695.length();
        java.lang.String genVar1697;
        genVar1697=genVar1690 + genVar1691 + genVar1693+ genVar1694+ genVar1696;
        logger.trace(genVar1697);
        boolean genVar1698;
        genVar1698=noChilds && noContent;
        if (genVar1698) {
          e.detach();
        }
 else {
          java.lang.String genVar1699;
          genVar1699=e.getTextTrim();
          e.setText(genVar1699);
        }
      }
    }
 catch (    JDOMException e) {
      java.lang.String genVar1700;
      genVar1700="";
      logger.error(genVar1700,e);
    }
    return rootElement;
  }
  public static void main(  String[] args) throws Exception {
    java.lang.String genVar1701;
    genVar1701="log4j.xml";
    LoggerInit loggerInit;
    loggerInit=new LoggerInit(genVar1701);
    java.lang.String genVar1702;
    genVar1702="resources/config";
    loggerInit.addAltPath(genVar1702);
    loggerInit.init();
    String propFile;
    propFile="resources/properties/user.properties";
    int genVar1703;
    genVar1703=1;
    boolean genVar1704;
    genVar1704=args.length == genVar1703;
    if (genVar1704) {
      int genVar1705;
      genVar1705=0;
      propFile=args[genVar1705];
    }
 else {
      ;
    }
    ConfigLoader.add(propFile);
    Configuration config;
    config=ConfigLoader.init();
    java.lang.String genVar1706;
    genVar1706="wiki.processor.test.contenttrimmer";
    String fnOfx;
    fnOfx=config.getString(genVar1706);
    Document doc;
    doc=JDomUtil.load(fnOfx);
    OfxContentTrimmer test;
    test=new OfxContentTrimmer();
    test.trim(doc);
    JDomUtil.debug(doc);
  }
}
