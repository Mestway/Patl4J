package org.openfuxml.renderer.processor.html.header;
import net.sf.exlp.exception.ExlpXpathNotFoundException;
import org.jdom2.Content;
import org.jdom2.Text;
import org.openfuxml.content.ofx.Section;
import org.openfuxml.content.ofx.Title;
import org.openfuxml.renderer.processor.html.interfaces.OfxHeaderRenderer;
import org.openfuxml.xml.xpath.content.SectionXpath;
public class StringHeaderRenderer implements OfxHeaderRenderer {
  public Content render(  Section section){
    Title title;
    title=null;
    try {
      title=SectionXpath.getTitle(section);
    }
 catch (    ExlpXpathNotFoundException e) {
      e.printStackTrace();
    }
    java.lang.String genVar1568;
    genVar1568=title.getValue();
    org.jdom2.Text genVar1569;
    genVar1569=new Text(genVar1568);
    return genVar1569;
  }
}
