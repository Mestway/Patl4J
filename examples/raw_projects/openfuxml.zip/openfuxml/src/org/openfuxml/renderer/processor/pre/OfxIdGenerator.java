package org.openfuxml.renderer.processor.pre;
import java.io.File;
import java.util.Iterator;
import java.util.List;
import net.sf.exlp.util.xml.JDomUtil;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.Namespace;
import org.jdom2.output.Format;
import org.jdom2.xpath.XPath;
import org.openfuxml.exception.OfxInternalProcessingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class OfxIdGenerator {
  final static Logger logger=LoggerFactory.getLogger(OfxIdGenerator.class);
  private Document doc;
  private XPath xpath;
  private int autoId;
  public OfxIdGenerator(){
    autoId=1;
    try {
      java.lang.String genVar1707;
      genVar1707="//ofx:section";
      xpath=XPath.newInstance(genVar1707);
      java.lang.String genVar1708;
      genVar1708="ofx";
      java.lang.String genVar1709;
      genVar1709="http://www.openfuxml.org";
      org.jdom2.Namespace genVar1710;
      genVar1710=Namespace.getNamespace(genVar1708,genVar1709);
      xpath.addNamespace(genVar1710);
      java.lang.String genVar1711;
      genVar1711="wiki";
      java.lang.String genVar1712;
      genVar1712="http://www.openfuxml.org/wiki";
      org.jdom2.Namespace genVar1713;
      genVar1713=Namespace.getNamespace(genVar1711,genVar1712);
      xpath.addNamespace(genVar1713);
    }
 catch (    JDOMException e) {
      java.lang.String genVar1714;
      genVar1714="";
      logger.error(genVar1714,e);
    }
  }
  public void createIds(  File srcFile,  File dstFile) throws OfxInternalProcessingException {
    boolean genVar1715;
    genVar1715=srcFile == null;
    if (genVar1715) {
      java.lang.String genVar1716;
      genVar1716="FileNoteFound: ";
      java.lang.String genVar1717;
      genVar1717=srcFile.getAbsolutePath();
      java.lang.String genVar1718;
      genVar1718=genVar1716 + genVar1717;
      org.openfuxml.exception.OfxInternalProcessingException genVar1719;
      genVar1719=new OfxInternalProcessingException(genVar1718);
      throw genVar1719;
    }
 else {
      ;
    }
    doc=JDomUtil.load(srcFile);
    boolean genVar1720;
    genVar1720=doc == null;
    if (genVar1720) {
      java.lang.String genVar1721;
      genVar1721="FileNoteFound: ";
      java.lang.String genVar1722;
      genVar1722=srcFile.getAbsolutePath();
      java.lang.String genVar1723;
      genVar1723=genVar1721 + genVar1722;
      org.openfuxml.exception.OfxInternalProcessingException genVar1724;
      genVar1724=new OfxInternalProcessingException(genVar1723);
      throw genVar1724;
    }
 else {
      ;
    }
    try {
      OfxIdGenerator genVar1725;
      genVar1725=this;
      genVar1725.idCreator();
      org.jdom2.output.Format genVar1726;
      genVar1726=Format.getRawFormat();
      JDomUtil.save(doc,dstFile,genVar1726);
    }
 catch (    JDOMException e) {
      java.lang.String genVar1727;
      genVar1727="";
      logger.error(genVar1727,e);
    }
  }
  private void idCreator() throws JDOMException {
    org.jdom2.Element genVar1728;
    genVar1728=doc.getRootElement();
    List<?> list;
    list=xpath.selectNodes(genVar1728);
    int genVar1729;
    genVar1729=list.size();
    java.lang.String genVar1730;
    genVar1730=" sections for idTagging";
    java.lang.String genVar1731;
    genVar1731=genVar1729 + genVar1730;
    logger.debug(genVar1731);
    Iterator<?> iter;
    iter=list.iterator();
    for (; iter.hasNext(); ) {
      Object genVar1732;
      genVar1732=iter.next();
      Element e;
      e=(Element)genVar1732;
      java.lang.String genVar1733;
      genVar1733="id";
      org.jdom2.Attribute genVar1734;
      genVar1734=e.getAttribute(genVar1733);
      boolean genVar1735;
      genVar1735=genVar1734 == null;
      if (genVar1735) {
        java.lang.String genVar1736;
        genVar1736="id";
        java.lang.String genVar1737;
        genVar1737="autoId";
        java.lang.String genVar1738;
        genVar1738=genVar1737 + autoId;
        e.setAttribute(genVar1736,genVar1738);
        autoId++;
      }
 else {
        ;
      }
    }
  }
}
