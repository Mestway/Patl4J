package org.openfuxml.renderer.processor.pre;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.sf.exlp.util.io.LoggerInit;
import net.sf.exlp.util.xml.JDomUtil;
import net.sf.exlp.util.xml.JaxbUtil;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.Namespace;
import org.jdom2.xpath.XPath;
import org.openfuxml.content.ofx.Document;
import org.openfuxml.content.ofx.Section;
import org.openfuxml.content.ofx.Sections;
import org.openfuxml.content.ofx.Title;
import org.openfuxml.exception.OfxInternalProcessingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class OfxContainerMerger {
  final static Logger logger=LoggerFactory.getLogger(OfxContainerMerger.class);
  private List<XPath> lXpath;
  public OfxContainerMerger(){
    lXpath=new ArrayList<XPath>();
    try {
      java.lang.String genVar1739;
      genVar1739="ofx";
      java.lang.String genVar1740;
      genVar1740="http://www.openfuxml.org";
      Namespace nsOfx;
      nsOfx=Namespace.getNamespace(genVar1739,genVar1740);
      java.lang.String genVar1741;
      genVar1741="wiki";
      java.lang.String genVar1742;
      genVar1742="http://www.openfuxml.org/wiki";
      Namespace nsWiki;
      nsWiki=Namespace.getNamespace(genVar1741,genVar1742);
      java.lang.String genVar1743;
      genVar1743="//ofx:sections";
      XPath xpSections;
      xpSections=XPath.newInstance(genVar1743);
      xpSections.addNamespace(nsOfx);
      xpSections.addNamespace(nsWiki);
      lXpath.add(xpSections);
      java.lang.String genVar1744;
      genVar1744="//ofx:section[@container='true']";
      XPath xpSectionTransparent;
      xpSectionTransparent=XPath.newInstance(genVar1744);
      xpSectionTransparent.addNamespace(nsOfx);
      xpSectionTransparent.addNamespace(nsWiki);
      lXpath.add(xpSectionTransparent);
    }
 catch (    JDOMException e) {
      java.lang.String genVar1745;
      genVar1745="";
      logger.error(genVar1745,e);
    }
  }
  public Document merge(  Document ofxDoc) throws OfxInternalProcessingException {
    org.jdom2.Document doc;
    doc=JaxbUtil.toDocument(ofxDoc);
    for (    XPath xpath : lXpath) {
      OfxContainerMerger genVar1746;
      genVar1746=this;
      org.jdom2.Element genVar1747;
      genVar1747=doc.getRootElement();
      Element result;
      result=genVar1746.mergeRecursive(genVar1747,xpath);
      result.detach();
      doc.setRootElement(result);
    }
    java.lang.Class<org.openfuxml.content.ofx.Document> genVar1748;
    genVar1748=Document.class;
    java.lang.Object genVar1749;
    genVar1749=JDomUtil.toJaxb(doc,genVar1748);
    ofxDoc=(Document)genVar1749;
    return ofxDoc;
  }
  private Element mergeRecursive(  Element rootElement,  XPath xpath) throws OfxInternalProcessingException {
    try {
      List<?> list;
      list=xpath.selectNodes(rootElement);
      int genVar1750;
      genVar1750=list.size();
      java.lang.String genVar1751;
      genVar1751=" sections";
      java.lang.String genVar1752;
      genVar1752=genVar1750 + genVar1751;
      logger.debug(genVar1752);
      Iterator<?> iter;
      iter=list.iterator();
      for (; iter.hasNext(); ) {
        Object genVar1753;
        genVar1753=iter.next();
        Element e;
        e=(Element)genVar1753;
        org.jdom2.Element genVar1754;
        genVar1754=e.getParentElement();
        int index;
        index=genVar1754.indexOf(e);
        List<Element> lChilds;
        lChilds=new ArrayList<Element>();
        java.lang.String genVar1755;
        genVar1755=e.getName();
        java.lang.Class<org.openfuxml.content.ofx.Sections> genVar1756;
        genVar1756=Sections.class;
        java.lang.String genVar1757;
        genVar1757=genVar1756.getSimpleName();
        boolean genVar1758;
        genVar1758=genVar1755.equalsIgnoreCase(genVar1757);
        if (genVar1758) {
          OfxContainerMerger genVar1759;
          genVar1759=this;
          java.util.List<org.jdom2.Element> genVar1760;
          genVar1760=e.getChildren();
          lChilds=genVar1759.processSections(genVar1760);
        }
 else {
          java.lang.String genVar1761;
          genVar1761=e.getName();
          java.lang.Class<org.openfuxml.content.ofx.Section> genVar1762;
          genVar1762=Section.class;
          java.lang.String genVar1763;
          genVar1763=genVar1762.getSimpleName();
          boolean genVar1764;
          genVar1764=genVar1761.equalsIgnoreCase(genVar1763);
          if (genVar1764) {
            OfxContainerMerger genVar1765;
            genVar1765=this;
            java.util.List<org.jdom2.Element> genVar1766;
            genVar1766=e.getChildren();
            lChilds=genVar1765.processSection(genVar1766);
          }
 else {
            java.lang.String genVar1767;
            genVar1767="Root element <";
            java.lang.String genVar1768;
            genVar1768=e.getName();
            java.lang.String genVar1769;
            genVar1769="> of Wiki.Processing not expected";
            java.lang.String genVar1770;
            genVar1770=genVar1767 + genVar1768 + genVar1769;
            org.openfuxml.exception.OfxInternalProcessingException genVar1771;
            genVar1771=new OfxInternalProcessingException(genVar1770);
            throw genVar1771;
          }
        }
        org.jdom2.Element genVar1772;
        genVar1772=e.getParentElement();
        genVar1772.addContent(index,lChilds);
        org.jdom2.Element genVar1773;
        genVar1773=e.getParentElement();
        genVar1773.removeContent(e);
      }
    }
 catch (    JDOMException e) {
      java.lang.String genVar1774;
      genVar1774="";
      logger.error(genVar1774,e);
    }
    return rootElement;
  }
  private List<Element> processSections(  List<?> lChilds){
    List<Element> lSection;
    lSection=new ArrayList<Element>();
    for (    Object o : lChilds) {
      Element e;
      e=(Element)o;
      lSection.add(e);
    }
    for (    Element e : lSection) {
      e.detach();
    }
    return lSection;
  }
  private List<Element> processSection(  List<?> lChilds){
    List<Element> lSection;
    lSection=new ArrayList<Element>();
    for (    Object o : lChilds) {
      Element e;
      e=(Element)o;
      boolean add;
      add=true;
      java.lang.String genVar1775;
      genVar1775=e.getName();
      java.lang.Class<org.openfuxml.content.ofx.Title> genVar1776;
      genVar1776=Title.class;
      java.lang.String genVar1777;
      genVar1777=genVar1776.getSimpleName();
      boolean genVar1778;
      genVar1778=genVar1775.equalsIgnoreCase(genVar1777);
      if (genVar1778) {
        add=false;
      }
 else {
        ;
      }
      if (add) {
        lSection.add(e);
      }
 else {
        ;
      }
    }
    for (    Element e : lSection) {
      e.detach();
    }
    return lSection;
  }
  public static void main(  String[] args) throws Exception {
    java.lang.String genVar1779;
    genVar1779="log4j.xml";
    LoggerInit loggerInit;
    loggerInit=new LoggerInit(genVar1779);
    java.lang.String genVar1780;
    genVar1780="resources/config";
    loggerInit.addAltPath(genVar1780);
    loggerInit.init();
    java.lang.String genVar1781;
    genVar1781="Testing ExternalMerger";
    logger.debug(genVar1781);
    String fName;
    fName="resources/data/xml/preprocessor/merge/container/transparent.xml";
    int genVar1782;
    genVar1782=1;
    boolean genVar1783;
    genVar1783=args.length == genVar1782;
    if (genVar1783) {
      int genVar1784;
      genVar1784=0;
      fName=args[genVar1784];
    }
 else {
      ;
    }
    java.lang.Class<org.openfuxml.content.ofx.Document> genVar1785;
    genVar1785=Document.class;
    Document ofxDocOriginal;
    ofxDocOriginal=JaxbUtil.loadJAXB(fName,genVar1785);
    JaxbUtil.debug(ofxDocOriginal);
    OfxContainerMerger containerMerger;
    containerMerger=new OfxContainerMerger();
    Document ofxDocContainer;
    ofxDocContainer=containerMerger.merge(ofxDocOriginal);
    JaxbUtil.debug(ofxDocContainer);
  }
}
