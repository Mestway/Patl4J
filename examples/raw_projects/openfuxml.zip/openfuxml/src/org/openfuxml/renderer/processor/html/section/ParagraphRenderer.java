package org.openfuxml.renderer.processor.html.section;
import org.jdom2.Content;
import org.jdom2.Element;
import org.jdom2.Text;
import org.openfuxml.content.ofx.Paragraph;
import org.openfuxml.content.ofx.Reference;
import org.openfuxml.renderer.processor.html.structure.ReferenceRenderer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class ParagraphRenderer {
  final static Logger logger=LoggerFactory.getLogger(ParagraphRenderer.class);
  public ParagraphRenderer(){
  }
  public Content render(  Paragraph ofxParagraph){
    java.lang.String genVar1585;
    genVar1585="p";
    Element p;
    p=new Element(genVar1585);
    java.util.List<java.lang.Object> genVar1586;
    genVar1586=ofxParagraph.getContent();
    for (    Object o : genVar1586) {
      boolean genVar1587;
      genVar1587=o instanceof String;
      if (genVar1587) {
        java.lang.String genVar1588;
        genVar1588=(String)o;
        org.jdom2.Text genVar1589;
        genVar1589=new Text(genVar1588);
        p.addContent(genVar1589);
      }
 else {
        boolean genVar1590;
        genVar1590=o instanceof Reference;
        if (genVar1590) {
          ReferenceRenderer r;
          r=new ReferenceRenderer();
          org.openfuxml.content.ofx.Reference genVar1591;
          genVar1591=(Reference)o;
          org.jdom2.Content genVar1592;
          genVar1592=r.render(genVar1591);
          p.addContent(genVar1592);
        }
 else {
          java.lang.String genVar1593;
          genVar1593="Unknown content: ";
          java.lang.Class genVar1594;
          genVar1594=o.getClass();
          java.lang.String genVar1595;
          genVar1595=genVar1594.getSimpleName();
          java.lang.String genVar1596;
          genVar1596=genVar1593 + genVar1595;
          logger.warn(genVar1596);
        }
      }
    }
    return p;
  }
}
