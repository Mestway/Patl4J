package org.openfuxml.renderer.processor.html.section;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Collection;
import net.sf.exlp.util.xml.JDomUtil;
import net.sf.exlp.util.xml.JaxbUtil;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.openfuxml.content.ofx.Section;
import org.openfuxml.exception.OfxConfigurationException;
import org.openfuxml.exception.OfxInternalProcessingException;
import org.openfuxml.renderer.html.section.SectionRenderer;
import org.openfuxml.test.AbstractFileProcessingTest;
import org.openfuxml.test.OfxCoreTestBootstrap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@RunWith(Parameterized.class) public class TestSectionRenderer extends AbstractFileProcessingTest {
  final static Logger logger=LoggerFactory.getLogger(TestSectionRenderer.class);
  private SectionRenderer renderer;
  public static String srcDirName="src/test/resources/data/html/section/ofx";
  public static final String dstDirName="src/test/resources/data/html/section/web";
  public TestSectionRenderer(  File fTest){
    org.openfuxml.renderer.processor.html.section.TestSectionRenderer genVar1597;
    genVar1597=this;
    genVar1597.fTest=fTest;
    java.lang.String genVar1598;
    genVar1598=fTest.getName();
    int genVar1599;
    genVar1599=0;
    java.lang.String genVar1600;
    genVar1600=fTest.getName();
    int genVar1601;
    genVar1601=genVar1600.length();
    int genVar1602;
    genVar1602=4;
    int genVar1603;
    genVar1603=genVar1601 - genVar1602;
    String name;
    name=genVar1598.substring(genVar1599,genVar1603);
    java.lang.String genVar1604;
    genVar1604=".html";
    java.lang.String genVar1605;
    genVar1605=name + genVar1604;
    fRef=new File(dstDirName,genVar1605);
  }
  @Parameterized.Parameters public static Collection<Object[]> initFileNames(){
    java.lang.String genVar1607;
    genVar1607=".xml";
    java.util.Collection<java.lang.Object[]> genVar1608;
    genVar1608=TestSectionRenderer.initFileNames(srcDirName,genVar1607);
    return genVar1608;
  }
  public static Collection<Object[]> initFileNames(  String srcDirName,  String suffix){
    return null;
  }
  @Before public void init() throws FileNotFoundException, OfxConfigurationException, OfxInternalProcessingException {
    renderer=new SectionRenderer();
  }
  @After public void close(){
    renderer=null;
  }
  @Test public void render() throws OfxInternalProcessingException, FileNotFoundException {
    TestSectionRenderer genVar1609;
    genVar1609=this;
    boolean genVar1610;
    genVar1610=false;
    genVar1609.render(genVar1610);
  }
  private void render(  boolean saveReference) throws FileNotFoundException {
    java.lang.String genVar1611;
    genVar1611=fTest.getAbsolutePath();
    logger.debug(genVar1611);
    java.lang.String genVar1612;
    genVar1612=fTest.getAbsolutePath();
    java.lang.Class<org.openfuxml.content.ofx.Section> genVar1613;
    genVar1613=Section.class;
    org.openfuxml.content.ofx.Section genVar1614;
    genVar1614=JaxbUtil.loadJAXB(genVar1612,genVar1613);
    Section section;
    section=(Section)genVar1614;
    java.lang.String genVar1615;
    genVar1615="html";
    Element html;
    html=new Element(genVar1615);
    java.util.List<org.jdom2.Content> genVar1616;
    genVar1616=renderer.render(section);
    html.addContent(genVar1616);
    Document doc;
    doc=new Document();
    doc.setRootElement(html);
    if (saveReference) {
      org.jdom2.output.Format genVar1617;
      genVar1617=Format.getPrettyFormat();
      JDomUtil.save(doc,fRef,genVar1617);
    }
 else {
      Document docRef;
      docRef=JDomUtil.load(fRef);
      java.lang.String genVar1618;
      genVar1618=JDomUtil.toString(docRef);
      java.lang.String genVar1619;
      genVar1619=JDomUtil.toString(doc);
      Assert.assertEquals(genVar1618,genVar1619);
    }
  }
  public static void main(  String[] args) throws FileNotFoundException, OfxConfigurationException, OfxInternalProcessingException {
    OfxCoreTestBootstrap.init();
    boolean saveReference;
    saveReference=true;
    int id;
    id=3;
    int index;
    index=0;
    java.util.Collection<java.lang.Object[]> genVar1620;
    genVar1620=TestSectionRenderer.initFileNames();
    for (    Object[] o : genVar1620) {
      int genVar1621;
      genVar1621=0;
      java.lang.Object genVar1622;
      genVar1622=o[genVar1621];
      File fTest;
      fTest=(File)genVar1622;
      TestSectionRenderer test;
      test=new TestSectionRenderer(fTest);
      test.init();
      java.lang.String genVar1623;
      genVar1623=" ";
      java.lang.String genVar1624;
      genVar1624=id + genVar1623 + index;
      logger.trace(genVar1624);
      int genVar1625;
      genVar1625=0;
      boolean genVar1626;
      genVar1626=id < genVar1625;
      boolean genVar1627;
      genVar1627=id == index;
      boolean genVar1628;
      genVar1628=genVar1626 | genVar1627;
      if (genVar1628) {
        test.render(saveReference);
      }
 else {
        ;
      }
      test.close();
      index++;
    }
  }
}
