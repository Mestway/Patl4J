package org.openfuxml.renderer.processor.pre;
import java.io.File;
import org.jdom2.Document;
public class OfxExternalMerger {
  public OfxExternalMerger(  File f){
  }
  public Document mergeToDoc(){
    return null;
  }
}
