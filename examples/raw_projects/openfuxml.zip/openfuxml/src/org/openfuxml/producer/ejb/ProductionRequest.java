package org.openfuxml.producer.ejb;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom2.Document;
import org.jdom2.Element;
import org.openfuxml.communication.cluster.ejb.EjbObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import de.kisner.util.xml.XmlElementNotFoundException;
import de.kisner.util.xml.XmlObject;
@Entity public class ProductionRequest implements Serializable, EjbObject {
  final static Logger logger=LoggerFactory.getLogger(ProductionRequest.class);
  static final long serialVersionUID=2;
  public static enum Typ {  PRODUCE,   ENTITIES}
  public static enum Sync {  NOSYNC,   UNISON}
  private final static String rootElementName="sessionpreferences";
  private int id;
  private Typ typ;
  private Sync sync;
  private Date record;
  private String application, project, format, document, username;
  private Collection<ProductionRequestEntityFile> entityFiles;
  private Collection<FormatOption> formatOptions;
  private Collection<SyncLocation> syncLocations;
  @Id @GeneratedValue(strategy=GenerationType.AUTO) public int getId(){
    return id;
  }
  public void setId(  int id){
    org.openfuxml.producer.ejb.ProductionRequest genVar1243;
    genVar1243=this;
    genVar1243.id=id;
  }
  @OneToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER,mappedBy="productionRequest") public Collection<ProductionRequestEntityFile> getEntityFiles(){
    return entityFiles;
  }
  public void setEntityFiles(  Collection<ProductionRequestEntityFile> entityFiles){
    org.openfuxml.producer.ejb.ProductionRequest genVar1244;
    genVar1244=this;
    genVar1244.entityFiles=entityFiles;
  }
  @OneToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER,mappedBy="productionRequest") public Collection<SyncLocation> getSyncLocations(){
    return syncLocations;
  }
  public void setSyncLocations(  Collection<SyncLocation> syncLocations){
    org.openfuxml.producer.ejb.ProductionRequest genVar1245;
    genVar1245=this;
    genVar1245.syncLocations=syncLocations;
  }
  public Collection<FormatOption> getFormatOptions(){
    return formatOptions;
  }
  public void setFormatOptions(  Collection<FormatOption> formatOptions){
    org.openfuxml.producer.ejb.ProductionRequest genVar1246;
    genVar1246=this;
    genVar1246.formatOptions=formatOptions;
  }
  public String getApplication(){
    return application;
  }
  public void setApplication(  String application){
    org.openfuxml.producer.ejb.ProductionRequest genVar1247;
    genVar1247=this;
    genVar1247.application=application;
  }
  public String getDocument(){
    return document;
  }
  public void setDocument(  String document){
    org.openfuxml.producer.ejb.ProductionRequest genVar1248;
    genVar1248=this;
    genVar1248.document=document;
  }
  public String getProject(){
    return project;
  }
  public void setProject(  String project){
    org.openfuxml.producer.ejb.ProductionRequest genVar1249;
    genVar1249=this;
    genVar1249.project=project;
  }
  public Date getRecord(){
    return record;
  }
  public void setRecord(  Date record){
    org.openfuxml.producer.ejb.ProductionRequest genVar1250;
    genVar1250=this;
    genVar1250.record=record;
  }
  public String getUsername(){
    return username;
  }
  public void setUsername(  String username){
    org.openfuxml.producer.ejb.ProductionRequest genVar1251;
    genVar1251=this;
    genVar1251.username=username;
  }
  public String getFormat(){
    return format;
  }
  public void setFormat(  String format){
    org.openfuxml.producer.ejb.ProductionRequest genVar1252;
    genVar1252=this;
    genVar1252.format=format;
  }
  public Typ getTyp(){
    return typ;
  }
  public void setTyp(  Typ typ){
    org.openfuxml.producer.ejb.ProductionRequest genVar1253;
    genVar1253=this;
    genVar1253.typ=typ;
  }
  public Sync getSync(){
    return sync;
  }
  public void setSync(  Sync sync){
    org.openfuxml.producer.ejb.ProductionRequest genVar1254;
    genVar1254=this;
    genVar1254.sync=sync;
  }
  public void loadXML(  File xmlFile) throws XmlElementNotFoundException {
    XmlObject xO;
    xO=new XmlObject();
    xO.load(xmlFile);
    ProductionRequest genVar1255;
    genVar1255=this;
    java.lang.String genVar1256;
    genVar1256="application";
    java.lang.String genVar1257;
    genVar1257=xO.getText(genVar1256);
    genVar1255.setApplication(genVar1257);
    ProductionRequest genVar1258;
    genVar1258=this;
    java.lang.String genVar1259;
    genVar1259="project";
    java.lang.String genVar1260;
    genVar1260=xO.getText(genVar1259);
    genVar1258.setProject(genVar1260);
    ProductionRequest genVar1261;
    genVar1261=this;
    java.lang.String genVar1262;
    genVar1262="document";
    java.lang.String genVar1263;
    genVar1263=xO.getText(genVar1262);
    genVar1261.setDocument(genVar1263);
    ProductionRequest genVar1264;
    genVar1264=this;
    java.lang.String genVar1265;
    genVar1265="format";
    java.lang.String genVar1266;
    genVar1266=xO.getText(genVar1265);
    genVar1264.setFormat(genVar1266);
    ProductionRequest genVar1267;
    genVar1267=this;
    java.lang.String genVar1268;
    genVar1268="username";
    java.lang.String genVar1269;
    genVar1269=xO.getText(genVar1268);
    genVar1267.setUsername(genVar1269);
switch (typ) {
case ENTITIES:
      logger.warn("Das Laden eines ENTITIES-ProductionRequests ist nicht getestet!!!!");
    break;
}
entityFiles=new ArrayList<ProductionRequestEntityFile>();
java.lang.String genVar1270;
genVar1270="productionentities/file";
java.util.List<org.jdom2.Element> genVar1271;
genVar1271=xO.getElements(genVar1270);
for (Element elFile : genVar1271) {
  ProductionRequestEntityFile pef;
  pef=new ProductionRequestEntityFile();
  pef.init(elFile);
  org.openfuxml.producer.ejb.ProductionRequest genVar1272;
  genVar1272=this;
  pef.setProductionRequest(genVar1272);
  entityFiles.add(pef);
}
ArrayList<Element> alOptions;
alOptions=new ArrayList<Element>();
try {
  java.lang.String genVar1273;
  genVar1273="options/option";
  java.util.List<org.jdom2.Element> genVar1274;
  genVar1274=xO.getElements(genVar1273);
  alOptions=(ArrayList<Element>)genVar1274;
}
 catch (XmlElementNotFoundException e) {
}
for (Element elFormatOption : alOptions) {
  FormatOption fo;
  fo=new FormatOption();
  fo.init(elFormatOption);
  ProductionRequest genVar1275;
  genVar1275=this;
  genVar1275.addFormatOption(fo);
}
}
public Document toXmlDoc(){
ProductionRequest genVar1276;
genVar1276=this;
org.jdom2.Element genVar1277;
genVar1277=genVar1276.toXmlElement();
Document xmlDoc;
xmlDoc=new Document(genVar1277);
return xmlDoc;
}
public String toDocumentName(){
java.lang.String genVar1278;
genVar1278=".xml";
int suffixindex;
suffixindex=document.indexOf(genVar1278);
int genVar1279;
genVar1279=0;
java.lang.String genVar1280;
genVar1280=document.substring(genVar1279,suffixindex);
return genVar1280;
}
public Element toXmlElement(){
Element elSessionpreferences;
elSessionpreferences=new Element(rootElementName);
java.lang.String genVar1281;
genVar1281="application";
Element elApplication;
elApplication=new Element(genVar1281);
java.lang.String genVar1282;
genVar1282="project";
Element elProject;
elProject=new Element(genVar1282);
java.lang.String genVar1283;
genVar1283="document";
Element elDocument;
elDocument=new Element(genVar1283);
java.lang.String genVar1284;
genVar1284="username";
Element elUsername;
elUsername=new Element(genVar1284);
java.lang.String genVar1285;
genVar1285="format";
Element elFormat;
elFormat=new Element(genVar1285);
elApplication.setText(application);
elProject.setText(project);
elDocument.setText(document);
elUsername.setText(username);
elFormat.setText(format);
elSessionpreferences.addContent(elApplication);
elSessionpreferences.addContent(elProject);
elSessionpreferences.addContent(elDocument);
elSessionpreferences.addContent(elUsername);
elSessionpreferences.addContent(elFormat);
boolean genVar1286;
genVar1286=sync != Sync.NOSYNC;
boolean genVar1287;
genVar1287=syncLocations != null;
boolean genVar1288;
genVar1288=genVar1286 && genVar1287;
int genVar1289;
genVar1289=syncLocations.size();
int genVar1290;
genVar1290=0;
boolean genVar1291;
genVar1291=genVar1289 > genVar1290;
boolean genVar1292;
genVar1292=genVar1288 && genVar1291;
if (genVar1292) {
  java.lang.String genVar1293;
  genVar1293="sync";
  Element elSync;
  elSync=new Element(genVar1293);
  java.lang.String genVar1294;
  genVar1294="typ";
  java.lang.String genVar1295;
  genVar1295=sync.name();
  elSync.setAttribute(genVar1294,genVar1295);
  for (  SyncLocation sl : syncLocations) {
    org.jdom2.Element genVar1296;
    genVar1296=sl.toXML();
    elSync.addContent(genVar1296);
  }
  elSessionpreferences.addContent(elSync);
}
 else {
  ;
}
switch (typ) {
case PRODUCE:
  if (entityFiles != null && entityFiles.size() > 0) {
    Element elProductionentities=new Element("productionentities");
    for (    ProductionRequestEntityFile ef : entityFiles) {
      elProductionentities.addContent(ef.toXML());
    }
    elSessionpreferences.addContent(elProductionentities);
  }
if (formatOptions != null && formatOptions.size() > 0) {
  Element elFormatOptions=new Element("options");
  for (  FormatOption fo : formatOptions) {
    elFormatOptions.addContent(fo.toXML());
  }
  elSessionpreferences.addContent(elFormatOptions);
}
break;
}
return elSessionpreferences;
}
public void addEntityFile(ProductionRequestEntityFile ef){
boolean genVar1297;
genVar1297=entityFiles == null;
if (genVar1297) {
entityFiles=new ArrayList<ProductionRequestEntityFile>();
}
 else {
;
}
entityFiles.add(ef);
}
public void addFormatOption(FormatOption fo){
boolean genVar1298;
genVar1298=formatOptions == null;
if (genVar1298) {
formatOptions=new ArrayList<FormatOption>();
}
 else {
;
}
formatOptions.add(fo);
}
public void addSyncLocation(String url,SyncLocation.Typ typ){
SyncLocation sl;
sl=new SyncLocation();
org.openfuxml.producer.ejb.ProductionRequest genVar1299;
genVar1299=this;
sl.setProductionRequest(genVar1299);
sl.setTyp(typ);
sl.setUrl(url);
boolean genVar1300;
genVar1300=syncLocations == null;
if (genVar1300) {
syncLocations=new ArrayList<SyncLocation>();
}
 else {
;
}
syncLocations.add(sl);
}
}
