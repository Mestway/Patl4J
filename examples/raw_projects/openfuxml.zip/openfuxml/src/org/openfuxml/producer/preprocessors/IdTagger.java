package org.openfuxml.producer.preprocessors;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.sf.exlp.util.io.LoggerInit;
import net.sf.exlp.util.xml.JDomUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom2.Attribute;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.Namespace;
import org.jdom2.xpath.XPath;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class IdTagger {
  final static Logger logger=LoggerFactory.getLogger(IdTagger.class);
  private Namespace ns;
  private XPath xpath;
  private int idCounter;
  private List<String> alElementNames;
  public IdTagger(){
    java.lang.String genVar1382;
    genVar1382="ofx";
    java.lang.String genVar1383;
    genVar1383="http://www.openfuxml.org";
    ns=Namespace.getNamespace(genVar1382,genVar1383);
    alElementNames=new ArrayList<String>();
    java.lang.String genVar1384;
    genVar1384="section";
    alElementNames.add(genVar1384);
  }
  public void tag(  Document doc){
    for (    String eName : alElementNames) {
      try {
        java.lang.String genVar1385;
        genVar1385="//ofx:";
        java.lang.String genVar1386;
        genVar1386=genVar1385 + eName;
        xpath=XPath.newInstance(genVar1386);
        xpath.addNamespace(ns);
        IdTagger genVar1387;
        genVar1387=this;
        org.jdom2.Element genVar1388;
        genVar1388=doc.getRootElement();
        genVar1387.idTag(genVar1388,eName);
      }
 catch (      JDOMException e) {
        java.lang.String genVar1389;
        genVar1389="";
        logger.error(genVar1389,e);
      }
    }
  }
  private void idTag(  Element rootElement,  String idPrefix){
    idCounter=0;
    try {
      List<?> list;
      list=xpath.selectNodes(rootElement);
      Iterator<?> iter;
      iter=list.iterator();
      for (; iter.hasNext(); ) {
        Object genVar1390;
        genVar1390=iter.next();
        Element childElement;
        childElement=(Element)genVar1390;
        java.lang.String genVar1391;
        genVar1391="id";
        Attribute att;
        att=childElement.getAttribute(genVar1391);
        boolean genVar1392;
        genVar1392=att != null;
        if (genVar1392) {
          java.lang.String genVar1393;
          genVar1393=att.getValue();
          int genVar1394;
          genVar1394=genVar1393.length();
          int genVar1395;
          genVar1395=0;
          boolean genVar1396;
          genVar1396=genVar1394 == genVar1395;
          if (genVar1396) {
            IdTagger genVar1397;
            genVar1397=this;
            genVar1397.addId(childElement,idPrefix);
          }
 else {
            ;
          }
        }
 else {
          boolean genVar1398;
          genVar1398=att == null;
          if (genVar1398) {
            IdTagger genVar1399;
            genVar1399=this;
            genVar1399.addId(childElement,idPrefix);
          }
 else {
            ;
          }
        }
      }
    }
 catch (    JDOMException e) {
      java.lang.String genVar1400;
      genVar1400="";
      logger.error(genVar1400,e);
    }
    java.lang.String genVar1401;
    genVar1401=" ids generated for ";
    java.lang.String genVar1402;
    genVar1402=idCounter + genVar1401 + idPrefix;
    logger.debug(genVar1402);
  }
  private void addId(  Element e,  String idPrefix){
    idCounter++;
    java.lang.String genVar1403;
    genVar1403="id";
    java.lang.String genVar1404;
    genVar1404="-";
    java.lang.String genVar1405;
    genVar1405="-auto";
    java.lang.String genVar1406;
    genVar1406=idPrefix + genVar1404 + idCounter+ genVar1405;
    e.setAttribute(genVar1403,genVar1406);
  }
  public static void main(  String[] args) throws Exception {
    java.lang.String genVar1407;
    genVar1407="log4j.xml";
    LoggerInit loggerInit;
    loggerInit=new LoggerInit(genVar1407);
    java.lang.String genVar1408;
    genVar1408="resources/config";
    loggerInit.addAltPath(genVar1408);
    loggerInit.init();
    java.lang.String genVar1409;
    genVar1409="Testing ExternalMerger";
    logger.debug(genVar1409);
    java.lang.String genVar1410;
    genVar1410="resources/data/xml/exmerge/chapter-1.xml";
    File f;
    f=new File(genVar1410);
    Document doc;
    doc=JDomUtil.load(f);
    IdTagger idTagger;
    idTagger=new IdTagger();
    idTagger.tag(doc);
    JDomUtil.debug(doc);
  }
}
