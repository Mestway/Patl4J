package org.openfuxml.producer.postprocessors;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.sf.exlp.util.io.LoggerInit;
import org.apache.commons.io.DirectoryWalker;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.filefilter.FileFilterUtils;
import org.apache.commons.io.filefilter.HiddenFileFilter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.htmlcleaner.CleanerProperties;
import org.htmlcleaner.CleanerTransformations;
import org.htmlcleaner.HtmlCleaner;
import org.htmlcleaner.JDomSerializer;
import org.htmlcleaner.TagNode;
import org.htmlcleaner.TagTransformation;
import org.jdom2.Document;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
import org.openfuxml.util.OfxApp;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class HtmlPrettyFormatter extends DirectoryWalker {
  final static Logger logger=LoggerFactory.getLogger(OfxApp.class);
  private CleanerTransformations ct;
  public HtmlPrettyFormatter(  String suffix){
    HtmlPrettyFormatter genVar1346;
    genVar1346=this;
    genVar1346.initCT();
  }
  private void initCT(){
    ct=new CleanerTransformations();
    java.lang.String genVar1347;
    genVar1347="div";
    java.lang.String genVar1348;
    genVar1348="div";
    boolean genVar1349;
    genVar1349=true;
    TagTransformation tt;
    tt=new TagTransformation(genVar1347,genVar1348,genVar1349);
    java.lang.String genVar1350;
    genVar1350="xmlns:saxon";
    tt.addAttributeTransformation(genVar1350);
    java.lang.String genVar1351;
    genVar1351="xmlns:xs";
    tt.addAttributeTransformation(genVar1351);
    ct.addTransformation(tt);
  }
  @SuppressWarnings("unchecked") protected void handleFile(  File file,  int depth,  Collection results){
    java.lang.String genVar1352;
    genVar1352=file.getAbsolutePath();
    java.lang.String genVar1353;
    genVar1353=FilenameUtils.normalize(genVar1352);
    File f;
    f=new File(genVar1353);
    try {
      HtmlCleaner cleaner;
      cleaner=new HtmlCleaner();
      CleanerProperties props;
      props=cleaner.getProperties();
      boolean genVar1354;
      genVar1354=false;
      props.setAdvancedXmlEscape(genVar1354);
      TagNode node;
      node=cleaner.clean(f);
      boolean genVar1355;
      genVar1355=false;
      org.htmlcleaner.TagNode[] genVar1356;
      genVar1356=node.getAllElements(genVar1355);
      int genVar1357;
      genVar1357=1;
      TagNode tnBody;
      tnBody=genVar1356[genVar1357];
      List l;
      l=tnBody.getChildren();
      boolean genVar1358;
      genVar1358=l != null;
      int genVar1359;
      genVar1359=l.size();
      int genVar1360;
      genVar1360=0;
      boolean genVar1361;
      genVar1361=genVar1359 > genVar1360;
      boolean genVar1362;
      genVar1362=genVar1358 && genVar1361;
      if (genVar1362) {
        int genVar1363;
        genVar1363=0;
        java.lang.Object genVar1364;
        genVar1364=l.get(genVar1363);
        tnBody.removeChild(genVar1364);
      }
 else {
        ;
      }
      boolean genVar1365;
      genVar1365=true;
      org.htmlcleaner.JDomSerializer genVar1366;
      genVar1366=new JDomSerializer(props,genVar1365);
      Document myJDom;
      myJDom=genVar1366.createJDom(node);
      Format format;
      format=Format.getRawFormat();
      java.lang.String genVar1367;
      genVar1367="iso-8859-1";
      format.setEncoding(genVar1367);
      XMLOutputter outputter;
      outputter=new XMLOutputter(format);
      OutputStream os;
      os=new FileOutputStream(f);
      outputter.output(myJDom,os);
      java.io.File genVar1368;
      genVar1368=f.getAbsoluteFile();
      results.add(genVar1368);
    }
 catch (    IOException e) {
      java.lang.String genVar1369;
      genVar1369="";
      logger.error(genVar1369,e);
    }
  }
  public void start(  File startDir,  Collection results){
    try {
      HtmlPrettyFormatter genVar1370;
      genVar1370=this;
      genVar1370.walk(startDir,results);
    }
 catch (    IOException e) {
      java.lang.String genVar1371;
      genVar1371="";
      logger.error(genVar1371,e);
    }
    java.lang.String genVar1372;
    genVar1372="Processed files: ";
    int genVar1373;
    genVar1373=results.size();
    java.lang.String genVar1374;
    genVar1374=genVar1372 + genVar1373;
    logger.debug(genVar1374);
  }
  public static void main(  String args[]){
    java.lang.String genVar1375;
    genVar1375="log4j.xml";
    LoggerInit loggerInit;
    loggerInit=new LoggerInit(genVar1375);
    java.lang.String genVar1376;
    genVar1376="resources/config";
    loggerInit.addAltPath(genVar1376);
    loggerInit.init();
    java.lang.String genVar1377;
    genVar1377="/Users/thorsten/Documents/workspace/openfuxml/output/fuxml/jWan/html/jWAN";
    File f;
    f=new File(genVar1377);
    Collection<String> c;
    c=new ArrayList<String>();
    java.lang.String genVar1378;
    genVar1378="html";
    HtmlPrettyFormatter hpf;
    hpf=new HtmlPrettyFormatter(genVar1378);
    hpf.start(f,c);
    java.lang.String genVar1379;
    genVar1379="Processed files: ";
    int genVar1380;
    genVar1380=c.size();
    java.lang.String genVar1381;
    genVar1381=genVar1379 + genVar1380;
    logger.debug(genVar1381);
  }
}
