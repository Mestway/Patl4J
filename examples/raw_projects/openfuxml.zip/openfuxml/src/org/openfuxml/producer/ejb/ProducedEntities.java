package org.openfuxml.producer.ejb;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom2.Document;
import org.jdom2.Element;
import org.openfuxml.communication.cluster.ejb.EjbObject;
import org.openfuxml.producer.ejb.ProductionRequest.Typ;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import de.kisner.util.xml.XmlElementNotFoundException;
import de.kisner.util.xml.XmlObject;
@Entity public class ProducedEntities implements Serializable, EjbObject {
  final static Logger logger=LoggerFactory.getLogger(ProducedEntities.class);
  static final long serialVersionUID=1;
  private int id;
  private Typ typ;
  private Date record;
  private String logfile;
  private Collection<ProducedEntitiesEntityFile> entityFiles;
  @Id @GeneratedValue(strategy=GenerationType.AUTO) public int getId(){
    return id;
  }
  public void setId(  int id){
    org.openfuxml.producer.ejb.ProducedEntities genVar1310;
    genVar1310=this;
    genVar1310.id=id;
  }
  @OneToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER,mappedBy="producibleEntities") public Collection<ProducedEntitiesEntityFile> getEntityFiles(){
    return entityFiles;
  }
  public void setEntityFiles(  Collection<ProducedEntitiesEntityFile> entityFiles){
    org.openfuxml.producer.ejb.ProducedEntities genVar1311;
    genVar1311=this;
    genVar1311.entityFiles=entityFiles;
  }
  public Typ getTyp(){
    return typ;
  }
  public void setTyp(  Typ typ){
    org.openfuxml.producer.ejb.ProducedEntities genVar1312;
    genVar1312=this;
    genVar1312.typ=typ;
  }
  public Date getRecord(){
    return record;
  }
  public void setRecord(  Date record){
    org.openfuxml.producer.ejb.ProducedEntities genVar1313;
    genVar1313=this;
    genVar1313.record=record;
  }
  public String getLogfile(){
    return logfile;
  }
  public void setLogfile(  String logfile){
    org.openfuxml.producer.ejb.ProducedEntities genVar1314;
    genVar1314=this;
    genVar1314.logfile=logfile;
  }
  public void loadXML(  File xmlFile) throws XmlElementNotFoundException {
    XmlObject xO;
    xO=new XmlObject();
    java.lang.String genVar1315;
    genVar1315="UTF-8";
    xO.load(xmlFile,genVar1315);
    java.lang.String genVar1316;
    genVar1316="";
    java.lang.String genVar1317;
    genVar1317="logfile";
    logfile=xO.getAttribute(genVar1316,genVar1317);
    String xPathFile;
    xPathFile=null;
switch (typ) {
case ENTITIES:
      xPathFile="file";
    break;
case PRODUCE:
  xPathFile="producedentities/file";
break;
}
entityFiles=new ArrayList<ProducedEntitiesEntityFile>();
java.util.List<org.jdom2.Element> genVar1318;
genVar1318=xO.getElements(xPathFile);
for (Element elFile : genVar1318) {
ProducedEntitiesEntityFile pef;
pef=new ProducedEntitiesEntityFile();
pef.init(elFile);
org.openfuxml.producer.ejb.ProducedEntities genVar1319;
genVar1319=this;
pef.setProducibleEntities(genVar1319);
entityFiles.add(pef);
}
}
public Document toXmlDoc(){
ProducedEntities genVar1320;
genVar1320=this;
org.jdom2.Element genVar1321;
genVar1321=genVar1320.toXmlElement();
Document xmlDoc;
xmlDoc=new Document(genVar1321);
return xmlDoc;
}
public Element toXmlElement(){
ProducedEntities genVar1322;
genVar1322=this;
java.lang.String genVar1323;
genVar1323=genVar1322.obtainRootElementName();
Element elRoot;
elRoot=new Element(genVar1323);
java.lang.String genVar1324;
genVar1324="logfile";
elRoot.setAttribute(genVar1324,logfile);
boolean genVar1325;
genVar1325=entityFiles != null;
int genVar1326;
genVar1326=entityFiles.size();
int genVar1327;
genVar1327=0;
boolean genVar1328;
genVar1328=genVar1326 > genVar1327;
boolean genVar1329;
genVar1329=genVar1325 && genVar1328;
if (genVar1329) {
switch (typ) {
case ENTITIES:
for (ProducedEntitiesEntityFile pef : entityFiles) {
  elRoot.addContent(pef.toXML());
}
;
break;
case PRODUCE:
Element elPe=new Element("producedentities");
for (ProducedEntitiesEntityFile pef : entityFiles) {
elPe.addContent(pef.toXML());
}
elRoot.addContent(elPe);
break;
}
}
 else {
;
}
return elRoot;
}
private String obtainRootElementName(){
String rootElementName;
rootElementName=null;
switch (typ) {
case ENTITIES:
rootElementName="producibleEntities";
break;
case PRODUCE:
rootElementName="productionresult";
break;
}
return rootElementName;
}
}
