package org.openfuxml.producer.ejb;
import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import org.jdom2.Element;
@Entity public class FormatOption implements Serializable {
  static final long serialVersionUID=1;
  private int id;
  private String displayname, name, type;
  private boolean value;
  private String description;
  @Id @GeneratedValue(strategy=GenerationType.AUTO) public int getId(){
    return id;
  }
  public void setId(  int id){
    org.openfuxml.producer.ejb.FormatOption genVar1219;
    genVar1219=this;
    genVar1219.id=id;
  }
  public String getDescription(){
    return description;
  }
  public void setDescription(  String description){
    org.openfuxml.producer.ejb.FormatOption genVar1220;
    genVar1220=this;
    genVar1220.description=description;
  }
  public String getDisplayname(){
    return displayname;
  }
  public void setDisplayname(  String displayname){
    org.openfuxml.producer.ejb.FormatOption genVar1221;
    genVar1221=this;
    genVar1221.displayname=displayname;
  }
  public String getName(){
    return name;
  }
  public void setName(  String name){
    org.openfuxml.producer.ejb.FormatOption genVar1222;
    genVar1222=this;
    genVar1222.name=name;
  }
  public String getType(){
    return type;
  }
  public void setType(  String type){
    org.openfuxml.producer.ejb.FormatOption genVar1223;
    genVar1223=this;
    genVar1223.type=type;
  }
  public boolean isValue(){
    return value;
  }
  public void setValue(  boolean value){
    org.openfuxml.producer.ejb.FormatOption genVar1224;
    genVar1224=this;
    genVar1224.value=value;
  }
  public void init(  Element option){
    java.lang.String genVar1225;
    genVar1225="name";
    name=option.getAttributeValue(genVar1225);
    java.lang.String genVar1226;
    genVar1226="type";
    type=option.getAttributeValue(genVar1226);
    java.lang.String genVar1227;
    genVar1227="value";
    java.lang.String genVar1228;
    genVar1228=option.getAttributeValue(genVar1227);
    value=new Boolean(genVar1228);
    java.lang.String genVar1229;
    genVar1229="displayname";
    displayname=option.getAttributeValue(genVar1229);
    java.lang.String genVar1230;
    genVar1230="description";
    Element elDescription;
    elDescription=option.getChild(genVar1230);
    boolean genVar1231;
    genVar1231=elDescription != null;
    if (genVar1231) {
      description=elDescription.getText();
    }
 else {
      ;
    }
  }
  public Element toXML(){
    java.lang.String genVar1232;
    genVar1232="option";
    Element option;
    option=new Element(genVar1232);
    java.lang.String genVar1233;
    genVar1233="name";
    option.setAttribute(genVar1233,name);
    boolean genVar1234;
    genVar1234=type != null;
    if (genVar1234) {
      java.lang.String genVar1235;
      genVar1235="type";
      option.setAttribute(genVar1235,type);
    }
 else {
      ;
    }
    java.lang.String genVar1236;
    genVar1236="value";
    java.lang.String genVar1237;
    genVar1237="";
    java.lang.String genVar1238;
    genVar1238=genVar1237 + value;
    option.setAttribute(genVar1236,genVar1238);
    boolean genVar1239;
    genVar1239=displayname != null;
    if (genVar1239) {
      java.lang.String genVar1240;
      genVar1240="displayname";
      option.setAttribute(genVar1240,displayname);
    }
 else {
      ;
    }
    boolean genVar1241;
    genVar1241=description != null;
    if (genVar1241) {
      java.lang.String genVar1242;
      genVar1242="description";
      Element elDescription;
      elDescription=new Element(genVar1242);
      elDescription.addContent(description);
      option.addContent(elDescription);
    }
 else {
      ;
    }
    return option;
  }
}
