package org.openfuxml.producer.ejb;
import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import org.jdom2.Element;
import org.openfuxml.communication.cluster.ejb.EjbObject;
@Entity public class ProducedEntitiesEntityFile implements Serializable, EjbObject {
  static final long serialVersionUID=1;
  private int id;
  private ProducedEntities producibleEntities;
  private String directory, filename, description;
  @Id @GeneratedValue(strategy=GenerationType.AUTO) public int getId(){
    return id;
  }
  public void setId(  int id){
    org.openfuxml.producer.ejb.ProducedEntitiesEntityFile genVar1330;
    genVar1330=this;
    genVar1330.id=id;
  }
  @ManyToOne public ProducedEntities getProducibleEntities(){
    return producibleEntities;
  }
  public void setProducibleEntities(  ProducedEntities producibleEntities){
    org.openfuxml.producer.ejb.ProducedEntitiesEntityFile genVar1331;
    genVar1331=this;
    genVar1331.producibleEntities=producibleEntities;
  }
  public String getDescription(){
    return description;
  }
  public void setDescription(  String description){
    org.openfuxml.producer.ejb.ProducedEntitiesEntityFile genVar1332;
    genVar1332=this;
    genVar1332.description=description;
  }
  public String getDirectory(){
    return directory;
  }
  public void setDirectory(  String directory){
    org.openfuxml.producer.ejb.ProducedEntitiesEntityFile genVar1333;
    genVar1333=this;
    genVar1333.directory=directory;
  }
  public String getFilename(){
    return filename;
  }
  public void setFilename(  String filename){
    org.openfuxml.producer.ejb.ProducedEntitiesEntityFile genVar1334;
    genVar1334=this;
    genVar1334.filename=filename;
  }
  public void init(  Element elFile){
    java.lang.String genVar1335;
    genVar1335="directory";
    directory=elFile.getAttributeValue(genVar1335);
    java.lang.String genVar1336;
    genVar1336="filename";
    filename=elFile.getAttributeValue(genVar1336);
    java.lang.String genVar1337;
    genVar1337="description";
    Element elDescription;
    elDescription=elFile.getChild(genVar1337);
    description=elDescription.getText();
  }
  public Element toXML(){
    java.lang.String genVar1338;
    genVar1338="file";
    Element elFile;
    elFile=new Element(genVar1338);
    java.lang.String genVar1339;
    genVar1339="directory";
    elFile.setAttribute(genVar1339,directory);
    java.lang.String genVar1340;
    genVar1340="filename";
    elFile.setAttribute(genVar1340,filename);
    java.lang.String genVar1341;
    genVar1341="description";
    Element elDescription;
    elDescription=new Element(genVar1341);
    elDescription.addContent(description);
    elFile.addContent(elDescription);
    return elFile;
  }
}
