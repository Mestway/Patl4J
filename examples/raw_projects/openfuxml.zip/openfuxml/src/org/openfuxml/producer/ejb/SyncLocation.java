package org.openfuxml.producer.ejb;
import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import org.jdom2.Element;
import org.openfuxml.communication.cluster.ejb.EjbObject;
@Entity public class SyncLocation implements Serializable, EjbObject {
  static final long serialVersionUID=1;
  public static enum Typ {  REPOSITORY,   OUTPUT}
  private int id;
  private ProductionRequest productionRequest;
  private Typ typ;
  private String url;
  @Id @GeneratedValue(strategy=GenerationType.AUTO) public int getId(){
    return id;
  }
  public void setId(  int id){
    org.openfuxml.producer.ejb.SyncLocation genVar1301;
    genVar1301=this;
    genVar1301.id=id;
  }
  @ManyToOne public ProductionRequest getProductionRequest(){
    return productionRequest;
  }
  public void setProductionRequest(  ProductionRequest productionRequest){
    org.openfuxml.producer.ejb.SyncLocation genVar1302;
    genVar1302=this;
    genVar1302.productionRequest=productionRequest;
  }
  public Typ getTyp(){
    return typ;
  }
  public void setTyp(  Typ typ){
    org.openfuxml.producer.ejb.SyncLocation genVar1303;
    genVar1303=this;
    genVar1303.typ=typ;
  }
  public String getUrl(){
    return url;
  }
  public void setUrl(  String url){
    org.openfuxml.producer.ejb.SyncLocation genVar1304;
    genVar1304=this;
    genVar1304.url=url;
  }
  public void init(  Element elTyp){
    java.lang.String genVar1305;
    genVar1305="typ";
    java.lang.String genVar1306;
    genVar1306=elTyp.getAttributeValue(genVar1305);
    typ=Typ.valueOf(genVar1306);
    url=elTyp.getText();
  }
  public Element toXML(){
    java.lang.String genVar1307;
    genVar1307="url";
    Element elUrl;
    elUrl=new Element(genVar1307);
    java.lang.String genVar1308;
    genVar1308="typ";
    java.lang.String genVar1309;
    genVar1309=typ.name();
    elUrl.setAttribute(genVar1308,genVar1309);
    elUrl.setText(url);
    return elUrl;
  }
}
