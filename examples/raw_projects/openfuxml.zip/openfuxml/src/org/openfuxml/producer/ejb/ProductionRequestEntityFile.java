package org.openfuxml.producer.ejb;
import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import org.jdom2.Element;
import org.openfuxml.communication.cluster.ejb.EjbObject;
@Entity public class ProductionRequestEntityFile implements Serializable, EjbObject {
  static final long serialVersionUID=1;
  private int id;
  private ProductionRequest productionRequest;
  private String directory, filename, description;
  @Id @GeneratedValue(strategy=GenerationType.AUTO) public int getId(){
    return id;
  }
  public void setId(  int id){
    org.openfuxml.producer.ejb.ProductionRequestEntityFile genVar1207;
    genVar1207=this;
    genVar1207.id=id;
  }
  @ManyToOne public ProductionRequest getProductionRequest(){
    return productionRequest;
  }
  public void setProductionRequest(  ProductionRequest productionRequest){
    org.openfuxml.producer.ejb.ProductionRequestEntityFile genVar1208;
    genVar1208=this;
    genVar1208.productionRequest=productionRequest;
  }
  public String getDescription(){
    return description;
  }
  public void setDescription(  String description){
    org.openfuxml.producer.ejb.ProductionRequestEntityFile genVar1209;
    genVar1209=this;
    genVar1209.description=description;
  }
  public String getDirectory(){
    return directory;
  }
  public void setDirectory(  String directory){
    org.openfuxml.producer.ejb.ProductionRequestEntityFile genVar1210;
    genVar1210=this;
    genVar1210.directory=directory;
  }
  public String getFilename(){
    return filename;
  }
  public void setFilename(  String filename){
    org.openfuxml.producer.ejb.ProductionRequestEntityFile genVar1211;
    genVar1211=this;
    genVar1211.filename=filename;
  }
  public void init(  Element elFile){
    java.lang.String genVar1212;
    genVar1212="directory";
    directory=elFile.getAttributeValue(genVar1212);
    java.lang.String genVar1213;
    genVar1213="filename";
    filename=elFile.getAttributeValue(genVar1213);
    java.lang.String genVar1214;
    genVar1214="description";
    Element elDescription;
    elDescription=elFile.getChild(genVar1214);
    description=elDescription.getText();
  }
  public Element toXML(){
    java.lang.String genVar1215;
    genVar1215="file";
    Element elFile;
    elFile=new Element(genVar1215);
    java.lang.String genVar1216;
    genVar1216="directory";
    elFile.setAttribute(genVar1216,directory);
    java.lang.String genVar1217;
    genVar1217="filename";
    elFile.setAttribute(genVar1217,filename);
    java.lang.String genVar1218;
    genVar1218="description";
    Element elDescription;
    elDescription=new Element(genVar1218);
    elDescription.addContent(description);
    elFile.addContent(elDescription);
    return elFile;
  }
}
