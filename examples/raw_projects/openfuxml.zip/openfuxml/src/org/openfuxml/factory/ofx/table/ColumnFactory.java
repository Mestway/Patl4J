package org.openfuxml.factory.ofx.table;
import org.openfuxml.content.table.Columns;
public class ColumnFactory {
  public static Columns create(  String name,  int width){
    return null;
  }
}
