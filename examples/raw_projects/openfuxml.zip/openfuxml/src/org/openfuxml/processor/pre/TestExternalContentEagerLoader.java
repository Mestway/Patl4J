package org.openfuxml.processor.pre;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Collection;
import java.util.List;
import net.sf.exlp.util.io.RelativePathFactory;
import net.sf.exlp.util.xml.JDomUtil;
import org.apache.commons.io.FilenameUtils;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.jdom2.xpath.XPathExpression;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.openfuxml.exception.OfxAuthoringException;
import org.openfuxml.exception.OfxConfigurationException;
import org.openfuxml.exception.OfxInternalProcessingException;
import org.openfuxml.test.AbstractFileProcessingTest;
import org.openfuxml.test.OfxCoreTestBootstrap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@RunWith(Parameterized.class) public class TestExternalContentEagerLoader extends AbstractFileProcessingTest {
  final static Logger logger=LoggerFactory.getLogger(TestExternalContentEagerLoader.class);
  private ExternalContentEagerLoader ecel;
  int expectedExternals;
  public static String srcDir="src/test/resources";
  public static String srcDirName=srcDir + "/data/pre/external/elements/in";
  public static final String dstDirName=srcDir + "/data/pre/external/elements/out";
  public TestExternalContentEagerLoader(  File fTest){
    org.openfuxml.processor.pre.TestExternalContentEagerLoader genVar1111;
    genVar1111=this;
    genVar1111.fTest=fTest;
    java.lang.String genVar1112;
    genVar1112=fTest.getName();
    java.lang.String genVar1113;
    genVar1113=FilenameUtils.removeExtension(genVar1112);
    expectedExternals=new Integer(genVar1113);
    java.lang.String genVar1114;
    genVar1114=fTest.getName();
    String name;
    name=FilenameUtils.removeExtension(genVar1114);
    java.lang.String genVar1115;
    genVar1115=".xml";
    java.lang.String genVar1116;
    genVar1116=name + genVar1115;
    fRef=new File(dstDirName,genVar1116);
  }
  @Parameterized.Parameters public static Collection<Object[]> initFileNames(){
    java.lang.String genVar1118;
    genVar1118=".xml";
    java.util.Collection<java.lang.Object[]> genVar1119;
    genVar1119=TestExternalContentEagerLoader.initFileNames(srcDirName,genVar1118);
    return genVar1119;
  }
  public static Collection<Object[]> initFileNames(  String srcDirName,  String suffix){
    return null;
  }
  @Before public void init(){
    ecel=new ExternalContentEagerLoader();
  }
  @After public void close(){
    ecel=null;
  }
  @Test public void xpathWithDocument() throws OfxInternalProcessingException, FileNotFoundException {
    Document doc;
    doc=JDomUtil.load(fTest);
    XPathExpression<Element> xpe;
    xpe=ecel.build();
    List<Element> list;
    list=xpe.evaluate(doc);
    int genVar1120;
    genVar1120=list.size();
    Assert.assertEquals(expectedExternals,genVar1120);
  }
  @Test public void xpathWithRootElement() throws OfxInternalProcessingException, FileNotFoundException {
    Document doc;
    doc=JDomUtil.load(fTest);
    XPathExpression<Element> xpe;
    xpe=ecel.build();
    org.jdom2.Element genVar1121;
    genVar1121=doc.getRootElement();
    List<Element> list;
    list=xpe.evaluate(genVar1121);
    int genVar1122;
    genVar1122=list.size();
    Assert.assertEquals(expectedExternals,genVar1122);
  }
  @Test public void loadFromFile() throws FileNotFoundException, OfxAuthoringException {
    TestExternalContentEagerLoader genVar1123;
    genVar1123=this;
    java.lang.String genVar1124;
    genVar1124=fTest.getAbsolutePath();
    boolean genVar1125;
    genVar1125=false;
    genVar1123.render(genVar1124,genVar1125);
  }
  @Test public void loadFromResource() throws FileNotFoundException, OfxAuthoringException {
    java.io.File genVar1126;
    genVar1126=new File(srcDir);
    RelativePathFactory rpf;
    rpf=new RelativePathFactory(genVar1126);
    java.io.File genVar1127;
    genVar1127=fTest.getAbsoluteFile();
    String relativeResource;
    relativeResource=rpf.relativate(genVar1127);
    logger.info(relativeResource);
    TestExternalContentEagerLoader genVar1128;
    genVar1128=this;
    boolean genVar1129;
    genVar1129=false;
    genVar1128.render(relativeResource,genVar1129);
  }
  private void render(  boolean saveReference) throws FileNotFoundException, OfxAuthoringException {
    TestExternalContentEagerLoader genVar1130;
    genVar1130=this;
    java.lang.String genVar1131;
    genVar1131=fTest.getAbsolutePath();
    genVar1130.render(genVar1131,saveReference);
  }
  private void render(  String fileName,  boolean saveReference) throws FileNotFoundException, OfxAuthoringException {
    Document docActual;
    docActual=ecel.load(fileName);
    if (saveReference) {
      org.jdom2.output.Format genVar1132;
      genVar1132=Format.getRawFormat();
      JDomUtil.save(docActual,fRef,genVar1132);
    }
 else {
      Document docExcepcted;
      docExcepcted=JDomUtil.load(fRef);
      java.lang.String genVar1133;
      genVar1133=JDomUtil.toString(docExcepcted);
      java.lang.String genVar1134;
      genVar1134=JDomUtil.toString(docActual);
      Assert.assertEquals(genVar1133,genVar1134);
    }
  }
  public static void main(  String[] args) throws FileNotFoundException, OfxConfigurationException, OfxAuthoringException {
    OfxCoreTestBootstrap.init();
    boolean saveReference;
    saveReference=true;
    int genVar1135;
    genVar1135=1;
    int id;
    id=-genVar1135;
    int index;
    index=0;
    java.util.Collection<java.lang.Object[]> genVar1136;
    genVar1136=TestExternalContentEagerLoader.initFileNames();
    for (    Object[] o : genVar1136) {
      int genVar1137;
      genVar1137=0;
      java.lang.Object genVar1138;
      genVar1138=o[genVar1137];
      File fTest;
      fTest=(File)genVar1138;
      TestExternalContentEagerLoader test;
      test=new TestExternalContentEagerLoader(fTest);
      test.init();
      java.lang.String genVar1139;
      genVar1139=" ";
      java.lang.String genVar1140;
      genVar1140=id + genVar1139 + index;
      logger.trace(genVar1140);
      int genVar1141;
      genVar1141=0;
      boolean genVar1142;
      genVar1142=id < genVar1141;
      boolean genVar1143;
      genVar1143=id == index;
      boolean genVar1144;
      genVar1144=genVar1142 | genVar1143;
      if (genVar1144) {
        test.render(saveReference);
      }
 else {
        ;
      }
      test.close();
      index++;
    }
  }
}
