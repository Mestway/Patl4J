package org.openfuxml.processor.pre;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;
import net.sf.exlp.util.io.RelativePathFactory;
import net.sf.exlp.util.io.resourceloader.MultiResourceLoader;
import net.sf.exlp.util.xml.JDomUtil;
import org.apache.commons.io.FilenameUtils;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.Namespace;
import org.jdom2.filter.Filters;
import org.jdom2.xpath.XPath;
import org.jdom2.xpath.XPathExpression;
import org.jdom2.xpath.XPathFactory;
import org.openfuxml.content.ofx.Document;
import org.openfuxml.exception.OfxAuthoringException;
import org.openfuxml.exception.OfxInternalProcessingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class ExternalContentEagerLoader {
  final static Logger logger=LoggerFactory.getLogger(ExternalContentEagerLoader.class);
  private RelativePathFactory rpf;
  private MultiResourceLoader mrl;
  private File rootFile;
  private org.jdom2.Document doc;
  private XPathFactory xpFactory;
  private XPath xpath;
  public ExternalContentEagerLoader(){
    mrl=new MultiResourceLoader();
    rpf=new RelativePathFactory(RelativePathFactory.PathSeparator.CURRENT);
    try {
      java.lang.String genVar1145;
      genVar1145="//*[@external='true']";
      xpath=XPath.newInstance(genVar1145);
      java.lang.String genVar1146;
      genVar1146="ofx";
      java.lang.String genVar1147;
      genVar1147="http://www.openfuxml.org";
      org.jdom2.Namespace genVar1148;
      genVar1148=Namespace.getNamespace(genVar1146,genVar1147);
      xpath.addNamespace(genVar1148);
      java.lang.String genVar1149;
      genVar1149="wiki";
      java.lang.String genVar1150;
      genVar1150="http://www.openfuxml.org/wiki";
      org.jdom2.Namespace genVar1151;
      genVar1151=Namespace.getNamespace(genVar1149,genVar1150);
      xpath.addNamespace(genVar1151);
    }
 catch (    JDOMException e) {
      java.lang.String genVar1152;
      genVar1152="";
      logger.error(genVar1152,e);
    }
    xpFactory=XPathFactory.instance();
  }
  protected XPathExpression<Element> build(){
    java.lang.String genVar1153;
    genVar1153="//*[@include]";
    org.jdom2.filter.Filter<org.jdom2.Element> genVar1154;
    genVar1154=Filters.element();
    XPathExpression<Element> xpe;
    xpe=xpFactory.compile(genVar1153,genVar1154);
    return xpe;
  }
  public org.jdom2.Document load(  String resourceName) throws FileNotFoundException, OfxAuthoringException {
    org.jdom2.Document doc;
    doc=new org.jdom2.Document();
    ExternalContentEagerLoader genVar1155;
    genVar1155=this;
    org.jdom2.Element genVar1156;
    genVar1156=genVar1155.loadElement(resourceName);
    doc.setRootElement(genVar1156);
    return doc;
  }
  private Element loadElement(  String resourceName) throws OfxAuthoringException {
    try {
      InputStream is;
      is=mrl.searchIs(resourceName);
      java.lang.String genVar1157;
      genVar1157=is.toString();
      java.io.File genVar1158;
      genVar1158=new File(genVar1157);
      org.jdom2.Document doc;
      doc=JDomUtil.load(genVar1158);
      Element root;
      root=doc.getRootElement();
      ExternalContentEagerLoader genVar1159;
      genVar1159=this;
      org.jdom2.xpath.XPathExpression<org.jdom2.Element> genVar1160;
      genVar1160=genVar1159.build();
      List<Element> list;
      list=genVar1160.evaluate(root);
      java.lang.String genVar1161;
      genVar1161="Now processing childs: ";
      int genVar1162;
      genVar1162=list.size();
      java.lang.String genVar1163;
      genVar1163=genVar1161 + genVar1162;
      logger.debug(genVar1163);
      for (      Element childElement : list) {
        java.lang.String genVar1164;
        genVar1164="include";
        org.jdom2.Attribute genVar1165;
        genVar1165=childElement.getAttribute(genVar1164);
        String source;
        source=genVar1165.getValue();
        java.lang.String genVar1166;
        genVar1166=FilenameUtils.getFullPath(resourceName);
        String resourceChild;
        resourceChild=genVar1166 + source;
        java.lang.String genVar1167;
        genVar1167="Found external in ";
        java.lang.String genVar1168;
        genVar1168=genVar1167 + resourceChild;
        logger.debug(genVar1168);
        ExternalContentEagerLoader em;
        em=new ExternalContentEagerLoader();
        Element eExternal;
        eExternal=em.loadElement(resourceChild);
        eExternal.detach();
        org.jdom2.Element genVar1169;
        genVar1169=childElement.getParentElement();
        int index;
        index=genVar1169.indexOf(childElement);
        org.jdom2.Element genVar1170;
        genVar1170=childElement.getParentElement();
        genVar1170.setContent(index,eExternal);
        childElement.detach();
      }
      root.detach();
      return root;
    }
 catch (    FileNotFoundException e) {
      java.lang.String genVar1171;
      genVar1171=e.getMessage();
      org.openfuxml.exception.OfxAuthoringException genVar1172;
      genVar1172=new OfxAuthoringException(genVar1171);
      throw genVar1172;
    }
  }
  @Deprecated private void loadRoot(  File rootFile) throws OfxInternalProcessingException {
    org.openfuxml.processor.pre.ExternalContentEagerLoader genVar1173;
    genVar1173=this;
    genVar1173.rootFile=rootFile;
    doc=JDomUtil.load(rootFile);
    boolean genVar1174;
    genVar1174=doc == null;
    if (genVar1174) {
      java.lang.String genVar1175;
      genVar1175="FileNoteFound: ";
      java.lang.String genVar1176;
      genVar1176=rootFile.getAbsolutePath();
      java.lang.String genVar1177;
      genVar1177=genVar1175 + genVar1176;
      org.openfuxml.exception.OfxInternalProcessingException genVar1178;
      genVar1178=new OfxInternalProcessingException(genVar1177);
      throw genVar1178;
    }
 else {
      ;
    }
    java.lang.String genVar1179;
    genVar1179="Loaded: ";
    java.lang.String genVar1180;
    genVar1180=rootFile.getAbsolutePath();
    java.lang.String genVar1181;
    genVar1181=genVar1179 + genVar1180;
    logger.trace(genVar1181);
  }
  @Deprecated public Document mergeToOfxDoc(  File rootFile) throws OfxInternalProcessingException {
    ExternalContentEagerLoader genVar1182;
    genVar1182=this;
    org.jdom2.Document doc;
    doc=genVar1182.mergeToDoc(rootFile);
    java.lang.Class<org.openfuxml.content.ofx.Document> genVar1183;
    genVar1183=Document.class;
    java.lang.Object genVar1184;
    genVar1184=JDomUtil.toJaxb(doc,genVar1183);
    Document ofxDoc;
    ofxDoc=(Document)genVar1184;
    return ofxDoc;
  }
  @Deprecated public org.jdom2.Document mergeToDoc(  File rootFile) throws OfxInternalProcessingException {
    ExternalContentEagerLoader genVar1185;
    genVar1185=this;
    genVar1185.loadRoot(rootFile);
    Element rootElement;
    rootElement=doc.getRootElement();
    ExternalContentEagerLoader genVar1186;
    genVar1186=this;
    Element result;
    result=genVar1186.mergeRecursive(rootElement);
    result.detach();
    doc.setRootElement(result);
    return doc;
  }
  @Deprecated public Element getExternal(  File rootFile) throws OfxInternalProcessingException {
    ExternalContentEagerLoader genVar1187;
    genVar1187=this;
    genVar1187.loadRoot(rootFile);
    Element rootElement;
    rootElement=doc.getRootElement();
    ExternalContentEagerLoader genVar1188;
    genVar1188=this;
    org.jdom2.Element genVar1189;
    genVar1189=genVar1188.mergeRecursive(rootElement);
    return genVar1189;
  }
  @Deprecated private Element mergeRecursive(  Element rootElement) throws OfxInternalProcessingException {
    try {
      List<?> list;
      list=xpath.selectNodes(rootElement);
      int genVar1190;
      genVar1190=list.size();
      java.lang.String genVar1191;
      genVar1191=" external sources in ";
      java.lang.String genVar1192;
      genVar1192=rootElement.getName();
      java.lang.String genVar1193;
      genVar1193=" in ";
      java.lang.String genVar1194;
      genVar1194=rootFile.getAbsolutePath();
      java.lang.String genVar1195;
      genVar1195=genVar1190 + genVar1191 + genVar1192+ genVar1193+ genVar1194;
      logger.debug(genVar1195);
      Iterator<?> iter;
      iter=list.iterator();
      for (; iter.hasNext(); ) {
        Object genVar1196;
        genVar1196=iter.next();
        Element childElement;
        childElement=(Element)genVar1196;
        java.lang.String genVar1197;
        genVar1197="source";
        org.jdom2.Attribute genVar1198;
        genVar1198=childElement.getAttribute(genVar1197);
        String source;
        source=genVar1198.getValue();
        java.io.File genVar1199;
        genVar1199=rootFile.getParentFile();
        File childFile;
        childFile=new File(genVar1199,source);
        java.lang.String genVar1200;
        genVar1200="Found external in ";
        java.io.File genVar1201;
        genVar1201=rootFile.getParentFile();
        java.lang.String genVar1202;
        genVar1202=rpf.relativate(genVar1201,childFile);
        java.lang.String genVar1203;
        genVar1203=genVar1200 + genVar1202;
        logger.trace(genVar1203);
        ExternalContentEagerLoader em;
        em=new ExternalContentEagerLoader();
        Element eEx;
        eEx=em.getExternal(childFile);
        eEx.detach();
        org.jdom2.Element genVar1204;
        genVar1204=childElement.getParentElement();
        int index;
        index=genVar1204.indexOf(childElement);
        org.jdom2.Element genVar1205;
        genVar1205=childElement.getParentElement();
        genVar1205.setContent(index,eEx);
        childElement.detach();
      }
    }
 catch (    JDOMException e) {
      java.lang.String genVar1206;
      genVar1206="";
      logger.error(genVar1206,e);
    }
    return rootElement;
  }
}
