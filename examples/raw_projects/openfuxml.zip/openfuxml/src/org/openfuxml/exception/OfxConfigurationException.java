package org.openfuxml.exception;
public class OfxConfigurationException extends Exception {
  public OfxConfigurationException(  String message){
  }
}
