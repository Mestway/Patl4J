package org.openfuxml.exception;
public class OfxInternalProcessingException extends Exception {
  public OfxInternalProcessingException(  String message){
  }
}
