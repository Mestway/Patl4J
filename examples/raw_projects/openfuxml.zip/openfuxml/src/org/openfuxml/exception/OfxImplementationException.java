package org.openfuxml.exception;
public class OfxImplementationException extends Exception {
  public OfxImplementationException(  String message){
  }
}
