package org.openfuxml.exception;
public class OfxAuthoringException extends Exception {
  public OfxAuthoringException(  String message){
  }
}
