package org.openfuxml.content.table;
import java.util.List;
public class Body {
  public List<Row> getRow(){
    return null;
  }
}
