package org.openfuxml.content.ofx;
public class Metadata {
  public Title getTitle(){
    return null;
  }
}
