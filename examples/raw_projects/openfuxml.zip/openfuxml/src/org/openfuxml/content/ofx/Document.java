package org.openfuxml.content.ofx;
public class Document {
  public Sections getContent(){
    return null;
  }
}
