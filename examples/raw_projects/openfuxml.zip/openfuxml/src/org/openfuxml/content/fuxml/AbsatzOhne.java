package org.openfuxml.content.fuxml;
public class AbsatzOhne {
  public void setValue(  String value){
  }
}
