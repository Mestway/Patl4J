package org.openfuxml.content.table;
import java.util.List;
public class Head {
  public List<Row> getRow(){
    return null;
  }
}
