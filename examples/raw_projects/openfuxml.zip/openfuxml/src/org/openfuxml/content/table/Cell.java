package org.openfuxml.content.table;
import java.util.List;
public class Cell {
  public List<Object> getContent(){
    return null;
  }
}
