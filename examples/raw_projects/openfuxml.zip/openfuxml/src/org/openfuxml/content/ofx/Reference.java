package org.openfuxml.content.ofx;
public class Reference {
  public String getTarget(){
    return null;
  }
  public String getValue(){
    return null;
  }
}
