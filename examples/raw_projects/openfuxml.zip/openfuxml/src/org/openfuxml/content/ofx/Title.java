package org.openfuxml.content.ofx;
public class Title {
  public String getValue(){
    return null;
  }
  public void setValue(  String value){
  }
}
