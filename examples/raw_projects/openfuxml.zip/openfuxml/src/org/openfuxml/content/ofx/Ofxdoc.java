package org.openfuxml.content.ofx;
public class Ofxdoc {
  public Sections getContent(){
    return null;
  }
  public Metadata getMetadata(){
    return null;
  }
}
