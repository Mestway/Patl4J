package org.openfuxml.content.table;
import java.util.List;
public class Content {
  public void setHead(  Head head){
  }
  public Head getHead(){
    return null;
  }
  public List<Body> getBody(){
    return null;
  }
}
