package org.openfuxml.content.ofx;
import java.util.List;
import org.openfuxml.content.table.Table;
public class Section {
  public String getId(){
    return null;
  }
  public void setContainer(  boolean isContainer){
  }
  public List<Table> getContent(){
    return null;
  }
  public boolean isSetContainer(){
    boolean genVar1109;
    genVar1109=false;
    return genVar1109;
  }
  public boolean isContainer(){
    boolean genVar1110;
    genVar1110=false;
    return genVar1110;
  }
  public void setExternal(  boolean external){
  }
  public void setSource(  String sourceFileName){
  }
}
