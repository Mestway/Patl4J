package org.openfuxml.content.fuxml;
import java.util.List;
import org.openfuxml.content.fuxml.medienobjekt.Objekttitel;
public class Medienobjekt {
  public void setGleiten(  String gleiten){
  }
  public void setId(  String id){
  }
  public void setObjekttitel(  Objekttitel objekttitel){
  }
  public List<Grafik> getGrafik(){
    return null;
  }
}
