package org.openfuxml.content.fuxml.medienobjekt;
import java.util.List;
import org.openfuxml.content.fuxml.AbsatzOhne;
public class Objekttitel {
  public List<AbsatzOhne> getAbsatzOhne(){
    return null;
  }
}
