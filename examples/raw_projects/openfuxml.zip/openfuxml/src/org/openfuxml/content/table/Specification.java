package org.openfuxml.content.table;
public class Specification {
  public void setColumns(  Columns columns){
  }
}
