package org.openfuxml.content.ofx;
public class Emphasis {
  public void setBold(  boolean bold){
  }
  public void setValue(  String value){
  }
}
