package org.openfuxml.content.ofx;
import java.util.List;
public class Paragraph {
  public List<Object> getContent(){
    return null;
  }
}
