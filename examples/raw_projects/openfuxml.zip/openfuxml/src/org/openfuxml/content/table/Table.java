package org.openfuxml.content.table;
import org.openfuxml.content.ofx.Title;
public class Table {
  public Content getContent(){
    return null;
  }
  public void setTitle(  Title title){
  }
  public void setSpecification(  Specification spacification){
  }
  public void setContent(  Content content){
  }
}
