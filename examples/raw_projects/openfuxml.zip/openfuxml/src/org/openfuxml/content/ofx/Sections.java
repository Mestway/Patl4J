package org.openfuxml.content.ofx;
import java.util.List;
public class Sections {
  public List<Section> getContent(){
    return null;
  }
  public void setExternal(  boolean external){
  }
  public void setSource(  String sourceFileName){
  }
}
