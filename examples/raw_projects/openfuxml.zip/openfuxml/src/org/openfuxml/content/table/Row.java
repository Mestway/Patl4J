package org.openfuxml.content.table;
import java.util.List;
public class Row {
  public List<Cell> getCell(){
    return null;
  }
}
