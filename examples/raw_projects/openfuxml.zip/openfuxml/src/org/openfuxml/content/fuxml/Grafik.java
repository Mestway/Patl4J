package org.openfuxml.content.fuxml;
public class Grafik {
  public void setAlign(  String align){
  }
  public void setFliessen(  String fliessen){
  }
  public void setWidth(  int width){
  }
  public void setDepth(  int depth){
  }
  public void setScale(  double scale){
  }
  public void setFileref(  String fileref){
  }
}
