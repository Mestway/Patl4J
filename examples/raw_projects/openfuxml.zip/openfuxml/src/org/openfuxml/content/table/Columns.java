package org.openfuxml.content.table;
import java.util.List;
public class Columns {
  public List<Columns> getColumn(){
    return null;
  }
}
