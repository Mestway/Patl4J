package org.openfuxml.communication.cluster.ejb;
public interface EjbObject {
}
