package org.openfuxml.addon.chart.jaxb;
public class Charttype {
public class Timeseries {
    public boolean isSetCumulate(){
      boolean genVar14;
      genVar14=false;
      return genVar14;
    }
    public boolean isCumulate(){
      boolean genVar15;
      genVar15=false;
      return genVar15;
    }
  }
}
