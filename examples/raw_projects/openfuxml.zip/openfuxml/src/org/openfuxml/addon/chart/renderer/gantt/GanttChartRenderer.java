package org.openfuxml.addon.chart.renderer.gantt;
import org.openfuxml.addon.chart.renderer.generic.OfxChartRenderer;
import org.openfuxml.addon.chart.interfaces.ChartRenderer;
public class GanttChartRenderer extends OfxChartRenderer implements ChartRenderer {
}
