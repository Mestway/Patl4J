package org.openfuxml.addon.wiki;
import org.openfuxml.addon.wiki.data.jaxb.MarkupProcessor;
import org.openfuxml.addon.wiki.data.jaxb.Templates;
import org.openfuxml.addon.wiki.data.jaxb.XhtmlProcessor;
public class Wiki {
  public MarkupProcessor getMarkupProcessor(){
    return null;
  }
  public XhtmlProcessor getXhtmlProcessor(){
    return null;
  }
  public Templates getTemplates(){
    return null;
  }
}
