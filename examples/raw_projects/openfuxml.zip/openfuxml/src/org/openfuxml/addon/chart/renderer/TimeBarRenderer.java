package org.openfuxml.addon.chart.renderer;
import org.openfuxml.addon.chart.interfaces.ChartRenderer;
import org.openfuxml.addon.chart.renderer.generic.OfxChartRenderer;
public class TimeBarRenderer extends OfxChartRenderer implements ChartRenderer {
}
