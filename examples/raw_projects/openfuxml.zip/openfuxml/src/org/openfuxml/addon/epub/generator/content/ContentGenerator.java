package org.openfuxml.addon.epub.generator.content;
import java.io.File;
import java.io.Serializable;
import net.sf.exlp.util.xml.JDomUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.jdom2.output.Format;
import org.openfuxml.content.ofx.Ofxdoc;
import org.openfuxml.content.ofx.Section;
import org.openfuxml.renderer.processor.pre.OfxExternalMerger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class ContentGenerator {
  final static Logger logger=LoggerFactory.getLogger(OfxExternalMerger.class);
  private File targetDir;
  private Namespace nsXhtml;
  private PartXhtmlFactory partFactory;
  public ContentGenerator(  File targetDir){
    org.openfuxml.addon.epub.generator.content.ContentGenerator genVar46;
    genVar46=this;
    genVar46.targetDir=targetDir;
    java.lang.String genVar47;
    genVar47="http://www.w3.org/1999/xhtml";
    nsXhtml=Namespace.getNamespace(genVar47);
    partFactory=new PartXhtmlFactory(nsXhtml);
  }
  public void create(  Ofxdoc ofxDoc){
    int partNr;
    partNr=1;
    org.openfuxml.content.ofx.Sections genVar48;
    genVar48=ofxDoc.getContent();
    java.util.List<org.openfuxml.content.ofx.Section> genVar49;
    genVar49=genVar48.getContent();
    for (    Object s : genVar49) {
      boolean genVar50;
      genVar50=s instanceof Section;
      if (genVar50) {
        Section section;
        section=(Section)s;
        java.lang.String genVar51;
        genVar51="part-";
        java.lang.String genVar52;
        genVar52=".xhtml";
        java.lang.String genVar53;
        genVar53=genVar51 + partNr + genVar52;
        File f;
        f=new File(targetDir,genVar53);
        Document doc;
        doc=new Document();
        Element rootElement;
        rootElement=partFactory.createPart(section);
        doc.setRootElement(rootElement);
        org.jdom2.output.Format genVar54;
        genVar54=Format.getPrettyFormat();
        JDomUtil.save(doc,f,genVar54);
        partNr++;
      }
 else {
        ;
      }
    }
  }
}
