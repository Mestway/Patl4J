package org.openfuxml.addon.wiki.processor.ofx.xml;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Collection;
import net.sf.exlp.util.io.LoggerInit;
import net.sf.exlp.util.io.StringIO;
import net.sf.exlp.util.xml.JDomUtil;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.openfuxml.addon.wiki.processor.markup.TestWikiInlineProcessor;
import org.openfuxml.exception.OfxConfigurationException;
import org.openfuxml.exception.OfxInternalProcessingException;
import org.openfuxml.test.AbstractFileProcessingTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@RunWith(Parameterized.class) public class TestWikiPageProcessor extends AbstractFileProcessingTest {
  final static Logger logger=LoggerFactory.getLogger(TestWikiInlineProcessor.class);
  private WikiPageProcessor xmlP;
  private static final String srcDirName="src/test/resources/data/xhtml/final";
  private static final String dstDirName="src/test/resources/data/xml/ofx";
  private File fTest;
  private File fRef;
  public TestWikiPageProcessor(  File fTest){
    org.openfuxml.addon.wiki.processor.ofx.xml.TestWikiPageProcessor genVar634;
    genVar634=this;
    genVar634.fTest=fTest;
    java.lang.String genVar635;
    genVar635=fTest.getName();
    int genVar636;
    genVar636=0;
    java.lang.String genVar637;
    genVar637=fTest.getName();
    int genVar638;
    genVar638=genVar637.length();
    int genVar639;
    genVar639=6;
    int genVar640;
    genVar640=genVar638 - genVar639;
    String name;
    name=genVar635.substring(genVar636,genVar640);
    java.lang.String genVar641;
    genVar641=".xml";
    java.lang.String genVar642;
    genVar642=name + genVar641;
    fRef=new File(dstDirName,genVar642);
  }
  @Parameterized.Parameters public static Collection<Object[]> initFileNames(){
    java.lang.String genVar644;
    genVar644=".xhtml";
    java.util.Collection<java.lang.Object[]> genVar645;
    genVar645=TestWikiPageProcessor.initFileNames(srcDirName,genVar644);
    return genVar645;
  }
  public static Collection<Object[]> initFileNames(  String srcDirName,  String suffix){
    return null;
  }
  @Before public void init() throws FileNotFoundException, OfxConfigurationException, OfxInternalProcessingException {
    xmlP=new WikiPageProcessor();
  }
  @After public void close(){
    xmlP=null;
  }
  @Test public void test() throws OfxInternalProcessingException {
    java.lang.String genVar646;
    genVar646=fTest.getAbsolutePath();
    logger.debug(genVar646);
    TestWikiPageProcessor genVar647;
    genVar647=this;
    boolean genVar648;
    genVar648=false;
    genVar647.test(genVar648);
  }
  private void test(  boolean saveReference) throws OfxInternalProcessingException {
    boolean genVar649;
    genVar649=false;
    String inTxt;
    inTxt=StringIO.loadTxt(fTest,genVar649);
    Element xml;
    xml=xmlP.process(inTxt);
    Document doc;
    doc=new Document();
    doc.setRootElement(xml);
    if (saveReference) {
      org.jdom2.output.Format genVar650;
      genVar650=Format.getRawFormat();
      JDomUtil.save(doc,fRef,genVar650);
    }
 else {
      Document refDoc;
      refDoc=JDomUtil.load(fRef);
      java.lang.String genVar651;
      genVar651=JDomUtil.docToTxt(refDoc);
      java.lang.String genVar652;
      genVar652=JDomUtil.docToTxt(doc);
      Assert.assertEquals(genVar651,genVar652);
    }
  }
  public static void chain(  int id,  boolean saveReference) throws FileNotFoundException, OfxConfigurationException, OfxInternalProcessingException {
    int index;
    index=0;
    java.util.Collection<java.lang.Object[]> genVar653;
    genVar653=TestWikiPageProcessor.initFileNames();
    for (    Object[] o : genVar653) {
      int genVar654;
      genVar654=0;
      boolean genVar655;
      genVar655=id < genVar654;
      boolean genVar656;
      genVar656=id == index;
      boolean genVar657;
      genVar657=genVar655 | genVar656;
      if (genVar657) {
        int genVar658;
        genVar658=0;
        java.lang.Object genVar659;
        genVar659=o[genVar658];
        File fTest;
        fTest=(File)genVar659;
        TestWikiPageProcessor test;
        test=new TestWikiPageProcessor(fTest);
        test.init();
        java.lang.String genVar660;
        genVar660=" ";
        java.lang.String genVar661;
        genVar661=id + genVar660 + index;
        logger.trace(genVar661);
        test.test(saveReference);
        test.close();
      }
 else {
        ;
      }
      index++;
    }
  }
  public static void main(  String[] args) throws FileNotFoundException, OfxConfigurationException, OfxInternalProcessingException {
    java.lang.String genVar662;
    genVar662="log4j.xml";
    LoggerInit loggerInit;
    loggerInit=new LoggerInit(genVar662);
    java.lang.String genVar663;
    genVar663="src/test/resources/config";
    loggerInit.addAltPath(genVar663);
    loggerInit.init();
    boolean saveReference;
    saveReference=true;
    int genVar664;
    genVar664=1;
    int id;
    id=-genVar664;
    TestWikiPageProcessor.chain(id,saveReference);
  }
}
