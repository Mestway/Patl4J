package org.openfuxml.addon.wiki.media.chart.factory;
import java.util.List;
import org.jdom2.Document;
import org.jdom2.JDOMException;
import org.jdom2.xpath.XPath;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYBarPainter;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYIntervalSeries;
import org.jfree.data.xy.XYIntervalSeriesCollection;
import org.openfuxml.addon.wiki.data.jaxb.Ofxchart;
import org.openfuxml.addon.wiki.media.chart.ChartXmlUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@Deprecated public class BarChartFactory extends AbstractChartFactory {
  final static Logger logger=LoggerFactory.getLogger(BarChartFactory.class);
  public BarChartFactory(){
  }
  private IntervalXYDataset createDataset(  Ofxchart ofxChart){
    XYIntervalSeriesCollection dataset;
    dataset=new XYIntervalSeriesCollection();
    Document doc;
    doc=ChartXmlUtil.loadChart(ofxChart);
    try {
      StringBuffer sbXpDataSeries;
      sbXpDataSeries=new StringBuffer();
      java.lang.String genVar471;
      genVar471="/ofxchart/ofxchartcontainer[@type='dataseries']";
      sbXpDataSeries.append(genVar471);
      java.lang.String genVar472;
      genVar472=sbXpDataSeries.toString();
      XPath xPath;
      xPath=XPath.newInstance(genVar472);
      List<?> lDataSeries;
      lDataSeries=xPath.selectNodes(doc);
      java.lang.String genVar473;
      genVar473="xpath.DataSeries = ";
      int genVar474;
      genVar474=lDataSeries.size();
      java.lang.String genVar475;
      genVar475=genVar473 + genVar474;
      logger.debug(genVar475);
      int i;
      i=1;
      for (; i <= lDataSeries.size(); i++) {
        StringBuffer sbXpDataSets;
        sbXpDataSets=new StringBuffer();
        sbXpDataSets.append(sbXpDataSeries);
        java.lang.String genVar476;
        genVar476="[";
        java.lang.String genVar477;
        genVar477="]";
        java.lang.String genVar478;
        genVar478=genVar476 + i + genVar477;
        sbXpDataSets.append(genVar478);
        java.lang.String genVar479;
        genVar479="/ofxchartcontainer[@type='dataset']";
        sbXpDataSets.append(genVar479);
        java.lang.String genVar480;
        genVar480=sbXpDataSets.toString();
        xPath=XPath.newInstance(genVar480);
        List<?> lDataSets;
        lDataSets=xPath.selectNodes(doc);
        java.lang.String genVar481;
        genVar481="xpath.lDataSets = ";
        int genVar482;
        genVar482=lDataSets.size();
        java.lang.String genVar483;
        genVar483=genVar481 + genVar482;
        logger.debug(genVar483);
        boolean genVar484;
        genVar484=lDataSets != null;
        int genVar485;
        genVar485=lDataSets.size();
        int genVar486;
        genVar486=0;
        boolean genVar487;
        genVar487=genVar485 > genVar486;
        boolean genVar488;
        genVar488=genVar484 && genVar487;
        if (genVar488) {
          XYIntervalSeries series;
          series=new XYIntervalSeries(i);
          int j;
          j=1;
          for (; j <= lDataSets.size(); j++) {
            StringBuffer sbXpDataSet;
            sbXpDataSet=new StringBuffer();
            sbXpDataSet.append(sbXpDataSets);
            java.lang.String genVar489;
            genVar489="[";
            java.lang.String genVar490;
            genVar490="]";
            java.lang.String genVar491;
            genVar491=genVar489 + j + genVar490;
            sbXpDataSet.append(genVar491);
            java.lang.String genVar492;
            genVar492="/ofxchartdata";
            sbXpDataSet.append(genVar492);
            BarChartFactory genVar493;
            genVar493=this;
            java.lang.String genVar494;
            genVar494=sbXpDataSet.toString();
            java.lang.String genVar495;
            genVar495="X";
            double X;
            X=genVar493.getChartValue(genVar494,genVar495,doc);
            BarChartFactory genVar496;
            genVar496=this;
            java.lang.String genVar497;
            genVar497=sbXpDataSet.toString();
            java.lang.String genVar498;
            genVar498="minY";
            double minY;
            minY=genVar496.getChartValue(genVar497,genVar498,doc);
            BarChartFactory genVar499;
            genVar499=this;
            java.lang.String genVar500;
            genVar500=sbXpDataSet.toString();
            java.lang.String genVar501;
            genVar501="maxY";
            double maxY;
            maxY=genVar499.getChartValue(genVar500,genVar501,doc);
            int genVar502;
            genVar502=3;
            double genVar503;
            genVar503=X - genVar502;
            int genVar504;
            genVar504=3;
            double genVar505;
            genVar505=X + genVar504;
            series.add(X,genVar503,genVar505,minY,minY,maxY);
          }
          dataset.addSeries(series);
        }
 else {
          ;
        }
      }
    }
 catch (    JDOMException e) {
      java.lang.String genVar506;
      genVar506="";
      logger.error(genVar506,e);
    }
    return dataset;
  }
  public JFreeChart createChart(  Ofxchart ofxChart){
    java.lang.String genVar507;
    genVar507="XYBarChartDemo6";
    java.lang.String genVar508;
    genVar508="X";
    boolean genVar509;
    genVar509=false;
    java.lang.String genVar510;
    genVar510="Y";
    BarChartFactory genVar511;
    genVar511=this;
    org.jfree.data.xy.IntervalXYDataset genVar512;
    genVar512=genVar511.createDataset(ofxChart);
    boolean genVar513;
    genVar513=false;
    boolean genVar514;
    genVar514=false;
    boolean genVar515;
    genVar515=false;
    JFreeChart chart;
    chart=ChartFactory.createXYBarChart(genVar507,genVar508,genVar509,genVar510,genVar512,PlotOrientation.VERTICAL,genVar513,genVar514,genVar515);
    org.jfree.chart.plot.Plot genVar516;
    genVar516=chart.getPlot();
    XYPlot plot;
    plot=(XYPlot)genVar516;
    org.jfree.chart.renderer.xy.XYItemRenderer genVar517;
    genVar517=plot.getRenderer();
    XYBarRenderer renderer;
    renderer=(XYBarRenderer)genVar517;
    java.lang.String genVar518;
    genVar518="Dont know if this works ...";
    logger.debug(genVar518);
    org.jfree.chart.renderer.xy.StandardXYBarPainter genVar519;
    genVar519=new StandardXYBarPainter();
    renderer.setBarPainter(genVar519);
    boolean genVar520;
    genVar520=true;
    renderer.setUseYInterval(genVar520);
    plot.setRenderer(renderer);
    return chart;
  }
}
