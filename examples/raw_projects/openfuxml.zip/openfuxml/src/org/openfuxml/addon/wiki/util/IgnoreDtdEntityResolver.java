package org.openfuxml.addon.wiki.util;
import org.xml.sax.EntityResolver;
public class IgnoreDtdEntityResolver {
  public static EntityResolver getInstance(){
    return null;
  }
}
