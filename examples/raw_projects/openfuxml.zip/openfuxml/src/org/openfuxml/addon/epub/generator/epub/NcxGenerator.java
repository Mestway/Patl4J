package org.openfuxml.addon.epub.generator.epub;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.sf.exlp.util.xml.JaxbUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom2.JDOMException;
import org.openfuxml.addon.epub.data.factory.NcxFactory;
import org.openfuxml.addon.epub.data.jaxb.EpubJaxbXpathLoader;
import org.openfuxml.addon.epub.data.jaxb.ncx.Head;
import org.openfuxml.addon.epub.data.jaxb.ncx.NavMap;
import org.openfuxml.addon.epub.data.jaxb.ncx.NavMap.NavPoint;
import org.openfuxml.addon.epub.data.jaxb.ncx.Ncx;
import org.openfuxml.content.ofx.Ofxdoc;
import org.openfuxml.content.ofx.Section;
import org.openfuxml.content.ofx.Title;
import org.openfuxml.renderer.processor.pre.OfxExternalMerger;
import org.openfuxml.util.xml.OfxNsPrefixMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class NcxGenerator {
  final static Logger logger=LoggerFactory.getLogger(OfxExternalMerger.class);
  private File targetDir;
  private Ncx ncx;
  private int playOrder;
  private OfxNsPrefixMapper ofxNsPrefixMapper;
  public NcxGenerator(  File targetDir){
    org.openfuxml.addon.epub.generator.epub.NcxGenerator genVar120;
    genVar120=this;
    genVar120.targetDir=targetDir;
    ofxNsPrefixMapper=new OfxNsPrefixMapper();
    playOrder=1;
  }
  public void create(  Ofxdoc ofxDoc){
    ncx=new Ncx();
    java.lang.String genVar121;
    genVar121="2005-1";
    ncx.setVersion(genVar121);
    NcxGenerator genVar122;
    genVar122=this;
    org.openfuxml.addon.epub.data.jaxb.ncx.Head genVar123;
    genVar123=genVar122.getHead();
    ncx.setHead(genVar123);
    org.openfuxml.content.ofx.Metadata genVar124;
    genVar124=ofxDoc.getMetadata();
    org.openfuxml.content.ofx.Title genVar125;
    genVar125=genVar124.getTitle();
    java.lang.String genVar126;
    genVar126=genVar125.getValue();
    org.openfuxml.content.ofx.Title genVar127;
    genVar127=NcxFactory.getTitle(genVar126);
    ncx.setDocTitle(genVar127);
    NcxGenerator genVar128;
    genVar128=this;
    org.openfuxml.addon.epub.data.jaxb.ncx.NavMap genVar129;
    genVar129=genVar128.getNavMap(ofxDoc);
    ncx.setNavMap(genVar129);
    NcxGenerator genVar130;
    genVar130=this;
    genVar130.save();
  }
  private void save(){
    java.lang.String genVar131;
    genVar131="toc.ncx";
    File f;
    f=new File(targetDir,genVar131);
    boolean genVar132;
    genVar132=true;
    JaxbUtil.save(f,ncx,genVar132);
  }
  private Head getHead(){
    java.lang.String genVar133;
    genVar133="Creating Head";
    logger.debug(genVar133);
    Head head;
    head=new Head();
    java.util.List<org.openfuxml.content.ofx.Metadata> genVar134;
    genVar134=head.getMeta();
    java.lang.String genVar135;
    genVar135="dtb:uid";
    java.util.UUID genVar136;
    genVar136=UUID.randomUUID();
    java.lang.String genVar137;
    genVar137=genVar136.toString();
    org.openfuxml.content.ofx.Metadata genVar138;
    genVar138=NcxFactory.getHeadMeta(genVar135,genVar137);
    genVar134.add(genVar138);
    java.util.List<org.openfuxml.content.ofx.Metadata> genVar139;
    genVar139=head.getMeta();
    java.lang.String genVar140;
    genVar140="dtb:depth";
    java.lang.String genVar141;
    genVar141="1";
    org.openfuxml.content.ofx.Metadata genVar142;
    genVar142=NcxFactory.getHeadMeta(genVar140,genVar141);
    genVar139.add(genVar142);
    java.util.List<org.openfuxml.content.ofx.Metadata> genVar143;
    genVar143=head.getMeta();
    java.lang.String genVar144;
    genVar144="dtb:totalPageCount";
    java.lang.String genVar145;
    genVar145="0";
    org.openfuxml.content.ofx.Metadata genVar146;
    genVar146=NcxFactory.getHeadMeta(genVar144,genVar145);
    genVar143.add(genVar146);
    java.util.List<org.openfuxml.content.ofx.Metadata> genVar147;
    genVar147=head.getMeta();
    java.lang.String genVar148;
    genVar148="dtb:maxPageNumber";
    java.lang.String genVar149;
    genVar149="0";
    org.openfuxml.content.ofx.Metadata genVar150;
    genVar150=NcxFactory.getHeadMeta(genVar148,genVar149);
    genVar147.add(genVar150);
    return head;
  }
  private NavMap getNavMap(  Ofxdoc ofxDoc){
    java.lang.String genVar151;
    genVar151="Creating NavMap";
    logger.debug(genVar151);
    NavMap navmap;
    navmap=new NavMap();
    try {
      java.util.List<org.openfuxml.addon.epub.data.jaxb.ncx.NavMap.NavPoint> genVar152;
      genVar152=navmap.getNavPoint();
      NcxGenerator genVar153;
      genVar153=this;
      java.util.List<org.openfuxml.addon.epub.data.jaxb.ncx.NavMap.NavPoint> genVar154;
      genVar154=genVar153.getSectionNav(ofxDoc);
      genVar152.addAll(genVar154);
    }
 catch (    JDOMException e) {
      java.lang.String genVar155;
      genVar155="";
      logger.error(genVar155,e);
    }
    return navmap;
  }
  private List<NavPoint> getSectionNav(  Ofxdoc ofxDoc) throws JDOMException {
    List<NavPoint> result;
    result=new ArrayList<NavPoint>();
    int partNr;
    partNr=1;
    org.openfuxml.content.ofx.Sections genVar156;
    genVar156=ofxDoc.getContent();
    java.util.List<org.openfuxml.content.ofx.Section> genVar157;
    genVar157=genVar156.getContent();
    for (    Object s : genVar157) {
      boolean genVar158;
      genVar158=s instanceof Section;
      if (genVar158) {
        Section section;
        section=(Section)s;
        java.lang.String genVar159;
        genVar159="secNo=";
        java.lang.String genVar160;
        genVar160=" ";
        java.lang.String genVar161;
        genVar161=section.getId();
        java.lang.String genVar162;
        genVar162=genVar159 + partNr + genVar160+ genVar161;
        logger.debug(genVar162);
        Title title;
        title=EpubJaxbXpathLoader.getTitle(section);
        java.lang.String genVar163;
        genVar163=section.getId();
        java.lang.String genVar164;
        genVar164=title.getValue();
        java.lang.String genVar165;
        genVar165="part-";
        java.lang.String genVar166;
        genVar166=".xhtml";
        java.lang.String genVar167;
        genVar167=genVar165 + partNr + genVar166;
        org.openfuxml.addon.epub.data.jaxb.ncx.NavMap.NavPoint genVar168;
        genVar168=NcxFactory.getNavPoint(genVar163,playOrder,genVar164,genVar167);
        result.add(genVar168);
        playOrder++;
        partNr++;
      }
 else {
        ;
      }
    }
    return result;
  }
}
