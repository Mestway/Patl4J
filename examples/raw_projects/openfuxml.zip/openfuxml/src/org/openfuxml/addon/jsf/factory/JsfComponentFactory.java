package org.openfuxml.addon.jsf.factory;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;
import net.sf.exlp.util.io.resourceloader.MultiResourceLoader;
import net.sf.exlp.util.xml.JDomUtil;
import org.jdom2.DataConversionException;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.Namespace;
import org.jdom2.filter.Filters;
import org.jdom2.xpath.XPathExpression;
import org.jdom2.xpath.XPathFactory;
import org.openfuxml.addon.jsf.controller.factory.xml.XmlAttributeFactory;
import org.openfuxml.xml.addon.jsf.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class JsfComponentFactory {
  final static Logger logger=LoggerFactory.getLogger(JsfComponentFactory.class);
  private Component component;
  private Namespace ns;
  public JsfComponentFactory(){
    java.lang.String genVar239;
    genVar239="composite";
    java.lang.String genVar240;
    genVar240="http://java.sun.com/jsf/composite";
    ns=Namespace.getNamespace(genVar239,genVar240);
  }
  public Component buildComponent(  String resourceName){
    component=new Component();
    try {
      JsfComponentFactory genVar241;
      genVar241=this;
      genVar241.read(resourceName);
    }
 catch (    FileNotFoundException e) {
      e.printStackTrace();
    }
catch (    JDOMException e) {
      e.printStackTrace();
    }
    return component;
  }
  private void read(  String resourceName) throws FileNotFoundException, JDOMException {
    MultiResourceLoader mrl;
    mrl=new MultiResourceLoader();
    java.lang.String genVar242;
    genVar242="MRL: ";
    boolean genVar243;
    genVar243=mrl.isAvailable(resourceName);
    java.lang.String genVar244;
    genVar244=genVar242 + genVar243;
    logger.trace(genVar244);
    InputStream is;
    is=mrl.searchIs(resourceName);
    java.lang.String genVar245;
    genVar245="UTF-8";
    Document doc;
    doc=JDomUtil.load(is,genVar245);
    String xpath;
    xpath="//composite:attribute";
    org.jdom2.xpath.XPathFactory genVar246;
    genVar246=XPathFactory.instance();
    org.jdom2.filter.Filter<org.jdom2.Element> genVar247;
    genVar247=Filters.element();
    XPathExpression<Element> xpe;
    xpe=genVar246.compile(xpath,genVar247,null,ns);
    List<Element> elements;
    elements=xpe.evaluate(doc);
    for (    Element e : elements) {
      JsfComponentFactory genVar248;
      genVar248=this;
      genVar248.addAttribute(e);
    }
  }
  private void addAttribute(  Element e) throws DataConversionException {
    org.jdom2.Attribute attribute;
    java.lang.String genVar249;
    genVar249="name";
    String name;
    name=e.getAttributeValue(genVar249);
    boolean required;
    required=false;
    java.lang.String genVar250;
    genVar250="required";
    attribute=e.getAttribute(genVar250);
    boolean genVar251;
    genVar251=attribute != null;
    if (genVar251) {
      required=attribute.getBooleanValue();
    }
 else {
      ;
    }
    String sDefault;
    sDefault=null;
    java.lang.String genVar252;
    genVar252="default";
    attribute=e.getAttribute(genVar252);
    boolean genVar253;
    genVar253=attribute != null;
    if (genVar253) {
      sDefault=attribute.getValue();
    }
 else {
      ;
    }
    String sDescription;
    sDescription=null;
    java.lang.String genVar254;
    genVar254="shortDescription";
    attribute=e.getAttribute(genVar254);
    boolean genVar255;
    genVar255=attribute != null;
    if (genVar255) {
      sDescription=attribute.getValue();
    }
 else {
      ;
    }
    java.util.List<java.lang.String> genVar256;
    genVar256=component.getAttribute();
    java.lang.String genVar257;
    genVar257=XmlAttributeFactory.create(name,required,sDefault,sDescription);
    genVar256.add(genVar257);
  }
}
