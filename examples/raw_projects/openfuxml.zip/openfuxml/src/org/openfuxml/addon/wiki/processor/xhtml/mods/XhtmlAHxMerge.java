package org.openfuxml.addon.wiki.processor.xhtml.mods;
import java.util.regex.Pattern;
import net.sf.exlp.util.xml.JDomUtil;
import org.jdom2.Attribute;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class XhtmlAHxMerge {
  final static Logger logger=LoggerFactory.getLogger(XhtmlAHxMerge.class);
  private Pattern p;
  public XhtmlAHxMerge(){
    java.lang.String genVar1011;
    genVar1011="h[\\d](.*)";
    p=Pattern.compile(genVar1011);
  }
  public String merge(  String xHtmlText){
    Document doc;
    doc=null;
    try {
      doc=JDomUtil.txtToDoc(xHtmlText);
    }
 catch (    JDOMException e) {
      java.lang.String genVar1012;
      genVar1012="";
      logger.error(genVar1012,e);
    }
    Element rootElement;
    rootElement=doc.getRootElement();
    rootElement.detach();
    XhtmlAHxMerge genVar1013;
    genVar1013=this;
    org.jdom2.Element genVar1014;
    genVar1014=genVar1013.merge(rootElement);
    doc.setRootElement(genVar1014);
    xHtmlText=JDomUtil.docToTxt(doc);
    return xHtmlText;
  }
  public Element merge(  Element oldRoot){
    java.lang.String genVar1015;
    genVar1015=oldRoot.getName();
    Element newRoot;
    newRoot=new Element(genVar1015);
    java.util.List<org.jdom2.Attribute> genVar1016;
    genVar1016=oldRoot.getAttributes();
    for (    Object oAtt : genVar1016) {
      Attribute att;
      att=(Attribute)oAtt;
      java.lang.String genVar1017;
      genVar1017=att.getName();
      java.lang.String genVar1018;
      genVar1018=att.getValue();
      Attribute newAtt;
      newAtt=new Attribute(genVar1017,genVar1018);
      newRoot.setAttribute(newAtt);
    }
    Element prevChild;
    prevChild=null;
    java.util.List<org.jdom2.Content> genVar1019;
    genVar1019=oldRoot.getContent();
    for (    Object o : genVar1019) {
      java.lang.Class<org.jdom2.Text> genVar1020;
      genVar1020=org.jdom2.Text.class;
      boolean genVar1021;
      genVar1021=genVar1020.isInstance(o);
      if (genVar1021) {
        boolean genVar1022;
        genVar1022=prevChild != null;
        if (genVar1022) {
          newRoot.addContent(prevChild);
          prevChild=null;
        }
 else {
          ;
        }
        Text txt;
        txt=(Text)o;
        java.lang.String genVar1023;
        genVar1023=txt.getText();
        Text newText;
        newText=new Text(genVar1023);
        newRoot.addContent(newText);
      }
 else {
        java.lang.Class<org.jdom2.Element> genVar1024;
        genVar1024=org.jdom2.Element.class;
        boolean genVar1025;
        genVar1025=genVar1024.isInstance(o);
        if (genVar1025) {
          Element oldChild;
          oldChild=(Element)o;
          Element newChild;
          newChild=null;
          boolean genVar1026;
          genVar1026=prevChild != null;
          if (genVar1026) {
            java.lang.String genVar1027;
            genVar1027=prevChild.getName();
            java.lang.String genVar1028;
            genVar1028="a";
            boolean prevA;
            prevA=genVar1027.equals(genVar1028);
            java.lang.String genVar1029;
            genVar1029=oldChild.getName();
            java.util.regex.Matcher genVar1030;
            genVar1030=p.matcher(genVar1029);
            boolean thisH;
            thisH=genVar1030.matches();
            java.lang.String genVar1031;
            genVar1031=prevChild.getName();
            java.lang.String genVar1032;
            genVar1032="-";
            java.lang.String genVar1033;
            genVar1033=oldChild.getName();
            java.lang.String genVar1034;
            genVar1034=" :";
            java.lang.String genVar1035;
            genVar1035="-";
            java.lang.String genVar1036;
            genVar1036=genVar1031 + genVar1032 + genVar1033+ genVar1034+ prevA+ genVar1035+ thisH;
            logger.debug(genVar1036);
            boolean genVar1037;
            genVar1037=prevA && thisH;
            if (genVar1037) {
            }
 else {
              newRoot.addContent(prevChild);
              prevChild=null;
            }
          }
 else {
            ;
          }
          XhtmlAHxMerge genVar1038;
          genVar1038=this;
          org.jdom2.Element genVar1039;
          genVar1039=genVar1038.merge(oldChild);
          prevChild=(genVar1039);
        }
 else {
          java.lang.String genVar1040;
          genVar1040="Unknown content: ";
          java.lang.Class genVar1041;
          genVar1041=o.getClass();
          java.lang.String genVar1042;
          genVar1042=genVar1041.getName();
          java.lang.String genVar1043;
          genVar1043=genVar1040 + genVar1042;
          logger.warn(genVar1043);
        }
      }
    }
    boolean genVar1044;
    genVar1044=prevChild != null;
    if (genVar1044) {
      newRoot.addContent(prevChild);
      prevChild=null;
    }
 else {
      ;
    }
    return newRoot;
  }
}
