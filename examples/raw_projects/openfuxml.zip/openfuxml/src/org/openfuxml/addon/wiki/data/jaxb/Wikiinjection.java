package org.openfuxml.addon.wiki.data.jaxb;
public class Wikiinjection {
  public int getId(){
    int genVar411;
    genVar411=1;
    int genVar412;
    genVar412=-genVar411;
    return genVar412;
  }
  public String getOfxtag(){
    return null;
  }
}
