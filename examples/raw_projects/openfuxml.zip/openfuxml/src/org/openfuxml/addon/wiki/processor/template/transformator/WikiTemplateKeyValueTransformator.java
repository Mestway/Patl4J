package org.openfuxml.addon.wiki.processor.template.transformator;
import net.sf.exlp.core.handler.EhResultContainer;
import net.sf.exlp.core.listener.LogListenerString;
import net.sf.exlp.interfaces.LogEvent;
import net.sf.exlp.interfaces.LogListener;
import net.sf.exlp.interfaces.LogParser;
import net.sf.exlp.util.config.ConfigLoader;
import net.sf.exlp.util.io.LoggerInit;
import net.sf.exlp.util.xml.JDomUtil;
import net.sf.exlp.util.xml.JaxbUtil;
import net.sf.exlp.xml.ns.NsPrefixMapperInterface;
import org.apache.commons.configuration.Configuration;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.openfuxml.addon.wiki.data.jaxb.Template;
import org.openfuxml.addon.wiki.processor.markup.WikiInlineProcessor;
import org.openfuxml.addon.wiki.processor.template.exlp.event.WikiKeyValueEvent;
import org.openfuxml.addon.wiki.processor.template.exlp.parser.WikiKeyValueParser;
import org.openfuxml.xml.OfxNsPrefixMapper;
import org.openfuxml.xml.renderer.cmp.Cmp;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class WikiTemplateKeyValueTransformator {
  final static Logger logger=LoggerFactory.getLogger(WikiTemplateKeyValueTransformator.class);
  private Namespace nsOfx;
  private NsPrefixMapperInterface nsPrefixMapper;
  private WikiInlineProcessor wikiInlineProcessor;
  public WikiTemplateKeyValueTransformator(  WikiInlineProcessor wikiInlineProcessor){
    org.openfuxml.addon.wiki.processor.template.transformator.WikiTemplateKeyValueTransformator genVar839;
    genVar839=this;
    genVar839.wikiInlineProcessor=wikiInlineProcessor;
    nsPrefixMapper=new OfxNsPrefixMapper();
    java.lang.String genVar840;
    genVar840="ofx";
    java.lang.String genVar841;
    genVar841="http://www.openfuxml.org";
    nsOfx=Namespace.getNamespace(genVar840,genVar841);
  }
  public Element transform(  Template templateDef,  Template template){
    EhResultContainer leh;
    leh=new EhResultContainer();
    LogParser lp;
    lp=new WikiKeyValueParser(leh);
    org.openfuxml.addon.wiki.processor.markup.WikiMarkupProcessor genVar842;
    genVar842=template.getMarkup();
    java.lang.String genVar843;
    genVar843=genVar842.getValue();
    LogListener ll;
    ll=new LogListenerString(genVar843,lp);
    ll.processSingle();
    java.util.ArrayList<net.sf.exlp.interfaces.LogEvent> genVar844;
    genVar844=leh.getAlResults();
    for (    LogEvent logEvent : genVar844) {
      WikiKeyValueEvent kvEvent;
      kvEvent=(WikiKeyValueEvent)logEvent;
      java.util.List<org.openfuxml.addon.wiki.data.jaxb.TemplateKv> genVar845;
      genVar845=template.getTemplateKv();
      org.openfuxml.addon.wiki.data.jaxb.TemplateKv genVar846;
      genVar846=kvEvent.getKv();
      genVar845.add(genVar846);
    }
    WikiTemplateKeyValueTransformator genVar847;
    genVar847=this;
    org.jdom2.Element genVar848;
    genVar848=genVar847.transformWithClass(templateDef,template);
    return genVar848;
  }
  private Element transformWithClass(  Template templateDef,  Template template){
    WikiTemplateGenericTable genericTable;
    genericTable=new WikiTemplateGenericTable(nsPrefixMapper);
    genericTable.setWikiInlineProcessor(wikiInlineProcessor);
    Element e;
    e=genericTable.transform(template);
    return e;
  }
  public static void main(  String[] args) throws Exception {
    java.lang.String genVar849;
    genVar849="log4j.xml";
    LoggerInit loggerInit;
    loggerInit=new LoggerInit(genVar849);
    java.lang.String genVar850;
    genVar850="resources/config";
    loggerInit.addAltPath(genVar850);
    loggerInit.init();
    String propFile;
    propFile="resources/properties/user.properties";
    int genVar851;
    genVar851=1;
    boolean genVar852;
    genVar852=args.length == genVar851;
    if (genVar852) {
      int genVar853;
      genVar853=0;
      propFile=args[genVar853];
    }
 else {
      ;
    }
    ConfigLoader.add(propFile);
    Configuration config;
    config=ConfigLoader.init();
    java.lang.String genVar854;
    genVar854="ofx.xml.cmp";
    String fNameCmp;
    fNameCmp=config.getString(genVar854);
    java.lang.Class<org.openfuxml.xml.renderer.cmp.Cmp> genVar855;
    genVar855=Cmp.class;
    org.openfuxml.xml.renderer.cmp.Cmp genVar856;
    genVar856=JaxbUtil.loadJAXB(fNameCmp,genVar855);
    Cmp cmp;
    cmp=(Cmp)genVar856;
    WikiInlineProcessor wikiInline;
    wikiInline=new WikiInlineProcessor(cmp);
    java.lang.String genVar857;
    genVar857="wiki.processor.test.template.kv";
    String fnTemplate;
    fnTemplate=config.getString(genVar857);
    java.lang.Class<org.openfuxml.addon.wiki.data.jaxb.Template> genVar858;
    genVar858=Template.class;
    org.openfuxml.addon.wiki.data.jaxb.Template genVar859;
    genVar859=JaxbUtil.loadJAXB(fnTemplate,genVar858);
    Template template;
    template=(Template)genVar859;
    Template templateDef;
    templateDef=new Template();
    java.lang.String genVar860;
    genVar860="xx";
    templateDef.setClazz(genVar860);
    WikiTemplateKeyValueTransformator kvTransformator;
    kvTransformator=new WikiTemplateKeyValueTransformator(wikiInline);
    Element e;
    e=kvTransformator.transform(templateDef,template);
    JDomUtil.debug(e);
  }
}
