package org.openfuxml.addon.wiki.media.chart.factory;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.xpath.XPath;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@Deprecated public class AbstractChartFactory {
  final static Logger logger=LoggerFactory.getLogger(AbstractChartFactory.class);
  protected double getChartValue(  String xp,  String type,  Document doc){
    double value;
    value=0;
    try {
      java.lang.String genVar521;
      genVar521="[@type='";
      java.lang.String genVar522;
      genVar522="']";
      java.lang.String genVar523;
      genVar523=xp + genVar521 + type+ genVar522;
      XPath xPath;
      xPath=XPath.newInstance(genVar523);
      java.lang.Object genVar524;
      genVar524=xPath.selectSingleNode(doc);
      Element element;
      element=(Element)genVar524;
      java.lang.String genVar525;
      genVar525=element.getTextTrim();
      value=new Double(genVar525);
    }
 catch (    JDOMException e) {
      java.lang.String genVar526;
      genVar526="";
      logger.error(genVar526,e);
    }
    return value;
  }
}
