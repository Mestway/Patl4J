package org.openfuxml.addon.wiki.data.jaxb;
import java.util.List;
public class Category {
  public List<Page> getPage(){
    return null;
  }
}
