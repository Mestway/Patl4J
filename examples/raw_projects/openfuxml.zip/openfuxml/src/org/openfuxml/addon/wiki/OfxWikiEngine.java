package org.openfuxml.addon.wiki;
public class OfxWikiEngine {
  public enum Status {  xhtmlProcessed,   xhtmlFinal}
}
