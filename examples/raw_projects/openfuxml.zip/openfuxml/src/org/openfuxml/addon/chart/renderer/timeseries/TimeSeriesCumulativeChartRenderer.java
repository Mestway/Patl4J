package org.openfuxml.addon.chart.renderer.timeseries;
import org.openfuxml.addon.chart.renderer.generic.OfxChartRenderer;
public class TimeSeriesCumulativeChartRenderer extends OfxChartRenderer {
}
