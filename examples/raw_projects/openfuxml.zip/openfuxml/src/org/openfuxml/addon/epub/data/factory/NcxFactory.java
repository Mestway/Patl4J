package org.openfuxml.addon.epub.data.factory;
import org.openfuxml.addon.epub.data.jaxb.ncx.NavMap.NavPoint;
import org.openfuxml.content.ofx.Metadata;
import org.openfuxml.content.ofx.Title;
public class NcxFactory {
  public static Metadata getHeadMeta(  String name,  String value){
    return null;
  }
  public static NavPoint getNavPoint(  String id,  int palyOrder,  String title,  String partName){
    return null;
  }
  public static Title getTitle(  String value){
    return null;
  }
}
