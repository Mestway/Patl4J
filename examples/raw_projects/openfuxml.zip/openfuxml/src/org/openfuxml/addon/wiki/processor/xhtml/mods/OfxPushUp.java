package org.openfuxml.addon.wiki.processor.xhtml.mods;
import java.util.ArrayList;
import net.sf.exlp.util.xml.JDomUtil;
import org.jdom2.Attribute;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class OfxPushUp {
  final static Logger logger=LoggerFactory.getLogger(OfxPushUp.class);
  public OfxPushUp(){
  }
  public String moveOfxElements(  String xHtmlText){
    Document doc;
    doc=null;
    try {
      doc=JDomUtil.txtToDoc(xHtmlText);
    }
 catch (    JDOMException e) {
      java.lang.String genVar931;
      genVar931="";
      logger.error(genVar931,e);
    }
    Element rootElement;
    rootElement=doc.getRootElement();
    rootElement.detach();
    OfxPushUp genVar932;
    genVar932=this;
    java.lang.String genVar933;
    genVar933="wikiinjection";
    int genVar934;
    genVar934=0;
    ArrayList<Element> al;
    al=genVar932.moveOfxElement(rootElement,genVar933,genVar934);
    int genVar935;
    genVar935=al.size();
    int genVar936;
    genVar936=1;
    boolean genVar937;
    genVar937=genVar935 > genVar936;
    if (genVar937) {
      java.lang.String genVar938;
      genVar938="Moved Elements has a size>1 !!!";
      logger.warn(genVar938);
    }
 else {
      ;
    }
    int genVar939;
    genVar939=0;
    rootElement=al.get(genVar939);
    doc.addContent(rootElement);
    xHtmlText=JDomUtil.docToTxt(doc);
    return xHtmlText;
  }
  public ArrayList<Element> moveOfxElement(  Element oldRoot,  String tag,  int level){
    ArrayList<Element> movedElements;
    movedElements=new ArrayList<Element>();
    java.lang.String genVar940;
    genVar940=oldRoot.getName();
    Element newRoot;
    newRoot=new Element(genVar940);
    java.util.List<org.jdom2.Attribute> genVar941;
    genVar941=oldRoot.getAttributes();
    for (    Object oAtt : genVar941) {
      Attribute att;
      att=(Attribute)oAtt;
      java.lang.String genVar942;
      genVar942=att.getName();
      java.lang.String genVar943;
      genVar943=att.getValue();
      Attribute newAtt;
      newAtt=new Attribute(genVar942,genVar943);
      newRoot.setAttribute(newAtt);
    }
    StringBuffer sb;
    sb=new StringBuffer();
    java.lang.String genVar944;
    genVar944="Tag=";
    java.lang.String genVar945;
    genVar945=" Level=";
    java.lang.String genVar946;
    genVar946=genVar944 + tag + genVar945+ level;
    sb.append(genVar946);
    java.util.List<org.jdom2.Content> genVar947;
    genVar947=oldRoot.getContent();
    for (    Object o : genVar947) {
      java.lang.Class<org.jdom2.Text> genVar948;
      genVar948=org.jdom2.Text.class;
      boolean genVar949;
      genVar949=genVar948.isInstance(o);
      if (genVar949) {
        Text txt;
        txt=(Text)o;
        java.lang.String genVar950;
        genVar950=txt.getText();
        Text newText;
        newText=new Text(genVar950);
        newRoot.addContent(newText);
        java.lang.String genVar951;
        genVar951=" txt";
        sb.append(genVar951);
      }
 else {
        java.lang.Class<org.jdom2.Element> genVar952;
        genVar952=org.jdom2.Element.class;
        boolean genVar953;
        genVar953=genVar952.isInstance(o);
        if (genVar953) {
          Element oldChild;
          oldChild=(Element)o;
          java.lang.String genVar954;
          genVar954=" ";
          java.lang.String genVar955;
          genVar955=oldChild.getName();
          java.lang.String genVar956;
          genVar956=genVar954 + genVar955;
          sb.append(genVar956);
          java.lang.String genVar957;
          genVar957=oldChild.getName();
          boolean genVar958;
          genVar958=genVar957.equals(tag);
          if (genVar958) {
            java.lang.String genVar959;
            genVar959="Detaching ";
            java.lang.String genVar960;
            genVar960=oldChild.getName();
            java.lang.String genVar961;
            genVar961=genVar959 + genVar960;
            logger.debug(genVar961);
            OfxPushUp genVar962;
            genVar962=this;
            int genVar963;
            genVar963=1;
            int genVar964;
            genVar964=level + genVar963;
            java.util.ArrayList<org.jdom2.Element> genVar965;
            genVar965=genVar962.moveOfxElement(oldChild,tag,genVar964);
            movedElements.addAll(genVar965);
          }
 else {
            OfxPushUp genVar966;
            genVar966=this;
            int genVar967;
            genVar967=1;
            int genVar968;
            genVar968=level + genVar967;
            ArrayList<Element> al;
            al=genVar966.moveOfxElement(oldChild,tag,genVar968);
            newRoot.addContent(al);
          }
        }
 else {
          java.lang.String genVar969;
          genVar969="Unknown content: ";
          java.lang.Class genVar970;
          genVar970=o.getClass();
          java.lang.String genVar971;
          genVar971=genVar970.getName();
          java.lang.String genVar972;
          genVar972=genVar969 + genVar971;
          logger.warn(genVar972);
        }
      }
    }
    java.lang.String genVar973;
    genVar973=sb.toString();
    logger.trace(genVar973);
    ArrayList<Element> result;
    result=new ArrayList<Element>();
    result.add(newRoot);
    result.addAll(movedElements);
    return result;
  }
}
