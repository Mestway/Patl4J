package org.openfuxml.addon.wiki.emitter.injection;
import javax.xml.stream.XMLStreamException;
import net.sf.exlp.util.xml.JDomUtil;
import org.jdom2.Element;
import org.openfuxml.addon.wiki.data.jaxb.Wikiinjection;
import org.openfuxml.addon.wiki.util.JdomXmlStreamer;
import org.openfuxml.addon.wiki.util.WikiContentIO;
import org.openfuxml.content.fuxml.AbsatzOhne;
import org.openfuxml.content.fuxml.Grafik;
import org.openfuxml.content.fuxml.Medienobjekt;
import org.openfuxml.content.fuxml.medienobjekt.Objekttitel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class OfxChartEmitter {
  final static Logger logger=LoggerFactory.getLogger(OfxChartEmitter.class);
  private Wikiinjection injection;
  public OfxChartEmitter(  Wikiinjection injection){
    org.openfuxml.addon.wiki.emitter.injection.OfxChartEmitter genVar440;
    genVar440=this;
    genVar440.injection=injection;
  }
  private Element createOfxContent(){
    AbsatzOhne absatz;
    absatz=new AbsatzOhne();
    java.lang.String genVar441;
    genVar441="TestTitel";
    absatz.setValue(genVar441);
    Objekttitel objektitel;
    objektitel=new Objekttitel();
    java.util.List<org.openfuxml.content.fuxml.AbsatzOhne> genVar442;
    genVar442=objektitel.getAbsatzOhne();
    genVar442.add(absatz);
    Grafik grafik;
    grafik=new Grafik();
    java.lang.String genVar443;
    genVar443="left";
    grafik.setAlign(genVar443);
    java.lang.String genVar444;
    genVar444="nicht";
    grafik.setFliessen(genVar444);
    int genVar445;
    genVar445=480;
    grafik.setWidth(genVar445);
    int genVar446;
    genVar446=320;
    grafik.setDepth(genVar446);
    double genVar447;
    genVar447=1.0;
    grafik.setScale(genVar447);
    java.lang.String genVar448;
    genVar448="../bilder/web/";
    int genVar449;
    genVar449=injection.getId();
    java.lang.String genVar450;
    genVar450="-";
    java.lang.String genVar451;
    genVar451=injection.getOfxtag();
    java.lang.String genVar452;
    genVar452=".png";
    java.lang.String genVar453;
    genVar453=genVar448 + genVar449 + genVar450+ genVar451+ genVar452;
    grafik.setFileref(genVar453);
    Medienobjekt medienobjekt;
    medienobjekt=new Medienobjekt();
    java.lang.String genVar454;
    genVar454="ja";
    medienobjekt.setGleiten(genVar454);
    java.lang.String genVar455;
    genVar455="testId";
    medienobjekt.setId(genVar455);
    medienobjekt.setObjekttitel(objektitel);
    java.util.List<org.openfuxml.content.fuxml.Grafik> genVar456;
    genVar456=medienobjekt.getGrafik();
    genVar456.add(grafik);
    java.lang.Class<org.openfuxml.content.fuxml.Medienobjekt> genVar457;
    genVar457=Medienobjekt.class;
    Element result;
    result=WikiContentIO.toElement(medienobjekt,genVar457);
    return result;
  }
  public void transform(  JdomXmlStreamer jdomStreamer){
    OfxChartEmitter genVar458;
    genVar458=this;
    Element e;
    e=genVar458.createOfxContent();
    JDomUtil.debugElement(e);
    try {
      jdomStreamer.write(e);
    }
 catch (    XMLStreamException e1) {
      java.lang.String genVar459;
      genVar459="";
      logger.error(genVar459,e);
    }
  }
}
