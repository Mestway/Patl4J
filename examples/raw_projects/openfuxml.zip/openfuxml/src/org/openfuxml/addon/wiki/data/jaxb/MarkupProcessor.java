package org.openfuxml.addon.wiki.data.jaxb;
import org.openfuxml.addon.jsfapp.data.jaxb.Ofxinjections;
public class MarkupProcessor {
  public Replacements getReplacements(){
    return null;
  }
  public Ofxinjections getInjections(){
    return null;
  }
}
