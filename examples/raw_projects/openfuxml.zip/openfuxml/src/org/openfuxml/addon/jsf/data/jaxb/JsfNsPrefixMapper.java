package org.openfuxml.addon.jsf.data.jaxb;
import net.sf.exlp.xml.ns.NsPrefixMapperInterface;
public class JsfNsPrefixMapper implements NsPrefixMapperInterface {
  @Override public String[] getPreDeclaredNamespaceUris(){
    return null;
  }
  @Override public String getPreferredPrefix(  String arg0,  String arg1,  boolean arg2){
    return null;
  }
}
