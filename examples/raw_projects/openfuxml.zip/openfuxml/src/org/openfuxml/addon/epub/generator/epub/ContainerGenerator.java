package org.openfuxml.addon.epub.generator.epub;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import net.sf.exlp.util.xml.JDomUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.jdom2.output.Format;
import org.openfuxml.renderer.processor.pre.OfxExternalMerger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class ContainerGenerator {
  final static Logger logger=LoggerFactory.getLogger(OfxExternalMerger.class);
  private File targetDir;
  private Document doc;
  private Namespace nsContainer;
  public ContainerGenerator(  File targetDir){
    org.openfuxml.addon.epub.generator.epub.ContainerGenerator genVar169;
    genVar169=this;
    genVar169.targetDir=targetDir;
    java.lang.String genVar170;
    genVar170="urn:oasis:names:tc:opendocument:xmlns:container";
    nsContainer=Namespace.getNamespace(genVar170);
  }
  public void create(){
    doc=new Document();
    java.lang.String genVar171;
    genVar171="container";
    Element eContainer;
    eContainer=new Element(genVar171);
    java.lang.String genVar172;
    genVar172="version";
    java.lang.String genVar173;
    genVar173="1.0";
    eContainer.setAttribute(genVar172,genVar173);
    eContainer.setNamespace(nsContainer);
    ContainerGenerator genVar174;
    genVar174=this;
    org.jdom2.Element genVar175;
    genVar175=genVar174.getRootfiles();
    eContainer.addContent(genVar175);
    doc.setRootElement(eContainer);
    ContainerGenerator genVar176;
    genVar176=this;
    genVar176.save();
  }
  private Element getRootfiles(){
    java.lang.String genVar177;
    genVar177="rootfiles";
    Element eRootfiles;
    eRootfiles=new Element(genVar177,nsContainer);
    ContainerGenerator genVar178;
    genVar178=this;
    java.util.List<org.jdom2.Element> genVar179;
    genVar179=genVar178.getRootfile();
    for (    Element e : genVar179) {
      eRootfiles.addContent(e);
    }
    return eRootfiles;
  }
  private List<Element> getRootfile(){
    List<Element> lRootfiles;
    lRootfiles=new ArrayList<Element>();
    java.lang.String genVar180;
    genVar180="rootfile";
    Element eRootfile;
    eRootfile=new Element(genVar180,nsContainer);
    java.lang.String genVar181;
    genVar181="media-type";
    java.lang.String genVar182;
    genVar182="application/oebps-package+xml";
    eRootfile.setAttribute(genVar181,genVar182);
    java.lang.String genVar183;
    genVar183="full-path";
    java.lang.String genVar184;
    genVar184="content.opf";
    eRootfile.setAttribute(genVar183,genVar184);
    lRootfiles.add(eRootfile);
    return lRootfiles;
  }
  private void save(){
    java.lang.String genVar185;
    genVar185="META-INF";
    File dMetainf;
    dMetainf=new File(targetDir,genVar185);
    dMetainf.mkdir();
    java.lang.String genVar186;
    genVar186="container.xml";
    File f;
    f=new File(dMetainf,genVar186);
    org.jdom2.output.Format genVar187;
    genVar187=Format.getPrettyFormat();
    JDomUtil.save(doc,f,genVar187);
  }
}
