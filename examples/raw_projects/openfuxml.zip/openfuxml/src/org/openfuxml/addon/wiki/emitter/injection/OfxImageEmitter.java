package org.openfuxml.addon.wiki.emitter.injection;
import javax.xml.stream.XMLStreamException;
import net.sf.exlp.util.xml.JDomUtil;
import org.jdom2.Element;
import org.openfuxml.addon.wiki.data.jaxb.Ofxgallery.Ofximage;
import org.openfuxml.addon.wiki.util.JdomXmlStreamer;
import org.openfuxml.addon.wiki.util.WikiContentIO;
import org.openfuxml.content.fuxml.AbsatzOhne;
import org.openfuxml.content.fuxml.Grafik;
import org.openfuxml.content.fuxml.Medienobjekt;
import org.openfuxml.content.fuxml.medienobjekt.Objekttitel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class OfxImageEmitter {
  final static Logger logger=LoggerFactory.getLogger(OfxImageEmitter.class);
  private Ofximage image;
  private String fileName;
  public OfxImageEmitter(  Ofximage image,  String fileName){
    org.openfuxml.addon.wiki.emitter.injection.OfxImageEmitter genVar422;
    genVar422=this;
    genVar422.image=image;
    org.openfuxml.addon.wiki.emitter.injection.OfxImageEmitter genVar423;
    genVar423=this;
    genVar423.fileName=fileName;
  }
  private Element createOfxContent(){
    AbsatzOhne absatz;
    absatz=new AbsatzOhne();
    java.lang.String genVar424;
    genVar424=image.getValue();
    absatz.setValue(genVar424);
    Objekttitel objektitel;
    objektitel=new Objekttitel();
    java.util.List<org.openfuxml.content.fuxml.AbsatzOhne> genVar425;
    genVar425=objektitel.getAbsatzOhne();
    genVar425.add(absatz);
    Grafik grafik;
    grafik=new Grafik();
    java.lang.String genVar426;
    genVar426="left";
    grafik.setAlign(genVar426);
    java.lang.String genVar427;
    genVar427="nicht";
    grafik.setFliessen(genVar427);
    int genVar428;
    genVar428=480;
    grafik.setWidth(genVar428);
    int genVar429;
    genVar429=320;
    grafik.setDepth(genVar429);
    double genVar430;
    genVar430=1.0;
    grafik.setScale(genVar430);
    java.lang.String genVar431;
    genVar431="../bilder/web/";
    java.lang.String genVar432;
    genVar432=".png";
    java.lang.String genVar433;
    genVar433=genVar431 + fileName + genVar432;
    grafik.setFileref(genVar433);
    Medienobjekt medienobjekt;
    medienobjekt=new Medienobjekt();
    java.lang.String genVar434;
    genVar434="ja";
    medienobjekt.setGleiten(genVar434);
    java.lang.String genVar435;
    genVar435="testId";
    medienobjekt.setId(genVar435);
    medienobjekt.setObjekttitel(objektitel);
    java.util.List<org.openfuxml.content.fuxml.Grafik> genVar436;
    genVar436=medienobjekt.getGrafik();
    genVar436.add(grafik);
    java.lang.Class<org.openfuxml.content.fuxml.Medienobjekt> genVar437;
    genVar437=Medienobjekt.class;
    Element result;
    result=WikiContentIO.toElement(medienobjekt,genVar437);
    return result;
  }
  public void transform(  JdomXmlStreamer jdomStreamer){
    OfxImageEmitter genVar438;
    genVar438=this;
    Element e;
    e=genVar438.createOfxContent();
    JDomUtil.debugElement(e);
    try {
      jdomStreamer.write(e);
    }
 catch (    XMLStreamException e1) {
      java.lang.String genVar439;
      genVar439="";
      logger.error(genVar439,e);
    }
  }
}
