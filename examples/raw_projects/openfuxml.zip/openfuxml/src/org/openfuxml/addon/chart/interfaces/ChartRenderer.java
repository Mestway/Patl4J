package org.openfuxml.addon.chart.interfaces;
import org.jfree.chart.JFreeChart;
import org.openfuxml.addon.chart.jaxb.Chart;
import org.openfuxml.addon.chart.jaxb.Charttype;
public interface ChartRenderer {
  public JFreeChart render(  Chart ofxChart);
  public Charttype.Timeseries getTimeseries();
}
