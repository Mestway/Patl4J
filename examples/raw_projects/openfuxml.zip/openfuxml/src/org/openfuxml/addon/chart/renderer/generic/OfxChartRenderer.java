package org.openfuxml.addon.chart.renderer.generic;
import org.jfree.chart.JFreeChart;
import org.openfuxml.addon.chart.interfaces.ChartRenderer;
import org.openfuxml.addon.chart.jaxb.Chart;
import org.openfuxml.addon.chart.jaxb.Charttype.Timeseries;
public class OfxChartRenderer implements ChartRenderer {
  @Override public JFreeChart render(  Chart ofxChart){
    return null;
  }
  @Override public Timeseries getTimeseries(){
    return null;
  }
}
