package org.openfuxml.addon.wiki.processor.template.transformator;
import java.io.Serializable;
import java.util.List;
import net.sf.exlp.util.xml.JaxbUtil;
import net.sf.exlp.xml.ns.NsPrefixMapperInterface;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.openfuxml.addon.wiki.data.jaxb.Template;
import org.openfuxml.addon.wiki.data.jaxb.TemplateKv;
import org.openfuxml.addon.wiki.processor.markup.WikiInlineProcessor;
import org.openfuxml.content.ofx.Paragraph;
import org.openfuxml.content.ofx.Section;
import org.openfuxml.content.ofx.Title;
import org.openfuxml.content.table.Body;
import org.openfuxml.content.table.Cell;
import org.openfuxml.content.table.Columns;
import org.openfuxml.content.table.Content;
import org.openfuxml.content.table.Head;
import org.openfuxml.content.table.Row;
import org.openfuxml.content.table.Specification;
import org.openfuxml.content.table.Table;
import org.openfuxml.exception.OfxInternalProcessingException;
import org.openfuxml.factory.ofx.table.ColumnFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class WikiTemplateGenericTable implements WikiTemplateTransformator {
  final static Logger logger=LoggerFactory.getLogger(WikiTemplateGenericTable.class);
  private final Namespace nsOfx=Namespace.getNamespace("ofx","http://www.openfuxml.org");
  private NsPrefixMapperInterface nsPrefixMapper;
  private WikiInlineProcessor wikiInlineProcessor;
  public WikiTemplateGenericTable(  NsPrefixMapperInterface nsPrefixMapper){
    org.openfuxml.addon.wiki.processor.template.transformator.WikiTemplateGenericTable genVar791;
    genVar791=this;
    genVar791.nsPrefixMapper=nsPrefixMapper;
  }
  public Element transform(  Template template){
    Section section;
    section=new Section();
    boolean genVar792;
    genVar792=true;
    section.setContainer(genVar792);
    WikiTemplateGenericTable genVar793;
    genVar793=this;
    java.util.List<org.openfuxml.addon.wiki.data.jaxb.TemplateKv> genVar794;
    genVar794=template.getTemplateKv();
    Table table;
    table=genVar793.getTable(genVar794);
    java.util.List<org.openfuxml.content.table.Table> genVar795;
    genVar795=section.getContent();
    genVar795.add(table);
    org.jdom2.Document genVar796;
    genVar796=JaxbUtil.toDocument(section,nsPrefixMapper);
    Element result;
    result=genVar796.getRootElement();
    result.detach();
    return result;
  }
  private Table getTable(  List<TemplateKv> listKv){
    Table table;
    table=new Table();
    WikiTemplateGenericTable genVar797;
    genVar797=this;
    org.openfuxml.content.ofx.Title genVar798;
    genVar798=genVar797.getTitle();
    table.setTitle(genVar798);
    WikiTemplateGenericTable genVar799;
    genVar799=this;
    org.openfuxml.content.table.Specification genVar800;
    genVar800=genVar799.getSpecification();
    table.setSpecification(genVar800);
    WikiTemplateGenericTable genVar801;
    genVar801=this;
    org.openfuxml.content.table.Content genVar802;
    genVar802=genVar801.getTableContent(listKv);
    table.setContent(genVar802);
    return table;
  }
  private Specification getSpecification(){
    Specification specification;
    specification=new Specification();
    Columns columns;
    columns=new Columns();
    java.util.List<org.openfuxml.content.table.Columns> genVar803;
    genVar803=columns.getColumn();
    java.lang.String genVar804;
    genVar804="left";
    int genVar805;
    genVar805=2;
    org.openfuxml.content.table.Columns genVar806;
    genVar806=ColumnFactory.create(genVar804,genVar805);
    genVar803.add(genVar806);
    java.util.List<org.openfuxml.content.table.Columns> genVar807;
    genVar807=columns.getColumn();
    java.lang.String genVar808;
    genVar808="left";
    int genVar809;
    genVar809=4;
    org.openfuxml.content.table.Columns genVar810;
    genVar810=ColumnFactory.create(genVar808,genVar809);
    genVar807.add(genVar810);
    specification.setColumns(columns);
    return specification;
  }
  private Title getTitle(){
    Title title;
    title=new Title();
    java.lang.String genVar811;
    genVar811="TestTitel";
    title.setValue(genVar811);
    return title;
  }
  private Content getTableContent(  List<TemplateKv> listKv){
    Content tgroup;
    tgroup=new Content();
    WikiTemplateGenericTable genVar812;
    genVar812=this;
    org.openfuxml.content.table.Head genVar813;
    genVar813=genVar812.getTableHead();
    tgroup.setHead(genVar813);
    java.util.List<org.openfuxml.content.table.Body> genVar814;
    genVar814=tgroup.getBody();
    WikiTemplateGenericTable genVar815;
    genVar815=this;
    org.openfuxml.content.table.Body genVar816;
    genVar816=genVar815.getTableBody(listKv);
    genVar814.add(genVar816);
    return tgroup;
  }
  private Head getTableHead(){
    Head head;
    head=new Head();
    Row row;
    row=new Row();
    Cell cellKey;
    cellKey=new Cell();
    java.util.List<java.lang.Object> genVar817;
    genVar817=cellKey.getContent();
    java.lang.String genVar818;
    genVar818="Key";
    genVar817.add(genVar818);
    java.util.List<org.openfuxml.content.table.Cell> genVar819;
    genVar819=row.getCell();
    genVar819.add(cellKey);
    Cell teValue;
    teValue=new Cell();
    java.util.List<java.lang.Object> genVar820;
    genVar820=teValue.getContent();
    java.lang.String genVar821;
    genVar821="Value";
    genVar820.add(genVar821);
    java.util.List<org.openfuxml.content.table.Cell> genVar822;
    genVar822=row.getCell();
    genVar822.add(teValue);
    java.util.List<org.openfuxml.content.table.Row> genVar823;
    genVar823=head.getRow();
    genVar823.add(row);
    return head;
  }
  private Body getTableBody(  List<TemplateKv> listKv){
    Body tbody;
    tbody=new Body();
    for (    TemplateKv kv : listKv) {
      java.util.List<org.openfuxml.content.table.Row> genVar824;
      genVar824=tbody.getRow();
      WikiTemplateGenericTable genVar825;
      genVar825=this;
      org.openfuxml.content.table.Row genVar826;
      genVar826=genVar825.getRow(kv);
      genVar824.add(genVar826);
    }
    return tbody;
  }
  private Row getRow(  TemplateKv kv){
    Row row;
    row=new Row();
    Paragraph p;
    p=new Paragraph();
    java.util.List<java.lang.Object> genVar827;
    genVar827=p.getContent();
    java.lang.Object genVar828;
    genVar828=kv.getKey();
    genVar827.add(genVar828);
    Cell cellKey;
    cellKey=new Cell();
    java.util.List<java.lang.Object> genVar829;
    genVar829=cellKey.getContent();
    genVar829.add(p);
    java.util.List<org.openfuxml.content.table.Cell> genVar830;
    genVar830=row.getCell();
    genVar830.add(cellKey);
    Cell cellValue;
    cellValue=new Cell();
    try {
      org.openfuxml.addon.wiki.processor.markup.WikiMarkupProcessor genVar831;
      genVar831=kv.getMarkup();
      java.lang.String genVar832;
      genVar832=genVar831.getValue();
      Section section;
      section=wikiInlineProcessor.toOfx(genVar832);
      java.util.List<org.openfuxml.content.table.Table> genVar833;
      genVar833=section.getContent();
      for (      Object s : genVar833) {
        java.util.List<java.lang.Object> genVar834;
        genVar834=cellValue.getContent();
        java.io.Serializable genVar835;
        genVar835=(Serializable)s;
        genVar834.add(genVar835);
      }
    }
 catch (    OfxInternalProcessingException e) {
      java.lang.String genVar836;
      genVar836="";
      logger.error(genVar836,e);
    }
    java.util.List<org.openfuxml.content.table.Cell> genVar837;
    genVar837=row.getCell();
    genVar837.add(cellValue);
    return row;
  }
  @Override public void setNsPrefixMapperInterface(  NsPrefixMapperInterface nsPrefixMapper){
  }
  @Override public void setWikiInlineProcessor(  WikiInlineProcessor wikiInlineProcessor){
    org.openfuxml.addon.wiki.processor.template.transformator.WikiTemplateGenericTable genVar838;
    genVar838=this;
    genVar838.wikiInlineProcessor=wikiInlineProcessor;
  }
}
