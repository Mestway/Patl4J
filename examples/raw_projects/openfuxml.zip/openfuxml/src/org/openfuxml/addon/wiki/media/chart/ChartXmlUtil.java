package org.openfuxml.addon.wiki.media.chart;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.openfuxml.addon.wiki.data.jaxb.Ofxchart;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class ChartXmlUtil {
  final static Logger logger=LoggerFactory.getLogger(ChartXmlUtil.class);
  public static synchronized Document loadChart(  Ofxchart ofxChart){
    Document doc;
    doc=null;
    try {
      ByteArrayOutputStream out;
      out=new ByteArrayOutputStream();
      java.lang.Class<org.openfuxml.addon.wiki.data.jaxb.Ofxchart> genVar460;
      genVar460=Ofxchart.class;
      JAXBContext context;
      context=JAXBContext.newInstance(genVar460);
      Marshaller m;
      m=context.createMarshaller();
      m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,Boolean.TRUE);
      m.marshal(ofxChart,out);
      byte[] genVar461;
      genVar461=out.toByteArray();
      InputStream is;
      is=new ByteArrayInputStream(genVar461);
      org.jdom2.input.SAXBuilder genVar462;
      genVar462=new SAXBuilder();
      doc=genVar462.build(is);
      org.jdom2.Element genVar464;
      genVar464=doc.getRootElement();
      org.jdom2.Element genVar465;
      genVar465=ChartXmlUtil.unsetNameSpace(genVar464);
      doc.setRootElement(genVar465);
    }
 catch (    JAXBException e) {
      java.lang.String genVar466;
      genVar466="";
      logger.error(genVar466,e);
    }
catch (    JDOMException e) {
      java.lang.String genVar467;
      genVar467="";
      logger.error(genVar467,e);
    }
catch (    IOException e) {
      java.lang.String genVar468;
      genVar468="";
      logger.error(genVar468,e);
    }
    return doc;
  }
  private static synchronized Element unsetNameSpace(  Element e){
    e.setNamespace(null);
    java.util.List<org.jdom2.Element> genVar469;
    genVar469=e.getChildren();
    for (    Object o : genVar469) {
      Element eChild;
      eChild=(Element)o;
      eChild=ChartXmlUtil.unsetNameSpace(eChild);
    }
    return e;
  }
}
