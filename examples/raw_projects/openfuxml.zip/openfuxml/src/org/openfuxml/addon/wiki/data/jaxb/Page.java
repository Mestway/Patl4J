package org.openfuxml.addon.wiki.data.jaxb;
import java.io.File;
import org.openfuxml.content.ofx.Section;
public class Page {
  public File getFile(){
    return null;
  }
  public String getName(){
    return null;
  }
  public Section getSection(){
    return null;
  }
  public boolean isSetSection(){
    boolean genVar421;
    genVar421=false;
    return genVar421;
  }
}
