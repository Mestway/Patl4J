package org.openfuxml.addon.wiki.processor.template;
import java.io.File;
import java.io.FileNotFoundException;
import net.sf.exlp.util.xml.JDomUtil;
import net.sf.exlp.util.xml.JaxbUtil;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.openfuxml.addon.wiki.data.jaxb.Template;
import org.openfuxml.addon.wiki.data.jaxb.Templates;
import org.openfuxml.addon.wiki.processor.markup.WikiInlineProcessor;
import org.openfuxml.addon.wiki.processor.template.transformator.WikiTemplateKeyValueTransformator;
import org.openfuxml.addon.wiki.processor.util.AbstractWikiProcessor;
import org.openfuxml.addon.wiki.processor.util.WikiConfigXmlXpathHelper;
import org.openfuxml.addon.wiki.processor.util.WikiProcessor;
import org.openfuxml.exception.OfxConfigurationException;
import org.openfuxml.exception.OfxInternalProcessingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class WikiTemplateProcessor extends AbstractWikiProcessor {
  final static Logger logger=LoggerFactory.getLogger(WikiTemplateProcessor.class);
  private Templates templates;
  private WikiTemplateKeyValueTransformator kvTransformator;
  public WikiTemplateProcessor(  WikiInlineProcessor wikiInlineProcessor,  Templates templates){
    org.openfuxml.addon.wiki.processor.template.WikiTemplateProcessor genVar705;
    genVar705=this;
    genVar705.templates=templates;
    kvTransformator=new WikiTemplateKeyValueTransformator(wikiInlineProcessor);
  }
  public File getDir(  String template){
    return null;
  }
  public void process() throws OfxInternalProcessingException, OfxConfigurationException {
    WikiTemplateProcessor genVar706;
    genVar706=this;
    File fTemplateDir;
    fTemplateDir=genVar706.getDir(WikiProcessor.WikiDir.wikiTemplate);
    java.io.File[] genVar707;
    genVar707=fTemplateDir.listFiles();
    for (    File fTemplate : genVar707) {
      try {
        java.lang.String genVar708;
        genVar708=fTemplate.getAbsolutePath();
        java.lang.Class<org.openfuxml.addon.wiki.data.jaxb.Template> genVar709;
        genVar709=Template.class;
        org.openfuxml.addon.wiki.data.jaxb.Template genVar710;
        genVar710=JaxbUtil.loadJAXB(genVar708,genVar709);
        Template template;
        template=(Template)genVar710;
        WikiTemplateProcessor genVar711;
        genVar711=this;
        java.io.File genVar712;
        genVar712=genVar711.getDir(WikiProcessor.WikiDir.ofxTemplate);
        java.lang.String genVar713;
        genVar713=template.getId();
        java.lang.String genVar714;
        genVar714=".xml";
        java.lang.String genVar715;
        genVar715=genVar713 + genVar714;
        File fOfxTemplate;
        fOfxTemplate=new File(genVar712,genVar715);
        WikiTemplateProcessor genVar716;
        genVar716=this;
        Document doc;
        doc=genVar716.processTemplate(template);
        org.jdom2.output.Format genVar717;
        genVar717=Format.getRawFormat();
        JDomUtil.save(doc,fOfxTemplate,genVar717);
      }
 catch (      FileNotFoundException e) {
        java.lang.String genVar718;
        genVar718=e.getMessage();
        org.openfuxml.exception.OfxInternalProcessingException genVar719;
        genVar719=new OfxInternalProcessingException(genVar718);
        throw genVar719;
      }
    }
  }
  private Document processTemplate(  Template template) throws OfxConfigurationException {
    Document doc;
    doc=new Document();
    java.lang.String genVar720;
    genVar720=template.getName();
    Template templateDef;
    templateDef=WikiConfigXmlXpathHelper.getTemplate(templates,genVar720);
    Element e;
    e=kvTransformator.transform(templateDef,template);
    doc.setRootElement(e);
    return doc;
  }
}
