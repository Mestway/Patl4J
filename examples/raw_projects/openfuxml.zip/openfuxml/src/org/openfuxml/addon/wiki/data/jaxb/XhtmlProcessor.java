package org.openfuxml.addon.wiki.data.jaxb;
public class XhtmlProcessor {
  public Replacements getReplacements(){
    return null;
  }
}
