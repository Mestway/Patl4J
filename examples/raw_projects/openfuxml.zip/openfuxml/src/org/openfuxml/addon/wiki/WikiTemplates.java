package org.openfuxml.addon.wiki;
public class WikiTemplates {
  public static String htmlFooter="";
  public static String htmlHeader="";
  public static void init(){
  }
}
