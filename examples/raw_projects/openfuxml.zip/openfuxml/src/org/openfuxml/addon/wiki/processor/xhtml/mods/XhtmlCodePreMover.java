package org.openfuxml.addon.wiki.processor.xhtml.mods;
import java.util.Iterator;
import java.util.List;
import net.sf.exlp.util.xml.JDomUtil;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.xpath.XPath;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class XhtmlCodePreMover {
  final static Logger logger=LoggerFactory.getLogger(XhtmlCodePreMover.class);
  private XPath xpathCode, xpParent, xpathPre;
  private Element rootElement;
  public XhtmlCodePreMover(){
    try {
      java.lang.String genVar974;
      genVar974="//code";
      xpathCode=XPath.newInstance(genVar974);
      java.lang.String genVar975;
      genVar975="..";
      xpParent=XPath.newInstance(genVar975);
      java.lang.String genVar976;
      genVar976="following-sibling::pre[position()=1]";
      xpathPre=XPath.newInstance(genVar976);
    }
 catch (    JDOMException e) {
      java.lang.String genVar977;
      genVar977="";
      logger.error(genVar977,e);
    }
  }
  public String move(  String xHtmlText) throws JDOMException {
    Document doc;
    doc=JDomUtil.txtToDoc(xHtmlText);
    rootElement=doc.getRootElement();
    java.lang.String genVar978;
    genVar978=JDomUtil.docToTxt(doc);
    logger.debug(genVar978);
    XhtmlCodePreMover genVar979;
    genVar979=this;
    genVar979.process();
    xHtmlText=JDomUtil.docToTxt(doc);
    return xHtmlText;
  }
  private void process() throws JDOMException {
    List<?> list;
    list=xpathCode.selectNodes(rootElement);
    int genVar980;
    genVar980=list.size();
    java.lang.String genVar981;
    genVar981=" <code> elements found in ";
    java.lang.String genVar982;
    genVar982=rootElement.getName();
    java.lang.String genVar983;
    genVar983=genVar980 + genVar981 + genVar982;
    logger.debug(genVar983);
    Iterator<?> iter;
    iter=list.iterator();
    for (; iter.hasNext(); ) {
      java.lang.String genVar984;
      genVar984="Processing code *************";
      logger.trace(genVar984);
      Object genVar985;
      genVar985=iter.next();
      Element eCode;
      eCode=(Element)genVar985;
      java.util.List<org.jdom2.Element> genVar986;
      genVar986=eCode.getChildren();
      int genVar987;
      genVar987=genVar986.size();
      int genVar988;
      genVar988=0;
      boolean genVar989;
      genVar989=genVar987 == genVar988;
      if (genVar989) {
        java.lang.Object genVar990;
        genVar990=xpParent.selectSingleNode(eCode);
        Element eP;
        eP=(Element)genVar990;
        boolean genVar991;
        genVar991=eP != null;
        if (genVar991) {
          java.lang.String genVar992;
          genVar992="eP=";
          java.lang.String genVar993;
          genVar993=genVar992 + eP;
          logger.trace(genVar993);
          java.lang.Object genVar994;
          genVar994=xpathPre.selectSingleNode(eP);
          Element ePre;
          ePre=(Element)genVar994;
          boolean genVar995;
          genVar995=ePre != null;
          if (genVar995) {
            java.lang.String genVar996;
            genVar996="ePre=";
            java.lang.String genVar997;
            genVar997=genVar996 + ePre;
            logger.trace(genVar997);
            org.jdom2.Parent genVar998;
            genVar998=eP.getParent();
            int iP;
            iP=genVar998.indexOf(eP);
            org.jdom2.Parent genVar999;
            genVar999=ePre.getParent();
            int iPre;
            iPre=genVar999.indexOf(ePre);
            java.lang.String genVar1000;
            genVar1000=" ";
            java.lang.String genVar1001;
            genVar1001=iP + genVar1000 + iPre;
            logger.trace(genVar1001);
            int genVar1002;
            genVar1002=1;
            int genVar1003;
            genVar1003=iP + genVar1002;
            int genVar1004;
            genVar1004=(genVar1003);
            boolean genVar1005;
            genVar1005=iPre == genVar1004;
            if (genVar1005) {
              java.lang.String genVar1006;
              genVar1006=ePre.getText();
              eCode.setText(genVar1006);
              ePre.detach();
              org.jdom2.Element genVar1007;
              genVar1007=eCode.getParentElement();
              Element eCodeGrandParent;
              eCodeGrandParent=genVar1007.getParentElement();
              org.jdom2.Element genVar1008;
              genVar1008=eCode.getParentElement();
              int iCodeParent;
              iCodeParent=eCodeGrandParent.indexOf(genVar1008);
              java.lang.String genVar1009;
              genVar1009="";
              java.lang.String genVar1010;
              genVar1010=iCodeParent + genVar1009;
              logger.debug(genVar1010);
              eCode.detach();
              eCodeGrandParent.removeContent(iCodeParent);
              eCodeGrandParent.addContent(iCodeParent,eCode);
            }
 else {
              ;
            }
          }
 else {
            ;
          }
        }
 else {
          ;
        }
      }
 else {
        ;
      }
    }
  }
}
