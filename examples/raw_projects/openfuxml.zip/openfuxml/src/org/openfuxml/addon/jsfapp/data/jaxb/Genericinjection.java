package org.openfuxml.addon.jsfapp.data.jaxb;
import java.util.List;
public class Genericinjection {
  public List<Ofxinjection> getOfxinjection(){
    return null;
  }
}
