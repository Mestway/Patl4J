package org.openfuxml.addon.wiki.data.jaxb;
import java.util.List;
import org.openfuxml.addon.wiki.processor.markup.WikiMarkupProcessor;
public class Template {
  public List<TemplateKv> getTemplateKv(){
    return null;
  }
  public void setClazz(  String clazz){
  }
  public String getId(){
    return null;
  }
  public String getName(){
    return null;
  }
  public WikiMarkupProcessor getMarkup(){
    return null;
  }
}
