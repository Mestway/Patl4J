package org.openfuxml.addon.wiki.processor.util;
import java.io.File;
public abstract class AbstractWikiProcessor {
  public File srcDir;
  public String dstDir;
}
