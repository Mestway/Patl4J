package org.openfuxml.addon.jsfapp.data.jaxb;
import org.openfuxml.addon.jsfapp.Jsf;
public class Ofxinjection {
  public int getId(){
    int genVar346;
    genVar346=1;
    int genVar347;
    genVar347=-genVar346;
    return genVar347;
  }
  public boolean isSetIframe(){
    boolean genVar348;
    genVar348=false;
    return genVar348;
  }
  public boolean isSetJsf(){
    boolean genVar349;
    genVar349=false;
    return genVar349;
  }
  public Object getIframe(){
    return null;
  }
  public String getXsrc(){
    return null;
  }
  public Jsf getJsf(){
    return null;
  }
}
