package org.openfuxml.addon.jsfapp.factory;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom2.Namespace;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class NsFactory {
  final static Logger logger=LoggerFactory.getLogger(NsFactory.class);
  private static Map<String,Namespace> mNs;
  private static void init(){
    mNs=new Hashtable<String,Namespace>();
    java.lang.String genVar374;
    genVar374="html";
    java.lang.String genVar375;
    genVar375="html";
    java.lang.String genVar376;
    genVar376="http://www.w3.org/1999/xhtml";
    org.jdom2.Namespace genVar377;
    genVar377=Namespace.getNamespace(genVar375,genVar376);
    mNs.put(genVar374,genVar377);
    java.lang.String genVar378;
    genVar378="jsp";
    java.lang.String genVar379;
    genVar379="jsp";
    java.lang.String genVar380;
    genVar380="http://java.sun.com/JSP/Page";
    org.jdom2.Namespace genVar381;
    genVar381=Namespace.getNamespace(genVar379,genVar380);
    mNs.put(genVar378,genVar381);
    java.lang.String genVar382;
    genVar382="f";
    java.lang.String genVar383;
    genVar383="f";
    java.lang.String genVar384;
    genVar384="http://java.sun.com/jsf/core";
    org.jdom2.Namespace genVar385;
    genVar385=Namespace.getNamespace(genVar383,genVar384);
    mNs.put(genVar382,genVar385);
    java.lang.String genVar386;
    genVar386="h";
    java.lang.String genVar387;
    genVar387="h";
    java.lang.String genVar388;
    genVar388="http://java.sun.com/jsf/html";
    org.jdom2.Namespace genVar389;
    genVar389=Namespace.getNamespace(genVar387,genVar388);
    mNs.put(genVar386,genVar389);
    java.lang.String genVar390;
    genVar390="a4j";
    java.lang.String genVar391;
    genVar391="a4j";
    java.lang.String genVar392;
    genVar392="http://richfaces.org/a4j";
    org.jdom2.Namespace genVar393;
    genVar393=Namespace.getNamespace(genVar391,genVar392);
    mNs.put(genVar390,genVar393);
    java.lang.String genVar394;
    genVar394="rich";
    java.lang.String genVar395;
    genVar395="rich";
    java.lang.String genVar396;
    genVar396="http://richfaces.org/rich";
    org.jdom2.Namespace genVar397;
    genVar397=Namespace.getNamespace(genVar395,genVar396);
    mNs.put(genVar394,genVar397);
  }
  public static synchronized List<Namespace> getNs(  String... x){
    List<Namespace> lNs;
    lNs=new ArrayList<Namespace>();
    boolean genVar398;
    genVar398=mNs == null;
    if (genVar398) {
      NsFactory.init();
    }
 else {
      ;
    }
    for (    String key : x) {
      boolean genVar400;
      genVar400=mNs.containsKey(key);
      if (genVar400) {
        org.jdom2.Namespace genVar401;
        genVar401=mNs.get(key);
        lNs.add(genVar401);
      }
 else {
        java.lang.String genVar402;
        genVar402="Namespace ";
        java.lang.String genVar403;
        genVar403=" not defined";
        java.lang.String genVar404;
        genVar404=genVar402 + key + genVar403;
        logger.warn(genVar404);
      }
    }
    return lNs;
  }
  public static synchronized Namespace getSingelNs(  String x){
    Namespace ns;
    ns=null;
    boolean genVar405;
    genVar405=mNs == null;
    if (genVar405) {
      NsFactory.init();
    }
 else {
      ;
    }
    boolean genVar407;
    genVar407=mNs.containsKey(x);
    if (genVar407) {
      ns=mNs.get(x);
    }
 else {
      java.lang.String genVar408;
      genVar408="Namespace ";
      java.lang.String genVar409;
      genVar409=" not defined";
      java.lang.String genVar410;
      genVar410=genVar408 + x + genVar409;
      logger.warn(genVar410);
    }
    return ns;
  }
}
