package org.openfuxml.addon.wiki.data.jaxb;
import java.io.File;
public class Injections {
  public boolean isSetExternal(){
    boolean genVar418;
    genVar418=false;
    return genVar418;
  }
  public boolean isExternal(){
    boolean genVar419;
    genVar419=false;
    return genVar419;
  }
  public boolean isSetSource(){
    boolean genVar420;
    genVar420=false;
    return genVar420;
  }
  public File getSource(){
    return null;
  }
}
