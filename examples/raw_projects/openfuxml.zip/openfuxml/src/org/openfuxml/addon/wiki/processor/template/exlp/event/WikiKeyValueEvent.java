package org.openfuxml.addon.wiki.processor.template.exlp.event;
import org.openfuxml.addon.wiki.data.jaxb.TemplateKv;
public class WikiKeyValueEvent {
  public TemplateKv getKv(){
    return null;
  }
}
