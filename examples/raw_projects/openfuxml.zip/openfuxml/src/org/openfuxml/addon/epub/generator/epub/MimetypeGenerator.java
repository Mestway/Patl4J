package org.openfuxml.addon.epub.generator.epub;
import java.io.File;
public class MimetypeGenerator {
  public MimetypeGenerator(){
  }
  public MimetypeGenerator(  File targetDir){
  }
  public void save(){
  }
}
