package org.openfuxml.addon.chart.renderer.timeseries;
import org.jfree.chart.JFreeChart;
import org.openfuxml.addon.chart.interfaces.ChartRenderer;
import org.openfuxml.addon.chart.jaxb.Chart;
import org.openfuxml.addon.chart.renderer.generic.OfxChartRenderer;
public class TimeSeriesChartRenderer extends OfxChartRenderer implements ChartRenderer {
  @Override public JFreeChart render(  Chart ofxChart){
    return null;
  }
}
