package org.openfuxml.addon.jsfapp;
import java.io.File;
public class Jsf {
  public String getJsfile(){
    return null;
  }
}
