package org.openfuxml.addon.wiki.data.jaxb;
import java.io.File;
public class Replacements {
  public boolean isSetExternal(){
    boolean genVar415;
    genVar415=false;
    return genVar415;
  }
  public boolean isExternal(){
    boolean genVar416;
    genVar416=false;
    return genVar416;
  }
  public boolean isSetSource(){
    boolean genVar417;
    genVar417=false;
    return genVar417;
  }
  public File getSource(){
    return null;
  }
}
