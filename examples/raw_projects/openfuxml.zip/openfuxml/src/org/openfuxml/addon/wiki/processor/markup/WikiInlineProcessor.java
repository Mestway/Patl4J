package org.openfuxml.addon.wiki.processor.markup;
import net.sf.exlp.util.xml.JDomUtil;
import net.sf.exlp.util.xml.JaxbUtil;
import org.jdom2.Element;
import org.openfuxml.addon.wiki.data.jaxb.MarkupProcessor;
import org.openfuxml.addon.wiki.data.jaxb.Templates;
import org.openfuxml.addon.wiki.data.jaxb.XhtmlProcessor;
import org.openfuxml.addon.wiki.processor.ofx.xml.WikiPageProcessor;
import org.openfuxml.addon.wiki.processor.xhtml.XhtmlFinalProcessor;
import org.openfuxml.addon.wiki.processor.xhtml.XhtmlReplaceProcessor;
import org.openfuxml.content.ofx.Section;
import org.openfuxml.exception.OfxConfigurationException;
import org.openfuxml.exception.OfxInternalProcessingException;
import org.openfuxml.xml.renderer.cmp.Cmp;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class WikiInlineProcessor {
  final static Logger logger=LoggerFactory.getLogger(WikiInlineProcessor.class);
  public static boolean debugOutput=false;
  private WikiMarkupProcessor wpMarkup;
  private WikiModelProcessor wpModel;
  private XhtmlReplaceProcessor wpXhtmlR;
  private XhtmlFinalProcessor wpXhtmlF;
  private WikiPageProcessor ofxP;
  public WikiInlineProcessor(  Cmp cmp) throws OfxConfigurationException {
    org.openfuxml.addon.wiki.processor.markup.WikiPreprocessor genVar527;
    genVar527=cmp.getPreprocessor();
    org.openfuxml.addon.wiki.Wiki genVar528;
    genVar528=genVar527.getWiki();
    MarkupProcessor mpXml;
    mpXml=genVar528.getMarkupProcessor();
    org.openfuxml.addon.wiki.processor.markup.WikiPreprocessor genVar529;
    genVar529=cmp.getPreprocessor();
    org.openfuxml.addon.wiki.Wiki genVar530;
    genVar530=genVar529.getWiki();
    XhtmlProcessor xpXml;
    xpXml=genVar530.getXhtmlProcessor();
    org.openfuxml.addon.wiki.processor.markup.WikiPreprocessor genVar531;
    genVar531=cmp.getPreprocessor();
    org.openfuxml.addon.wiki.Wiki genVar532;
    genVar532=genVar531.getWiki();
    Templates templates;
    templates=genVar532.getTemplates();
    org.openfuxml.addon.wiki.data.jaxb.Replacements genVar533;
    genVar533=mpXml.getReplacements();
    org.openfuxml.addon.jsfapp.data.jaxb.Ofxinjections genVar534;
    genVar534=mpXml.getInjections();
    wpMarkup=new WikiMarkupProcessor(genVar533,genVar534,templates);
    wpModel=new WikiModelProcessor();
    org.openfuxml.addon.wiki.data.jaxb.Replacements genVar535;
    genVar535=xpXml.getReplacements();
    wpXhtmlR=new XhtmlReplaceProcessor(genVar535);
    wpXhtmlF=new XhtmlFinalProcessor();
    ofxP=new WikiPageProcessor();
  }
  public Section toOfx(  String wikiPlain) throws OfxInternalProcessingException {
    if (debugOutput) {
      java.lang.String genVar536;
      genVar536="wikiPlain: ";
      java.lang.String genVar537;
      genVar537=genVar536 + wikiPlain;
      logger.debug(genVar537);
    }
 else {
      ;
    }
    java.lang.String genVar538;
    genVar538="ARTICLE ... ";
    String wikiMarkup;
    wikiMarkup=wpMarkup.process(wikiPlain,genVar538);
    if (debugOutput) {
      java.lang.String genVar539;
      genVar539="wikiMarkup: ";
      java.lang.String genVar540;
      genVar540=genVar539 + wikiMarkup;
      logger.debug(genVar540);
    }
 else {
      ;
    }
    String xhtmlModel;
    xhtmlModel=wpModel.process(wikiMarkup);
    if (debugOutput) {
      java.lang.String genVar541;
      genVar541="xhtmlModel: ";
      java.lang.String genVar542;
      genVar542=genVar541 + xhtmlModel;
      logger.debug(genVar542);
    }
 else {
      ;
    }
    String xhtmlReplace;
    xhtmlReplace=wpXhtmlR.process(xhtmlModel);
    if (debugOutput) {
      java.lang.String genVar543;
      genVar543="xhtmlReplace: ";
      java.lang.String genVar544;
      genVar544=genVar543 + xhtmlReplace;
      logger.debug(genVar544);
    }
 else {
      ;
    }
    String xhtmlFinal;
    xhtmlFinal=wpXhtmlF.process(xhtmlReplace);
    if (debugOutput) {
      java.lang.String genVar545;
      genVar545="xhtmlFinal: ";
      java.lang.String genVar546;
      genVar546=genVar545 + xhtmlFinal;
      logger.debug(genVar546);
    }
 else {
      ;
    }
    Element xml;
    xml=ofxP.process(xhtmlFinal);
    if (debugOutput) {
      java.lang.String genVar547;
      genVar547=JaxbUtil.toString(xml);
      logger.debug(genVar547);
    }
 else {
      ;
    }
    java.lang.Class<org.openfuxml.content.ofx.Section> genVar548;
    genVar548=Section.class;
    org.openfuxml.content.ofx.Section genVar549;
    genVar549=JDomUtil.toJaxb(xml,genVar548);
    Section section;
    section=(Section)genVar549;
    return section;
  }
}
