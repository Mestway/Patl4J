package org.openfuxml.addon.epub.data.jaxb.ncx;
import java.util.List;
public class NavMap {
public class NavPoint {
  }
  public List<NavPoint> getNavPoint(){
    return null;
  }
}
