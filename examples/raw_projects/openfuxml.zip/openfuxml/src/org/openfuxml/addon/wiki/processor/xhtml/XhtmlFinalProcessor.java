package org.openfuxml.addon.wiki.processor.xhtml;
import net.sf.exlp.util.io.StringIO;
import org.jdom2.JDOMException;
import org.openfuxml.addon.wiki.data.jaxb.Category;
import org.openfuxml.addon.wiki.data.jaxb.Content;
import org.openfuxml.addon.wiki.data.jaxb.Page;
import org.openfuxml.addon.wiki.processor.util.AbstractWikiProcessor;
import org.openfuxml.addon.wiki.processor.util.WikiProcessor;
import org.openfuxml.addon.wiki.processor.xhtml.mods.OfxPushUp;
import org.openfuxml.addon.wiki.processor.xhtml.mods.XhtmlAHxMerge;
import org.openfuxml.addon.wiki.processor.xhtml.mods.XhtmlCodePreMover;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class XhtmlFinalProcessor extends AbstractWikiProcessor implements WikiProcessor {
  final static Logger logger=LoggerFactory.getLogger(XhtmlFinalProcessor.class);
  public XhtmlFinalProcessor(){
  }
  protected void processCategory(  Content content){
    Category category;
    category=content.getCategory();
    java.util.List<org.openfuxml.addon.wiki.data.jaxb.Page> genVar915;
    genVar915=category.getPage();
    for (    Page page : genVar915) {
      XhtmlFinalProcessor genVar916;
      genVar916=this;
      genVar916.processPage(page);
    }
  }
  protected void processPage(  Content content){
    Page page;
    page=content.getPage();
    XhtmlFinalProcessor genVar917;
    genVar917=this;
    genVar917.processPage(page);
  }
  public void processPage(  Page page){
    java.io.File genVar918;
    genVar918=page.getFile();
    java.lang.String genVar919;
    genVar919=".";
    String fNameXhtml;
    fNameXhtml=genVar918 + genVar919 + WikiProcessor.WikiFileExtension.xhtml;
    String txtMarkup;
    txtMarkup=StringIO.loadTxt(srcDir,fNameXhtml);
    XhtmlFinalProcessor genVar920;
    genVar920=this;
    String result;
    result=genVar920.process(txtMarkup);
    StringIO.writeTxt(dstDir,fNameXhtml,result);
  }
  public String process(  String xHtml){
    OfxPushUp pushUp;
    pushUp=new OfxPushUp();
    XhtmlAHxMerge merger;
    merger=new XhtmlAHxMerge();
    XhtmlCodePreMover moveCodePre;
    moveCodePre=new XhtmlCodePreMover();
    xHtml=pushUp.moveOfxElements(xHtml);
    xHtml=merger.merge(xHtml);
    try {
      xHtml=moveCodePre.move(xHtml);
    }
 catch (    JDOMException e) {
      e.printStackTrace();
    }
    XhtmlFinalProcessor genVar921;
    genVar921=this;
    xHtml=genVar921.removeWellFormed(xHtml);
    return xHtml;
  }
  public String removeWellFormed(  String text){
    java.lang.String genVar922;
    genVar922="<wiki />";
    int testIndex;
    testIndex=text.indexOf(genVar922);
    int genVar923;
    genVar923=0;
    boolean genVar924;
    genVar924=testIndex > genVar923;
    if (genVar924) {
      java.lang.String genVar925;
      genVar925="";
      return genVar925;
    }
 else {
      java.lang.String genVar926;
      genVar926="<wiki>";
      int genVar927;
      genVar927=text.indexOf(genVar926);
      int genVar928;
      genVar928=6;
      int from;
      from=genVar927 + genVar928;
      java.lang.String genVar929;
      genVar929="</wiki>";
      int to;
      to=text.lastIndexOf(genVar929);
      java.lang.String genVar930;
      genVar930=text.substring(from,to);
      return genVar930;
    }
  }
}
