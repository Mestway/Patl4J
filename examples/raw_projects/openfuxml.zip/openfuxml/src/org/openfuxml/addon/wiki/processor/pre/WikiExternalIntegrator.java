package org.openfuxml.addon.wiki.processor.pre;
import java.util.Iterator;
import java.util.List;
import net.sf.exlp.util.xml.JDomUtil;
import net.sf.exlp.util.xml.JaxbUtil;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.Namespace;
import org.jdom2.xpath.XPath;
import org.openfuxml.addon.wiki.data.jaxb.Content;
import org.openfuxml.addon.wiki.data.jaxb.Contents;
import org.openfuxml.content.ofx.Document;
import org.openfuxml.exception.OfxAuthoringException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class WikiExternalIntegrator {
  final static Logger logger=LoggerFactory.getLogger(WikiExternalIntegrator.class);
  private Namespace ns;
  private XPath xpath;
  private int counter;
  private String wikiXmlDirName;
  private Document ofxDocWithWikisAsExternal;
  private Contents wikiQueries;
  public WikiExternalIntegrator(  String wikiXmlDirName){
    org.openfuxml.addon.wiki.processor.pre.WikiExternalIntegrator genVar665;
    genVar665=this;
    genVar665.wikiXmlDirName=wikiXmlDirName;
    try {
      java.lang.String genVar666;
      genVar666="ofx";
      java.lang.String genVar667;
      genVar667="http://www.openfuxml.org";
      ns=Namespace.getNamespace(genVar666,genVar667);
      java.lang.String genVar668;
      genVar668="wiki";
      java.lang.String genVar669;
      genVar669="http://www.openfuxml.org/wiki";
      ns=Namespace.getNamespace(genVar668,genVar669);
      java.lang.String genVar670;
      genVar670="//wiki:content";
      xpath=XPath.newInstance(genVar670);
      xpath.addNamespace(ns);
    }
 catch (    JDOMException e) {
      java.lang.String genVar671;
      genVar671="";
      logger.error(genVar671,e);
    }
    xpath.addNamespace(ns);
    counter=1;
    wikiQueries=new Contents();
  }
  public void integrateWikiAsExternal(  Document ofxDoc) throws OfxAuthoringException {
    org.jdom2.Document doc;
    doc=JaxbUtil.toDocument(ofxDoc);
    try {
      org.jdom2.Element genVar672;
      genVar672=doc.getRootElement();
      List<?> list;
      list=xpath.selectNodes(genVar672);
      int genVar673;
      genVar673=list.size();
      java.lang.String genVar674;
      genVar674=" <wiki:content/> found";
      java.lang.String genVar675;
      genVar675=genVar673 + genVar674;
      logger.debug(genVar675);
      Iterator<?> iter;
      iter=list.iterator();
      for (; iter.hasNext(); ) {
        Object genVar676;
        genVar676=iter.next();
        Element eChild;
        eChild=(Element)genVar676;
        java.lang.String genVar677;
        genVar677=eChild.getName();
        logger.trace(genVar677);
        java.lang.Class<org.openfuxml.addon.wiki.data.jaxb.Content> genVar678;
        genVar678=Content.class;
        org.openfuxml.addon.wiki.data.jaxb.Content genVar679;
        genVar679=JDomUtil.toJaxb(eChild,genVar678);
        Content wikiContent;
        wikiContent=(Content)genVar679;
        WikiExternalIntegrator genVar680;
        genVar680=this;
        Element eOfx;
        eOfx=genVar680.processWikiContent(wikiContent);
        java.lang.String genVar681;
        genVar681="source";
        java.lang.String genVar682;
        genVar682=eOfx.getAttributeValue(genVar681);
        wikiContent.setSource(genVar682);
        java.util.List<org.openfuxml.addon.wiki.data.jaxb.Content> genVar683;
        genVar683=wikiQueries.getContent();
        genVar683.add(wikiContent);
        org.jdom2.Element genVar684;
        genVar684=eChild.getParentElement();
        int index;
        index=genVar684.indexOf(eChild);
        org.jdom2.Element genVar685;
        genVar685=eChild.getParentElement();
        genVar685.addContent(index,eOfx);
        eChild.detach();
      }
    }
 catch (    JDOMException e) {
      java.lang.String genVar686;
      genVar686="";
      logger.error(genVar686,e);
    }
    java.lang.Class<org.openfuxml.content.ofx.Document> genVar687;
    genVar687=Document.class;
    java.lang.Object genVar688;
    genVar688=JDomUtil.toJaxb(doc,genVar687);
    ofxDocWithWikisAsExternal=(Document)genVar688;
  }
  public Document getResult(){
    return ofxDocWithWikisAsExternal;
  }
  public Contents getWikiQueries(){
    return wikiQueries;
  }
  private Element processWikiContent(  Content wikiContent) throws OfxAuthoringException {
    Element e;
    e=null;
    boolean genVar689;
    genVar689=wikiContent.isSetPage();
    if (genVar689) {
      WikiExternalIntegrator genVar690;
      genVar690=this;
      e=genVar690.getSection(wikiContent);
    }
 else {
      boolean genVar691;
      genVar691=wikiContent.isSetCategory();
      if (genVar691) {
        WikiExternalIntegrator genVar692;
        genVar692=this;
        e=genVar692.getCategory(wikiContent);
      }
 else {
        java.lang.String genVar693;
        genVar693="Element wiki:content has no known child";
        org.openfuxml.exception.OfxAuthoringException genVar694;
        genVar694=new OfxAuthoringException(genVar693);
        throw genVar694;
      }
    }
    return e;
  }
  private Element getCategory(  Content wikiContent){
    org.openfuxml.content.ofx.Sections ofxSections;
    ofxSections=new org.openfuxml.content.ofx.Sections();
    boolean genVar695;
    genVar695=true;
    ofxSections.setExternal(genVar695);
    java.lang.String genVar696;
    genVar696="/";
    java.lang.String genVar697;
    genVar697=".xml";
    java.lang.String genVar698;
    genVar698=wikiXmlDirName + genVar696 + counter+ genVar697;
    ofxSections.setSource(genVar698);
    counter++;
    org.jdom2.Document genVar699;
    genVar699=JaxbUtil.toDocument(ofxSections);
    Element eResult;
    eResult=genVar699.getRootElement();
    eResult.detach();
    return eResult;
  }
  private Element getSection(  Content wikiContent){
    org.openfuxml.content.ofx.Section ofxSection;
    ofxSection=new org.openfuxml.content.ofx.Section();
    boolean genVar700;
    genVar700=true;
    ofxSection.setExternal(genVar700);
    java.lang.String genVar701;
    genVar701="/";
    java.lang.String genVar702;
    genVar702=".xml";
    java.lang.String genVar703;
    genVar703=wikiXmlDirName + genVar701 + counter+ genVar702;
    ofxSection.setSource(genVar703);
    counter++;
    org.jdom2.Document genVar704;
    genVar704=JaxbUtil.toDocument(ofxSection);
    Element eResult;
    eResult=genVar704.getRootElement();
    eResult.detach();
    return eResult;
  }
}
