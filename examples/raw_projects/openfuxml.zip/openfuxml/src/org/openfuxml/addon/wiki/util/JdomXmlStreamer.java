package org.openfuxml.addon.wiki.util;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import org.jdom2.Attribute;
import org.jdom2.Element;
import org.jdom2.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class JdomXmlStreamer {
  final static Logger logger=LoggerFactory.getLogger(JdomXmlStreamer.class);
  private XMLStreamWriter writer;
  public JdomXmlStreamer(  XMLStreamWriter writer){
    org.openfuxml.addon.wiki.util.JdomXmlStreamer genVar1045;
    genVar1045=this;
    genVar1045.writer=writer;
  }
  public void write(  Element rootElement) throws XMLStreamException {
    java.lang.String genVar1046;
    genVar1046=rootElement.getName();
    writer.writeStartElement(genVar1046);
    java.util.List<org.jdom2.Attribute> genVar1047;
    genVar1047=rootElement.getAttributes();
    for (    Object o : genVar1047) {
      Attribute a;
      a=(Attribute)o;
      java.lang.String genVar1048;
      genVar1048=a.getName();
      java.lang.String genVar1049;
      genVar1049=a.getValue();
      writer.writeAttribute(genVar1048,genVar1049);
    }
    java.util.List<org.jdom2.Content> genVar1050;
    genVar1050=rootElement.getContent();
    for (    Object o : genVar1050) {
      java.lang.Class<org.jdom2.Text> genVar1051;
      genVar1051=org.jdom2.Text.class;
      boolean genVar1052;
      genVar1052=genVar1051.isInstance(o);
      if (genVar1052) {
        Text txt;
        txt=(Text)o;
        java.lang.String genVar1053;
        genVar1053=txt.getText();
        writer.writeCharacters(genVar1053);
      }
 else {
        java.lang.Class<org.jdom2.Element> genVar1054;
        genVar1054=org.jdom2.Element.class;
        boolean genVar1055;
        genVar1055=genVar1054.isInstance(o);
        if (genVar1055) {
          Element child;
          child=(Element)o;
          JdomXmlStreamer genVar1056;
          genVar1056=this;
          genVar1056.write(child);
        }
 else {
          java.lang.String genVar1057;
          genVar1057="Unknown content: ";
          java.lang.Class genVar1058;
          genVar1058=o.getClass();
          java.lang.String genVar1059;
          genVar1059=genVar1058.getName();
          java.lang.String genVar1060;
          genVar1060=genVar1057 + genVar1059;
          logger.warn(genVar1060);
        }
      }
    }
    writer.writeEndElement();
  }
}
