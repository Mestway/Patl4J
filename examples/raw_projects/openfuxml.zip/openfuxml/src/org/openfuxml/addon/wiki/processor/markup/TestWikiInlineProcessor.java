package org.openfuxml.addon.wiki.processor.markup;
public class TestWikiInlineProcessor {
}
