package org.openfuxml.addon.epub.data.jaxb.ncx;
import java.util.List;
import org.openfuxml.content.ofx.Metadata;
public class Head {
  public List<Metadata> getMeta(){
    return null;
  }
}
