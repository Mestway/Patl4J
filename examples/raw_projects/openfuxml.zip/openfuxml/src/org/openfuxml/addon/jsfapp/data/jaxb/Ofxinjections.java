package org.openfuxml.addon.jsfapp.data.jaxb;
import java.util.List;
public class Ofxinjections {
  public boolean isSetGenericinjection(){
    boolean genVar350;
    genVar350=false;
    return genVar350;
  }
  public String getLocale(){
    return null;
  }
  public List<Ofxinjection> getOfxinjection(){
    return null;
  }
  public Genericinjection getGenericinjection(){
    return null;
  }
}
