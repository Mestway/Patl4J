package org.openfuxml.addon.wiki.processor.ofx.xml;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.text.MessageFormat;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import net.sf.exlp.util.io.StringIO;
import net.sf.exlp.util.xml.JDomUtil;
import net.sf.exlp.util.xml.JaxbUtil;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.output.Format;
import org.openfuxml.addon.wiki.FormattingXMLStreamWriter;
import org.openfuxml.addon.wiki.WikiTemplates;
import org.openfuxml.addon.wiki.data.jaxb.Page;
import org.openfuxml.addon.wiki.processor.ofx.OfxHtmlContentHandler;
import org.openfuxml.addon.wiki.processor.util.AbstractWikiProcessor;
import org.openfuxml.addon.wiki.processor.util.WikiProcessor;
import org.openfuxml.addon.wiki.util.IgnoreDtdEntityResolver;
import org.openfuxml.content.ofx.Section;
import org.openfuxml.exception.OfxAuthoringException;
import org.openfuxml.exception.OfxInternalProcessingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
public class WikiPageProcessor extends AbstractWikiProcessor {
  final static Logger logger=LoggerFactory.getLogger(WikiPageProcessor.class);
  public WikiPageProcessor(){
    WikiTemplates.init();
  }
  public void processPage(  Page page) throws OfxAuthoringException, OfxInternalProcessingException {
    WikiPageProcessor genVar550;
    genVar550=this;
    genVar550.checkPageConfig(page);
    try {
      java.io.File genVar551;
      genVar551=page.getFile();
      java.lang.String genVar552;
      genVar552=".";
      String srcName;
      srcName=genVar551 + genVar552 + WikiProcessor.WikiFileExtension.xhtml;
      java.io.File genVar553;
      genVar553=page.getFile();
      java.lang.String genVar554;
      genVar554=".";
      String dstName;
      dstName=genVar553 + genVar554 + WikiProcessor.WikiFileExtension.xml;
      String txtMarkup;
      txtMarkup=StringIO.loadTxt(srcDir,srcName);
      WikiPageProcessor genVar555;
      genVar555=this;
      java.lang.String genVar556;
      genVar556=page.getName();
      String result;
      result=genVar555.process(txtMarkup,genVar556);
      File fDst;
      fDst=new File(dstDir,dstName);
      Document doc;
      doc=JDomUtil.txtToDoc(result);
      WikiPageProcessor genVar557;
      genVar557=this;
      org.openfuxml.content.ofx.Section genVar558;
      genVar558=page.getSection();
      doc=genVar557.checkTransparent(doc,genVar558);
      java.lang.String genVar559;
      genVar559="Content Trimmer deactivated here";
      logger.warn(genVar559);
      org.jdom2.output.Format genVar560;
      genVar560=Format.getRawFormat();
      JDomUtil.save(doc,fDst,genVar560);
    }
 catch (    IOException e) {
      java.lang.String genVar561;
      genVar561="";
      logger.error(genVar561,e);
    }
catch (    ParserConfigurationException e) {
      java.lang.String genVar562;
      genVar562="";
      logger.error(genVar562,e);
    }
catch (    XMLStreamException e) {
      java.lang.String genVar563;
      genVar563="";
      logger.error(genVar563,e);
    }
catch (    SAXException e) {
      java.lang.String genVar564;
      genVar564="";
      logger.error(genVar564,e);
    }
catch (    JDOMException e) {
      java.lang.String genVar565;
      genVar565="";
      logger.error(genVar565,e);
    }
  }
  private Document checkTransparent(  Document doc,  Section section) throws OfxInternalProcessingException {
    boolean genVar566;
    genVar566=section.isSetContainer();
    boolean genVar567;
    genVar567=section.isContainer();
    boolean genVar568;
    genVar568=genVar566 && genVar567;
    if (genVar568) {
      Element rootElement;
      rootElement=doc.getRootElement();
      java.lang.String genVar569;
      genVar569=rootElement.getName();
      java.lang.Class<org.openfuxml.content.ofx.Section> genVar570;
      genVar570=Section.class;
      java.lang.String genVar571;
      genVar571=genVar570.getSimpleName();
      boolean genVar572;
      genVar572=genVar569.equalsIgnoreCase(genVar571);
      if (genVar572) {
        java.lang.String genVar573;
        genVar573="transparent";
        java.lang.String genVar574;
        genVar574="true";
        rootElement.setAttribute(genVar573,genVar574);
        java.lang.String genVar575;
        genVar575=rootElement.getName();
        logger.debug(genVar575);
      }
 else {
        java.lang.String genVar576;
        genVar576="Root element <";
        java.lang.String genVar577;
        genVar577=rootElement.getName();
        java.lang.String genVar578;
        genVar578="> of Wiki.Processing not expected";
        java.lang.String genVar579;
        genVar579=genVar576 + genVar577 + genVar578;
        org.openfuxml.exception.OfxInternalProcessingException genVar580;
        genVar580=new OfxInternalProcessingException(genVar579);
        throw genVar580;
      }
    }
 else {
      ;
    }
    return doc;
  }
  public Element process(  String xhtmlContent){
    Element result;
    result=null;
    try {
      WikiPageProcessor genVar581;
      genVar581=this;
      java.lang.String genVar582;
      genVar582="dummy";
      String xml;
      xml=genVar581.process(xhtmlContent,genVar582);
      Document doc;
      doc=JDomUtil.txtToDoc(xml);
      result=doc.getRootElement();
      result.detach();
      java.util.List<org.jdom2.Element> genVar583;
      genVar583=result.getChildren();
      int genVar584;
      genVar584=0;
      org.jdom2.Element genVar585;
      genVar585=genVar583.get(genVar584);
      Element eTitle;
      eTitle=(Element)genVar585;
      eTitle.detach();
      java.lang.String genVar586;
      genVar586="transparent";
      java.lang.String genVar587;
      genVar587="true";
      result.setAttribute(genVar586,genVar587);
    }
 catch (    IOException e) {
      java.lang.String genVar588;
      genVar588="";
      logger.error(genVar588,e);
    }
catch (    ParserConfigurationException e) {
      java.lang.String genVar589;
      genVar589="";
      logger.error(genVar589,e);
    }
catch (    XMLStreamException e) {
      java.lang.String genVar590;
      genVar590="";
      logger.error(genVar590,e);
    }
catch (    SAXException e) {
      java.lang.String genVar591;
      genVar591="";
      logger.error(genVar591,e);
    }
catch (    JDOMException e) {
      java.lang.String genVar592;
      genVar592="";
      logger.error(genVar592,e);
    }
    return result;
  }
  public String process(  String xhtmlContent,  String titleText) throws IOException, ParserConfigurationException, XMLStreamException, SAXException {
    Object[] objects;
    objects=new Object[2];
    int genVar593;
    genVar593=0;
    objects[genVar593]=titleText;
    String header;
    header=MessageFormat.format(WikiTemplates.htmlHeader,objects);
    StringBuffer sb;
    sb=new StringBuffer();
    sb.append(header);
    sb.append(xhtmlContent);
    sb.append(WikiTemplates.htmlFooter);
    java.lang.String genVar594;
    genVar594="Parsing: ";
    int genVar595;
    genVar595=sb.length();
    java.lang.String genVar596;
    genVar596=" characters";
    java.lang.String genVar597;
    genVar597=genVar594 + genVar595 + genVar596;
    logger.debug(genVar597);
    java.lang.String genVar598;
    genVar598=sb.toString();
    java.io.StringReader genVar599;
    genVar599=new StringReader(genVar598);
    InputSource inputSource;
    inputSource=new InputSource(genVar599);
    SAXParserFactory factory;
    factory=SAXParserFactory.newInstance();
    boolean genVar600;
    genVar600=true;
    factory.setNamespaceAware(genVar600);
    boolean genVar601;
    genVar601=false;
    factory.setValidating(genVar601);
    SAXParser saxParser;
    saxParser=factory.newSAXParser();
    XMLReader xmlReader;
    xmlReader=saxParser.getXMLReader();
    org.xml.sax.EntityResolver genVar602;
    genVar602=IgnoreDtdEntityResolver.getInstance();
    xmlReader.setEntityResolver(genVar602);
    StringWriter out;
    out=new StringWriter();
    WikiPageProcessor genVar603;
    genVar603=this;
    XMLStreamWriter writer;
    writer=genVar603.createXMLStreamWriter(out);
    java.lang.String genVar604;
    genVar604="Using dummy String injectionDir";
    logger.warn(genVar604);
    java.lang.String genVar605;
    genVar605=".";
    OfxHtmlContentHandler contentHandler;
    contentHandler=new OfxHtmlContentHandler(writer,genVar605);
    xmlReader.setContentHandler(contentHandler);
    xmlReader.parse(inputSource);
    writer.close();
    String result;
    result=out.toString();
    WikiPageProcessor genVar606;
    genVar606=this;
    result=genVar606.addNS(result);
    return result;
  }
  private String addNS(  String xml){
    java.lang.String genVar607;
    genVar607=">";
    int indexXml;
    indexXml=xml.indexOf(genVar607);
    int genVar608;
    genVar608=1;
    int genVar609;
    genVar609=indexXml + genVar608;
    int genVar610;
    genVar610=xml.length();
    java.lang.String genVar611;
    genVar611=xml.substring(genVar609,genVar610);
    java.lang.String genVar612;
    genVar612=">";
    int indexRoot;
    indexRoot=genVar611.indexOf(genVar612);
    StringBuffer sb;
    sb=new StringBuffer();
    int genVar613;
    genVar613=0;
    int genVar614;
    genVar614=1;
    int genVar615;
    genVar615=indexXml + indexRoot + genVar614;
    java.lang.String genVar616;
    genVar616=xml.substring(genVar613,genVar615);
    sb.append(genVar616);
    java.lang.String genVar617;
    genVar617=" xmlns:ofx=\"http://www.openfuxml.org\"";
    sb.append(genVar617);
    java.lang.String genVar618;
    genVar618=" xmlns:list=\"http://www.openfuxml.org/list\"";
    sb.append(genVar618);
    java.lang.String genVar619;
    genVar619=" xmlns:table=\"http://www.openfuxml.org/table\"";
    sb.append(genVar619);
    java.lang.String genVar620;
    genVar620=" xmlns:layout=\"http://www.openfuxml.org/layout\"";
    sb.append(genVar620);
    java.lang.String genVar621;
    genVar621=" xmlns:wiki=\"http://www.openfuxml.org/wiki\"";
    sb.append(genVar621);
    int genVar622;
    genVar622=1;
    int genVar623;
    genVar623=indexXml + indexRoot + genVar622;
    int genVar624;
    genVar624=xml.length();
    java.lang.String genVar625;
    genVar625=xml.substring(genVar623,genVar624);
    sb.append(genVar625);
    java.lang.String genVar626;
    genVar626=sb.toString();
    return genVar626;
  }
  protected XMLStreamWriter createXMLStreamWriter(  Writer out){
    XMLStreamWriter writer;
    try {
      javax.xml.stream.XMLOutputFactory genVar627;
      genVar627=XMLOutputFactory.newInstance();
      writer=genVar627.createXMLStreamWriter(out);
    }
 catch (    XMLStreamException e1) {
      java.lang.IllegalStateException genVar628;
      genVar628=new IllegalStateException(e1);
      throw genVar628;
    }
catch (    FactoryConfigurationError e1) {
      java.lang.IllegalStateException genVar629;
      genVar629=new IllegalStateException(e1);
      throw genVar629;
    }
    org.openfuxml.addon.wiki.FormattingXMLStreamWriter genVar630;
    genVar630=new FormattingXMLStreamWriter(writer);
    return genVar630;
  }
  private void checkPageConfig(  Page page) throws OfxAuthoringException {
    JaxbUtil.debug(page);
    boolean sSection;
    sSection=page.isSetSection();
    boolean genVar631;
    genVar631=!sSection;
    if (genVar631) {
      java.lang.String genVar632;
      genVar632="None of <section>  selected!";
      org.openfuxml.exception.OfxAuthoringException genVar633;
      genVar633=new OfxAuthoringException(genVar632);
      throw genVar633;
    }
 else {
      ;
    }
  }
}
