package org.openfuxml.addon.epub.generator;
import java.io.File;
import net.sf.exlp.util.io.LoggerInit;
import net.sf.exlp.util.xml.JDomUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom2.Document;
import org.openfuxml.addon.epub.generator.content.ContentGenerator;
import org.openfuxml.addon.epub.generator.epub.ContainerGenerator;
import org.openfuxml.addon.epub.generator.epub.MimetypeGenerator;
import org.openfuxml.addon.epub.generator.epub.NcxGenerator;
import org.openfuxml.addon.epub.generator.epub.OpfGenerator;
import org.openfuxml.addon.epub.util.EpubZipper;
import org.openfuxml.content.ofx.Ofxdoc;
import org.openfuxml.producer.preprocessors.IdTagger;
import org.openfuxml.renderer.data.exception.OfxInternalProcessingException;
import org.openfuxml.renderer.processor.pre.OfxExternalMerger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class EpubGenerator {
  final static Logger logger=LoggerFactory.getLogger(EpubGenerator.class);
  private NcxGenerator ncxGenerator;
  private MimetypeGenerator mimeFactory;
  private ContainerGenerator containerFactory;
  private OpfGenerator opfFactory;
  private EpubZipper epubZipper;
  private ContentGenerator contentGenerator;
  private IdTagger idTagger;
  public EpubGenerator(  File targetDir){
    ncxGenerator=new NcxGenerator(targetDir);
    mimeFactory=new MimetypeGenerator(targetDir);
    containerFactory=new ContainerGenerator(targetDir);
    opfFactory=new OpfGenerator(targetDir);
    contentGenerator=new ContentGenerator(targetDir);
    epubZipper=new EpubZipper(targetDir);
    idTagger=new IdTagger();
  }
  public void process(  File f) throws OfxInternalProcessingException {
    OfxExternalMerger exMerger;
    exMerger=new OfxExternalMerger(f);
    Document doc;
    doc=exMerger.mergeToDoc();
    idTagger.tag(doc);
    java.lang.Class<org.openfuxml.content.ofx.Ofxdoc> genVar16;
    genVar16=Ofxdoc.class;
    java.lang.Object genVar17;
    genVar17=JDomUtil.toJaxb(doc,genVar16);
    Ofxdoc ofxDoc;
    ofxDoc=(Ofxdoc)genVar17;
    ncxGenerator.create(ofxDoc);
    containerFactory.create();
    mimeFactory.save();
    opfFactory.create(ofxDoc);
    contentGenerator.create(ofxDoc);
    epubZipper.zip();
  }
  public static void main(  String[] args) throws Exception {
    java.lang.String genVar18;
    genVar18="log4j.xml";
    LoggerInit loggerInit;
    loggerInit=new LoggerInit(genVar18);
    java.lang.String genVar19;
    genVar19="resources/config";
    loggerInit.addAltPath(genVar19);
    loggerInit.init();
    java.lang.String genVar20;
    genVar20="resources/data/xml/epub/helloworld.xml";
    File f;
    f=new File(genVar20);
    java.lang.String genVar21;
    genVar21="dist";
    File baseDir;
    baseDir=new File(genVar21);
    EpubGenerator epub;
    epub=new EpubGenerator(baseDir);
    epub.process(f);
  }
}
