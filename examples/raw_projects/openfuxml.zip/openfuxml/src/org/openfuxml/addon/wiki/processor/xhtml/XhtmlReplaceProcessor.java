package org.openfuxml.addon.wiki.processor.xhtml;
import org.openfuxml.addon.wiki.data.jaxb.Replacements;
public class XhtmlReplaceProcessor {
  public XhtmlReplaceProcessor(  Replacements replacements){
  }
  public String process(  String xhtmlModel){
    return null;
  }
}
