package org.openfuxml.addon.jsfapp;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import net.sf.exlp.util.io.dir.RecursiveFileFinder;
import net.sf.exlp.util.xml.JDomUtil;
import net.sf.exlp.util.xml.JaxbUtil;
import net.sf.exlp.util.xml.exception.JDomUtilException;
import org.apache.commons.io.filefilter.FileFilterUtils;
import org.apache.commons.io.filefilter.HiddenFileFilter;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.tools.ant.Task;
import org.jdom2.Content;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.Namespace;
import org.jdom2.output.Format;
import org.jdom2.xpath.XPath;
import org.openfuxml.addon.jsfapp.data.jaxb.Ofxinjection;
import org.openfuxml.addon.jsfapp.data.jaxb.Ofxinjections;
import org.openfuxml.addon.jsfapp.factory.JsfJspxFactory;
import org.openfuxml.addon.jsfapp.factory.NsFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class AppInjection extends Task {
  final static Logger logger=LoggerFactory.getLogger(AppInjection.class);
  private boolean useLog4j;
  private RecursiveFileFinder rfi;
  private Ofxinjections ofxIs;
  private File jsfDir;
  private static boolean False=false;
  public AppInjection(  Ofxinjections ofxIs,  File jsfDir){
    this(ofxIs,jsfDir,False);
  }
  public AppInjection(  Ofxinjections ofxIs,  File jsfDir,  boolean useLog4j){
    org.openfuxml.addon.jsfapp.AppInjection genVar259;
    genVar259=this;
    genVar259.ofxIs=ofxIs;
    org.openfuxml.addon.jsfapp.AppInjection genVar260;
    genVar260=this;
    genVar260.jsfDir=jsfDir;
    org.openfuxml.addon.jsfapp.AppInjection genVar261;
    genVar261=this;
    genVar261.useLog4j=useLog4j;
    IOFileFilter df;
    df=HiddenFileFilter.VISIBLE;
    java.lang.String genVar262;
    genVar262=".html";
    IOFileFilter ff;
    ff=FileFilterUtils.suffixFileFilter(genVar262);
    rfi=new RecursiveFileFinder(ff);
  }
  public void inject(  File htmlDir){
    List<File> htmlFile;
    htmlFile=new ArrayList<File>();
    try {
      htmlFile=rfi.find(htmlDir);
    }
 catch (    IOException e) {
      if (useLog4j) {
        java.lang.String genVar263;
        genVar263=e.getMessage();
        logger.debug(genVar263);
      }
 else {
        java.lang.String genVar264;
        genVar264=e.getMessage();
        System.err.println(genVar264);
      }
    }
    for (    File f : htmlFile) {
      AppInjection genVar265;
      genVar265=this;
      File fJsf;
      fJsf=genVar265.getJsfFile(f);
      try {
        java.lang.String genVar266;
        genVar266=f.getAbsolutePath();
        logger.debug(genVar266);
        AppInjection genVar267;
        genVar267=this;
        java.lang.String genVar268;
        genVar268="ISO-8859-1";
        org.jdom2.Document genVar269;
        genVar269=JDomUtil.load(f,genVar268);
        Document docJsf;
        docJsf=genVar267.createJsf(genVar269);
        AppInjection genVar270;
        genVar270=this;
        genVar270.addJsfView(docJsf);
        boolean genVar271;
        genVar271=ofxIs.isSetGenericinjection();
        if (genVar271) {
          org.openfuxml.addon.jsfapp.data.jaxb.Genericinjection genVar272;
          genVar272=ofxIs.getGenericinjection();
          java.util.List<org.openfuxml.addon.jsfapp.data.jaxb.Ofxinjection> genVar273;
          genVar273=genVar272.getOfxinjection();
          for (          Ofxinjection ofxI : genVar273) {
            AppInjection genVar274;
            genVar274=this;
            genVar274.genericInjection(ofxI,docJsf);
          }
        }
 else {
          ;
        }
        java.util.List<org.openfuxml.addon.jsfapp.data.jaxb.Ofxinjection> genVar275;
        genVar275=ofxIs.getOfxinjection();
        idsearch:         for (        Ofxinjection ofxI : genVar275) {
          try {
            java.lang.String genVar276;
            genVar276="//html:div[@id=\"";
            int genVar277;
            genVar277=ofxI.getId();
            java.lang.String genVar278;
            genVar278="\"]";
            java.lang.String genVar279;
            genVar279=genVar276 + genVar277 + genVar278;
            XPath xpath;
            xpath=XPath.newInstance(genVar279);
            java.lang.String genVar280;
            genVar280="html";
            java.util.List<org.jdom2.Namespace> genVar281;
            genVar281=NsFactory.getNs(genVar280);
            for (            Namespace ns : genVar281) {
              xpath.addNamespace(ns);
            }
            java.lang.Object genVar282;
            genVar282=xpath.selectSingleNode(docJsf);
            Element element;
            element=(Element)genVar282;
            boolean genVar283;
            genVar283=element != null;
            if (genVar283) {
              StringBuffer sb;
              sb=new StringBuffer();
              boolean genVar284;
              genVar284=ofxI.isSetIframe();
              if (genVar284) {
                java.lang.String genVar285;
                genVar285="iframe: ";
                sb.append(genVar285);
                AppInjection genVar286;
                genVar286=this;
                genVar286.injectIframe(ofxI,element);
              }
 else {
                boolean genVar287;
                genVar287=ofxI.isSetJsf();
                if (genVar287) {
                  java.lang.String genVar288;
                  genVar288="jsf: ";
                  sb.append(genVar288);
                  AppInjection genVar289;
                  genVar289=this;
                  genVar289.injectJsf(ofxI,docJsf);
                }
 else {
                  ;
                }
              }
              java.lang.String genVar290;
              genVar290=f.getName();
              sb.append(genVar290);
              if (useLog4j) {
                java.lang.String genVar291;
                genVar291=sb.toString();
                logger.debug(genVar291);
              }
 else {
                java.lang.String genVar292;
                genVar292=sb.toString();
                System.out.println(genVar292);
              }
              break idsearch;
            }
 else {
              ;
            }
          }
 catch (          JDOMException e) {
            java.lang.String genVar293;
            genVar293="";
            logger.error(genVar293,e);
          }
        }
        org.jdom2.output.Format genVar294;
        genVar294=Format.getRawFormat();
        java.lang.String genVar295;
        genVar295="ISO-8859-1";
        JDomUtil.save(docJsf,fJsf,genVar294,genVar295);
      }
 catch (      JDomUtilException e) {
        if (useLog4j) {
          java.lang.String genVar296;
          genVar296=e.getMessage();
          logger.error(genVar296);
        }
 else {
          java.lang.String genVar297;
          genVar297=e.getMessage();
          System.err.println(genVar297);
        }
      }
    }
  }
  private void injectIframe(  Ofxinjection ofxI,  Element element){
    java.lang.String genVar298;
    genVar298="Injection iframe";
    logger.debug(genVar298);
    java.lang.Object genVar299;
    genVar299=ofxI.getIframe();
    Document d;
    d=JaxbUtil.toDocument(genVar299);
    Element eIframe;
    eIframe=d.getRootElement();
    eIframe.detach();
    eIframe.setNamespace(null);
    element.addContent(eIframe);
  }
  private void injectJsf(  Ofxinjection ofxI,  Document docJsf){
    try {
      java.lang.String genVar300;
      genVar300="//html:div[@id='lehrinhalt']";
      XPath xpathNewJsf;
      xpathNewJsf=XPath.newInstance(genVar300);
      java.lang.String genVar301;
      genVar301="html";
      java.util.List<org.jdom2.Namespace> genVar302;
      genVar302=NsFactory.getNs(genVar301);
      for (      Namespace ns : genVar302) {
        xpathNewJsf.addNamespace(ns);
      }
      java.lang.Object genVar303;
      genVar303=xpathNewJsf.selectSingleNode(docJsf);
      Element eNewJsf;
      eNewJsf=(Element)genVar303;
      org.openfuxml.addon.jsfapp.Jsf genVar304;
      genVar304=ofxI.getJsf();
      java.lang.String genVar305;
      genVar305=genVar304.getJsfile();
      File fOrigJsf;
      fOrigJsf=new File(jsfDir,genVar305);
      Document docOrigJsf;
      docOrigJsf=JDomUtil.load(fOrigJsf);
      java.lang.String genVar306;
      genVar306="//f:view";
      XPath xpathOrigJsf;
      xpathOrigJsf=XPath.newInstance(genVar306);
      java.lang.String genVar307;
      genVar307="f";
      java.util.List<org.jdom2.Namespace> genVar308;
      genVar308=NsFactory.getNs(genVar307);
      for (      Namespace ns : genVar308) {
        xpathOrigJsf.addNamespace(ns);
      }
      java.lang.Object genVar309;
      genVar309=xpathOrigJsf.selectSingleNode(docOrigJsf);
      Element eOrigJsf;
      eOrigJsf=(Element)genVar309;
      eNewJsf.removeContent();
      java.util.List<org.jdom2.Content> genVar310;
      genVar310=eOrigJsf.cloneContent();
      eNewJsf.addContent(genVar310);
    }
 catch (    JDOMException e) {
      java.lang.String genVar311;
      genVar311="";
      logger.error(genVar311,e);
    }
  }
  private File getJsfFile(  File fHtml){
    File dir;
    dir=fHtml.getParentFile();
    String name;
    name=fHtml.getName();
    int genVar312;
    genVar312=0;
    java.lang.String genVar313;
    genVar313=".html";
    int genVar314;
    genVar314=name.lastIndexOf(genVar313);
    java.lang.String genVar315;
    genVar315=name.substring(genVar312,genVar314);
    java.lang.String genVar316;
    genVar316=".jspx";
    name=genVar315 + genVar316;
    File fJsf;
    fJsf=new File(dir,name);
    return fJsf;
  }
  private Document createJsf(  Document docHtml){
    java.lang.String genVar317;
    genVar317="http://www.w3.org/1999/xhtml";
    Namespace htmlNs;
    htmlNs=Namespace.getNamespace(genVar317);
    org.jdom2.Element genVar318;
    genVar318=docHtml.getRootElement();
    org.jdom2.Element genVar319;
    genVar319=genVar318.clone();
    Element html;
    html=(Element)genVar319;
    JDomUtil.setNameSpaceRecursive(html,htmlNs);
    Document docJsf;
    docJsf=JsfJspxFactory.createDOMjspx();
    org.jdom2.Element genVar320;
    genVar320=docJsf.getRootElement();
    genVar320.addContent(html);
    return docJsf;
  }
  @SuppressWarnings("unchecked") private void addJsfView(  Document docJsf){
    try {
      java.lang.String genVar321;
      genVar321="//html:body";
      XPath xpath;
      xpath=XPath.newInstance(genVar321);
      java.lang.String genVar322;
      genVar322="html";
      java.lang.String genVar323;
      genVar323="jsp";
      java.util.List<org.jdom2.Namespace> genVar324;
      genVar324=NsFactory.getNs(genVar322,genVar323);
      for (      Namespace ns : genVar324) {
        xpath.addNamespace(ns);
      }
      java.lang.Object genVar325;
      genVar325=xpath.selectSingleNode(docJsf);
      Element eBody;
      eBody=(Element)genVar325;
      boolean genVar326;
      genVar326=eBody != null;
      if (genVar326) {
        List<Content> l;
        l=eBody.removeContent();
        java.lang.String genVar327;
        genVar327="view";
        java.lang.String genVar328;
        genVar328="f";
        org.jdom2.Namespace genVar329;
        genVar329=NsFactory.getSingelNs(genVar328);
        Element eView;
        eView=new Element(genVar327,genVar329);
        java.lang.String genVar330;
        genVar330="locale";
        java.lang.String genVar331;
        genVar331=ofxIs.getLocale();
        eView.setAttribute(genVar330,genVar331);
        eView.addContent(l);
        eBody.addContent(eView);
      }
 else {
        ;
      }
    }
 catch (    JDOMException e) {
      java.lang.String genVar332;
      genVar332="";
      logger.error(genVar332,e);
    }
  }
  private void genericInjection(  Ofxinjection ofxI,  Document docJsf){
    try {
      java.lang.String genVar333;
      genVar333="//html:div[@id='navi1']";
      XPath xpathResultJsf;
      xpathResultJsf=XPath.newInstance(genVar333);
      java.lang.String genVar334;
      genVar334="html";
      org.jdom2.Namespace genVar335;
      genVar335=NsFactory.getSingelNs(genVar334);
      xpathResultJsf.addNamespace(genVar335);
      java.lang.Object genVar336;
      genVar336=xpathResultJsf.selectSingleNode(docJsf);
      Element element;
      element=(Element)genVar336;
      boolean genVar337;
      genVar337=element != null;
      if (genVar337) {
        element.removeContent();
        org.openfuxml.addon.jsfapp.Jsf genVar338;
        genVar338=ofxI.getJsf();
        java.lang.String genVar339;
        genVar339=genVar338.getJsfile();
        File fOrigJsf;
        fOrigJsf=new File(jsfDir,genVar339);
        Document docOrigJsf;
        docOrigJsf=JDomUtil.load(fOrigJsf);
        java.lang.String genVar340;
        genVar340=ofxI.getXsrc();
        XPath xpath;
        xpath=XPath.newInstance(genVar340);
        java.lang.String genVar341;
        genVar341="h";
        java.lang.String genVar342;
        genVar342="jsp";
        java.util.List<org.jdom2.Namespace> genVar343;
        genVar343=NsFactory.getNs(genVar341,genVar342);
        for (        Namespace ns : genVar343) {
          xpath.addNamespace(ns);
        }
        java.lang.Object genVar344;
        genVar344=xpath.selectSingleNode(docOrigJsf);
        Element eMenu;
        eMenu=(Element)genVar344;
        eMenu.detach();
        element.addContent(eMenu);
      }
 else {
        ;
      }
    }
 catch (    JDOMException e) {
      java.lang.String genVar345;
      genVar345="";
      logger.error(genVar345,e);
    }
  }
}
