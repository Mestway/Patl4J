package org.openfuxml.addon.chart.renderer.xy;
import org.openfuxml.addon.chart.renderer.generic.OfxChartRenderer;
import org.openfuxml.addon.chart.interfaces.ChartRenderer;
public class SplineChartRenderer extends OfxChartRenderer implements ChartRenderer {
}
