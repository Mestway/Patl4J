package org.openfuxml.addon.chart.renderer;
import org.openfuxml.addon.chart.renderer.generic.OfxChartRenderer;
import org.openfuxml.addon.chart.interfaces.ChartRenderer;
public class BarChartRenderer extends OfxChartRenderer implements ChartRenderer {
}
