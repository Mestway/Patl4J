package org.openfuxml.addon.wiki.processor.util;
import java.io.FileNotFoundException;
import net.sf.exlp.util.io.LoggerInit;
import net.sf.exlp.util.xml.JDomUtil;
import net.sf.exlp.util.xml.JaxbUtil;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.Namespace;
import org.jdom2.xpath.XPath;
import org.openfuxml.addon.wiki.data.jaxb.Injections;
import org.openfuxml.addon.wiki.data.jaxb.Replacements;
import org.openfuxml.addon.wiki.data.jaxb.Template;
import org.openfuxml.addon.wiki.data.jaxb.Templates;
import org.openfuxml.exception.OfxConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class WikiConfigXmlXpathHelper {
  final static Logger logger=LoggerFactory.getLogger(WikiConfigXmlXpathHelper.class);
  public static synchronized Template getTemplate(  Templates templates,  String name) throws OfxConfigurationException {
    Template result;
    result=new Template();
    try {
      java.lang.String genVar861;
      genVar861="//wiki:template[@name='";
      java.lang.String genVar862;
      genVar862="']";
      java.lang.String genVar863;
      genVar863=genVar861 + name + genVar862;
      XPath xpath;
      xpath=XPath.newInstance(genVar863);
      java.lang.String genVar864;
      genVar864="ofx";
      java.lang.String genVar865;
      genVar865="http://www.openfuxml.org";
      org.jdom2.Namespace genVar866;
      genVar866=Namespace.getNamespace(genVar864,genVar865);
      xpath.addNamespace(genVar866);
      java.lang.String genVar867;
      genVar867="wiki";
      java.lang.String genVar868;
      genVar868="http://www.openfuxml.org/wiki";
      org.jdom2.Namespace genVar869;
      genVar869=Namespace.getNamespace(genVar867,genVar868);
      xpath.addNamespace(genVar869);
      Document doc;
      doc=JaxbUtil.toDocument(templates);
      java.lang.Object genVar870;
      genVar870=xpath.selectSingleNode(doc);
      Element e;
      e=(Element)genVar870;
      boolean genVar871;
      genVar871=e != null;
      if (genVar871) {
        java.lang.Class<org.openfuxml.addon.wiki.data.jaxb.Template> genVar872;
        genVar872=Template.class;
        org.openfuxml.addon.wiki.data.jaxb.Template genVar873;
        genVar873=JDomUtil.toJaxb(e,genVar872);
        result=(Template)genVar873;
      }
 else {
        java.lang.String genVar874;
        genVar874="No template definition for templateName=";
        java.lang.String genVar875;
        genVar875=genVar874 + name;
        org.openfuxml.exception.OfxConfigurationException genVar876;
        genVar876=new OfxConfigurationException(genVar875);
        throw genVar876;
      }
    }
 catch (    JDOMException e) {
      java.lang.String genVar877;
      genVar877="";
      logger.error(genVar877,e);
    }
    return result;
  }
  public static synchronized Replacements initReplacements(  Replacements replacements) throws OfxConfigurationException {
    boolean genVar878;
    genVar878=replacements.isSetExternal();
    boolean genVar879;
    genVar879=replacements.isExternal();
    boolean genVar880;
    genVar880=genVar878 && genVar879;
    if (genVar880) {
      try {
        boolean genVar881;
        genVar881=replacements.isSetSource();
        if (genVar881) {
          java.io.File genVar882;
          genVar882=replacements.getSource();
          java.lang.Class<org.openfuxml.addon.wiki.data.jaxb.Replacements> genVar883;
          genVar883=Replacements.class;
          org.openfuxml.addon.wiki.data.jaxb.Replacements genVar884;
          genVar884=JaxbUtil.loadJAXB(genVar882,genVar883);
          replacements=(Replacements)genVar884;
        }
 else {
          java.lang.String genVar885;
          genVar885="Replacement is set to external, but no source definded";
          org.openfuxml.exception.OfxConfigurationException genVar886;
          genVar886=new OfxConfigurationException(genVar885);
          throw genVar886;
        }
      }
 catch (      FileNotFoundException e) {
        e.printStackTrace();
        java.lang.String genVar887;
        genVar887=e.getMessage();
        org.openfuxml.exception.OfxConfigurationException genVar888;
        genVar888=new OfxConfigurationException(genVar887);
        throw genVar888;
      }
    }
 else {
      ;
    }
    return replacements;
  }
  public static synchronized Injections initInjections(  Injections injections) throws OfxConfigurationException {
    boolean genVar889;
    genVar889=injections.isSetExternal();
    boolean genVar890;
    genVar890=injections.isExternal();
    boolean genVar891;
    genVar891=genVar889 && genVar890;
    if (genVar891) {
      try {
        boolean genVar892;
        genVar892=injections.isSetSource();
        if (genVar892) {
          java.lang.String genVar893;
          genVar893="Loading external ";
          java.lang.Class<org.openfuxml.addon.wiki.data.jaxb.Injections> genVar894;
          genVar894=Injections.class;
          java.lang.String genVar895;
          genVar895=genVar894.getSimpleName();
          java.lang.String genVar896;
          genVar896=" file: ";
          java.io.File genVar897;
          genVar897=injections.getSource();
          java.lang.String genVar898;
          genVar898=genVar893 + genVar895 + genVar896+ genVar897;
          logger.debug(genVar898);
          java.io.File genVar899;
          genVar899=injections.getSource();
          java.lang.Class<org.openfuxml.addon.wiki.data.jaxb.Injections> genVar900;
          genVar900=Injections.class;
          org.openfuxml.addon.wiki.data.jaxb.Injections genVar901;
          genVar901=JaxbUtil.loadJAXB(genVar899,genVar900);
          injections=(Injections)genVar901;
        }
 else {
          java.lang.Class<org.openfuxml.addon.wiki.data.jaxb.Injections> genVar902;
          genVar902=Injections.class;
          java.lang.String genVar903;
          genVar903=genVar902.getSimpleName();
          java.lang.String genVar904;
          genVar904=" is set to external, but no source definded";
          java.lang.String genVar905;
          genVar905=genVar903 + genVar904;
          org.openfuxml.exception.OfxConfigurationException genVar906;
          genVar906=new OfxConfigurationException(genVar905);
          throw genVar906;
        }
      }
 catch (      FileNotFoundException e) {
        java.lang.String genVar907;
        genVar907=e.getMessage();
        org.openfuxml.exception.OfxConfigurationException genVar908;
        genVar908=new OfxConfigurationException(genVar907);
        throw genVar908;
      }
    }
 else {
      ;
    }
    java.lang.String genVar909;
    genVar909=JaxbUtil.toString(injections);
    logger.debug(genVar909);
    return injections;
  }
  public static void main(  String[] args) throws Exception {
    java.lang.String genVar910;
    genVar910="log4j.xml";
    LoggerInit loggerInit;
    loggerInit=new LoggerInit(genVar910);
    java.lang.String genVar911;
    genVar911="resources/config";
    loggerInit.addAltPath(genVar911);
    loggerInit.init();
    String fnInjections;
    fnInjections="resources/config/wiki/wikiinjection.xml";
    java.lang.Class<org.openfuxml.addon.wiki.data.jaxb.Injections> genVar912;
    genVar912=Injections.class;
    org.openfuxml.addon.wiki.data.jaxb.Injections genVar913;
    genVar913=JaxbUtil.loadJAXB(fnInjections,genVar912);
    Injections injections;
    injections=(Injections)genVar913;
    java.lang.String genVar914;
    genVar914=JaxbUtil.toString(injections);
    logger.debug(genVar914);
  }
}
