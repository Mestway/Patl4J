package org.openfuxml.addon.epub.generator.content;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.openfuxml.content.ofx.Section;
import org.openfuxml.renderer.processor.epub.factory.EpubSectionFactory;
import org.openfuxml.renderer.processor.epub.factory.EpubTitleFactory;
import org.openfuxml.renderer.processor.pre.OfxExternalMerger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class BodyXhtmlFactory {
  final static Logger logger=LoggerFactory.getLogger(OfxExternalMerger.class);
  private Namespace ns;
  private EpubSectionFactory sectionFactory;
  private EpubTitleFactory titleFactory;
  public BodyXhtmlFactory(  Namespace ns){
    org.openfuxml.addon.epub.generator.content.BodyXhtmlFactory genVar55;
    genVar55=this;
    genVar55.ns=ns;
    titleFactory=new EpubTitleFactory(ns);
    sectionFactory=new EpubSectionFactory(titleFactory,ns);
  }
  public Element createBody(  Section section){
    java.lang.String genVar56;
    genVar56="add body";
    logger.debug(genVar56);
    java.lang.String genVar57;
    genVar57="body";
    Element body;
    body=new Element(genVar57,ns);
    int genVar58;
    genVar58=1;
    java.util.List<org.jdom2.Element> genVar59;
    genVar59=sectionFactory.createSection(section,genVar58);
    body.addContent(genVar59);
    return body;
  }
}
