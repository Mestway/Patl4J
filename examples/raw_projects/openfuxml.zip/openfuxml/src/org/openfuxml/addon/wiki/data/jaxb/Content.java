package org.openfuxml.addon.wiki.data.jaxb;
public class Content {
  public Category getCategory(){
    return null;
  }
  public Page getPage(){
    return null;
  }
  public void setSource(  String source){
  }
  public boolean isSetPage(){
    boolean genVar413;
    genVar413=false;
    return genVar413;
  }
  public boolean isSetCategory(){
    boolean genVar414;
    genVar414=false;
    return genVar414;
  }
}
