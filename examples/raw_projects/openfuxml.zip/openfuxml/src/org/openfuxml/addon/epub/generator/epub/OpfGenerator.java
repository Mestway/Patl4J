package org.openfuxml.addon.epub.generator.epub;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import net.sf.exlp.util.xml.JDomUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom2.Attribute;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.jdom2.output.Format;
import org.openfuxml.content.ofx.Metadata;
import org.openfuxml.content.ofx.Ofxdoc;
import org.openfuxml.content.ofx.Section;
import org.openfuxml.renderer.processor.pre.OfxExternalMerger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class OpfGenerator {
  final static Logger logger=LoggerFactory.getLogger(OfxExternalMerger.class);
  private File targetDir;
  private Document doc;
  private Namespace nsXsi, nsOpf, nsDc;
  private List<String> spineItemRef;
  public OpfGenerator(  File targetDir){
    org.openfuxml.addon.epub.generator.epub.OpfGenerator genVar60;
    genVar60=this;
    genVar60.targetDir=targetDir;
    java.lang.String genVar61;
    genVar61="xsi";
    java.lang.String genVar62;
    genVar62="http://www.w3.org/2001/XMLSchema-instance";
    nsXsi=Namespace.getNamespace(genVar61,genVar62);
    java.lang.String genVar63;
    genVar63="http://www.idpf.org/2007/opf";
    nsOpf=Namespace.getNamespace(genVar63);
    java.lang.String genVar64;
    genVar64="dc";
    java.lang.String genVar65;
    genVar65="http://purl.org/dc/elements/1.1/";
    nsDc=Namespace.getNamespace(genVar64,genVar65);
    spineItemRef=new ArrayList<String>();
  }
  public void create(  Ofxdoc ofxDoc){
    doc=new Document();
    java.lang.String genVar66;
    genVar66="package";
    Element ePackage;
    ePackage=new Element(genVar66);
    java.lang.String genVar67;
    genVar67="version";
    java.lang.String genVar68;
    genVar68="2.0";
    ePackage.setAttribute(genVar67,genVar68);
    ePackage.setNamespace(nsOpf);
    ePackage.addNamespaceDeclaration(nsXsi);
    ePackage.addNamespaceDeclaration(nsDc);
    OpfGenerator genVar69;
    genVar69=this;
    org.openfuxml.content.ofx.Metadata genVar70;
    genVar70=ofxDoc.getMetadata();
    org.jdom2.Element genVar71;
    genVar71=genVar69.getMetadata(genVar70);
    ePackage.addContent(genVar71);
    OpfGenerator genVar72;
    genVar72=this;
    org.jdom2.Element genVar73;
    genVar73=genVar72.getManifest(ofxDoc);
    ePackage.addContent(genVar73);
    OpfGenerator genVar74;
    genVar74=this;
    org.jdom2.Element genVar75;
    genVar75=genVar74.getSpine(ofxDoc);
    ePackage.addContent(genVar75);
    doc.setRootElement(ePackage);
    OpfGenerator genVar76;
    genVar76=this;
    genVar76.save();
  }
  private Element getMetadata(  Metadata metadata){
    java.lang.String genVar77;
    genVar77="metadata";
    Element eMetadata;
    eMetadata=new Element(genVar77,nsOpf);
    java.lang.String genVar78;
    genVar78="language";
    Element eLanguage;
    eLanguage=new Element(genVar78,nsDc);
    java.lang.String genVar79;
    genVar79="de-DE";
    eLanguage.addContent(genVar79);
    java.lang.String genVar80;
    genVar80="type";
    java.lang.String genVar81;
    genVar81="dcterms:RFC3066";
    Attribute aType;
    aType=new Attribute(genVar80,genVar81,nsXsi);
    eLanguage.setAttribute(aType);
    eMetadata.addContent(eLanguage);
    java.lang.String genVar82;
    genVar82="title";
    Element eTitle;
    eTitle=new Element(genVar82,nsDc);
    org.openfuxml.content.ofx.Title genVar83;
    genVar83=metadata.getTitle();
    java.lang.String genVar84;
    genVar84=genVar83.getValue();
    eTitle.addContent(genVar84);
    eMetadata.addContent(eTitle);
    java.lang.String genVar85;
    genVar85="identifier";
    Element eId;
    eId=new Element(genVar85,nsDc);
    java.lang.String genVar86;
    genVar86="id";
    java.lang.String genVar87;
    genVar87="idddddd";
    eId.setAttribute(genVar86,genVar87);
    java.lang.String genVar88;
    genVar88="identifierssss";
    eId.addContent(genVar88);
    eMetadata.addContent(eId);
    return eMetadata;
  }
  private Element getManifest(  Ofxdoc ofxDoc){
    java.lang.String genVar89;
    genVar89="manifest";
    Element eManifest;
    eManifest=new Element(genVar89,nsOpf);
    OpfGenerator genVar90;
    genVar90=this;
    java.lang.String genVar91;
    genVar91="ncx";
    java.lang.String genVar92;
    genVar92="toc.ncx";
    java.lang.String genVar93;
    genVar93="application/x-dtbncx+xml";
    org.jdom2.Element genVar94;
    genVar94=genVar90.getItem(genVar91,genVar92,genVar93);
    eManifest.addContent(genVar94);
    int partNr;
    partNr=1;
    org.openfuxml.content.ofx.Sections genVar95;
    genVar95=ofxDoc.getContent();
    java.util.List<org.openfuxml.content.ofx.Section> genVar96;
    genVar96=genVar95.getContent();
    for (    Object s : genVar96) {
      boolean genVar97;
      genVar97=s instanceof Section;
      if (genVar97) {
        Section section;
        section=(Section)s;
        OpfGenerator genVar98;
        genVar98=this;
        java.lang.String genVar99;
        genVar99=section.getId();
        java.lang.String genVar100;
        genVar100="part-";
        java.lang.String genVar101;
        genVar101=".xhtml";
        java.lang.String genVar102;
        genVar102=genVar100 + partNr + genVar101;
        java.lang.String genVar103;
        genVar103="application/xhtml+xml";
        org.jdom2.Element genVar104;
        genVar104=genVar98.getItem(genVar99,genVar102,genVar103);
        eManifest.addContent(genVar104);
        partNr++;
      }
 else {
        ;
      }
    }
    return eManifest;
  }
  private Element getItem(  String id,  String href,  String mediaType){
    java.lang.String genVar105;
    genVar105="item";
    Element item;
    item=new Element(genVar105,nsOpf);
    java.lang.String genVar106;
    genVar106="id";
    item.setAttribute(genVar106,id);
    java.lang.String genVar107;
    genVar107="href";
    item.setAttribute(genVar107,href);
    java.lang.String genVar108;
    genVar108="media-type";
    item.setAttribute(genVar108,mediaType);
    return item;
  }
  private Element getSpine(  Ofxdoc ofxDoc){
    java.lang.String genVar109;
    genVar109="spine";
    Element eSpine;
    eSpine=new Element(genVar109,nsOpf);
    java.lang.String genVar110;
    genVar110="toc";
    java.lang.String genVar111;
    genVar111="ncx";
    eSpine.setAttribute(genVar110,genVar111);
    org.openfuxml.content.ofx.Sections genVar112;
    genVar112=ofxDoc.getContent();
    java.util.List<org.openfuxml.content.ofx.Section> genVar113;
    genVar113=genVar112.getContent();
    for (    Object s : genVar113) {
      boolean genVar114;
      genVar114=s instanceof Section;
      if (genVar114) {
        Section section;
        section=(Section)s;
        java.lang.String genVar115;
        genVar115="itemref";
        Element eRef;
        eRef=new Element(genVar115,nsOpf);
        java.lang.String genVar116;
        genVar116="idref";
        java.lang.String genVar117;
        genVar117=section.getId();
        eRef.setAttribute(genVar116,genVar117);
        eSpine.addContent(eRef);
      }
 else {
        ;
      }
    }
    return eSpine;
  }
  private void save(){
    java.lang.String genVar118;
    genVar118="inhalt.opf";
    File f;
    f=new File(targetDir,genVar118);
    org.jdom2.output.Format genVar119;
    genVar119=Format.getPrettyFormat();
    JDomUtil.save(doc,f,genVar119);
  }
}
