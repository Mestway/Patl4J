package org.openfuxml.addon.epub.data.jaxb;
import org.openfuxml.content.ofx.Section;
import org.openfuxml.content.ofx.Title;
public class EpubJaxbXpathLoader {
  public static Title getTitle(  Section section){
    return null;
  }
}
