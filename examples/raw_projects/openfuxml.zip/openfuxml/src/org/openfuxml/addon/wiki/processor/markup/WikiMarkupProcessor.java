package org.openfuxml.addon.wiki.processor.markup;
import org.openfuxml.addon.jsfapp.data.jaxb.Ofxinjections;
import org.openfuxml.addon.wiki.data.jaxb.Replacements;
import org.openfuxml.addon.wiki.data.jaxb.Templates;
public class WikiMarkupProcessor {
  public WikiMarkupProcessor(  Replacements replacements,  Ofxinjections injections,  Templates templates){
  }
  public String process(  String wikiPlain,  String type){
    return null;
  }
  public String getValue(){
    return null;
  }
}
