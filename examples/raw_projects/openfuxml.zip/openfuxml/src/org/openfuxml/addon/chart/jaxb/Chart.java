package org.openfuxml.addon.chart.jaxb;
import org.openfuxml.addon.chart.interfaces.ChartRenderer;
public class Chart {
  public ChartRenderer getCharttype(){
    return null;
  }
  public ChartRenderer getRenderer(){
    return null;
  }
}
