package org.openfuxml.addon.wiki.util;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringReader;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import net.sf.exlp.util.io.StringBufferOutputStream;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
import org.openfuxml.addon.wiki.data.jaxb.Wikiinjection;
import org.openfuxml.xml.OfxNsPrefixMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class WikiContentIO {
  final static Logger logger=LoggerFactory.getLogger(WikiContentIO.class);
  public static synchronized void writeXml(  String dirName,  String fileName,  String content){
    java.lang.String genVar1061;
    genVar1061="Writing Xml to ";
    java.lang.String genVar1062;
    genVar1062="/";
    java.lang.String genVar1063;
    genVar1063=genVar1061 + dirName + genVar1062+ fileName;
    logger.debug(genVar1063);
    try {
      Reader sr;
      sr=new StringReader(content);
      org.jdom2.input.SAXBuilder genVar1064;
      genVar1064=new SAXBuilder();
      Document doc;
      doc=genVar1064.build(sr);
      org.jdom2.output.Format genVar1065;
      genVar1065=Format.getRawFormat();
      XMLOutputter xmlOut;
      xmlOut=new XMLOutputter(genVar1065);
      java.lang.String genVar1066;
      genVar1066="/";
      java.lang.String genVar1067;
      genVar1067=dirName + genVar1066 + fileName;
      File f;
      f=new File(genVar1067);
      OutputStream os;
      os=new FileOutputStream(f);
      java.lang.String genVar1068;
      genVar1068="UTF-8";
      OutputStreamWriter osw;
      osw=new OutputStreamWriter(os,genVar1068);
      xmlOut.output(doc,osw);
      osw.close();
      os.close();
    }
 catch (    JDOMException e) {
      java.lang.String genVar1069;
      genVar1069="";
      logger.error(genVar1069,e);
    }
catch (    IOException e) {
      java.lang.String genVar1070;
      genVar1070="";
      logger.error(genVar1070,e);
    }
  }
  public static synchronized String loadTxt(  String dirName,  String fileName){
    java.lang.String genVar1071;
    genVar1071="Reading Txt from ";
    java.lang.String genVar1072;
    genVar1072="/";
    java.lang.String genVar1073;
    genVar1073=genVar1071 + dirName + genVar1072+ fileName;
    logger.debug(genVar1073);
    StringBuffer sb;
    sb=new StringBuffer();
    try {
      java.lang.String genVar1074;
      genVar1074="/";
      java.lang.String genVar1075;
      genVar1075=dirName + genVar1074 + fileName;
      java.io.File genVar1076;
      genVar1076=new File(genVar1075);
      java.io.FileReader genVar1077;
      genVar1077=new FileReader(genVar1076);
      BufferedReader bw;
      bw=new BufferedReader(genVar1077);
      boolean genVar1078;
      genVar1078=bw.ready();
      while (genVar1078) {
        java.lang.String genVar1079;
        genVar1079=bw.readLine();
        sb.append(genVar1079);
      }
      bw.close();
    }
 catch (    IOException e) {
      java.lang.String genVar1080;
      genVar1080="";
      logger.error(genVar1080,e);
    }
    java.lang.String genVar1081;
    genVar1081=sb.toString();
    return genVar1081;
  }
  public synchronized static StringBuffer toString(  Wikiinjection injection){
    StringBufferOutputStream sbos;
    sbos=new StringBufferOutputStream();
    try {
      java.lang.Class<org.openfuxml.addon.wiki.data.jaxb.Wikiinjection> genVar1083;
      genVar1083=Wikiinjection.class;
      Element element;
      element=WikiContentIO.toElement(injection,genVar1083);
      org.jdom2.output.Format genVar1084;
      genVar1084=Format.getRawFormat();
      XMLOutputter xmlOut;
      xmlOut=new XMLOutputter(genVar1084);
      xmlOut.output(element,sbos);
    }
 catch (    IOException e) {
      java.lang.String genVar1085;
      genVar1085="";
      logger.error(genVar1085,e);
    }
    java.lang.StringBuffer genVar1086;
    genVar1086=sbos.getStringBuffer();
    return genVar1086;
  }
  public static synchronized Element toElement(  Object o,  Class<?> c){
    Element result;
    result=null;
    try {
      StringBufferOutputStream sbos;
      sbos=new StringBufferOutputStream();
      JAXBContext context;
      context=JAXBContext.newInstance(c);
      Marshaller m;
      m=context.createMarshaller();
      m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,Boolean.FALSE);
      m.marshal(o,sbos);
      java.lang.StringBuffer genVar1087;
      genVar1087=sbos.getStringBuffer();
      java.lang.String genVar1088;
      genVar1088=genVar1087.toString();
      Reader sr;
      sr=new StringReader(genVar1088);
      org.jdom2.input.SAXBuilder genVar1089;
      genVar1089=new SAXBuilder();
      Document doc;
      doc=genVar1089.build(sr);
      org.jdom2.Element genVar1091;
      genVar1091=doc.getRootElement();
      result=WikiContentIO.unsetNameSpace(genVar1091);
    }
 catch (    JAXBException e) {
      java.lang.String genVar1092;
      genVar1092="";
      logger.error(genVar1092,e);
    }
catch (    JDOMException e) {
      java.lang.String genVar1093;
      genVar1093="";
      logger.error(genVar1093,e);
    }
catch (    IOException e) {
      java.lang.String genVar1094;
      genVar1094="";
      logger.error(genVar1094,e);
    }
    return result;
  }
  private synchronized static Element unsetNameSpace(  Element e){
    e.setNamespace(null);
    java.util.List<org.jdom2.Element> genVar1095;
    genVar1095=e.getChildren();
    for (    Object o : genVar1095) {
      Element eChild;
      eChild=(Element)o;
      eChild=WikiContentIO.unsetNameSpace(eChild);
    }
    return e;
  }
  public synchronized static void toFile(  Wikiinjection injection,  File baseDir){
    int genVar1097;
    genVar1097=injection.getId();
    java.lang.String genVar1098;
    genVar1098="-";
    java.lang.String genVar1099;
    genVar1099=injection.getOfxtag();
    java.lang.String genVar1100;
    genVar1100=".xml";
    java.lang.String genVar1101;
    genVar1101=genVar1097 + genVar1098 + genVar1099+ genVar1100;
    File f;
    f=new File(baseDir,genVar1101);
    boolean genVar1102;
    genVar1102=f.exists();
    boolean genVar1103;
    genVar1103=f.isFile();
    boolean genVar1104;
    genVar1104=genVar1102 && genVar1103;
    if (genVar1104) {
      f.delete();
    }
 else {
      ;
    }
    try {
      java.lang.Class<org.openfuxml.addon.wiki.data.jaxb.Wikiinjection> genVar1105;
      genVar1105=Wikiinjection.class;
      JAXBContext context;
      context=JAXBContext.newInstance(genVar1105);
      Marshaller m;
      m=context.createMarshaller();
      m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,Boolean.TRUE);
      java.lang.String genVar1106;
      genVar1106="com.sun.xml.bind.namespacePrefixMapper";
      org.openfuxml.xml.OfxNsPrefixMapper genVar1107;
      genVar1107=new OfxNsPrefixMapper();
      m.setProperty(genVar1106,genVar1107);
      m.marshal(injection,f);
    }
 catch (    JAXBException e) {
      java.lang.String genVar1108;
      genVar1108="";
      logger.error(genVar1108,e);
    }
  }
}
