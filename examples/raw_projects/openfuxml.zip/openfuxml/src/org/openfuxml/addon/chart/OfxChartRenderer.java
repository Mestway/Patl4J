package org.openfuxml.addon.chart;
import net.sf.exlp.util.xml.JDomUtil;
import org.jdom2.Document;
import org.jfree.chart.JFreeChart;
import org.openfuxml.addon.chart.interfaces.ChartRenderer;
import org.openfuxml.addon.chart.jaxb.Chart;
import org.openfuxml.addon.chart.renderer.BarChartRenderer;
import org.openfuxml.addon.chart.renderer.TimeBarRenderer;
import org.openfuxml.addon.chart.renderer.gantt.GanttChartRenderer;
import org.openfuxml.addon.chart.renderer.timeseries.TimeSeriesChartRenderer;
import org.openfuxml.addon.chart.renderer.xy.SplineChartRenderer;
import org.openfuxml.addon.chart.util.OfxChartTypeResolver;
import org.openfuxml.xml.addon.chart.Renderer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class OfxChartRenderer {
  final static Logger logger=LoggerFactory.getLogger(OfxChartRenderer.class);
  private ChartRenderer ofxRenderer;
  public OfxChartRenderer(){
  }
  public JFreeChart render(  Chart ofxChart){
    org.openfuxml.addon.chart.interfaces.ChartRenderer genVar0;
    genVar0=ofxChart.getRenderer();
    OfxChartTypeResolver.Type chartType;
    chartType=OfxChartTypeResolver.getType(genVar0);
switch (chartType) {
case TimeSeries:
      ofxRenderer=new TimeSeriesChartRenderer();
    break;
case TimeBar:
  ofxRenderer=new TimeBarRenderer();
break;
case Bar:
ofxRenderer=new BarChartRenderer();
break;
case Gantt:
ofxRenderer=new GanttChartRenderer();
break;
case Spline:
ofxRenderer=new SplineChartRenderer();
break;
default :
logger.warn("No Renderer available for " + chartType);
}
JFreeChart jfreeChart;
jfreeChart=ofxRenderer.render(ofxChart);
return jfreeChart;
}
public JFreeChart render(Document doc){
java.lang.Class<org.openfuxml.addon.chart.jaxb.Chart> genVar1;
genVar1=Chart.class;
java.lang.Object genVar2;
genVar2=JDomUtil.toJaxb(doc,genVar1);
Chart ofxChart;
ofxChart=(Chart)genVar2;
OfxChartRenderer genVar3;
genVar3=this;
org.jfree.chart.JFreeChart genVar4;
genVar4=genVar3.render(ofxChart);
return genVar4;
}
public ChartRenderer getOfxRenderer(){
return ofxRenderer;
}
}
