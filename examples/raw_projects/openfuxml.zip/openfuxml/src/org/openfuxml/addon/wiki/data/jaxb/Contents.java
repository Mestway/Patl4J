package org.openfuxml.addon.wiki.data.jaxb;
import java.util.List;
public class Contents {
  public List<Content> getContent(){
    return null;
  }
}
