package org.openfuxml.addon.epub.data.jaxb.ncx;
import org.openfuxml.content.ofx.Title;
public class Ncx {
  public void setVersion(  String version){
  }
  public void setHead(  Head head){
  }
  public void setNavMap(  NavMap navMap){
  }
  public void setDocTitle(  Title title){
  }
}
