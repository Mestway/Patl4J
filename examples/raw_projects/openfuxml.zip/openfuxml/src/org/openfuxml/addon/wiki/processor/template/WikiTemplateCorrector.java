package org.openfuxml.addon.wiki.processor.template;
import java.util.Iterator;
import java.util.List;
import net.sf.exlp.util.config.ConfigLoader;
import net.sf.exlp.util.io.LoggerInit;
import net.sf.exlp.util.xml.JDomUtil;
import net.sf.exlp.util.xml.JaxbUtil;
import org.apache.commons.configuration.Configuration;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.Namespace;
import org.jdom2.xpath.XPath;
import org.openfuxml.addon.wiki.processor.util.AbstractWikiProcessor;
import org.openfuxml.addon.wiki.processor.util.WikiProcessor;
import org.openfuxml.content.ofx.Document;
import org.openfuxml.exception.OfxInternalProcessingException;
import org.openfuxml.xml.OfxNsPrefixMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class WikiTemplateCorrector extends AbstractWikiProcessor implements WikiProcessor {
  final static Logger logger=LoggerFactory.getLogger(WikiTemplateCorrector.class);
  private final String startDelimiter="&lt;wiki:injection id=&quot;";
  private final String endDelimiter="&quot;/&gt;";
  private OfxNsPrefixMapper nsPrefixMapper;
  private XPath xpath;
  public WikiTemplateCorrector(){
    nsPrefixMapper=new OfxNsPrefixMapper();
    try {
      java.lang.String genVar721;
      genVar721="ofx";
      java.lang.String genVar722;
      genVar722="http://www.openfuxml.org";
      Namespace nsOfx;
      nsOfx=Namespace.getNamespace(genVar721,genVar722);
      java.lang.String genVar723;
      genVar723="wiki";
      java.lang.String genVar724;
      genVar724="http://www.openfuxml.org/wiki";
      Namespace nsWiki;
      nsWiki=Namespace.getNamespace(genVar723,genVar724);
      java.lang.String genVar725;
      genVar725="//wiki:template";
      xpath=XPath.newInstance(genVar725);
      xpath.addNamespace(nsOfx);
      xpath.addNamespace(nsWiki);
    }
 catch (    JDOMException e) {
      java.lang.String genVar726;
      genVar726="";
      logger.error(genVar726,e);
    }
  }
  public Document correctTemplateInjections(  Document ofxDoc) throws OfxInternalProcessingException {
    WikiTemplateCorrector genVar727;
    genVar727=this;
    org.jdom2.Document doc;
    doc=genVar727.transformToElement(ofxDoc);
    WikiTemplateCorrector genVar728;
    genVar728=this;
    doc=genVar728.exchangeParagraphByTemplate(doc);
    java.lang.Class<org.openfuxml.content.ofx.Document> genVar729;
    genVar729=Document.class;
    java.lang.Object genVar730;
    genVar730=JDomUtil.toJaxb(doc,genVar729);
    ofxDoc=(Document)genVar730;
    return ofxDoc;
  }
  private org.jdom2.Document exchangeParagraphByTemplate(  org.jdom2.Document doc){
    try {
      java.lang.String genVar731;
      genVar731="ofx";
      java.lang.String genVar732;
      genVar732="http://www.openfuxml.org";
      Namespace nsOfx;
      nsOfx=Namespace.getNamespace(genVar731,genVar732);
      java.lang.String genVar733;
      genVar733="wiki";
      java.lang.String genVar734;
      genVar734="http://www.openfuxml.org/wiki";
      Namespace nsWiki;
      nsWiki=Namespace.getNamespace(genVar733,genVar734);
      java.lang.String genVar735;
      genVar735="//wiki:template";
      XPath xpath;
      xpath=XPath.newInstance(genVar735);
      xpath.addNamespace(nsOfx);
      xpath.addNamespace(nsWiki);
      WikiTemplateCorrector genVar736;
      genVar736=this;
      org.jdom2.Element genVar737;
      genVar737=doc.getRootElement();
      Element result;
      result=genVar736.exchangeParagraphByTemplate(genVar737,xpath);
      result.detach();
      doc.setRootElement(result);
    }
 catch (    JDOMException e) {
      java.lang.String genVar738;
      genVar738="";
      logger.error(genVar738,e);
    }
    return doc;
  }
  private Element exchangeParagraphByTemplate(  Element rootElement,  XPath xpath){
    try {
      List<?> list;
      list=xpath.selectNodes(rootElement);
      int genVar739;
      genVar739=list.size();
      java.lang.String genVar740;
      genVar740=" sections";
      java.lang.String genVar741;
      genVar741=genVar739 + genVar740;
      logger.debug(genVar741);
      Iterator<?> iter;
      iter=list.iterator();
      for (; iter.hasNext(); ) {
        Object genVar742;
        genVar742=iter.next();
        Element eTemplate;
        eTemplate=(Element)genVar742;
        org.jdom2.Element genVar743;
        genVar743=eTemplate.getParentElement();
        org.jdom2.Element genVar744;
        genVar744=genVar743.getParentElement();
        org.jdom2.Element genVar745;
        genVar745=eTemplate.getParentElement();
        int index;
        index=genVar744.indexOf(genVar745);
        org.jdom2.Element genVar746;
        genVar746=eTemplate.getParentElement();
        Element parent;
        parent=genVar746.getParentElement();
        eTemplate.detach();
        parent.removeContent(index);
        WikiTemplateCorrector genVar747;
        genVar747=this;
        org.jdom2.Element genVar748;
        genVar748=genVar747.createExternalTemplate(eTemplate);
        parent.addContent(index,genVar748);
      }
    }
 catch (    JDOMException e) {
      java.lang.String genVar749;
      genVar749="";
      logger.error(genVar749,e);
    }
    return rootElement;
  }
  private Element createExternalTemplate(  Element eTemplate){
    StringBuffer sb;
    sb=new StringBuffer();
    java.lang.String genVar750;
    genVar750=WikiProcessor.WikiDir.ofxTemplate.toString();
    sb.append(genVar750);
    java.lang.String genVar751;
    genVar751="/";
    java.lang.StringBuffer genVar752;
    genVar752=sb.append(genVar751);
    java.lang.String genVar753;
    genVar753="id";
    java.lang.String genVar754;
    genVar754=eTemplate.getAttributeValue(genVar753);
    java.lang.StringBuffer genVar755;
    genVar755=genVar752.append(genVar754);
    java.lang.String genVar756;
    genVar756=".xml";
    genVar755.append(genVar756);
    java.lang.String genVar757;
    genVar757="external";
    java.lang.String genVar758;
    genVar758="true";
    eTemplate.setAttribute(genVar757,genVar758);
    java.lang.String genVar759;
    genVar759="source";
    java.lang.String genVar760;
    genVar760=sb.toString();
    eTemplate.setAttribute(genVar759,genVar760);
    return eTemplate;
  }
  private org.jdom2.Document transformToElement(  Document ofxDoc){
    boolean genVar761;
    genVar761=true;
    String txt;
    txt=JaxbUtil.toString(ofxDoc,nsPrefixMapper,genVar761);
    int genVar762;
    genVar762=1;
    int beginIndex;
    beginIndex=-genVar762;
    int genVar763;
    genVar763=beginIndex=txt.indexOf(startDelimiter);
    int genVar764;
    genVar764=(genVar763);
    int genVar765;
    genVar765=0;
    boolean genVar766;
    genVar766=genVar764 >= genVar765;
    while (genVar766) {
      int genVar767;
      genVar767=startDelimiter.length();
      int genVar768;
      genVar768=beginIndex + genVar767;
      int genVar769;
      genVar769=txt.length();
      String behindStart;
      behindStart=txt.substring(genVar768,genVar769);
      int endIndex;
      endIndex=behindStart.indexOf(endDelimiter);
      int genVar770;
      genVar770=0;
      String id;
      id=behindStart.substring(genVar770,endIndex);
      StringBuffer sb;
      sb=new StringBuffer();
      int genVar771;
      genVar771=0;
      java.lang.String genVar772;
      genVar772=txt.substring(genVar771,beginIndex);
      sb.append(genVar772);
      WikiTemplateCorrector genVar773;
      genVar773=this;
      java.lang.String genVar774;
      genVar774=genVar773.getTemplateXml(id);
      sb.append(genVar774);
      int genVar775;
      genVar775=startDelimiter.length();
      int genVar776;
      genVar776=id.length();
      int genVar777;
      genVar777=endDelimiter.length();
      int genVar778;
      genVar778=beginIndex + genVar775 + genVar776+ genVar777;
      java.lang.String genVar779;
      genVar779=txt.substring(genVar778);
      sb.append(genVar779);
      txt=sb.toString();
    }
    org.jdom2.Document doc;
    doc=null;
    try {
      doc=JDomUtil.txtToDoc(txt);
    }
 catch (    JDOMException e) {
      java.lang.String genVar780;
      genVar780="";
      logger.error(genVar780,e);
    }
    return doc;
  }
  private String getTemplateXml(  String id){
    StringBuffer sb;
    sb=new StringBuffer();
    java.lang.String genVar781;
    genVar781="<wiki:template id=\"";
    sb.append(genVar781);
    sb.append(id);
    java.lang.String genVar782;
    genVar782="\"/>";
    sb.append(genVar782);
    java.lang.String genVar783;
    genVar783=sb.toString();
    return genVar783;
  }
  public static void main(  String[] args) throws Exception {
    java.lang.String genVar784;
    genVar784="log4j.xml";
    LoggerInit loggerInit;
    loggerInit=new LoggerInit(genVar784);
    java.lang.String genVar785;
    genVar785="resources/config";
    loggerInit.addAltPath(genVar785);
    loggerInit.init();
    String propFile;
    propFile="resources/properties/user.properties";
    int genVar786;
    genVar786=1;
    boolean genVar787;
    genVar787=args.length == genVar786;
    if (genVar787) {
      int genVar788;
      genVar788=0;
      propFile=args[genVar788];
    }
 else {
      ;
    }
    ConfigLoader.add(propFile);
    Configuration config;
    config=ConfigLoader.init();
    java.lang.String genVar789;
    genVar789="wiki.processor.test.template.correct";
    String fnOfx;
    fnOfx=config.getString(genVar789);
    java.lang.Class<org.openfuxml.content.ofx.Document> genVar790;
    genVar790=Document.class;
    Document ofxDoc;
    ofxDoc=JaxbUtil.loadJAXB(fnOfx,genVar790);
    WikiTemplateCorrector templateCorrector;
    templateCorrector=new WikiTemplateCorrector();
    templateCorrector.correctTemplateInjections(ofxDoc);
  }
}
