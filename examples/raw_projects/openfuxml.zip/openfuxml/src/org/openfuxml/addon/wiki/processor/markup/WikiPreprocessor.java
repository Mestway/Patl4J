package org.openfuxml.addon.wiki.processor.markup;
import org.openfuxml.addon.wiki.Wiki;
public class WikiPreprocessor {
  public Wiki getWiki(){
    return null;
  }
}
