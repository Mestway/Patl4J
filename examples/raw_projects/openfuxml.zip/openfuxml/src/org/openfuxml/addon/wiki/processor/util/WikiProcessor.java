package org.openfuxml.addon.wiki.processor.util;
public interface WikiProcessor {
  public enum WikiFileExtension {  xhtml,   xml}
public interface WikiDir {
    public String ofxTemplate="";
    public String wikiTemplate="";
  }
}
