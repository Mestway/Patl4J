package org.openfuxml.addon.wiki.data.jaxb;
import org.openfuxml.addon.wiki.processor.markup.WikiMarkupProcessor;
public class TemplateKv {
  public Object getKey(){
    return null;
  }
  public WikiMarkupProcessor getMarkup(){
    return null;
  }
}
