package org.openfuxml.addon.jsf.controller.factory.xml;
public class XmlAttributeFactory {
  public static String create(  String name,  boolean required,  String sDefault,  String sDescription){
    return null;
  }
}
