package org.openfuxml.addon.chart.util;
import org.openfuxml.addon.chart.interfaces.ChartRenderer;
public class OfxChartTypeResolver {
  public enum Type {  TimeSeries,   TimeBar,   Bar,   Gantt,   Spline}
  public static Type getType(  ChartRenderer chartRenderer){
    return null;
  }
}
