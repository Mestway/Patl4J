package org.openfuxml.addon.wiki.processor.markup;
public class WikiModelProcessor {
  public String process(  String wikiMarkup){
    return null;
  }
}
