package org.openfuxml.addon.wiki.processor.template.exlp.parser;
import java.util.List;
import java.util.Properties;
import net.sf.exlp.core.handler.EhResultContainer;
import net.sf.exlp.interfaces.LogParser;
public class WikiKeyValueParser implements LogParser {
  public WikiKeyValueParser(  EhResultContainer ehResultContainer){
  }
  @Override public void addMetaInfo(  Properties arg0){
  }
  @Override public void close(){
  }
  @Override public void debugStats(){
  }
  @Override public void parseItem(  List<String> arg0){
  }
  @Override public void parseLine(  String arg0){
  }
  @Override public void parseLine(  String arg0,  String arg1){
  }
}
