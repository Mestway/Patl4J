package org.openfuxml.addon.wiki.data.jaxb;
public class Ofxgallery {
public class Ofximage {
    public String getValue(){
      return null;
    }
  }
}
