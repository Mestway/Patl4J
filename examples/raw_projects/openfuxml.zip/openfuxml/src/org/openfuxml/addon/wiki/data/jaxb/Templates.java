package org.openfuxml.addon.wiki.data.jaxb;
public class Templates {
}
