/** 
 * Copyright (c) 2004-2011 QOS.ch All rights reserved. Permission is hereby granted, free  of charge, to any person obtaining a  copy  of this  software  and  associated  documentation files  (the "Software"), to  deal in  the Software without  restriction, including without limitation  the rights to  use, copy, modify,  merge, publish, distribute,  sublicense, and/or sell  copies of  the Software,  and to permit persons to whom the Software  is furnished to do so, subject to the following conditions: The  above  copyright  notice  and  this permission  notice  shall  be included in all copies or substantial portions of the Software. THE  SOFTWARE IS  PROVIDED  "AS  IS", WITHOUT  WARRANTY  OF ANY  KIND, EXPRESS OR  IMPLIED, INCLUDING  BUT NOT LIMITED  TO THE  WARRANTIES OF MERCHANTABILITY,    FITNESS    FOR    A   PARTICULAR    PURPOSE    AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,  ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package org.slf4j;
import java.io.IOException;
import java.net.URL;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
/** 
 * The <code>LoggerFactory</code> is a utility class producing Loggers for various logging APIs, most notably for log4j, logback and JDK 1.4 logging. Other implementations such as   {@link org.slf4j.impl.NOPLogger NOPLogger} and{@link org.slf4j.impl.SimpleLogger SimpleLogger} are also supported.<p/> <p/> <code>LoggerFactory</code> is essentially a wrapper around an {@link ILoggerFactory} instance bound with <code>LoggerFactory</code> atcompile time. <p/> <p/> Please note that all methods in <code>LoggerFactory</code> are static.
 * @author Alexander Dorokhine
 * @author Robert Elliot
 * @author Ceki G&uuml;lc&uuml;
 */
public final class LoggerFactory {
  static final String CODES_PREFIX="http://www.slf4j.org/codes.html";
  static final String NO_STATICLOGGERBINDER_URL=CODES_PREFIX + "#StaticLoggerBinder";
  static final String MULTIPLE_BINDINGS_URL=CODES_PREFIX + "#multiple_bindings";
  static final String NULL_LF_URL=CODES_PREFIX + "#null_LF";
  static final String VERSION_MISMATCH=CODES_PREFIX + "#version_mismatch";
  static final String SUBSTITUTE_LOGGER_URL=CODES_PREFIX + "#substituteLogger";
  static final String LOGGER_NAME_MISMATCH_URL=CODES_PREFIX + "#loggerNameMismatch";
  static final String UNSUCCESSFUL_INIT_URL=CODES_PREFIX + "#unsuccessfulInit";
  static final String UNSUCCESSFUL_INIT_MSG="org.slf4j.LoggerFactory could not be successfully initialized. See also " + UNSUCCESSFUL_INIT_URL;
  static final int UNINITIALIZED=0;
  static final int ONGOING_INITIALIZATION=1;
  static final int FAILED_INITIALIZATION=2;
  static final int SUCCESSFUL_INITIALIZATION=3;
  static final int NOP_FALLBACK_INITIALIZATION=4;
  static int INITIALIZATION_STATE=UNINITIALIZED;
  static final String DETECT_LOGGER_NAME_MISMATCH_PROPERTY="slf4j.detectLoggerNameMismatch";
  static boolean DETECT_LOGGER_NAME_MISMATCH=Boolean.getBoolean(DETECT_LOGGER_NAME_MISMATCH_PROPERTY);
  /** 
 * It is LoggerFactory's responsibility to track version changes and manage the compatibility list. <p/> <p/> It is assumed that all versions in the 1.6 are mutually compatible.
 */
  static private final String[] API_COMPATIBILITY_LIST=new String[]{"1.6","1.7"};
  private LoggerFactory(){
  }
  /** 
 * Force LoggerFactory to consider itself uninitialized. <p/> <p/> This method is intended to be called by classes (in the same package) for testing purposes. This method is internal. It can be modified, renamed or removed at any time without notice. <p/> <p/> You are strongly discouraged from calling this method in production code.
 */
  static void reset(){
  }
  private final static void performInitialization(){
  }
  private static boolean messageContainsOrgSlf4jImplStaticLoggerBinder(  String msg){
    return false;
  }
  private final static void bind(){
  }
  static void failedBinding(  Throwable t){
  }
  private final static void fixSubstitutedLoggers(){
  }
  private final static void versionSanityCheck(){
  }
  private static String STATIC_LOGGER_BINDER_PATH="org/slf4j/impl/StaticLoggerBinder.class";
  private static Set<URL> findPossibleStaticLoggerBinderPathSet(){
    return null;
  }
  private static boolean isAmbiguousStaticLoggerBinderPathSet(  Set<URL> staticLoggerBinderPathSet){
    return false;
  }
  /** 
 * Prints a warning message on the console if multiple bindings were found on the class path. No reporting is done otherwise.
 */
  private static void reportMultipleBindingAmbiguity(  Set<URL> staticLoggerBinderPathSet){
  }
  private static void reportActualBinding(  Set<URL> staticLoggerBinderPathSet){
  }
  /** 
 * Return a logger named according to the name parameter using the statically bound   {@link ILoggerFactory} instance.
 * @param name The name of the logger.
 * @return logger
 */
  public static Logger getLogger(  String name){
    return null;
  }
  /** 
 * Return a logger named corresponding to the class passed as parameter, using the statically bound   {@link ILoggerFactory} instance.<p>In case the the <code>clazz</code> parameter differs from the name of the caller as computed internally by SLF4J, a logger name mismatch warning will be  printed but only if the <code>slf4j.detectLoggerNameMismatch</code> system property is  set to true. By default, this property is not set and no warnings will be printed even in case of a logger name mismatch.
 * @param clazz the returned logger will be named after clazz
 * @return logger
 * @see <a href="http://www.slf4j.org/codes.html#loggerNameMismatch">Detected logger name mismatch</a> 
 */
  public static Logger getLogger(  Class<?> clazz){
    return null;
  }
  private static boolean nonMatchingClasses(  Class<?> clazz,  Class<?> autoComputedCallingClass){
    return true;
  }
  /** 
 * Return the   {@link ILoggerFactory} instance in use.<p/> <p/> ILoggerFactory instance is bound with this class at compile time.
 * @return the ILoggerFactory instance in use
 */
  public static ILoggerFactory getILoggerFactory(){
    return null;
  }
}
