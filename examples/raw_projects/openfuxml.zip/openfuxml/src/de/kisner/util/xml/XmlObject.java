package de.kisner.util.xml;
import java.io.File;
import java.util.List;
import org.jdom2.Element;
public class XmlObject {
  public void load(  File xmlFile){
  }
  public void load(  File xmlFile,  String encoding){
  }
  public String getText(  String keyword){
    return null;
  }
  public String getAttribute(  String str,  String fileType){
    return null;
  }
  public List<Element> getElements(  String xPathName) throws XmlElementNotFoundException {
    return null;
  }
}
