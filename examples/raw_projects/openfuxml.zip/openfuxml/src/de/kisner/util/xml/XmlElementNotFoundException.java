package de.kisner.util.xml;
public class XmlElementNotFoundException extends Exception {
}
