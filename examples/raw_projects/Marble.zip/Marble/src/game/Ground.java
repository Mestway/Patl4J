package game;
public class Ground {
  public int price;
  public int fee;
  public int owner;
}
