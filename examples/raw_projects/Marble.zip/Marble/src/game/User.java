package game;
public class User {
  public int money=800000;
  public int position=0;
}
