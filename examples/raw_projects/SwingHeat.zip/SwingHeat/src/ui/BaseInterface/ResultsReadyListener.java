package ui.BaseInterface;
import models.FinInterface;
public interface ResultsReadyListener {
  public void goToResults(  FinInterface object);
}
