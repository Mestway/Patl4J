package ui.BaseInterface;
import javax.swing.JFrame;
public interface BaseInitializer {
  public void initializePanel();
}
