package business;
import entitites.Medicamento;
public class IMedicamentosDAO {
  public void cadastrarMedicamento(  Medicamento medic){
  }
}
