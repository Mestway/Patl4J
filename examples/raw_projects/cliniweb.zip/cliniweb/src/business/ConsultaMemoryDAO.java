package business;
public class ConsultaMemoryDAO extends IConsultasDAO {
}
