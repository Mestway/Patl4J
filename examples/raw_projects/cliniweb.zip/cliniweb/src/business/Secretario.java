package business;
public class Secretario {
}
