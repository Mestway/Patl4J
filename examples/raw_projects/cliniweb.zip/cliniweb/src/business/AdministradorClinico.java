package business;
public class AdministradorClinico {
}
