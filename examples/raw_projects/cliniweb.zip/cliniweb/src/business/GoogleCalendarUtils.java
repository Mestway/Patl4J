package business;
public class GoogleCalendarUtils {
  public static final String COLOR_ESPECIALISTA=null;
  public static final String COLOR_PACIENTE=null;
  public static final String COLOR_SECRETARIO=null;
  public static final String COLOR_ADMIN=null;
}
