package business;
import entitites.Consulta;
import entitites.Paciente;
import entitites.specialists.Especialista;
public class IConsultasDAO {
  public void cadastrarConsulta(  Paciente paciente,  Especialista especialista,  Consulta consulta){
  }
}
