package business;
import java.util.LinkedList;
import com.google.gdata.data.calendar.CalendarEventEntry;
import com.google.gdata.util.AuthenticationException;
import controller.util.AplicacaoUtils;
import entitites.AdministradorClinico;
import entitites.Consulta;
import entitites.Medicamento;
import entitites.Paciente;
import entitites.Usuario;
import entitites.specialists.Especialista;
import googlecalendar.GoogleCalendarManagerApp;
/** 
 * Cuida dos serviços de Consultas\Medicamentos bem como a criação de calendários no Google Agenda  e Compartilhamento entre eles.
 * @author alessandro87
 */
public class ServicosAgenda {
  private GoogleCalendarManagerApp managerCalendars;
  private IConsultasDAO consultasDAO;
  private IMedicamentosDAO medicamentosDAO;
  public ServicosAgenda() throws AuthenticationException {
    consultasDAO=new ConsultaMemoryDAO();
    medicamentosDAO=new MedicamentoMemoryDAO();
    managerCalendars=new GoogleCalendarManagerApp(AplicacaoUtils.APLICACAO_EMAIL,AplicacaoUtils.APLICACAO_SENHA,AplicacaoUtils.APLICACAO_LOCAL);
  }
  /** 
 * Adiciona ao calendario de aplicacao o calendario do paciente.
 * @param novoUsuario
 */
  public void cadastrarCalendario(  Usuario novoUsuario){
    String idCalendario;
    idCalendario=null;
    boolean genVar0;
    genVar0=novoUsuario instanceof Especialista;
    if (genVar0) {
      java.lang.String genVar1;
      genVar1=" ";
      java.lang.String genVar2;
      genVar2=novoUsuario.getLogin();
      java.lang.String genVar3;
      genVar3=AplicacaoUtils.APLICACAO_NOME + genVar1 + genVar2;
      idCalendario=managerCalendars.cadastrarCalendario(genVar3,GoogleCalendarUtils.COLOR_ESPECIALISTA);
    }
 else {
      boolean genVar4;
      genVar4=novoUsuario instanceof Paciente;
      if (genVar4) {
        java.lang.String genVar5;
        genVar5=" ";
        java.lang.String genVar6;
        genVar6=novoUsuario.getLogin();
        java.lang.String genVar7;
        genVar7=AplicacaoUtils.APLICACAO_NOME + genVar5 + genVar6;
        idCalendario=managerCalendars.cadastrarCalendario(genVar7,GoogleCalendarUtils.COLOR_PACIENTE);
      }
 else {
        boolean genVar8;
        genVar8=novoUsuario instanceof Secretario;
        if (genVar8) {
          java.lang.String genVar9;
          genVar9=" ";
          java.lang.String genVar10;
          genVar10=novoUsuario.getLogin();
          java.lang.String genVar11;
          genVar11=AplicacaoUtils.APLICACAO_NOME + genVar9 + genVar10;
          idCalendario=managerCalendars.cadastrarCalendario(genVar11,GoogleCalendarUtils.COLOR_SECRETARIO);
        }
 else {
          boolean genVar12;
          genVar12=novoUsuario instanceof AdministradorClinico;
          if (genVar12) {
            java.lang.String genVar13;
            genVar13=" ";
            java.lang.String genVar14;
            genVar14=novoUsuario.getLogin();
            java.lang.String genVar15;
            genVar15=AplicacaoUtils.APLICACAO_NOME + genVar13 + genVar14;
            idCalendario=managerCalendars.cadastrarCalendario(genVar15,GoogleCalendarUtils.COLOR_ADMIN);
          }
 else {
            ;
          }
        }
      }
    }
    novoUsuario.setIdGoogleCalendario(idCalendario);
    java.lang.String genVar16;
    genVar16=novoUsuario.getGmail();
    managerCalendars.compartilharCalendario(idCalendario,genVar16);
  }
  public void marcarConsulta(  Consulta consulta){
    entitites.Paciente genVar17;
    genVar17=consulta.getPaciente();
    entitites.specialists.Especialista genVar18;
    genVar18=consulta.getEspecialista();
    consultasDAO.cadastrarConsulta(genVar17,genVar18,consulta);
    entitites.Paciente genVar19;
    genVar19=consulta.getPaciente();
    java.lang.String genVar20;
    genVar20=genVar19.getIdGoogleCalendario();
    com.google.gdata.data.calendar.CalendarEventEntry genVar21;
    genVar21=consulta.getEvento();
    String idPaciente;
    idPaciente=managerCalendars.cadastrarEvento(genVar20,genVar21);
    entitites.specialists.Especialista genVar22;
    genVar22=consulta.getEspecialista();
    java.lang.String genVar23;
    genVar23=genVar22.getIdGoogleCalendario();
    com.google.gdata.data.calendar.CalendarEventEntry genVar24;
    genVar24=consulta.getEvento();
    String idEspecialista;
    idEspecialista=managerCalendars.cadastrarEvento(genVar23,genVar24);
    consulta.setGoogleIdPaciente(idPaciente);
    consulta.setGoogleIdEspecialista(idEspecialista);
  }
  public void marcarMedicamento(  Medicamento medic){
    medicamentosDAO.cadastrarMedicamento(medic);
    LinkedList<CalendarEventEntry> eventos;
    eventos=medic.getEventos();
    LinkedList<String> idsMedicamentosEventos;
    idsMedicamentosEventos=new LinkedList<String>();
    for (    CalendarEventEntry evento : eventos) {
      entitites.Paciente genVar25;
      genVar25=medic.getPaciente();
      java.lang.String genVar26;
      genVar26=genVar25.getIdGoogleCalendario();
      String id;
      id=managerCalendars.cadastrarEvento(genVar26,evento);
      idsMedicamentosEventos.add(id);
    }
    medic.setIdMedicamentoEventohora(idsMedicamentosEventos);
  }
}
