package business;
public class MedicamentoMemoryDAO extends IMedicamentosDAO {
}
