package googlecalendar;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import com.google.gdata.client.calendar.CalendarService;
import com.google.gdata.data.DateTime;
import com.google.gdata.data.PlainTextConstruct;
import com.google.gdata.data.acl.AclEntry;
import com.google.gdata.data.acl.AclScope;
import com.google.gdata.data.calendar.CalendarAclRole;
import com.google.gdata.data.calendar.CalendarEntry;
import com.google.gdata.data.calendar.CalendarEventEntry;
import com.google.gdata.data.calendar.CalendarFeed;
import com.google.gdata.data.calendar.ColorProperty;
import com.google.gdata.data.calendar.HiddenProperty;
import com.google.gdata.data.extensions.Recurrence;
import com.google.gdata.data.extensions.When;
import com.google.gdata.data.extensions.Where;
import com.google.gdata.util.AuthenticationException;
import com.google.gdata.util.ServiceException;
public class GoogleCalendarManagerApp {
  private CalendarService service;
  private String aplicacao;
  private String senhaAplicacao;
  private String local;
  public static int ajusteTimeZone=+3;
  public GoogleCalendarManagerApp(  String aplicacao,  String senhaAplicacao,  String local) throws AuthenticationException {
    googlecalendar.GoogleCalendarManagerApp genVar273;
    genVar273=this;
    genVar273.aplicacao=aplicacao;
    googlecalendar.GoogleCalendarManagerApp genVar274;
    genVar274=this;
    genVar274.senhaAplicacao=senhaAplicacao;
    googlecalendar.GoogleCalendarManagerApp genVar275;
    genVar275=this;
    genVar275.local=local;
    service=new CalendarService(aplicacao);
    googlecalendar.GoogleCalendarManagerApp genVar276;
    genVar276=this;
    java.lang.String genVar277;
    genVar277=genVar276.aplicacao;
    googlecalendar.GoogleCalendarManagerApp genVar278;
    genVar278=this;
    java.lang.String genVar279;
    genVar279=genVar278.senhaAplicacao;
    service.setUserCredentials(genVar277,genVar279);
  }
  /** 
 * Cadastra o calendario
 * @param string nome do Calendario
 * @param colorEspecialista codigo da cor
 * @return id do calendario
 */
  public String cadastrarCalendario(  String title,  String color){
    CalendarEntry calendar;
    calendar=new CalendarEntry();
    com.google.gdata.data.PlainTextConstruct genVar280;
    genVar280=new PlainTextConstruct(title);
    calendar.setTitle(genVar280);
    calendar.setHidden(HiddenProperty.FALSE);
    com.google.gdata.data.calendar.ColorProperty genVar281;
    genVar281=new ColorProperty(color);
    calendar.setColor(genVar281);
    com.google.gdata.data.extensions.Where genVar282;
    genVar282=new Where(local,local,local);
    calendar.addLocation(genVar282);
    URL postUrl;
    CalendarEntry returnedCalendar;
    returnedCalendar=null;
    try {
      postUrl=new URL(GoogleUtils.URL_CALENDARS_OWNER);
      returnedCalendar=service.insert(postUrl,calendar);
    }
 catch (    MalformedURLException e) {
      e.printStackTrace();
    }
catch (    IOException e) {
      e.printStackTrace();
    }
catch (    ServiceException e) {
      e.printStackTrace();
    }
    boolean genVar283;
    genVar283=returnedCalendar != null;
    if (genVar283) {
      java.lang.String genVar284;
      genVar284=returnedCalendar.getId();
      return genVar284;
    }
 else {
      ;
    }
    java.lang.String genVar285;
    genVar285="Erro no cadastramento do calendario do usuario com o google";
    System.err.println(genVar285);
    return GoogleUtils.ERROR_GOOGLE;
  }
  /** 
 * @param idCalendario
 * @return
 */
  public CalendarEntry retornarCalendario(  String idCalendario){
    CalendarEntry result;
    result=null;
    URL feedUrl;
    feedUrl=null;
    CalendarFeed resultFeed;
    resultFeed=null;
    try {
      feedUrl=new URL(GoogleUtils.URL_ALLCALENDARS);
      java.lang.Class<com.google.gdata.data.calendar.CalendarFeed> genVar286;
      genVar286=CalendarFeed.class;
      resultFeed=service.getFeed(feedUrl,genVar286);
    }
 catch (    MalformedURLException e) {
      e.printStackTrace();
    }
catch (    IOException e) {
      e.printStackTrace();
    }
catch (    ServiceException e) {
      e.printStackTrace();
    }
    int i=0;
    for (; i < resultFeed.getEntries().size(); i++) {
      java.util.List<com.google.gdata.data.calendar.CalendarEntry> genVar287;
      genVar287=resultFeed.getEntries();
      CalendarEntry entry;
      entry=genVar287.get(i);
      java.lang.String genVar288;
      genVar288=entry.getId();
      boolean genVar289;
      genVar289=genVar288.equals(idCalendario);
      if (genVar289) {
        return entry;
      }
 else {
        ;
      }
    }
    java.lang.String genVar290;
    genVar290="Calendario de Id: ";
    java.lang.String genVar291;
    genVar291=" nao encontrado na aplicacao ";
    java.lang.String genVar292;
    genVar292=genVar290 + idCalendario + genVar291+ aplicacao;
    System.err.println(genVar292);
    return result;
  }
  /** 
 * Compartilha o calendario de id tal com o email passado. O compartilhado so podera bisoiar.
 * @param idCalendario
 * @param gmail
 */
  public void compartilharCalendario(  String idCalendario,  String gmail){
    AclEntry entry;
    entry=new AclEntry();
    com.google.gdata.data.acl.AclScope genVar293;
    genVar293=new AclScope(AclScope.Type.USER,gmail);
    entry.setScope(genVar293);
    entry.setRole(CalendarAclRole.READ);
    try {
      java.lang.String genVar294;
      genVar294="/default/calendars";
      java.lang.String genVar295;
      genVar295="";
      java.lang.String genVar296;
      genVar296=idCalendario.replaceAll(genVar294,genVar295);
      java.lang.String genVar297;
      genVar297="/acl/full";
      String url;
      url=genVar296 + genVar297;
      URL aclUrl;
      aclUrl=new URL(url);
      AclEntry insertedEntry;
      insertedEntry=service.insert(aclUrl,entry);
    }
 catch (    MalformedURLException e) {
      e.printStackTrace();
    }
catch (    IOException e) {
      e.printStackTrace();
    }
catch (    ServiceException e) {
      e.printStackTrace();
    }
  }
  /** 
 * Cadastrado o Evento evento no calendario idCalendario
 * @param idCalendario
 * @param evento
 * @return O id do evento que foi cadastrado
 */
  public String cadastrarEvento(  String idCalendario,  CalendarEventEntry evento){
    com.google.gdata.data.extensions.Where genVar298;
    genVar298=new Where(local,local,local);
    evento.addLocation(genVar298);
    java.lang.String genVar299;
    genVar299="/default/calendars";
    java.lang.String genVar300;
    genVar300="";
    String strUrl;
    strUrl=idCalendario.replace(genVar299,genVar300);
    strUrl+="/private/full";
    try {
      URL url;
      url=new URL(strUrl);
      CalendarEventEntry insertedEntry;
      insertedEntry=service.insert(url,evento);
      java.lang.String genVar301;
      genVar301=insertedEntry.getId();
      return genVar301;
    }
 catch (    MalformedURLException e) {
      e.printStackTrace();
    }
catch (    IOException e) {
      e.printStackTrace();
    }
catch (    ServiceException e) {
      e.printStackTrace();
    }
    java.lang.String genVar302;
    genVar302="Erro com o Google no cadastramento do evento";
    System.err.println(genVar302);
    return null;
  }
}
