package googlecalendar;
public class GoogleUtils {
  public static final String URL_CALENDARS_OWNER=null;
  public static final String ERROR_GOOGLE=null;
  public static final String URL_ALLCALENDARS=null;
}
