package controller.util;
import java.util.Date;
public class CalendarUtils {
  public static char[] getMes(  Date data){
    return null;
  }
  public static char[] getDia(  Date data){
    return null;
  }
  public static char[] getAno(  Date data){
    return null;
  }
}
