package controller.util;
public class AplicacaoUtils {
  public static final String APLICACAO_TIMEZONE=null;
  public static final String APLICACAO_SENHA=null;
  public static final String APLICACAO_EMAIL=null;
  public static final String APLICACAO_LOCAL=null;
  public static final String APLICACAO_NOME=null;
}
