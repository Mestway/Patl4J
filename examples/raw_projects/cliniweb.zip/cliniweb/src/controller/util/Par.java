package controller.util;
public class Par<A,B> {
  public int getFirst(){
    int genVar27;
    genVar27=0;
    return genVar27;
  }
  public int getSecond(){
    int genVar28;
    genVar28=0;
    return genVar28;
  }
  public void setFirst(  int i){
  }
}
