package entitites;
import java.util.Date;
import java.util.LinkedList;
import com.google.gdata.data.PlainTextConstruct;
import com.google.gdata.data.TextConstruct;
import com.google.gdata.data.calendar.CalendarEventEntry;
import com.google.gdata.data.extensions.Recurrence;
import controller.util.CalendarUtils;
import controller.util.Par;
import entitites.EventoGeral;
import entitites.specialists.Especialista;
import entitites.util.Repeticao;
import googlecalendar.GoogleCalendarManagerApp;
/** 
 * Guarda todas informações importantes para o evento do Medicamento
 * @author alessandro87
 */
public class Medicamento extends EventoGeral {
  private String idMedicamento;
  private Date dataInicio;
  private Date dataFim;
  private String nome;
  private String dose;
  private String observacoes;
  private LinkedList<Par<Integer,Integer>> horarios;
  private LinkedList<String> idMedicamentoEventohora;
  private Repeticao repeticao;
  private Especialista profissional;
  private Paciente paciente;
  public Medicamento(){
    entitites.Medicamento genVar29;
    genVar29=this;
    genVar29.horarios=new LinkedList<Par<Integer,Integer>>();
    entitites.Medicamento genVar30;
    genVar30=this;
    genVar30.idMedicamentoEventohora=new LinkedList<String>();
  }
  public Especialista getProfissional(){
    return profissional;
  }
  public void setProfissional(  Especialista profissional){
    entitites.Medicamento genVar31;
    genVar31=this;
    genVar31.profissional=profissional;
  }
  public Paciente getPaciente(){
    return paciente;
  }
  public void setPaciente(  Paciente paciente){
    entitites.Medicamento genVar32;
    genVar32=this;
    genVar32.paciente=paciente;
  }
  public String getIdMedicamento(){
    return idMedicamento;
  }
  public void setIdMedicamento(  String idMedicamento){
    entitites.Medicamento genVar33;
    genVar33=this;
    genVar33.idMedicamento=idMedicamento;
  }
  public Date getDataInicio(){
    return dataInicio;
  }
  public void setDataInicio(  Date dataInicio){
    entitites.Medicamento genVar34;
    genVar34=this;
    genVar34.dataInicio=dataInicio;
  }
  public Date getDataFim(){
    return dataFim;
  }
  public void setDataFim(  Date dataFim){
    entitites.Medicamento genVar35;
    genVar35=this;
    genVar35.dataFim=dataFim;
  }
  public String getNome(){
    return nome;
  }
  public void setNome(  String nome){
    entitites.Medicamento genVar36;
    genVar36=this;
    genVar36.nome=nome;
  }
  public String getDose(){
    return dose;
  }
  public void setDose(  String quantidade){
    entitites.Medicamento genVar37;
    genVar37=this;
    genVar37.dose=quantidade;
  }
  public String getObservacoes(){
    return observacoes;
  }
  public void setObservacoes(  String observacoes){
    entitites.Medicamento genVar38;
    genVar38=this;
    genVar38.observacoes=observacoes;
  }
  public Repeticao getRepeticao(){
    return repeticao;
  }
  public void setRepeticao(  Repeticao repeticao){
    entitites.Medicamento genVar39;
    genVar39=this;
    genVar39.repeticao=repeticao;
  }
  /** 
 * Metodo utilitario para completar uma string com 0 caso a mesma so tenha um digito. Util na formatacao HH, MM,
 * @return
 */
  private String completeString(  String horasFim){
    String result;
    result=horasFim;
    int genVar40;
    genVar40=horasFim.length();
    int genVar41;
    genVar41=1;
    boolean genVar42;
    genVar42=genVar40 == genVar41;
    if (genVar42) {
      java.lang.String genVar43;
      genVar43="0";
      result=genVar43 + result;
    }
 else {
      ;
    }
    return result;
  }
  public LinkedList<CalendarEventEntry> getEventos(){
    LinkedList<CalendarEventEntry> result;
    result=new LinkedList<CalendarEventEntry>();
    java.lang.String genVar44;
    genVar44="Medicamento: ";
    Medicamento genVar45;
    genVar45=this;
    java.lang.String genVar46;
    genVar46=genVar45.getNome();
    java.lang.String genVar47;
    genVar47=genVar44 + genVar46;
    TextConstruct titulo;
    titulo=new PlainTextConstruct(genVar47);
    java.lang.String genVar48;
    genVar48="Medicamento: ";
    Medicamento genVar49;
    genVar49=this;
    java.lang.String genVar50;
    genVar50=genVar49.getNome();
    java.lang.String genVar51;
    genVar51="\nQuantidade: ";
    Medicamento genVar52;
    genVar52=this;
    java.lang.String genVar53;
    genVar53=genVar52.getDose();
    java.lang.String genVar54;
    genVar54="\nObservacoes: ";
    Medicamento genVar55;
    genVar55=this;
    java.lang.String genVar56;
    genVar56=genVar55.getObservacoes();
    java.lang.String genVar57;
    genVar57=genVar48 + genVar50 + genVar51+ genVar53+ genVar54+ genVar56;
    TextConstruct descricao;
    descricao=new PlainTextConstruct(genVar57);
    char[] genVar58;
    genVar58=CalendarUtils.getAno(dataInicio);
    String anoDataInicio;
    anoDataInicio=String.valueOf(genVar58);
    char[] genVar59;
    genVar59=CalendarUtils.getAno(dataFim);
    String anoDataFim;
    anoDataFim=String.valueOf(genVar59);
    char[] genVar60;
    genVar60=CalendarUtils.getMes(dataInicio);
    String mesDataInicio;
    mesDataInicio=String.valueOf(genVar60);
    Medicamento genVar61;
    genVar61=this;
    mesDataInicio=genVar61.completeString(mesDataInicio);
    char[] genVar62;
    genVar62=CalendarUtils.getMes(dataFim);
    String mesDataFim;
    mesDataFim=String.valueOf(genVar62);
    Medicamento genVar63;
    genVar63=this;
    mesDataFim=genVar63.completeString(mesDataFim);
    char[] genVar64;
    genVar64=CalendarUtils.getDia(dataInicio);
    String diaDataInicio;
    diaDataInicio=String.valueOf(genVar64);
    Medicamento genVar65;
    genVar65=this;
    diaDataInicio=genVar65.completeString(diaDataInicio);
    char[] genVar66;
    genVar66=CalendarUtils.getDia(dataFim);
    String diaDataFim;
    diaDataFim=String.valueOf(genVar66);
    Medicamento genVar67;
    genVar67=this;
    diaDataFim=genVar67.completeString(diaDataFim);
    java.lang.String genVar68;
    genVar68="DTSTART;VALUE=DATE-TIME:";
    String dataInicioEvento;
    dataInicioEvento=genVar68 + anoDataInicio + mesDataInicio+ diaDataInicio;
    java.lang.String genVar69;
    genVar69="DTEND;VALUE=DATE-TIME:";
    String dataFimEvento;
    dataFimEvento=genVar69 + anoDataInicio + mesDataInicio+ diaDataInicio;
    java.lang.String genVar70;
    genVar70="UNTIL=";
    String untilEvento;
    untilEvento=genVar70 + anoDataFim + mesDataFim+ diaDataFim;
    String freq;
    freq="FREQ=WEEKLY";
    String cabecalho;
    cabecalho="RRULE:";
    java.lang.String genVar71;
    genVar71="BYDAY=";
    java.lang.String genVar72;
    genVar72=repeticao.daysEvent();
    String byday;
    byday=genVar71 + genVar72;
    for (    Par<Integer,Integer> hora : horarios) {
      CalendarEventEntry evento;
      evento=new CalendarEventEntry();
      Recurrence recur;
      recur=new Recurrence();
      evento.setTitle(titulo);
      evento.setContent(descricao);
      Medicamento genVar73;
      genVar73=this;
      genVar73.ajusteHoraTimeZine(hora);
      java.lang.String genVar74;
      genVar74="T";
      Medicamento genVar75;
      genVar75=this;
      java.lang.String genVar76;
      genVar76=genVar75.getHora(hora);
      java.lang.String genVar77;
      genVar77="Z";
      String time;
      time=genVar74 + genVar76 + genVar77;
      java.lang.String genVar78;
      genVar78="\r\n";
      java.lang.String genVar79;
      genVar79="\r\n";
      java.lang.String genVar80;
      genVar80=";";
      java.lang.String genVar81;
      genVar81=";";
      java.lang.String genVar82;
      genVar82="\r\n";
      String recurData;
      recurData=dataInicioEvento + time + genVar78+ dataFimEvento+ time+ genVar79+ cabecalho+ freq+ genVar80+ byday+ genVar81+ untilEvento+ genVar82;
      System.out.println(recurData);
      recur.setValue(recurData);
      evento.setRecurrence(recur);
      result.add(evento);
    }
    return result;
  }
  /** 
 * @param hora
 * @return A String correspondente a hora no formato usado pela regra de recorrencia do google, ou seja HHMMSS
 */
  private String getHora(  Par<Integer,Integer> hora){
    int genVar83;
    genVar83=hora.getFirst();
    String horaStr;
    horaStr=String.valueOf(genVar83);
    int genVar84;
    genVar84=horaStr.length();
    int genVar85;
    genVar85=1;
    boolean genVar86;
    genVar86=genVar84 == genVar85;
    if (genVar86) {
      java.lang.String genVar87;
      genVar87="0";
      horaStr=genVar87 + horaStr;
    }
 else {
      ;
    }
    int genVar88;
    genVar88=hora.getSecond();
    String minStr;
    minStr=String.valueOf(genVar88);
    int genVar89;
    genVar89=minStr.length();
    int genVar90;
    genVar90=1;
    boolean genVar91;
    genVar91=genVar89 == genVar90;
    if (genVar91) {
      java.lang.String genVar92;
      genVar92="0";
      minStr=genVar92 + minStr;
    }
 else {
      ;
    }
    String seconds;
    seconds="00";
    String result;
    result=horaStr + minStr + seconds;
    return result;
  }
  /** 
 * @return A Hora ajustada de acordo com o timeZone levado pela aplicacao
 */
  private void ajusteHoraTimeZine(  Par<Integer,Integer> hora){
    int ajuste;
    ajuste=GoogleCalendarManagerApp.ajusteTimeZone;
    int genVar93;
    genVar93=hora.getFirst();
    int genVar94;
    genVar94=genVar93 + ajuste;
    hora.setFirst(genVar94);
  }
  public void setHorarios(  LinkedList<Par<Integer,Integer>> horarios){
    entitites.Medicamento genVar95;
    genVar95=this;
    genVar95.horarios=horarios;
  }
  public LinkedList<String> getIdMedicamentoEventohora(){
    return idMedicamentoEventohora;
  }
  public void setIdMedicamentoEventohora(  LinkedList<String> idMedicamentoEventohora){
    entitites.Medicamento genVar96;
    genVar96=this;
    genVar96.idMedicamentoEventohora=idMedicamentoEventohora;
  }
  public LinkedList<CalendarEventEntry> getEventosGoogleDoEvento(){
    LinkedList<CalendarEventEntry> result;
    result=new LinkedList<CalendarEventEntry>();
    java.lang.String genVar97;
    genVar97="Medicamento: ";
    Medicamento genVar98;
    genVar98=this;
    java.lang.String genVar99;
    genVar99=genVar98.getNome();
    java.lang.String genVar100;
    genVar100=genVar97 + genVar99;
    TextConstruct titulo;
    titulo=new PlainTextConstruct(genVar100);
    java.lang.String genVar101;
    genVar101="Medicamento: ";
    Medicamento genVar102;
    genVar102=this;
    java.lang.String genVar103;
    genVar103=genVar102.getNome();
    java.lang.String genVar104;
    genVar104="\nQuantidade: ";
    Medicamento genVar105;
    genVar105=this;
    java.lang.String genVar106;
    genVar106=genVar105.getDose();
    java.lang.String genVar107;
    genVar107="\nObservacoes: ";
    Medicamento genVar108;
    genVar108=this;
    java.lang.String genVar109;
    genVar109=genVar108.getObservacoes();
    java.lang.String genVar110;
    genVar110=genVar101 + genVar103 + genVar104+ genVar106+ genVar107+ genVar109;
    TextConstruct descricao;
    descricao=new PlainTextConstruct(genVar110);
    char[] genVar111;
    genVar111=CalendarUtils.getAno(dataInicio);
    String anoDataInicio;
    anoDataInicio=String.valueOf(genVar111);
    char[] genVar112;
    genVar112=CalendarUtils.getAno(dataFim);
    String anoDataFim;
    anoDataFim=String.valueOf(genVar112);
    char[] genVar113;
    genVar113=CalendarUtils.getMes(dataInicio);
    String mesDataInicio;
    mesDataInicio=String.valueOf(genVar113);
    Medicamento genVar114;
    genVar114=this;
    mesDataInicio=genVar114.completeString(mesDataInicio);
    char[] genVar115;
    genVar115=CalendarUtils.getMes(dataFim);
    String mesDataFim;
    mesDataFim=String.valueOf(genVar115);
    Medicamento genVar116;
    genVar116=this;
    mesDataFim=genVar116.completeString(mesDataFim);
    char[] genVar117;
    genVar117=CalendarUtils.getDia(dataInicio);
    String diaDataInicio;
    diaDataInicio=String.valueOf(genVar117);
    Medicamento genVar118;
    genVar118=this;
    diaDataInicio=genVar118.completeString(diaDataInicio);
    char[] genVar119;
    genVar119=CalendarUtils.getDia(dataFim);
    String diaDataFim;
    diaDataFim=String.valueOf(genVar119);
    Medicamento genVar120;
    genVar120=this;
    diaDataFim=genVar120.completeString(diaDataFim);
    java.lang.String genVar121;
    genVar121="DTSTART;VALUE=DATE-TIME:";
    String dataInicioEvento;
    dataInicioEvento=genVar121 + anoDataInicio + mesDataInicio+ diaDataInicio;
    java.lang.String genVar122;
    genVar122="DTEND;VALUE=DATE-TIME:";
    String dataFimEvento;
    dataFimEvento=genVar122 + anoDataInicio + mesDataInicio+ diaDataInicio;
    java.lang.String genVar123;
    genVar123="UNTIL=";
    String untilEvento;
    untilEvento=genVar123 + anoDataFim + mesDataFim+ diaDataFim;
    String freq;
    freq="FREQ=WEEKLY";
    String cabecalho;
    cabecalho="RRULE:";
    java.lang.String genVar124;
    genVar124="BYDAY=";
    java.lang.String genVar125;
    genVar125=repeticao.daysEvent();
    String byday;
    byday=genVar124 + genVar125;
    for (    Par<Integer,Integer> hora : horarios) {
      CalendarEventEntry evento;
      evento=new CalendarEventEntry();
      Recurrence recur;
      recur=new Recurrence();
      evento.setTitle(titulo);
      evento.setContent(descricao);
      Medicamento genVar126;
      genVar126=this;
      genVar126.ajusteHoraTimeZine(hora);
      java.lang.String genVar127;
      genVar127="T";
      Medicamento genVar128;
      genVar128=this;
      java.lang.String genVar129;
      genVar129=genVar128.getHora(hora);
      java.lang.String genVar130;
      genVar130="Z";
      String time;
      time=genVar127 + genVar129 + genVar130;
      java.lang.String genVar131;
      genVar131="\r\n";
      java.lang.String genVar132;
      genVar132="\r\n";
      java.lang.String genVar133;
      genVar133=";";
      java.lang.String genVar134;
      genVar134=";";
      java.lang.String genVar135;
      genVar135="\r\n";
      String recurData;
      recurData=dataInicioEvento + time + genVar131+ dataFimEvento+ time+ genVar132+ cabecalho+ freq+ genVar133+ byday+ genVar134+ untilEvento+ genVar135;
      System.out.println(recurData);
      recur.setValue(recurData);
      evento.setRecurrence(recur);
      result.add(evento);
    }
    return result;
  }
}
