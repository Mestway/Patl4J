package entitites;
public class Paciente {
  public String getIdGoogleCalendario(){
    return null;
  }
}
