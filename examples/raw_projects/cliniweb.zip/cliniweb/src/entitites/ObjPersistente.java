package entitites;
public class ObjPersistente {
}
