package entitites.specialists;
public class Especialista {
  public String getLogin(){
    return null;
  }
  public String getNomeCompleto(){
    return null;
  }
  public String getIdGoogleCalendario(){
    return null;
  }
}
