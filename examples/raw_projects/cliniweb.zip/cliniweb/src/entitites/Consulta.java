package entitites;
import java.util.Date;
import java.util.LinkedList;
import com.google.gdata.data.DateTime;
import com.google.gdata.data.PlainTextConstruct;
import com.google.gdata.data.calendar.CalendarEventEntry;
import com.google.gdata.data.extensions.When;
import controller.util.AplicacaoUtils;
import controller.util.CalendarUtils;
import controller.util.Par;
import entitites.specialists.Especialista;
public class Consulta extends EventoGeral {
  public Consulta(  Especialista profissional,  Paciente paciente,  Date data,  Par<Integer,Integer> hora,  int duracao){
    super();
    entitites.Consulta genVar136;
    genVar136=this;
    genVar136.profissional=profissional;
    entitites.Consulta genVar137;
    genVar137=this;
    genVar137.paciente=paciente;
    entitites.Consulta genVar138;
    genVar138=this;
    genVar138.data=data;
    entitites.Consulta genVar139;
    genVar139=this;
    genVar139.tempo=hora;
    entitites.Consulta genVar140;
    genVar140=this;
    genVar140.duracao=duracao;
  }
  private String idConsulta;
  private Especialista profissional;
  private Paciente paciente;
  private Date data;
  private Par<Integer,Integer> tempo;
  private int duracao;
  /** 
 * Google ID
 */
  private String googleIdPaciente="";
  private String googleIdEspecialista="";
  private When eventTimes;
  public String getIdConsulta(){
    return idConsulta;
  }
  public void setIdConsulta(  String idConsulta){
    entitites.Consulta genVar141;
    genVar141=this;
    genVar141.idConsulta=idConsulta;
  }
  public Especialista getEspecialista(){
    return profissional;
  }
  public void setProfissional(  Especialista profissional){
    entitites.Consulta genVar142;
    genVar142=this;
    genVar142.profissional=profissional;
  }
  public Paciente getPaciente(){
    return paciente;
  }
  public void setPaciente(  Paciente paciente){
    entitites.Consulta genVar143;
    genVar143=this;
    genVar143.paciente=paciente;
  }
  public Date getData(){
    return data;
  }
  public void setData(  Date data){
    entitites.Consulta genVar144;
    genVar144=this;
    genVar144.data=data;
  }
  public Par<Integer,Integer> getHora(){
    return tempo;
  }
  public void setHora(  Par<Integer,Integer> hora){
    entitites.Consulta genVar145;
    genVar145=this;
    genVar145.tempo=hora;
  }
  public int getDuracao(){
    return duracao;
  }
  public void setDuracao(  int duracao){
    entitites.Consulta genVar146;
    genVar146=this;
    genVar146.duracao=duracao;
  }
  /** 
 * Adapter
 * @return
 */
  public CalendarEventEntry getEvento(){
    CalendarEventEntry result;
    result=new CalendarEventEntry();
    java.lang.String genVar147;
    genVar147="Consulta: ";
    entitites.Consulta genVar148;
    genVar148=this;
    entitites.specialists.Especialista genVar149;
    genVar149=genVar148.profissional;
    java.lang.String genVar150;
    genVar150=genVar149.getLogin();
    java.lang.String genVar151;
    genVar151=genVar147 + genVar150;
    com.google.gdata.data.PlainTextConstruct genVar152;
    genVar152=new PlainTextConstruct(genVar151);
    result.setTitle(genVar152);
    java.lang.String genVar153;
    genVar153="Consulta: ";
    entitites.Consulta genVar154;
    genVar154=this;
    entitites.specialists.Especialista genVar155;
    genVar155=genVar154.profissional;
    java.lang.String genVar156;
    genVar156=genVar155.getLogin();
    java.lang.String genVar157;
    genVar157=genVar153 + genVar156;
    com.google.gdata.data.PlainTextConstruct genVar158;
    genVar158=new PlainTextConstruct(genVar157);
    result.setTitle(genVar158);
    java.lang.String genVar159;
    genVar159="Consulta com: ";
    entitites.Consulta genVar160;
    genVar160=this;
    entitites.specialists.Especialista genVar161;
    genVar161=genVar160.profissional;
    java.lang.String genVar162;
    genVar162=genVar161.getNomeCompleto();
    java.lang.String genVar163;
    genVar163=genVar159 + genVar162;
    com.google.gdata.data.PlainTextConstruct genVar164;
    genVar164=new PlainTextConstruct(genVar163);
    result.setContent(genVar164);
    int genVar165;
    genVar165=60;
    int horasduracao;
    horasduracao=duracao / genVar165;
    int genVar166;
    genVar166=60;
    int minutosduracao;
    minutosduracao=duracao % genVar166;
    entitites.Consulta genVar167;
    genVar167=this;
    controller.util.Par<java.lang.Integer,java.lang.Integer> genVar168;
    genVar168=genVar167.tempo;
    int genVar169;
    genVar169=genVar168.getFirst();
    int tempoHoras;
    tempoHoras=genVar169 + horasduracao;
    entitites.Consulta genVar170;
    genVar170=this;
    controller.util.Par<java.lang.Integer,java.lang.Integer> genVar171;
    genVar171=genVar170.tempo;
    int genVar172;
    genVar172=genVar171.getSecond();
    int tempoMinutos;
    tempoMinutos=genVar172 + minutosduracao;
    char[] genVar173;
    genVar173=CalendarUtils.getMes(data);
    String mes;
    mes=String.valueOf(genVar173);
    int genVar174;
    genVar174=mes.length();
    int genVar175;
    genVar175=1;
    boolean genVar176;
    genVar176=genVar174 == genVar175;
    if (genVar176) {
      java.lang.String genVar177;
      genVar177="0";
      mes=genVar177 + mes;
    }
 else {
      ;
    }
    char[] genVar178;
    genVar178=CalendarUtils.getDia(data);
    String dia;
    dia=String.valueOf(genVar178);
    int genVar179;
    genVar179=dia.length();
    int genVar180;
    genVar180=1;
    boolean genVar181;
    genVar181=genVar179 == genVar180;
    if (genVar181) {
      java.lang.String genVar182;
      genVar182="0";
      dia=genVar182 + dia;
    }
 else {
      ;
    }
    char[] genVar183;
    genVar183=CalendarUtils.getAno(data);
    String ano;
    ano=String.valueOf(genVar183);
    int genVar184;
    genVar184=tempo.getFirst();
    String horas;
    horas=String.valueOf(genVar184);
    int genVar185;
    genVar185=horas.length();
    int genVar186;
    genVar186=1;
    boolean genVar187;
    genVar187=genVar185 == genVar186;
    if (genVar187) {
      java.lang.String genVar188;
      genVar188="0";
      horas=genVar188 + horas;
    }
 else {
      ;
    }
    int genVar189;
    genVar189=tempo.getSecond();
    String minutos;
    minutos=String.valueOf(genVar189);
    int genVar190;
    genVar190=minutos.length();
    int genVar191;
    genVar191=1;
    boolean genVar192;
    genVar192=genVar190 == genVar191;
    if (genVar192) {
      java.lang.String genVar193;
      genVar193="0";
      minutos=genVar193 + minutos;
    }
 else {
      ;
    }
    java.lang.String genVar194;
    genVar194="-";
    java.lang.String genVar195;
    genVar195="-";
    java.lang.String genVar196;
    genVar196="T";
    java.lang.String genVar197;
    genVar197=":";
    java.lang.String genVar198;
    genVar198=":00";
    String startTime;
    startTime=ano + genVar194 + mes+ genVar195+ dia+ genVar196+ horas+ genVar197+ minutos+ genVar198+ AplicacaoUtils.APLICACAO_TIMEZONE;
    String horasFim;
    horasFim=String.valueOf(tempoHoras);
    int genVar199;
    genVar199=horasFim.length();
    int genVar200;
    genVar200=1;
    boolean genVar201;
    genVar201=genVar199 == genVar200;
    if (genVar201) {
      java.lang.String genVar202;
      genVar202="0";
      horasFim=genVar202 + horasFim;
    }
 else {
      ;
    }
    String minutosFim;
    minutosFim=String.valueOf(tempoMinutos);
    int genVar203;
    genVar203=minutosFim.length();
    int genVar204;
    genVar204=1;
    boolean genVar205;
    genVar205=genVar203 == genVar204;
    if (genVar205) {
      java.lang.String genVar206;
      genVar206="0";
      minutosFim=genVar206 + minutosFim;
    }
 else {
      ;
    }
    java.lang.String genVar207;
    genVar207="-";
    java.lang.String genVar208;
    genVar208="-";
    java.lang.String genVar209;
    genVar209="T";
    java.lang.String genVar210;
    genVar210=":";
    java.lang.String genVar211;
    genVar211=":00";
    String endTime;
    endTime=ano + genVar207 + mes+ genVar208+ dia+ genVar209+ horasFim+ genVar210+ minutosFim+ genVar211+ AplicacaoUtils.APLICACAO_TIMEZONE;
    DateTime startTimeDate;
    startTimeDate=DateTime.parseDateTime(startTime);
    DateTime endTimeDate;
    endTimeDate=DateTime.parseDateTime(endTime);
    eventTimes.setStartTime(startTimeDate);
    eventTimes.setEndTime(endTimeDate);
    result.addTime(eventTimes);
    return result;
  }
  public String getGoogleId(){
    return googleIdPaciente;
  }
  public void setGoogleIdPaciente(  String googleId){
    entitites.Consulta genVar212;
    genVar212=this;
    genVar212.googleIdPaciente=googleId;
  }
  public String getGoogleIdEspecialista(){
    return googleIdEspecialista;
  }
  public void setGoogleIdEspecialista(  String googleIdEspecialista){
    entitites.Consulta genVar213;
    genVar213=this;
    genVar213.googleIdEspecialista=googleIdEspecialista;
  }
  @Override public LinkedList<CalendarEventEntry> getEventosGoogleDoEvento(){
    LinkedList<CalendarEventEntry> results;
    results=new LinkedList<CalendarEventEntry>();
    CalendarEventEntry result;
    result=new CalendarEventEntry();
    java.lang.String genVar214;
    genVar214="Consulta: ";
    entitites.Consulta genVar215;
    genVar215=this;
    entitites.specialists.Especialista genVar216;
    genVar216=genVar215.profissional;
    java.lang.String genVar217;
    genVar217=genVar216.getLogin();
    java.lang.String genVar218;
    genVar218=genVar214 + genVar217;
    com.google.gdata.data.PlainTextConstruct genVar219;
    genVar219=new PlainTextConstruct(genVar218);
    result.setTitle(genVar219);
    java.lang.String genVar220;
    genVar220="Consulta com: ";
    entitites.Consulta genVar221;
    genVar221=this;
    entitites.specialists.Especialista genVar222;
    genVar222=genVar221.profissional;
    java.lang.String genVar223;
    genVar223=genVar222.getNomeCompleto();
    java.lang.String genVar224;
    genVar224=genVar220 + genVar223;
    com.google.gdata.data.PlainTextConstruct genVar225;
    genVar225=new PlainTextConstruct(genVar224);
    result.setContent(genVar225);
    int genVar226;
    genVar226=60;
    int horasduracao;
    horasduracao=duracao / genVar226;
    int genVar227;
    genVar227=60;
    int minutosduracao;
    minutosduracao=duracao % genVar227;
    entitites.Consulta genVar228;
    genVar228=this;
    controller.util.Par<java.lang.Integer,java.lang.Integer> genVar229;
    genVar229=genVar228.tempo;
    int genVar230;
    genVar230=genVar229.getFirst();
    int tempoHoras;
    tempoHoras=genVar230 + horasduracao;
    entitites.Consulta genVar231;
    genVar231=this;
    controller.util.Par<java.lang.Integer,java.lang.Integer> genVar232;
    genVar232=genVar231.tempo;
    int genVar233;
    genVar233=genVar232.getSecond();
    int tempoMinutos;
    tempoMinutos=genVar233 + minutosduracao;
    char[] genVar234;
    genVar234=CalendarUtils.getMes(data);
    String mes;
    mes=String.valueOf(genVar234);
    int genVar235;
    genVar235=mes.length();
    int genVar236;
    genVar236=1;
    boolean genVar237;
    genVar237=genVar235 == genVar236;
    if (genVar237) {
      java.lang.String genVar238;
      genVar238="0";
      mes=genVar238 + mes;
    }
 else {
      ;
    }
    char[] genVar239;
    genVar239=CalendarUtils.getDia(data);
    String dia;
    dia=String.valueOf(genVar239);
    int genVar240;
    genVar240=dia.length();
    int genVar241;
    genVar241=1;
    boolean genVar242;
    genVar242=genVar240 == genVar241;
    if (genVar242) {
      java.lang.String genVar243;
      genVar243="0";
      dia=genVar243 + dia;
    }
 else {
      ;
    }
    char[] genVar244;
    genVar244=CalendarUtils.getAno(data);
    String ano;
    ano=String.valueOf(genVar244);
    int genVar245;
    genVar245=tempo.getFirst();
    String horas;
    horas=String.valueOf(genVar245);
    int genVar246;
    genVar246=horas.length();
    int genVar247;
    genVar247=1;
    boolean genVar248;
    genVar248=genVar246 == genVar247;
    if (genVar248) {
      java.lang.String genVar249;
      genVar249="0";
      horas=genVar249 + horas;
    }
 else {
      ;
    }
    int genVar250;
    genVar250=tempo.getSecond();
    String minutos;
    minutos=String.valueOf(genVar250);
    int genVar251;
    genVar251=minutos.length();
    int genVar252;
    genVar252=1;
    boolean genVar253;
    genVar253=genVar251 == genVar252;
    if (genVar253) {
      java.lang.String genVar254;
      genVar254="0";
      minutos=genVar254 + minutos;
    }
 else {
      ;
    }
    java.lang.String genVar255;
    genVar255="-";
    java.lang.String genVar256;
    genVar256="-";
    java.lang.String genVar257;
    genVar257="T";
    java.lang.String genVar258;
    genVar258=":";
    java.lang.String genVar259;
    genVar259=":00";
    String startTime;
    startTime=ano + genVar255 + mes+ genVar256+ dia+ genVar257+ horas+ genVar258+ minutos+ genVar259+ AplicacaoUtils.APLICACAO_TIMEZONE;
    String horasFim;
    horasFim=String.valueOf(tempoHoras);
    int genVar260;
    genVar260=horasFim.length();
    int genVar261;
    genVar261=1;
    boolean genVar262;
    genVar262=genVar260 == genVar261;
    if (genVar262) {
      java.lang.String genVar263;
      genVar263="0";
      horasFim=genVar263 + horasFim;
    }
 else {
      ;
    }
    String minutosFim;
    minutosFim=String.valueOf(tempoMinutos);
    int genVar264;
    genVar264=minutosFim.length();
    int genVar265;
    genVar265=1;
    boolean genVar266;
    genVar266=genVar264 == genVar265;
    if (genVar266) {
      java.lang.String genVar267;
      genVar267="0";
      minutosFim=genVar267 + minutosFim;
    }
 else {
      ;
    }
    java.lang.String genVar268;
    genVar268="-";
    java.lang.String genVar269;
    genVar269="-";
    java.lang.String genVar270;
    genVar270="T";
    java.lang.String genVar271;
    genVar271=":";
    java.lang.String genVar272;
    genVar272=":00";
    String endTime;
    endTime=ano + genVar268 + mes+ genVar269+ dia+ genVar270+ horasFim+ genVar271+ minutosFim+ genVar272+ AplicacaoUtils.APLICACAO_TIMEZONE;
    DateTime startTimeDate;
    startTimeDate=DateTime.parseDateTime(startTime);
    DateTime endTimeDate;
    endTimeDate=DateTime.parseDateTime(endTime);
    eventTimes.setStartTime(startTimeDate);
    eventTimes.setEndTime(endTimeDate);
    result.addTime(eventTimes);
    results.add(result);
    return results;
  }
}
