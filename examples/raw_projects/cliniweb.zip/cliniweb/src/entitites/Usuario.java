package entitites;
public interface Usuario {
  String getLogin();
  void setIdGoogleCalendario(  String idCalendario);
  String getGmail();
}
