package entitites;
public class AdministradorClinico {
}
