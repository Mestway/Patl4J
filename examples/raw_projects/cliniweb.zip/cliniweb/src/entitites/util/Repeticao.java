package entitites.util;
public class Repeticao {
  public String daysEvent(){
    return null;
  }
}
