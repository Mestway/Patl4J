import os 
import string

path = "libsrc\\"

def getClassToLoad(path):
	list_dirs = os.walk(path) 
	for root, dirs, files in list_dirs:     
		for f in files: 
			str = os.path.join(root, f)
			print "<classToLoad>"+string.replace(str[4:-5],"\\",".")+"</classToLoad>"

def getLibToAdd(path):
	dirs = os.listdir(path)
	for f in dirs:
		if (os.path.isdir(os.path.join(path,f))):
			print "<classPath>D:\\runtime-EclipseApplication\\cliniweb\\libsrc\\" + f + "</classPath>"

getLibToAdd("libsrc\\")
