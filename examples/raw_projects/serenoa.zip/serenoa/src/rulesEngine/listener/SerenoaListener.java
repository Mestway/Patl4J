package rulesEngine.listener;
import rulesEngine.behavior.SerenoaSessionBehavior;
public class SerenoaListener extends FileListener {
  public SerenoaListener(  SerenoaSessionBehavior serenoaSessionBehavior){
  }
}
