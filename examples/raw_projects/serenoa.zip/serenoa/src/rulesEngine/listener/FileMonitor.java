package rulesEngine.listener;
import java.io.File;
public class FileMonitor {
  public FileMonitor(  int i){
  }
  public void addFile(  File f){
  }
  public void addListener(  FileListener listener){
  }
}
