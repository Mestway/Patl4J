package rulesEngine.utils;
import leon.app.LySession;
public class Logger {
  public static void init(  LySession session){
  }
  public static void log(  String string){
  }
}
