package rulesEngine.utils;
import java.io.IOException;
import java.io.InputStream;
public class FileUtils {
  public static String getInputStreamAsString(  InputStream file) throws IOException {
    return null;
  }
  public static void setFileFromString(  String rootPath,  String content){
  }
}
