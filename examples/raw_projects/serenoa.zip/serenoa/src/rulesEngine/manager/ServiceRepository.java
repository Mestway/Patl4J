package rulesEngine.manager;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
import org.jdom2.xpath.XPath;
import org.jdom2.xpath.jaxen.JDOMXPath;
public class ServiceRepository {
  public static void main(  String[] args){
    try {
      java.lang.String genVar946;
      genVar946="http://195.235.93.35:8080/SerenoaSR";
      java.lang.String genVar947;
      genVar947="C:\\Users\\mducass\\workspace\\TestsWeb2\\src\\serenoa\\testAaldl.xml";
      java.lang.String genVar948;
      genVar948="user1";
      java.lang.String genVar949;
      genVar949="undefined ";
      new ServiceRepository(genVar946,genVar947,genVar948,genVar949);
    }
 catch (    JDOMException e) {
      e.printStackTrace();
    }
catch (    IOException e) {
      e.printStackTrace();
    }
catch (    ContextManagerParserException e) {
      e.printStackTrace();
    }
  }
  private static final String APPLICATION_ID_PREFIX="w4serenoa";
  protected String applicationId;
  private String service_repository_uri;
  private boolean deconectedMode=false;
  private Document asfedl;
  private Document aaldl;
  private static SAXBuilder sxb=new SAXBuilder();
  private static Map<AE_ModelId,Document> models=new HashMap<AE_ModelId,Document>();
  public ServiceRepository(  String service_repository_uri,  String rulesPath,  String user,  String undefinedModelPrefix) throws JDOMException, IOException, ContextManagerParserException {
    applicationId=APPLICATION_ID_PREFIX + user;
    rulesEngine.manager.ServiceRepository genVar950;
    genVar950=this;
    genVar950.service_repository_uri=service_repository_uri;
    String rules;
    rules="";
    String auiModel;
    auiModel="";
    File rulesFile;
    String rulesToRegister;
    rulesToRegister="";
    try {
      rulesFile=new File(rulesPath);
      CM_Parser cmp;
      cmp=new CM_Parser(user);
      rules=cmp.parse(rulesFile);
      byte[] genVar951;
      genVar951=rules.getBytes();
      java.io.ByteArrayInputStream genVar952;
      genVar952=new ByteArrayInputStream(genVar951);
      aaldl=sxb.build(genVar952);
      Element rulesRoot;
      rulesRoot=aaldl.getRootElement();
      ServiceRepository genVar953;
      genVar953=this;
      auiModel=genVar953.contructASFE_DL(rulesRoot,rulesFile,undefinedModelPrefix);
      java.lang.String genVar954;
      genVar954="rule";
      List<Element> rulesElements;
      rulesElements=rulesRoot.getChildren(genVar954);
      org.jdom2.output.Format genVar955;
      genVar955=Format.getPrettyFormat();
      XMLOutputter out;
      out=new XMLOutputter(genVar955);
      for (      Element e : rulesElements) {
        java.lang.String genVar956;
        genVar956=out.outputString(e);
        java.lang.String genVar957;
        genVar957="\n";
        rulesToRegister+=genVar956 + genVar957;
      }
    }
 catch (    IOException e) {
      e.printStackTrace();
    }
    try {
    }
 catch (    Exception e) {
      deconectedMode=true;
    }
    boolean genVar958;
    genVar958=!deconectedMode;
    if (genVar958) {
      String response;
      response="";
      java.lang.String genVar959;
      genVar959="<aaldl>[\\s\\S]*</aaldl>";
      java.lang.String genVar960;
      genVar960="";
      response=response.replaceFirst(genVar959,genVar960);
      byte[] genVar961;
      genVar961=response.getBytes();
      java.lang.String genVar962;
      genVar962="UTF-8";
      String responseUTF8;
      responseUTF8=new String(genVar961,genVar962);
      byte[] genVar963;
      genVar963=responseUTF8.getBytes();
      java.io.ByteArrayInputStream genVar964;
      genVar964=new ByteArrayInputStream(genVar963);
      Document rulesModel;
      rulesModel=sxb.build(genVar964);
      org.jdom2.Element genVar965;
      genVar965=rulesModel.getRootElement();
      java.lang.String genVar966;
      genVar966="asfedl";
      org.jdom2.Element genVar967;
      genVar967=genVar965.getChild(genVar966);
      org.jdom2.Element genVar968;
      genVar968=genVar967.clone();
      asfedl=new Document(genVar968);
    }
 else {
      ;
    }
  }
  private URI getBaseURI(){
    return null;
  }
  public Document getAaldl(){
    return aaldl;
  }
  private String contructASFE_DL(  Element rulesRoot,  File rulesFile,  String undefinedModelPrefix) throws JDOMException, IOException {
    java.lang.String genVar969;
    genVar969="//ext_model_ref";
    XPath xpa;
    xpa=new JDOMXPath(genVar969);
    java.util.List genVar970;
    genVar970=xpa.selectNodes(rulesRoot);
    List<Element> modelsList;
    modelsList=(List<Element>)genVar970;
    int modelUndefinedIndex;
    modelUndefinedIndex=0;
    for (    Element e : modelsList) {
      java.lang.String genVar971;
      genVar971="model_id";
      String modelId;
      modelId=e.getAttributeValue(genVar971);
      boolean genVar972;
      genVar972=modelId == null;
      int genVar973;
      genVar973=modelId.length();
      int genVar974;
      genVar974=0;
      boolean genVar975;
      genVar975=genVar973 == genVar974;
      boolean genVar976;
      genVar976=genVar972 || genVar975;
      if (genVar976) {
        modelId=undefinedModelPrefix + modelUndefinedIndex;
        modelUndefinedIndex++;
      }
 else {
        ;
      }
      java.lang.String genVar977;
      genVar977="URI";
      String uri;
      uri=e.getAttributeValue(genVar977);
      java.lang.String genVar978;
      genVar978="%";
      java.lang.String genVar979;
      genVar979="%";
      java.lang.String genVar980;
      genVar980=genVar978 + CM_Parser.tokens.CONTEXT_MANAGER + genVar979;
      boolean genVar981;
      genVar981=uri.contains(genVar980);
      if (genVar981) {
        boolean genVar982;
        genVar982=true;
        rulesEngine.manager.AE_ModelId genVar983;
        genVar983=new AE_ModelId(modelId,genVar982);
        models.put(genVar983,null);
        continue;
      }
 else {
        ;
      }
      File f;
      f=null;
      try {
        java.lang.String genVar984;
        genVar984=rulesFile.getParent();
        f=new File(genVar984,uri);
        boolean genVar985;
        genVar985=f.exists();
        boolean genVar986;
        genVar986=!genVar985;
        if (genVar986) {
          java.lang.Exception genVar987;
          genVar987=new Exception();
          throw genVar987;
        }
 else {
          ;
        }
      }
 catch (      Exception exp) {
        try {
          URL oracle;
          oracle=new URL(uri);
          java.net.URI genVar988;
          genVar988=oracle.toURI();
          f=new File(genVar988);
        }
 catch (        Exception exp2) {
          rulesEngine.manager.ServiceRepository genVar989;
          genVar989=this;
          java.lang.Class genVar990;
          genVar990=genVar989.getClass();
          InputStream input;
          input=genVar990.getResourceAsStream(uri);
          java.lang.String genVar991;
          genVar991=rulesFile.getParent();
          java.lang.String genVar992;
          genVar992=input.toString();
          java.lang.String genVar993;
          genVar993=genVar991 + genVar992;
          f=new File(genVar993);
          OutputStream out;
          out=new FileOutputStream(f);
          int read;
          read=0;
          byte[] bytes;
          bytes=new byte[1024];
          int genVar994;
          genVar994=read=input.read(bytes);
          int genVar995;
          genVar995=(genVar994);
          int genVar996;
          genVar996=1;
          int genVar997;
          genVar997=-genVar996;
          boolean genVar998;
          genVar998=genVar995 != genVar997;
          while (genVar998) {
            int genVar999;
            genVar999=0;
            out.write(bytes,genVar999,read);
          }
          input.close();
          out.flush();
          out.close();
        }
      }
      Document model;
      model=sxb.build(f);
      rulesEngine.manager.AE_ModelId genVar1000;
      genVar1000=new AE_ModelId(modelId);
      models.put(genVar1000,model);
    }
    ServiceRepository genVar1001;
    genVar1001=this;
    java.lang.String genVar1002;
    genVar1002=genVar1001.getAllModelsAsXMLString();
    return genVar1002;
  }
  private String getAllModelsAsXMLString() throws JDOMException, IOException {
    String response;
    response="";
    java.util.Set<java.util.Map.Entry<rulesEngine.manager.AE_ModelId,org.jdom2.Document>> genVar1003;
    genVar1003=models.entrySet();
    for (    Entry<AE_ModelId,Document> entry : genVar1003) {
      ServiceRepository genVar1004;
      genVar1004=this;
      rulesEngine.manager.AE_ModelId genVar1005;
      genVar1005=entry.getKey();
      response+=genVar1004.getModelAsXMLString(genVar1005);
    }
    return response;
  }
  private String getModelAsXMLString(  AE_ModelId modelId) throws JDOMException, IOException {
    ServiceRepository genVar1006;
    genVar1006=this;
    Element model;
    model=genVar1006.getModel(modelId);
    String response;
    response="";
    boolean genVar1007;
    genVar1007=model != null;
    if (genVar1007) {
      org.jdom2.output.Format genVar1008;
      genVar1008=Format.getPrettyFormat();
      XMLOutputter sortie;
      sortie=new XMLOutputter(genVar1008);
      java.lang.String genVar1009;
      genVar1009="model";
      Element modelElement;
      modelElement=new Element(genVar1009);
      java.lang.String genVar1010;
      genVar1010="id";
      java.lang.String genVar1011;
      genVar1011=modelId.getId();
      modelElement.setAttribute(genVar1010,genVar1011);
      org.jdom2.Element genVar1012;
      genVar1012=model.clone();
      modelElement.addContent(genVar1012);
      response=sortie.outputString(modelElement);
      response+="\n";
    }
 else {
      ;
    }
    return response;
  }
  public Element getModel(  AE_ModelId modelId) throws JDOMException, IOException {
    java.util.Set<java.util.Map.Entry<rulesEngine.manager.AE_ModelId,org.jdom2.Document>> genVar1013;
    genVar1013=models.entrySet();
    for (    Entry<AE_ModelId,Document> model : genVar1013) {
      rulesEngine.manager.AE_ModelId genVar1014;
      genVar1014=model.getKey();
      boolean genVar1015;
      genVar1015=modelId.equals(genVar1014);
      if (genVar1015) {
        modelId=model.getKey();
        break;
      }
 else {
        ;
      }
    }
    boolean genVar1016;
    genVar1016=modelId.isContextManager();
    if (genVar1016) {
      return null;
    }
 else {
      ;
    }
    org.jdom2.Document genVar1017;
    genVar1017=models.get(modelId);
    org.jdom2.Element genVar1018;
    genVar1018=genVar1017.getRootElement();
    return genVar1018;
  }
  public boolean isDeconectedMode(){
    return deconectedMode;
  }
  public void updateModel(  AE_ModelId id,  Document document){
    models.put(id,document);
  }
}
