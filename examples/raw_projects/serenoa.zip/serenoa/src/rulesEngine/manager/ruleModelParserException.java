package rulesEngine.manager;
public class ruleModelParserException extends Exception {
  public ruleModelParserException(  String string){
  }
}
