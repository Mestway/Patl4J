package rulesEngine.manager;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.jdom2.Attribute;
import org.jdom2.Content;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
import org.jdom2.xpath.XPath;
import org.jdom2.xpath.jaxen.JDOMXPath;
import rulesEngine.listener.FileListener;
import rulesEngine.listener.FileMonitor;
import rulesEngine.listener.SerenoaListener;
@SuppressWarnings("deprecation") public class AdaptationEngineDeconected extends AdaptationEngine {
  private SAXBuilder sxb=new SAXBuilder();
  private Map<AE_ModelId,Document> models;
  private List<File> relatedFiles=new ArrayList<File>();
  @Override public Element getModel(  AE_ModelId modelId) throws JDOMException, IOException {
    java.util.Set<java.util.Map.Entry<rulesEngine.manager.AE_ModelId,org.jdom2.Document>> genVar856;
    genVar856=models.entrySet();
    for (    Entry<AE_ModelId,Document> model : genVar856) {
      rulesEngine.manager.AE_ModelId genVar857;
      genVar857=model.getKey();
      boolean genVar858;
      genVar858=modelId.equals(genVar857);
      if (genVar858) {
        modelId=model.getKey();
        break;
      }
 else {
        ;
      }
    }
    boolean genVar859;
    genVar859=modelId.isContextManager();
    if (genVar859) {
      org.jdom2.Element genVar860;
      genVar860=cm.getAllUser();
      return genVar860;
    }
 else {
      ;
    }
    org.jdom2.Document genVar861;
    genVar861=models.get(modelId);
    org.jdom2.Element genVar862;
    genVar862=genVar861.getRootElement();
    return genVar862;
  }
  public String getAllModelsAsXMLString() throws JDOMException, IOException, ContextManagerParserException {
    String response;
    response="";
    java.util.Set<java.util.Map.Entry<rulesEngine.manager.AE_ModelId,org.jdom2.Document>> genVar863;
    genVar863=models.entrySet();
    for (    Entry<AE_ModelId,Document> entry : genVar863) {
      AdaptationEngineDeconected genVar864;
      genVar864=this;
      rulesEngine.manager.AE_ModelId genVar865;
      genVar865=entry.getKey();
      response+=genVar864.getModelAsXMLString(genVar865);
    }
    return response;
  }
  public static void main(  String[] args){
    try {
      java.lang.String genVar866;
      genVar866="C:\\Users\\mducass\\workspace\\bicycleshop\\WebContent\\w4serenoa\\rules\\w4rules.xml";
      java.lang.String genVar867;
      genVar867="http://urano.isti.cnr.it:8080/cm";
      java.lang.String genVar868;
      genVar868="userW4";
      AdaptationEngineDeconected ae;
      ae=new AdaptationEngineDeconected(genVar866,genVar867,genVar868);
      java.lang.String genVar869;
      genVar869=ae.getAllModelsAsXMLString();
      System.out.println(genVar869);
      java.lang.String genVar870;
      genVar870="<create>";
      java.lang.String genVar871;
      genVar871="<containingEntityReference xPath='//temp' externalModelId='temp'/>";
      java.lang.String genVar872;
      genVar872="<simpleType/>";
      java.lang.String genVar873;
      genVar873="<value>";
      java.lang.String genVar874;
      genVar874="<constant type='boolean' value='true'/>";
      java.lang.String genVar875;
      genVar875="</value>";
      java.lang.String genVar876;
      genVar876="</create> ";
      String action;
      action=genVar870 + genVar871 + genVar872+ genVar873+ genVar874+ genVar875+ genVar876;
      ae.updateModel(action);
      java.lang.String genVar877;
      genVar877=ae.getAllModelsAsXMLString();
      System.out.println(genVar877);
    }
 catch (    JDOMException e) {
      e.printStackTrace();
    }
catch (    IOException e) {
      e.printStackTrace();
    }
catch (    ruleModelParserException e) {
      e.printStackTrace();
    }
catch (    ContextManagerParserException e) {
      e.printStackTrace();
    }
  }
  @Override public void loadModels(  String user) throws JDOMException, IOException, URISyntaxException, ContextManagerParserException {
    java.lang.String genVar878;
    genVar878="//ext_model_ref";
    XPath xpa;
    xpa=new JDOMXPath(genVar878);
    models=new HashMap<AE_ModelId,Document>();
    CM_Parser cmp;
    cmp=new CM_Parser(user);
    String contentParsed;
    contentParsed=cmp.parse(rulesFile);
    byte[] genVar879;
    genVar879=contentParsed.getBytes();
    java.io.ByteArrayInputStream genVar880;
    genVar880=new ByteArrayInputStream(genVar879);
    Document rulesModel;
    rulesModel=sxb.build(genVar880);
    rulesRoot=rulesModel.getRootElement();
    java.util.List genVar881;
    genVar881=xpa.selectNodes(rulesRoot);
    List<Element> modelsList;
    modelsList=(List<Element>)genVar881;
    int modelUndefinedIndex;
    modelUndefinedIndex=0;
    for (    Element e : modelsList) {
      java.lang.String genVar882;
      genVar882="model_id";
      String modelId;
      modelId=e.getAttributeValue(genVar882);
      boolean genVar883;
      genVar883=modelId == null;
      int genVar884;
      genVar884=modelId.length();
      int genVar885;
      genVar885=0;
      boolean genVar886;
      genVar886=genVar884 == genVar885;
      boolean genVar887;
      genVar887=genVar883 || genVar886;
      if (genVar887) {
        modelId=undefinedModelPrefix + modelUndefinedIndex;
        modelUndefinedIndex++;
      }
 else {
        ;
      }
      java.lang.String genVar888;
      genVar888="URI";
      String uri;
      uri=e.getAttributeValue(genVar888);
      java.lang.String genVar889;
      genVar889="%";
      java.lang.String genVar890;
      genVar890="%";
      java.lang.String genVar891;
      genVar891=genVar889 + CM_Parser.tokens.CONTEXT_MANAGER + genVar890;
      boolean genVar892;
      genVar892=uri.contains(genVar891);
      if (genVar892) {
        boolean genVar893;
        genVar893=true;
        rulesEngine.manager.AE_ModelId genVar894;
        genVar894=new AE_ModelId(modelId,genVar893);
        models.put(genVar894,null);
        continue;
      }
 else {
        ;
      }
      File f;
      f=null;
      try {
        java.lang.String genVar895;
        genVar895=rulesFile.getParent();
        f=new File(genVar895,uri);
        boolean genVar896;
        genVar896=f.exists();
        boolean genVar897;
        genVar897=!genVar896;
        if (genVar897) {
          java.lang.Exception genVar898;
          genVar898=new Exception();
          throw genVar898;
        }
 else {
          ;
        }
      }
 catch (      Exception exp) {
        try {
          URL oracle;
          oracle=new URL(uri);
          java.net.URI genVar899;
          genVar899=oracle.toURI();
          f=new File(genVar899);
        }
 catch (        Exception exp2) {
          rulesEngine.manager.AdaptationEngineDeconected genVar900;
          genVar900=this;
          java.lang.Class genVar901;
          genVar901=genVar900.getClass();
          InputStream input;
          input=genVar901.getResourceAsStream(uri);
          java.lang.String genVar902;
          genVar902=rulesFile.getParent();
          java.lang.String genVar903;
          genVar903=input.toString();
          java.lang.String genVar904;
          genVar904=genVar902 + genVar903;
          f=new File(genVar904);
          OutputStream out;
          out=new FileOutputStream(f);
          int read;
          read=0;
          byte[] bytes;
          bytes=new byte[1024];
          int genVar905;
          genVar905=read=input.read(bytes);
          int genVar906;
          genVar906=(genVar905);
          int genVar907;
          genVar907=1;
          int genVar908;
          genVar908=-genVar907;
          boolean genVar909;
          genVar909=genVar906 != genVar908;
          while (genVar909) {
            int genVar910;
            genVar910=0;
            out.write(bytes,genVar910,read);
          }
          input.close();
          out.flush();
          out.close();
        }
      }
      try {
        relatedFiles.add(f);
        java.lang.String genVar911;
        genVar911="[INFO] FILE LISTENED =";
        java.lang.String genVar912;
        genVar912=f.getAbsolutePath();
        java.lang.String genVar913;
        genVar913=genVar911 + genVar912;
        System.out.println(genVar913);
      }
 catch (      IllegalArgumentException iae) {
        java.lang.String genVar914;
        genVar914="[WARNING]: ";
        java.lang.String genVar915;
        genVar915=" is not 'file', therefore this resource will not be listened";
        java.lang.String genVar916;
        genVar916=genVar914 + uri + genVar915;
        System.out.println(genVar916);
      }
      Document model;
      model=sxb.build(f);
      rulesEngine.manager.AE_ModelId genVar917;
      genVar917=new AE_ModelId(modelId);
      models.put(genVar917,model);
    }
  }
  public AdaptationEngineDeconected(){
  }
  public AdaptationEngineDeconected(  String rulePath,  String context_manager_uri,  String currentUser) throws JDOMException, IOException {
    this(rulePath,context_manager_uri,true,currentUser);
  }
  public AdaptationEngineDeconected(  String rulePath,  String context_manager_uri,  boolean loadModels,  String currentUser) throws JDOMException, IOException {
    this(rulePath,context_manager_uri,loadModels,true,currentUser);
  }
  public AdaptationEngineDeconected(  String rulePath,  String context_manager_uri,  boolean loadModels,  boolean executeRules,  String currentUser) throws JDOMException, IOException {
    models=new HashMap<AE_ModelId,Document>();
    try {
      rulesFile=new File(rulePath);
      AdaptationEngineDeconected genVar920;
      genVar920=this;
      genVar920.init(context_manager_uri,loadModels,executeRules,currentUser);
    }
 catch (    Exception e) {
      e.printStackTrace();
    }
  }
  public List<File> getRelatedFiles(){
    return relatedFiles;
  }
  @Override public void launchListeners(  String rulesPath,  FileListener listener){
    int genVar921;
    genVar921=1000;
    FileMonitor monitor;
    monitor=new FileMonitor(genVar921);
    File f;
    f=new File(rulesPath);
    monitor.addFile(f);
    java.lang.String genVar922;
    genVar922="[INFO] FILE LISTENED =";
    java.lang.String genVar923;
    genVar923=f.getAbsolutePath();
    java.lang.String genVar924;
    genVar924=genVar922 + genVar923;
    System.out.println(genVar924);
    AdaptationEngineDeconected genVar925;
    genVar925=this;
    java.util.List<java.io.File> genVar926;
    genVar926=genVar925.getRelatedFiles();
    for (    File file : genVar926) {
      monitor.addFile(file);
    }
    monitor.addListener(listener);
  }
}
