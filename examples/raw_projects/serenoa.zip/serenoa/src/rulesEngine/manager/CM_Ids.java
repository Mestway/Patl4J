package rulesEngine.manager;
public class CM_Ids {
  public CM_Ids(  String string,  String string2){
  }
  public Object getIdUser(){
    return null;
  }
  public String getIdPreferences(){
    return null;
  }
}
