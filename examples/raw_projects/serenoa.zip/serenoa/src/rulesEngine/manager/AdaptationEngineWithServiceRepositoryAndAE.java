package rulesEngine.manager;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.xpath.jaxen.JDOMXPath;
import org.jdom2.xpath.XPath;
import rulesEngine.utils.Logger;
public class AdaptationEngineWithServiceRepositoryAndAE extends AdaptationEngineWithServiceRepository {
  AdaptationEngineSerenoa ae;
  public AdaptationEngineWithServiceRepositoryAndAE(  String rulePath,  String context_manager_uri,  String service_repository_uri,  boolean loadModels,  boolean executeRules,  String currentUser,  String adaptation_engine_uri) throws JDOMException, IOException, ContextManagerParserException {
    super(rulePath,context_manager_uri,service_repository_uri,loadModels,executeRules,currentUser);
    java.lang.String genVar612;
    genVar612="new adaptation engine";
    Logger.log(genVar612);
    AdaptationEngineWithServiceRepositoryAndAE genVar613;
    genVar613=this;
    rulesEngine.manager.ServiceRepository genVar614;
    genVar614=genVar613.getSR(currentUser);
    java.lang.String genVar615;
    genVar615=genVar614.applicationId;
    ae=new AdaptationEngineSerenoa(adaptation_engine_uri,genVar615);
    java.lang.String genVar616;
    genVar616="ae loaded";
    Logger.log(genVar616);
    boolean genVar617;
    genVar617=cm.isDeconectedMode();
    if (genVar617) {
      boolean genVar618;
      genVar618=true;
      ae.setDeconectedMode(genVar618);
    }
 else {
      ;
    }
  }
  @Override public boolean isDeconnected() throws JDOMException, IOException, ContextManagerParserException {
    boolean genVar619;
    genVar619=super.isDeconnected();
    boolean genVar620;
    genVar620=ae.isDeconectedMode();
    boolean genVar621;
    genVar621=genVar619 || genVar620;
    return genVar621;
  }
  @Override protected List<Element> getActions() throws JDOMException, ruleModelParserException, IOException {
    String response;
    response=ae.handleActions(currentUser);
    org.jdom2.input.SAXBuilder genVar622;
    genVar622=new SAXBuilder();
    byte[] genVar623;
    genVar623=response.getBytes();
    java.io.ByteArrayInputStream genVar624;
    genVar624=new ByteArrayInputStream(genVar623);
    Document actionDocument;
    actionDocument=genVar622.build(genVar624);
    java.lang.String genVar625;
    genVar625="//action";
    XPath xpa;
    xpa=new JDOMXPath(genVar625);
    org.jdom2.Element genVar626;
    genVar626=actionDocument.getRootElement();
    java.util.List genVar627;
    genVar627=xpa.selectNodes(genVar626);
    java.util.List<org.jdom2.Element> genVar628;
    genVar628=(List<Element>)genVar627;
    return genVar628;
  }
}
