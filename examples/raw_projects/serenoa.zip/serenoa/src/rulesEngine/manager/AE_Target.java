package rulesEngine.manager;
import java.util.List;
import org.jdom2.Document;
public class AE_Target {
  public AE_Target(  String modelId,  Document model,  Object object){
  }
  public List<?> getTargets(){
    return null;
  }
  public AE_ModelId getModelId(){
    return null;
  }
  public Document getModel(){
    return null;
  }
}
