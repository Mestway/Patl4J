package rulesEngine.manager;
import java.io.File;
public class CM_Parser {
  public enum tokens {  CONTEXT_MANAGER,   CURRENT_USER}
  public CM_Parser(  String user){
  }
  public String parse(  File rulesFile){
    return null;
  }
}
