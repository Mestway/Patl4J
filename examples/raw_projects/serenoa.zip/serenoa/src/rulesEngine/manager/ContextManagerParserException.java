package rulesEngine.manager;
public class ContextManagerParserException extends Exception {
}
