package rulesEngine.manager;
public class AdaptationEngineSerenoa {
  public AdaptationEngineSerenoa(  String adaptation_engine_uri,  String applicationId){
  }
  public void setDeconectedMode(  boolean b){
  }
  public boolean isDeconectedMode(){
    boolean genVar629;
    genVar629=false;
    return genVar629;
  }
  public String handleActions(  String currentUser){
    return null;
  }
}
