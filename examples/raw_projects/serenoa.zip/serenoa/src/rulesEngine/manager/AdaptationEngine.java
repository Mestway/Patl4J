package rulesEngine.manager;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import org.jdom2.Attribute;
import org.jdom2.Content;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
import org.jdom2.xpath.XPath;
import org.jdom2.xpath.jaxen.JDOMXPath;
import rulesEngine.listener.FileListener;
import rulesEngine.utils.Logger;
public abstract class AdaptationEngine {
  protected static final String undefinedModelPrefix="undefined ";
  protected ContextManager cm;
  protected File rulesFile;
  private enum ConditionType {  STRING,   BOOLEAN,   NUMBER}
  protected Element rulesRoot;
  public abstract Element getModel(  AE_ModelId modelId) throws JDOMException, IOException, ContextManagerParserException ;
  public abstract void loadModels(  String user) throws JDOMException, IOException, URISyntaxException, ContextManagerParserException ;
  public abstract void launchListeners(  String rulesPath,  FileListener listener);
  protected void init(  String context_manager_uri,  boolean loadModels,  boolean executeRules,  String currentUser) throws JDOMException, IOException {
    cm=new ContextManager(context_manager_uri);
    try {
      if (loadModels) {
        AdaptationEngine genVar167;
        genVar167=this;
        genVar167.loadModels(currentUser);
      }
 else {
        ;
      }
      if (executeRules) {
        AdaptationEngine genVar168;
        genVar168=this;
        genVar168.executeRules();
      }
 else {
        ;
      }
      java.lang.String genVar169;
      genVar169="models loaded and rules executed";
      Logger.log(genVar169);
    }
 catch (    Exception e) {
      e.printStackTrace();
      java.lang.String genVar170;
      genVar170="problem while loading the model or when executing rules";
      Logger.log(genVar170);
    }
  }
  private String getModelId(  Element elt){
    java.lang.String genVar171;
    genVar171="externalModelId";
    String model;
    model=elt.getAttributeValue(genVar171);
    boolean genVar172;
    genVar172=model == null;
    int genVar173;
    genVar173=model.length();
    int genVar174;
    genVar174=0;
    boolean genVar175;
    genVar175=genVar173 == genVar174;
    boolean genVar176;
    genVar176=genVar172 || genVar175;
    if (genVar176) {
      java.lang.String genVar177;
      genVar177="0";
      model=undefinedModelPrefix + genVar177;
    }
 else {
      ;
    }
    return model;
  }
  private boolean testCondition(  Element conditionElt) throws ruleModelParserException, JDOMException, IOException, ContextManagerParserException {
    XPath xpa;
    List<String> conditionsList;
    conditionsList=new ArrayList<String>();
    List<Element> conditionExpressions;
    conditionExpressions=conditionElt.getChildren();
    String type;
    type="";
    for (    Element conditionExpression : conditionExpressions) {
      java.lang.String genVar178;
      genVar178=conditionExpression.getName();
      java.lang.String genVar179;
      genVar179="constant";
      boolean genVar180;
      genVar180=genVar178.equals(genVar179);
      if (genVar180) {
        java.lang.String genVar181;
        genVar181="type";
        String typeTemp;
        typeTemp=conditionExpression.getAttributeValue(genVar181);
        boolean genVar182;
        genVar182=typeTemp != null;
        int genVar183;
        genVar183=typeTemp.length();
        int genVar184;
        genVar184=0;
        boolean genVar185;
        genVar185=genVar183 > genVar184;
        boolean genVar186;
        genVar186=genVar182 && genVar185;
        if (genVar186) {
          int genVar187;
          genVar187=type.length();
          int genVar188;
          genVar188=0;
          boolean genVar189;
          genVar189=genVar187 > genVar188;
          boolean genVar190;
          genVar190=typeTemp.equals(type);
          boolean genVar191;
          genVar191=!genVar190;
          boolean genVar192;
          genVar192=genVar189 && genVar191;
          if (genVar192) {
            java.lang.String genVar193;
            genVar193="Incompatibles condition types";
            rulesEngine.manager.ruleModelParserException genVar194;
            genVar194=new ruleModelParserException(genVar193);
            throw genVar194;
          }
 else {
            type=typeTemp;
          }
        }
 else {
          ;
        }
        java.lang.String genVar195;
        genVar195="value";
        java.lang.String genVar196;
        genVar196=conditionExpression.getAttributeValue(genVar195);
        conditionsList.add(genVar196);
      }
 else {
        java.lang.String genVar197;
        genVar197=conditionExpression.getName();
        java.lang.String genVar198;
        genVar198="entityReference";
        boolean genVar199;
        genVar199=genVar197.equals(genVar198);
        if (genVar199) {
          AdaptationEngine genVar200;
          genVar200=this;
          String modelId;
          modelId=genVar200.getModelId(conditionExpression);
          java.lang.String genVar201;
          genVar201="xPath";
          String xpath;
          xpath=conditionExpression.getAttributeValue(genVar201);
          xpa=new JDOMXPath(xpath);
          AdaptationEngine genVar202;
          genVar202=this;
          rulesEngine.manager.AE_ModelId genVar203;
          genVar203=new AE_ModelId(modelId);
          Element model;
          model=genVar202.getModel(genVar203);
          java.lang.String genVar204;
          genVar204=xpa.valueOf(model);
          conditionsList.add(genVar204);
        }
 else {
          java.lang.String genVar205;
          genVar205=conditionExpression.getName();
          java.lang.String genVar206;
          genVar206="condition";
          boolean genVar207;
          genVar207=genVar205.equals(genVar206);
          if (genVar207) {
            type="boolean";
            java.lang.String genVar208;
            genVar208="";
            AdaptationEngine genVar209;
            genVar209=this;
            boolean genVar210;
            genVar210=genVar209.testCondition(conditionExpression);
            java.lang.String genVar211;
            genVar211=genVar208 + genVar210;
            conditionsList.add(genVar211);
          }
 else {
            java.lang.String genVar212;
            genVar212=conditionExpression.getName();
            java.lang.String genVar213;
            genVar213=" tag isn't supported yet in conditions";
            java.lang.String genVar214;
            genVar214=genVar212 + genVar213;
            rulesEngine.manager.ruleModelParserException genVar215;
            genVar215=new ruleModelParserException(genVar214);
            throw genVar215;
          }
        }
      }
    }
    ConditionType conditionType;
    int genVar216;
    genVar216=type.length();
    int genVar217;
    genVar217=0;
    boolean genVar218;
    genVar218=genVar216 == genVar217;
    if (genVar218) {
      type="string";
    }
 else {
      ;
    }
    ArrayList<Boolean> booleanConditions;
    booleanConditions=new ArrayList<Boolean>();
    ArrayList<Double> NumberConditions;
    NumberConditions=new ArrayList<Double>();
    java.lang.String genVar219;
    genVar219="boolean";
    boolean genVar220;
    genVar220=type.equals(genVar219);
    if (genVar220) {
      conditionType=ConditionType.BOOLEAN;
      for (      String s : conditionsList) {
        boolean genVar221;
        genVar221=Boolean.parseBoolean(s);
        booleanConditions.add(genVar221);
      }
    }
 else {
      java.lang.String genVar222;
      genVar222="string";
      boolean genVar223;
      genVar223=type.equals(genVar222);
      java.lang.String genVar224;
      genVar224="normalizedString";
      boolean genVar225;
      genVar225=type.equals(genVar224);
      boolean genVar226;
      genVar226=genVar223 || genVar225;
      if (genVar226) {
        conditionType=ConditionType.STRING;
      }
 else {
        java.lang.String genVar227;
        genVar227="float";
        boolean genVar228;
        genVar228=type.equals(genVar227);
        java.lang.String genVar229;
        genVar229="int";
        boolean genVar230;
        genVar230=type.equals(genVar229);
        java.lang.String genVar231;
        genVar231="integer";
        boolean genVar232;
        genVar232=type.equals(genVar231);
        java.lang.String genVar233;
        genVar233="decimal";
        boolean genVar234;
        genVar234=type.equals(genVar233);
        java.lang.String genVar235;
        genVar235="negativeInteger";
        boolean genVar236;
        genVar236=type.equals(genVar235);
        java.lang.String genVar237;
        genVar237="nonPositiveInteger";
        boolean genVar238;
        genVar238=type.equals(genVar237);
        java.lang.String genVar239;
        genVar239="long";
        boolean genVar240;
        genVar240=type.equals(genVar239);
        java.lang.String genVar241;
        genVar241="positiveInteger";
        boolean genVar242;
        genVar242=type.equals(genVar241);
        java.lang.String genVar243;
        genVar243="short";
        boolean genVar244;
        genVar244=type.equals(genVar243);
        java.lang.String genVar245;
        genVar245="unsignedInt";
        boolean genVar246;
        genVar246=type.equals(genVar245);
        java.lang.String genVar247;
        genVar247="unsignedLong";
        boolean genVar248;
        genVar248=type.equals(genVar247);
        java.lang.String genVar249;
        genVar249="unsignedShort";
        boolean genVar250;
        genVar250=type.equals(genVar249);
        boolean genVar251;
        genVar251=genVar228 || genVar230 || genVar232|| genVar234|| genVar236|| genVar238|| genVar240|| genVar242|| genVar244|| genVar246|| genVar248|| genVar250;
        if (genVar251) {
          conditionType=ConditionType.NUMBER;
          for (          String s : conditionsList) {
            double genVar252;
            genVar252=Double.parseDouble(s);
            NumberConditions.add(genVar252);
          }
        }
 else {
          java.lang.String genVar253;
          genVar253="Type '";
          java.lang.String genVar254;
          genVar254="' isn't supproted yet";
          java.lang.String genVar255;
          genVar255=genVar253 + type + genVar254;
          rulesEngine.manager.ruleModelParserException genVar256;
          genVar256=new ruleModelParserException(genVar255);
          throw genVar256;
        }
      }
    }
    java.lang.String genVar257;
    genVar257="operator";
    String operator;
    operator=conditionElt.getAttributeValue(genVar257);
    java.lang.String genVar258;
    genVar258="Operator '";
    java.lang.String genVar259;
    genVar259="' isn't compatible with type '";
    java.lang.String genVar260;
    genVar260="'";
    String incompatibleOperatorMessage;
    incompatibleOperatorMessage=genVar258 + operator + genVar259+ type+ genVar260;
    boolean genVar261;
    genVar261=operator == null;
    if (genVar261) {
      int genVar262;
      genVar262=conditionsList.size();
      int genVar263;
      genVar263=1;
      boolean genVar264;
      genVar264=genVar262 == genVar263;
      if (genVar264) {
        try {
          AdaptationEngine genVar265;
          genVar265=this;
          java.util.List<org.jdom2.Element> genVar266;
          genVar266=conditionElt.getChildren();
          int genVar267;
          genVar267=0;
          org.jdom2.Element genVar268;
          genVar268=genVar266.get(genVar267);
          java.lang.String genVar269;
          genVar269=genVar265.readConstantOrEntity(genVar268);
          java.lang.Boolean genVar270;
          genVar270=new Boolean(genVar269);
          return genVar270;
        }
 catch (        Exception e) {
          java.lang.String genVar271;
          genVar271="Content of a condition without operator must be a boolean";
          rulesEngine.manager.ruleModelParserException genVar272;
          genVar272=new ruleModelParserException(genVar271);
          throw genVar272;
        }
      }
 else {
        ;
      }
      java.lang.String genVar273;
      genVar273="Condition without operator must have a size of 1";
      rulesEngine.manager.ruleModelParserException genVar274;
      genVar274=new ruleModelParserException(genVar273);
      throw genVar274;
    }
 else {
      ;
    }
    int genVar275;
    genVar275=conditionsList.size();
    int genVar276;
    genVar276=1;
    boolean genVar277;
    genVar277=genVar275 > genVar276;
    java.lang.String genVar278;
    genVar278="not";
    boolean genVar279;
    genVar279=operator.equals(genVar278);
    boolean genVar280;
    genVar280=genVar277 && genVar279;
    boolean genVar281;
    genVar281=(genVar280);
    int genVar282;
    genVar282=conditionsList.size();
    int genVar283;
    genVar283=2;
    boolean genVar284;
    genVar284=genVar282 < genVar283;
    java.lang.String genVar285;
    genVar285="not";
    boolean genVar286;
    genVar286=operator.equals(genVar285);
    boolean genVar287;
    genVar287=!genVar286;
    boolean genVar288;
    genVar288=genVar284 && genVar287;
    boolean genVar289;
    genVar289=(genVar288);
    boolean genVar290;
    genVar290=genVar281 || genVar289;
    if (genVar290) {
      java.lang.String genVar291;
      genVar291="Condition with operator '";
      java.lang.String genVar292;
      genVar292="' hasn't the appropriate number of arguments";
      java.lang.String genVar293;
      genVar293=genVar291 + operator + genVar292;
      rulesEngine.manager.ruleModelParserException genVar294;
      genVar294=new ruleModelParserException(genVar293);
      throw genVar294;
    }
 else {
      ;
    }
    boolean conditionOK;
    conditionOK=true;
    java.lang.String genVar295;
    genVar295="and";
    boolean genVar296;
    genVar296=operator.equals(genVar295);
    if (genVar296) {
      java.lang.String genVar297;
      genVar297=conditionType.name();
      java.lang.String genVar298;
      genVar298=ConditionType.BOOLEAN.name();
      boolean genVar299;
      genVar299=genVar297.equals(genVar298);
      boolean genVar300;
      genVar300=!genVar299;
      if (genVar300) {
        rulesEngine.manager.ruleModelParserException genVar301;
        genVar301=new ruleModelParserException(incompatibleOperatorMessage);
        throw genVar301;
      }
 else {
        ;
      }
      for (      Boolean b : booleanConditions) {
        conditionOK=conditionOK && b;
      }
    }
 else {
      java.lang.String genVar302;
      genVar302="or";
      boolean genVar303;
      genVar303=operator.equals(genVar302);
      if (genVar303) {
        java.lang.String genVar304;
        genVar304=conditionType.name();
        java.lang.String genVar305;
        genVar305=ConditionType.BOOLEAN.name();
        boolean genVar306;
        genVar306=genVar304.equals(genVar305);
        boolean genVar307;
        genVar307=!genVar306;
        if (genVar307) {
          rulesEngine.manager.ruleModelParserException genVar308;
          genVar308=new ruleModelParserException(incompatibleOperatorMessage);
          throw genVar308;
        }
 else {
          ;
        }
        conditionOK=false;
        for (        Boolean b : booleanConditions) {
          conditionOK=conditionOK || b;
        }
      }
 else {
        java.lang.String genVar309;
        genVar309="xor";
        boolean genVar310;
        genVar310=operator.equals(genVar309);
        if (genVar310) {
          java.lang.String genVar311;
          genVar311=conditionType.name();
          java.lang.String genVar312;
          genVar312=ConditionType.BOOLEAN.name();
          boolean genVar313;
          genVar313=genVar311.equals(genVar312);
          boolean genVar314;
          genVar314=!genVar313;
          if (genVar314) {
            rulesEngine.manager.ruleModelParserException genVar315;
            genVar315=new ruleModelParserException(incompatibleOperatorMessage);
            throw genVar315;
          }
 else {
            ;
          }
          int genVar316;
          genVar316=0;
          conditionOK=booleanConditions.get(genVar316);
          int i=1;
          for (; i < booleanConditions.size(); i++) {
            java.lang.Boolean genVar317;
            genVar317=booleanConditions.get(i);
            conditionOK=conditionOK ^ genVar317;
          }
        }
 else {
          java.lang.String genVar318;
          genVar318="contains";
          boolean genVar319;
          genVar319=operator.equals(genVar318);
          if (genVar319) {
            java.lang.String genVar320;
            genVar320=conditionType.name();
            java.lang.String genVar321;
            genVar321=ConditionType.BOOLEAN.name();
            boolean genVar322;
            genVar322=genVar320.equals(genVar321);
            if (genVar322) {
              rulesEngine.manager.ruleModelParserException genVar323;
              genVar323=new ruleModelParserException(incompatibleOperatorMessage);
              throw genVar323;
            }
 else {
              ;
            }
            int genVar324;
            genVar324=0;
            String reference;
            reference=conditionsList.get(genVar324);
            int i=1;
            for (; i < conditionsList.size(); i++) {
              java.lang.String genVar325;
              genVar325=conditionsList.get(i);
              boolean genVar326;
              genVar326=genVar325.contains(reference);
              conditionOK=conditionOK && genVar326;
            }
          }
 else {
            java.lang.String genVar327;
            genVar327="starts";
            boolean genVar328;
            genVar328=operator.equals(genVar327);
            if (genVar328) {
              java.lang.String genVar329;
              genVar329=conditionType.name();
              java.lang.String genVar330;
              genVar330=ConditionType.BOOLEAN.name();
              boolean genVar331;
              genVar331=genVar329.equals(genVar330);
              if (genVar331) {
                rulesEngine.manager.ruleModelParserException genVar332;
                genVar332=new ruleModelParserException(incompatibleOperatorMessage);
                throw genVar332;
              }
 else {
                ;
              }
              int genVar333;
              genVar333=0;
              String reference;
              reference=conditionsList.get(genVar333);
              int i=1;
              for (; i < conditionsList.size(); i++) {
                java.lang.String genVar334;
                genVar334=conditionsList.get(i);
                boolean genVar335;
                genVar335=genVar334.startsWith(reference);
                conditionOK=conditionOK && genVar335;
              }
            }
 else {
              java.lang.String genVar336;
              genVar336="ends";
              boolean genVar337;
              genVar337=operator.equals(genVar336);
              if (genVar337) {
                java.lang.String genVar338;
                genVar338=conditionType.name();
                java.lang.String genVar339;
                genVar339=ConditionType.BOOLEAN.name();
                boolean genVar340;
                genVar340=genVar338.equals(genVar339);
                if (genVar340) {
                  rulesEngine.manager.ruleModelParserException genVar341;
                  genVar341=new ruleModelParserException(incompatibleOperatorMessage);
                  throw genVar341;
                }
 else {
                  ;
                }
                int genVar342;
                genVar342=0;
                String reference;
                reference=conditionsList.get(genVar342);
                int i=1;
                for (; i < conditionsList.size(); i++) {
                  java.lang.String genVar343;
                  genVar343=conditionsList.get(i);
                  boolean genVar344;
                  genVar344=genVar343.endsWith(reference);
                  conditionOK=conditionOK && genVar344;
                }
              }
 else {
                java.lang.String genVar345;
                genVar345="gt";
                boolean genVar346;
                genVar346=operator.equals(genVar345);
                if (genVar346) {
                  java.lang.String genVar347;
                  genVar347=conditionType.name();
                  java.lang.String genVar348;
                  genVar348=ConditionType.BOOLEAN.name();
                  boolean genVar349;
                  genVar349=genVar347.equals(genVar348);
                  if (genVar349) {
                    rulesEngine.manager.ruleModelParserException genVar350;
                    genVar350=new ruleModelParserException(incompatibleOperatorMessage);
                    throw genVar350;
                  }
 else {
                    ;
                  }
                  java.lang.String genVar351;
                  genVar351=conditionType.name();
                  java.lang.String genVar352;
                  genVar352=ConditionType.STRING.name();
                  boolean genVar353;
                  genVar353=genVar351.equals(genVar352);
                  if (genVar353) {
                    int genVar354;
                    genVar354=0;
                    String reference;
                    reference=conditionsList.get(genVar354);
                    int i=1;
                    for (; i < conditionsList.size(); i++) {
                      java.lang.String genVar355;
                      genVar355=conditionsList.get(i);
                      int genVar356;
                      genVar356=genVar355.compareTo(reference);
                      int genVar357;
                      genVar357=0;
                      boolean genVar358;
                      genVar358=genVar356 > genVar357;
                      conditionOK=conditionOK && genVar358;
                    }
                  }
 else {
                    int genVar359;
                    genVar359=0;
                    Double reference;
                    reference=NumberConditions.get(genVar359);
                    int i=1;
                    for (; i < NumberConditions.size(); i++) {
                      java.lang.Double genVar360;
                      genVar360=NumberConditions.get(i);
                      boolean genVar361;
                      genVar361=genVar360 > reference;
                      conditionOK=conditionOK && genVar361;
                    }
                  }
                }
 else {
                  java.lang.String genVar362;
                  genVar362="lt";
                  boolean genVar363;
                  genVar363=operator.equals(genVar362);
                  if (genVar363) {
                    java.lang.String genVar364;
                    genVar364=conditionType.name();
                    java.lang.String genVar365;
                    genVar365=ConditionType.BOOLEAN.name();
                    boolean genVar366;
                    genVar366=genVar364.equals(genVar365);
                    if (genVar366) {
                      rulesEngine.manager.ruleModelParserException genVar367;
                      genVar367=new ruleModelParserException(incompatibleOperatorMessage);
                      throw genVar367;
                    }
 else {
                      ;
                    }
                    java.lang.String genVar368;
                    genVar368=conditionType.name();
                    java.lang.String genVar369;
                    genVar369=ConditionType.STRING.name();
                    boolean genVar370;
                    genVar370=genVar368.equals(genVar369);
                    if (genVar370) {
                      int genVar371;
                      genVar371=0;
                      String reference;
                      reference=conditionsList.get(genVar371);
                      int i=1;
                      for (; i < conditionsList.size(); i++) {
                        java.lang.String genVar372;
                        genVar372=conditionsList.get(i);
                        int genVar373;
                        genVar373=genVar372.compareTo(reference);
                        int genVar374;
                        genVar374=0;
                        boolean genVar375;
                        genVar375=genVar373 < genVar374;
                        conditionOK=conditionOK && genVar375;
                      }
                    }
 else {
                      int genVar376;
                      genVar376=0;
                      Double reference;
                      reference=NumberConditions.get(genVar376);
                      int i=1;
                      for (; i < NumberConditions.size(); i++) {
                        java.lang.Double genVar377;
                        genVar377=NumberConditions.get(i);
                        boolean genVar378;
                        genVar378=genVar377 < reference;
                        conditionOK=conditionOK && genVar378;
                      }
                    }
                  }
 else {
                    java.lang.String genVar379;
                    genVar379="gteq";
                    boolean genVar380;
                    genVar380=operator.equals(genVar379);
                    if (genVar380) {
                      java.lang.String genVar381;
                      genVar381=conditionType.name();
                      java.lang.String genVar382;
                      genVar382=ConditionType.BOOLEAN.name();
                      boolean genVar383;
                      genVar383=genVar381.equals(genVar382);
                      if (genVar383) {
                        rulesEngine.manager.ruleModelParserException genVar384;
                        genVar384=new ruleModelParserException(incompatibleOperatorMessage);
                        throw genVar384;
                      }
 else {
                        ;
                      }
                      java.lang.String genVar385;
                      genVar385=conditionType.name();
                      java.lang.String genVar386;
                      genVar386=ConditionType.STRING.name();
                      boolean genVar387;
                      genVar387=genVar385.equals(genVar386);
                      if (genVar387) {
                        int genVar388;
                        genVar388=0;
                        String reference;
                        reference=conditionsList.get(genVar388);
                        int i=1;
                        for (; i < conditionsList.size(); i++) {
                          java.lang.String genVar389;
                          genVar389=conditionsList.get(i);
                          int genVar390;
                          genVar390=genVar389.compareTo(reference);
                          int genVar391;
                          genVar391=0;
                          boolean genVar392;
                          genVar392=genVar390 >= genVar391;
                          conditionOK=conditionOK && genVar392;
                        }
                      }
 else {
                        int genVar393;
                        genVar393=0;
                        Double reference;
                        reference=NumberConditions.get(genVar393);
                        int i=1;
                        for (; i < NumberConditions.size(); i++) {
                          java.lang.Double genVar394;
                          genVar394=NumberConditions.get(i);
                          boolean genVar395;
                          genVar395=genVar394 >= reference;
                          conditionOK=conditionOK && genVar395;
                        }
                      }
                    }
 else {
                      java.lang.String genVar396;
                      genVar396="lteq";
                      boolean genVar397;
                      genVar397=operator.equals(genVar396);
                      if (genVar397) {
                        java.lang.String genVar398;
                        genVar398=conditionType.name();
                        java.lang.String genVar399;
                        genVar399=ConditionType.BOOLEAN.name();
                        boolean genVar400;
                        genVar400=genVar398.equals(genVar399);
                        if (genVar400) {
                          rulesEngine.manager.ruleModelParserException genVar401;
                          genVar401=new ruleModelParserException(incompatibleOperatorMessage);
                          throw genVar401;
                        }
 else {
                          ;
                        }
                        java.lang.String genVar402;
                        genVar402=conditionType.name();
                        java.lang.String genVar403;
                        genVar403=ConditionType.STRING.name();
                        boolean genVar404;
                        genVar404=genVar402.equals(genVar403);
                        if (genVar404) {
                          int genVar405;
                          genVar405=0;
                          String reference;
                          reference=conditionsList.get(genVar405);
                          int i=1;
                          for (; i < conditionsList.size(); i++) {
                            java.lang.String genVar406;
                            genVar406=conditionsList.get(i);
                            int genVar407;
                            genVar407=genVar406.compareTo(reference);
                            int genVar408;
                            genVar408=0;
                            boolean genVar409;
                            genVar409=genVar407 <= genVar408;
                            conditionOK=conditionOK && genVar409;
                          }
                        }
 else {
                          int genVar410;
                          genVar410=0;
                          Double reference;
                          reference=NumberConditions.get(genVar410);
                          int i=1;
                          for (; i < NumberConditions.size(); i++) {
                            java.lang.Double genVar411;
                            genVar411=NumberConditions.get(i);
                            boolean genVar412;
                            genVar412=genVar411 <= reference;
                            conditionOK=conditionOK && genVar412;
                          }
                        }
                      }
 else {
                        java.lang.String genVar413;
                        genVar413="eq";
                        boolean genVar414;
                        genVar414=operator.equals(genVar413);
                        if (genVar414) {
                          int genVar415;
                          genVar415=0;
                          String reference;
                          reference=conditionsList.get(genVar415);
                          int i=1;
                          for (; i < conditionsList.size(); i++) {
                            java.lang.String genVar416;
                            genVar416=conditionsList.get(i);
                            boolean genVar417;
                            genVar417=genVar416.equals(reference);
                            conditionOK=conditionOK && genVar417;
                          }
                        }
 else {
                          java.lang.String genVar418;
                          genVar418="neq";
                          boolean genVar419;
                          genVar419=operator.equals(genVar418);
                          if (genVar419) {
                            int i=0;
                            for (; i < conditionsList.size(); i++) {
                              String reference;
                              reference=conditionsList.get(i);
                              int j=0;
                              for (; j < conditionsList.size(); j++) {
                                boolean genVar420;
                                genVar420=i != j;
                                if (genVar420) {
                                  java.lang.String genVar421;
                                  genVar421=conditionsList.get(j);
                                  boolean genVar422;
                                  genVar422=genVar421.equals(reference);
                                  boolean genVar423;
                                  genVar423=(genVar422);
                                  boolean genVar424;
                                  genVar424=!genVar423;
                                  conditionOK=conditionOK && genVar424;
                                }
 else {
                                  ;
                                }
                              }
                            }
                          }
 else {
                            java.lang.String genVar425;
                            genVar425="not";
                            boolean genVar426;
                            genVar426=operator.equals(genVar425);
                            if (genVar426) {
                              java.lang.String genVar427;
                              genVar427=conditionType.name();
                              java.lang.String genVar428;
                              genVar428=ConditionType.BOOLEAN.name();
                              boolean genVar429;
                              genVar429=genVar427.equals(genVar428);
                              boolean genVar430;
                              genVar430=!genVar429;
                              if (genVar430) {
                                rulesEngine.manager.ruleModelParserException genVar431;
                                genVar431=new ruleModelParserException(incompatibleOperatorMessage);
                                throw genVar431;
                              }
 else {
                                ;
                              }
                              int genVar432;
                              genVar432=0;
                              java.lang.Boolean genVar433;
                              genVar433=booleanConditions.get(genVar432);
                              conditionOK=!genVar433;
                            }
 else {
                              ;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    return conditionOK;
  }
  private String readConstantOrEntity(  Element element) throws JDOMException, ruleModelParserException, IOException, ContextManagerParserException {
    String response;
    java.lang.String genVar434;
    genVar434=element.getName();
    java.lang.String genVar435;
    genVar435="constant";
    boolean genVar436;
    genVar436=genVar434.equals(genVar435);
    if (genVar436) {
      java.lang.String genVar437;
      genVar437="value";
      response=element.getAttributeValue(genVar437);
    }
 else {
      java.lang.String genVar438;
      genVar438=element.getName();
      java.lang.String genVar439;
      genVar439="entityReference";
      boolean genVar440;
      genVar440=genVar438.equals(genVar439);
      if (genVar440) {
        AdaptationEngine genVar441;
        genVar441=this;
        String modelId;
        modelId=genVar441.getModelId(element);
        java.lang.String genVar442;
        genVar442="xPath";
        String xpath;
        xpath=element.getAttributeValue(genVar442);
        XPath xpa;
        xpa=new JDOMXPath(xpath);
        AdaptationEngine genVar443;
        genVar443=this;
        rulesEngine.manager.AE_ModelId genVar444;
        genVar444=new AE_ModelId(modelId);
        org.jdom2.Element genVar445;
        genVar445=genVar443.getModel(genVar444);
        response=xpa.valueOf(genVar445);
      }
 else {
        java.lang.String genVar446;
        genVar446=element.getName();
        java.lang.String genVar447;
        genVar447=" tag isn't supported yet in conditions";
        java.lang.String genVar448;
        genVar448=genVar446 + genVar447;
        rulesEngine.manager.ruleModelParserException genVar449;
        genVar449=new ruleModelParserException(genVar448);
        throw genVar449;
      }
    }
    return response;
  }
  private void executeAction(  Element action) throws JDOMException, ruleModelParserException, IOException, ContextManagerParserException {
    AE_Target modelToUpdate;
    modelToUpdate=null;
    List<Element> actionExpressions;
    actionExpressions=action.getChildren();
    for (    Element actionExpression : actionExpressions) {
      java.lang.String genVar450;
      genVar450=actionExpression.getName();
      java.lang.String genVar451;
      genVar451="create";
      boolean genVar452;
      genVar452=genVar450.equals(genVar451);
      if (genVar452) {
        AdaptationEngine genVar453;
        genVar453=this;
        java.lang.String genVar454;
        genVar454="containingEntityReference";
        modelToUpdate=genVar453.getTargets(actionExpression,genVar454);
        List<?> actionTargets;
        actionTargets=modelToUpdate.getTargets();
        java.lang.String genVar455;
        genVar455="complexType";
        Element complexType;
        complexType=actionExpression.getChild(genVar455);
        boolean genVar456;
        genVar456=complexType == null;
        if (genVar456) {
          java.lang.String genVar457;
          genVar457="value";
          Element actionValueElt;
          actionValueElt=actionExpression.getChild(genVar457);
          boolean genVar458;
          genVar458=actionValueElt == null;
          if (genVar458) {
            java.lang.String genVar459;
            genVar459="Create action can't be interpreted yet whitout value";
            rulesEngine.manager.ruleModelParserException genVar460;
            genVar460=new ruleModelParserException(genVar459);
            throw genVar460;
          }
 else {
            ;
          }
          java.util.List<org.jdom2.Element> genVar461;
          genVar461=actionValueElt.getChildren();
          int genVar462;
          genVar462=0;
          actionValueElt=genVar461.get(genVar462);
          AdaptationEngine genVar463;
          genVar463=this;
          String actionValue;
          actionValue=genVar463.readConstantOrEntity(actionValueElt);
          for (          Object actionTarget : actionTargets) {
            boolean genVar464;
            genVar464=actionTarget instanceof Element;
            if (genVar464) {
              Element element;
              element=new Element(actionValue);
              org.jdom2.Element genVar465;
              genVar465=(Element)actionTarget;
              org.jdom2.Element genVar466;
              genVar466=(genVar465);
              genVar466.addContent(element);
            }
 else {
              boolean genVar467;
              genVar467=actionTarget instanceof Attribute;
              if (genVar467) {
              }
 else {
                java.lang.Class genVar468;
                genVar468=actionTarget.getClass();
                java.lang.String genVar469;
                genVar469=" not handled yet in create action";
                java.lang.String genVar470;
                genVar470=genVar468 + genVar469;
                rulesEngine.manager.ruleModelParserException genVar471;
                genVar471=new ruleModelParserException(genVar470);
                throw genVar471;
              }
            }
          }
        }
 else {
          AdaptationEngine genVar472;
          genVar472=this;
          AdaptationEngine genVar473;
          genVar473=this;
          java.lang.String genVar474;
          genVar474=genVar473.getModelId(complexType);
          rulesEngine.manager.AE_ModelId genVar475;
          genVar475=new AE_ModelId(genVar474);
          org.jdom2.Element genVar476;
          genVar476=genVar472.getModel(genVar475);
          Document model;
          model=genVar476.getDocument();
          AdaptationEngine genVar477;
          genVar477=this;
          java.lang.String genVar478;
          genVar478=genVar477.getModelId(complexType);
          modelToUpdate=new AE_Target(genVar478,model,null);
          java.lang.String genVar479;
          genVar479="xPath";
          java.lang.String genVar480;
          genVar480=complexType.getAttributeValue(genVar479);
          XPath xpa;
          xpa=new JDOMXPath(genVar480);
          org.jdom2.Element genVar481;
          genVar481=model.getRootElement();
          java.util.List genVar482;
          genVar482=xpa.selectNodes(genVar481);
          List<Object> elements;
          elements=(List<Object>)genVar482;
          for (          Object element : elements) {
            for (            Object actionTarget : actionTargets) {
              boolean genVar483;
              genVar483=element instanceof Element;
              if (genVar483) {
                org.jdom2.Element genVar484;
                genVar484=(Element)actionTarget;
                Element genVar485;
                genVar485=(genVar484);
                org.jdom2.Element genVar486;
                genVar486=(Element)element;
                Element genVar487;
                genVar487=(genVar486);
                org.jdom2.Element genVar488;
                genVar488=genVar487.clone();
                genVar485.addContent(genVar488);
              }
 else {
                boolean genVar489;
                genVar489=element instanceof Attribute;
                if (genVar489) {
                  org.jdom2.Element genVar490;
                  genVar490=(Element)actionTarget;
                  Element genVar491;
                  genVar491=(genVar490);
                  org.jdom2.Attribute genVar492;
                  genVar492=(Attribute)element;
                  Attribute genVar493;
                  genVar493=(genVar492);
                  java.lang.String genVar494;
                  genVar494=genVar493.getName();
                  org.jdom2.Attribute genVar495;
                  genVar495=(Attribute)element;
                  Attribute genVar496;
                  genVar496=(genVar495);
                  java.lang.String genVar497;
                  genVar497=genVar496.getValue();
                  genVar491.setAttribute(genVar494,genVar497);
                }
 else {
                  java.lang.Class genVar498;
                  genVar498=actionTarget.getClass();
                  java.lang.String genVar499;
                  genVar499=" not handled yet in create action";
                  java.lang.String genVar500;
                  genVar500=genVar498 + genVar499;
                  rulesEngine.manager.ruleModelParserException genVar501;
                  genVar501=new ruleModelParserException(genVar500);
                  throw genVar501;
                }
              }
            }
          }
        }
      }
 else {
        java.lang.String genVar502;
        genVar502=actionExpression.getName();
        java.lang.String genVar503;
        genVar503="delete";
        boolean genVar504;
        genVar504=genVar502.equals(genVar503);
        if (genVar504) {
          AdaptationEngine genVar505;
          genVar505=this;
          java.lang.String genVar506;
          genVar506="entityReference";
          modelToUpdate=genVar505.getTargets(actionExpression,genVar506);
          List<?> actionTargets;
          actionTargets=modelToUpdate.getTargets();
          for (          Object actionTarget : actionTargets) {
            boolean genVar507;
            genVar507=actionTarget instanceof Content;
            if (genVar507) {
              org.jdom2.Content genVar508;
              genVar508=(Content)actionTarget;
              Content genVar509;
              genVar509=(genVar508);
              genVar509.detach();
            }
 else {
              boolean genVar510;
              genVar510=actionTarget instanceof Attribute;
              if (genVar510) {
                org.jdom2.Attribute genVar511;
                genVar511=(Attribute)actionTarget;
                Attribute genVar512;
                genVar512=(genVar511);
                genVar512.detach();
              }
 else {
                java.lang.Class genVar513;
                genVar513=actionTarget.getClass();
                java.lang.String genVar514;
                genVar514=" not handled yet in delete action";
                java.lang.String genVar515;
                genVar515=genVar513 + genVar514;
                rulesEngine.manager.ruleModelParserException genVar516;
                genVar516=new ruleModelParserException(genVar515);
                throw genVar516;
              }
            }
          }
        }
 else {
          java.lang.String genVar517;
          genVar517=actionExpression.getName();
          java.lang.String genVar518;
          genVar518="update";
          boolean genVar519;
          genVar519=genVar517.equals(genVar518);
          if (genVar519) {
            AdaptationEngine genVar520;
            genVar520=this;
            java.lang.String genVar521;
            genVar521="entityReference";
            modelToUpdate=genVar520.getTargets(actionExpression,genVar521);
            List<?> actionTargets;
            actionTargets=modelToUpdate.getTargets();
            java.lang.String genVar522;
            genVar522="value";
            org.jdom2.Element genVar523;
            genVar523=actionExpression.getChild(genVar522);
            java.util.List<org.jdom2.Element> genVar524;
            genVar524=genVar523.getChildren();
            int genVar525;
            genVar525=0;
            Element actionValueElt;
            actionValueElt=genVar524.get(genVar525);
            AdaptationEngine genVar526;
            genVar526=this;
            String actionValue;
            actionValue=genVar526.readConstantOrEntity(actionValueElt);
            for (            Object actionTarget : actionTargets) {
              boolean genVar527;
              genVar527=actionTarget instanceof Element;
              if (genVar527) {
                org.jdom2.Element genVar528;
                genVar528=(Element)actionTarget;
                Element genVar529;
                genVar529=(genVar528);
                genVar529.setText(actionValue);
              }
 else {
                boolean genVar530;
                genVar530=actionTarget instanceof Attribute;
                if (genVar530) {
                  org.jdom2.Attribute genVar531;
                  genVar531=(Attribute)actionTarget;
                  Attribute genVar532;
                  genVar532=(genVar531);
                  genVar532.setValue(actionValue);
                }
 else {
                  java.lang.Class genVar533;
                  genVar533=actionTarget.getClass();
                  java.lang.String genVar534;
                  genVar534=" not handled yet in update action";
                  java.lang.String genVar535;
                  genVar535=genVar533 + genVar534;
                  rulesEngine.manager.ruleModelParserException genVar536;
                  genVar536=new ruleModelParserException(genVar535);
                  throw genVar536;
                }
              }
            }
          }
 else {
            java.lang.String genVar537;
            genVar537=actionExpression.getName();
            java.lang.String genVar538;
            genVar538="if";
            boolean genVar539;
            genVar539=genVar537.equals(genVar538);
            if (genVar539) {
              AdaptationEngine genVar540;
              genVar540=this;
              genVar540.executeIf(actionExpression);
            }
 else {
              java.lang.String genVar541;
              genVar541=actionExpression.getName();
              java.lang.String genVar542;
              genVar542="block";
              boolean genVar543;
              genVar543=genVar541.equals(genVar542);
              if (genVar543) {
                AdaptationEngine genVar544;
                genVar544=this;
                genVar544.executeAction(actionExpression);
              }
 else {
                java.lang.String genVar545;
                genVar545=actionExpression.getName();
                java.lang.String genVar546;
                genVar546="for";
                boolean genVar547;
                genVar547=genVar545.equals(genVar546);
                if (genVar547) {
                  java.lang.String genVar548;
                  genVar548="from";
                  java.lang.String genVar549;
                  genVar549=actionExpression.getAttributeValue(genVar548);
                  int from;
                  from=Integer.parseInt(genVar549);
                  java.lang.String genVar550;
                  genVar550="to";
                  java.lang.String genVar551;
                  genVar551=actionExpression.getAttributeValue(genVar550);
                  int to;
                  to=Integer.parseInt(genVar551);
                  int i=from;
                  for (; i < to; i++) {
                    java.util.List<org.jdom2.Element> genVar552;
                    genVar552=actionExpression.getChildren();
                    for (                    Element doElt : genVar552) {
                      AdaptationEngine genVar553;
                      genVar553=this;
                      genVar553.executeAction(doElt);
                    }
                  }
                }
 else {
                  java.lang.String genVar554;
                  genVar554=actionExpression.getName();
                  java.lang.String genVar555;
                  genVar555=" tag isn't supported yet in actions";
                  java.lang.String genVar556;
                  genVar556=genVar554 + genVar555;
                  rulesEngine.manager.ruleModelParserException genVar557;
                  genVar557=new ruleModelParserException(genVar556);
                  throw genVar557;
                }
              }
            }
          }
        }
      }
      AdaptationEngine genVar558;
      genVar558=this;
      genVar558.replaceModel(modelToUpdate);
    }
  }
  protected void replaceModel(  AE_Target modelToUpdate) throws JDOMException, IOException, ContextManagerParserException {
  }
  private AE_Target getTargets(  Element element,  String propertyWhithXpath) throws JDOMException, IOException, ContextManagerParserException {
    org.jdom2.Element genVar559;
    genVar559=element.getChild(propertyWhithXpath);
    java.lang.String genVar560;
    genVar560="xPath";
    String xpath;
    xpath=genVar559.getAttributeValue(genVar560);
    XPath xpa;
    xpa=new JDOMXPath(xpath);
    AdaptationEngine genVar561;
    genVar561=this;
    org.jdom2.Element genVar562;
    genVar562=element.getChild(propertyWhithXpath);
    String model;
    model=genVar561.getModelId(genVar562);
    AdaptationEngine genVar563;
    genVar563=this;
    rulesEngine.manager.AE_ModelId genVar564;
    genVar564=new AE_ModelId(model);
    Element modelElt;
    modelElt=genVar563.getModel(genVar564);
    org.jdom2.Document genVar565;
    genVar565=modelElt.getDocument();
    java.util.List genVar566;
    genVar566=xpa.selectNodes(modelElt);
    rulesEngine.manager.AE_Target genVar567;
    genVar567=new AE_Target(model,genVar565,genVar566);
    return genVar567;
  }
  private boolean executeIf(  Element actionExpression) throws ruleModelParserException, JDOMException, IOException, ContextManagerParserException {
    AdaptationEngine genVar568;
    genVar568=this;
    java.lang.String genVar569;
    genVar569="condition";
    org.jdom2.Element genVar570;
    genVar570=actionExpression.getChild(genVar569);
    boolean condition;
    condition=genVar568.testCondition(genVar570);
    if (condition) {
      AdaptationEngine genVar571;
      genVar571=this;
      java.lang.String genVar572;
      genVar572="then";
      org.jdom2.Element genVar573;
      genVar573=actionExpression.getChild(genVar572);
      genVar571.executeAction(genVar573);
      boolean genVar574;
      genVar574=true;
      return genVar574;
    }
 else {
      java.lang.String genVar575;
      genVar575="elseIf";
      java.util.List<org.jdom2.Element> genVar576;
      genVar576=actionExpression.getChildren(genVar575);
      for (      Element elseIf : genVar576) {
        AdaptationEngine genVar577;
        genVar577=this;
        condition=genVar577.executeIf(elseIf);
        if (condition) {
          boolean genVar578;
          genVar578=true;
          return genVar578;
        }
 else {
          ;
        }
      }
      java.lang.String genVar579;
      genVar579="else";
      java.util.List<org.jdom2.Element> genVar580;
      genVar580=actionExpression.getChildren(genVar579);
      for (      Element elseElt : genVar580) {
        AdaptationEngine genVar581;
        genVar581=this;
        genVar581.executeAction(elseElt);
        boolean genVar582;
        genVar582=true;
        return genVar582;
      }
    }
    boolean genVar583;
    genVar583=false;
    return genVar583;
  }
  protected List<Element> getActions() throws JDOMException, ruleModelParserException, IOException, ContextManagerParserException {
    List<Element> actions;
    actions=new ArrayList<Element>();
    java.lang.String genVar584;
    genVar584="//rule";
    XPath xpa;
    xpa=new JDOMXPath(genVar584);
    java.util.List genVar585;
    genVar585=xpa.selectNodes(rulesRoot);
    List<Element> rules;
    rules=(List<Element>)genVar585;
    for (    Element ruleElt : rules) {
      Element ruleEltCopy;
      ruleEltCopy=ruleElt.clone();
      new Document(ruleEltCopy);
      java.lang.String genVar586;
      genVar586="condition";
      List<Element> conditions;
      conditions=ruleEltCopy.getChildren(genVar586);
      boolean conditionsOK;
      conditionsOK=true;
      for (      Element conditionElt : conditions) {
        AdaptationEngine genVar587;
        genVar587=this;
        boolean genVar588;
        genVar588=genVar587.testCondition(conditionElt);
        boolean genVar589;
        genVar589=!genVar588;
        if (genVar589) {
          conditionsOK=false;
          break;
        }
 else {
          ;
        }
      }
      if (conditionsOK) {
        java.lang.String genVar590;
        genVar590="//action";
        xpa=new JDOMXPath(genVar590);
        java.util.List genVar591;
        genVar591=xpa.selectNodes(ruleEltCopy);
        actions=(List<Element>)genVar591;
      }
 else {
        ;
      }
    }
    return actions;
  }
  public void executeRules() throws JDOMException, ruleModelParserException, IOException, ContextManagerParserException {
    AdaptationEngine genVar592;
    genVar592=this;
    List<Element> actions;
    actions=genVar592.getActions();
    for (    Element action : actions) {
      AdaptationEngine genVar593;
      genVar593=this;
      genVar593.executeAction(action);
    }
  }
  public void updateModel(  String action) throws JDOMException, IOException, ruleModelParserException, ContextManagerParserException {
    java.lang.String genVar594;
    genVar594="<rootElement>";
    java.lang.String genVar595;
    genVar595="</rootElement>";
    action=genVar594 + action + genVar595;
    org.jdom2.input.SAXBuilder genVar596;
    genVar596=new SAXBuilder();
    byte[] genVar597;
    genVar597=action.getBytes();
    java.io.ByteArrayInputStream genVar598;
    genVar598=new ByteArrayInputStream(genVar597);
    Document rulesModel;
    rulesModel=genVar596.build(genVar598);
    AdaptationEngine genVar599;
    genVar599=this;
    org.jdom2.Element genVar600;
    genVar600=rulesModel.getRootElement();
    genVar599.executeAction(genVar600);
  }
  public ContextManager getCm(){
    return cm;
  }
  public void printModel(  String modelFilePath,  AE_ModelId modelId) throws FileNotFoundException, IOException, JDOMException, ContextManagerParserException {
    org.jdom2.output.Format genVar601;
    genVar601=Format.getPrettyFormat();
    XMLOutputter sortie;
    sortie=new XMLOutputter(genVar601);
    AdaptationEngine genVar602;
    genVar602=this;
    org.jdom2.Element genVar603;
    genVar603=genVar602.getModel(modelId);
    java.io.FileOutputStream genVar604;
    genVar604=new FileOutputStream(modelFilePath);
    sortie.output(genVar603,genVar604);
  }
  public String getModelAsXMLString(  AE_ModelId modelId) throws JDOMException, IOException, ContextManagerParserException {
    org.jdom2.output.Format genVar605;
    genVar605=Format.getPrettyFormat();
    XMLOutputter sortie;
    sortie=new XMLOutputter(genVar605);
    java.lang.String genVar606;
    genVar606="model";
    Element modelElement;
    modelElement=new Element(genVar606);
    java.lang.String genVar607;
    genVar607="id";
    java.lang.String genVar608;
    genVar608=modelId.getId();
    modelElement.setAttribute(genVar607,genVar608);
    AdaptationEngine genVar609;
    genVar609=this;
    org.jdom2.Element genVar610;
    genVar610=genVar609.getModel(modelId);
    org.jdom2.Element genVar611;
    genVar611=genVar610.clone();
    modelElement.addContent(genVar611);
    String response;
    response=sortie.outputString(modelElement);
    response+="\n";
    return response;
  }
}
