package rulesEngine.manager;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.jdom2.Attribute;
import org.jdom2.Content;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.xpath.XPath;
import org.jdom2.xpath.jaxen.JDOMXPath;
import rulesEngine.utils.Logger;
public class ContextManager {
  private static final String PREFERENCES_SUFFIX="W4preferences";
  private static final String TIMOUT_VALUE="1800000";
  private SAXBuilder sxb=new SAXBuilder();
  private String context_manager_uri;
  private Map<String,CM_Ids> index=new HashMap<String,CM_Ids>();
  private boolean deconectedMode=false;
  private Map<CM_Ids,Element> deconnectedMap=new HashMap<CM_Ids,Element>();
  private boolean userChanged=true;
  private Element allUser;
  public ContextManager(  String context_manager_uri) throws JDOMException, IOException {
    rulesEngine.manager.ContextManager genVar630;
    genVar630=this;
    genVar630.context_manager_uri=context_manager_uri;
    try {
      java.lang.String genVar631;
      genVar631="context manager --> ok";
      Logger.log(genVar631);
    }
 catch (    Exception e) {
      deconectedMode=true;
      java.lang.String genVar632;
      genVar632="context manager --> ko ==> ! DECONECTED MODE !";
      Logger.log(genVar632);
    }
  }
  public void deleteUser(  CM_Ids ids) throws JDOMException, IOException {
    if (deconectedMode) {
      deconnectedMap.remove(ids);
    }
 else {
    }
    userChanged=true;
    List<String> keysToRemove;
    keysToRemove=new ArrayList<String>();
    java.util.Set<java.util.Map.Entry<java.lang.String,rulesEngine.manager.CM_Ids>> genVar633;
    genVar633=index.entrySet();
    for (    Entry<String,CM_Ids> entry : genVar633) {
      if (deconectedMode) {
        rulesEngine.manager.CM_Ids genVar634;
        genVar634=entry.getValue();
        java.lang.Object genVar635;
        genVar635=genVar634.getIdUser();
        int genVar636;
        genVar636=genVar635.hashCode();
        java.lang.Object genVar637;
        genVar637=ids.getIdUser();
        int genVar638;
        genVar638=genVar637.hashCode();
        boolean genVar639;
        genVar639=genVar636 == genVar638;
        if (genVar639) {
          java.lang.String genVar640;
          genVar640=entry.getKey();
          keysToRemove.add(genVar640);
        }
 else {
          ;
        }
      }
 else {
        rulesEngine.manager.CM_Ids genVar641;
        genVar641=entry.getValue();
        boolean genVar642;
        genVar642=genVar641.equals(ids);
        if (genVar642) {
          java.lang.String genVar643;
          genVar643=entry.getKey();
          keysToRemove.add(genVar643);
        }
 else {
          ;
        }
      }
    }
    for (    String key : keysToRemove) {
      index.remove(key);
    }
  }
  private String buildDeleteCommand(  String id){
    java.lang.String genVar644;
    genVar644="<comet>";
    java.lang.String genVar645;
    genVar645="<op>delete</op>";
    java.lang.String genVar646;
    genVar646="<entity_id>";
    java.lang.String genVar647;
    genVar647=genVar644 + genVar645 + genVar646;
    java.lang.String genVar648;
    genVar648="</entity_id>";
    java.lang.String genVar649;
    genVar649="</comet>";
    String deleteCmd;
    deleteCmd=genVar647 + id + genVar648+ genVar649;
    return deleteCmd;
  }
  private boolean userExists(  String userName) throws JDOMException, IOException {
    boolean genVar650;
    genVar650=index.containsKey(userName);
    ContextManager genVar651;
    genVar651=this;
    org.jdom2.Element genVar652;
    genVar652=genVar651.getUser(userName);
    boolean genVar653;
    genVar653=genVar652 != null;
    boolean genVar654;
    genVar654=genVar650 || genVar653;
    return genVar654;
  }
  public CM_Ids createUser(  String userName) throws JDOMException, IOException {
    ContextManager genVar655;
    genVar655=this;
    java.util.ArrayList<rulesEngine.manager.CM_Value> genVar656;
    genVar656=new ArrayList<CM_Value>();
    rulesEngine.manager.CM_Ids genVar657;
    genVar657=genVar655.createUser(userName,genVar656);
    return genVar657;
  }
  public CM_Ids createUser(  String userName,  boolean temp) throws JDOMException, IOException {
    ContextManager genVar658;
    genVar658=this;
    java.util.ArrayList<rulesEngine.manager.CM_Value> genVar659;
    genVar659=new ArrayList<CM_Value>();
    rulesEngine.manager.CM_Ids genVar660;
    genVar660=genVar658.createUser(userName,genVar659,temp);
    return genVar660;
  }
  public CM_Ids createUser(  String userName,  CM_Value value) throws JDOMException, IOException {
    ContextManager genVar661;
    genVar661=this;
    boolean genVar662;
    genVar662=false;
    rulesEngine.manager.CM_Ids genVar663;
    genVar663=genVar661.createUser(userName,value,genVar662);
    return genVar663;
  }
  public CM_Ids createUser(  String userName,  CM_Value value,  boolean temp) throws JDOMException, IOException {
    List<CM_Value> values;
    values=new ArrayList<CM_Value>();
    values.add(value);
    ContextManager genVar664;
    genVar664=this;
    rulesEngine.manager.CM_Ids genVar665;
    genVar665=genVar664.createUser(userName,values,temp);
    return genVar665;
  }
  public CM_Ids createUser(  String userName,  List<CM_Value> values) throws JDOMException, IOException {
    ContextManager genVar666;
    genVar666=this;
    boolean genVar667;
    genVar667=false;
    rulesEngine.manager.CM_Ids genVar668;
    genVar668=genVar666.createUser(userName,values,genVar667);
    return genVar668;
  }
  public CM_Ids createUser(  String userName,  List<CM_Value> values,  boolean temp) throws JDOMException, IOException {
    ContextManager genVar669;
    genVar669=this;
    boolean genVar670;
    genVar670=genVar669.userExists(userName);
    if (genVar670) {
      ContextManager genVar671;
      genVar671=this;
      rulesEngine.manager.CM_Ids genVar672;
      genVar672=genVar671.getUserIds(userName);
      return genVar672;
    }
 else {
      ;
    }
    userChanged=true;
    CM_Ids newId;
    if (deconectedMode) {
      java.lang.String genVar673;
      genVar673="<user>";
      java.lang.String genVar674;
      genVar674="<userid>";
      java.lang.String genVar675;
      genVar675=genVar673 + genVar674;
      java.lang.String genVar676;
      genVar676="</userid>";
      java.lang.String genVar677;
      genVar677="<account/>";
      java.lang.String genVar678;
      genVar678="<location/>";
      java.lang.String genVar679;
      genVar679="<environment>";
      java.lang.String genVar680;
      genVar680="<light_level>0</light_level>";
      java.lang.String genVar681;
      genVar681="<noise_level>0</noise_level>";
      java.lang.String genVar682;
      genVar682="<temperature>0</temperature>";
      java.lang.String genVar683;
      genVar683="</environment>";
      java.lang.String genVar684;
      genVar684="<preferences>";
      java.lang.String genVar685;
      genVar685="<";
      java.lang.String genVar686;
      genVar686=">";
      java.lang.String genVar687;
      genVar687="</";
      java.lang.String genVar688;
      genVar688=">";
      java.lang.String genVar689;
      genVar689="</preferences>";
      java.lang.String genVar690;
      genVar690="<deviceBattery>";
      java.lang.String genVar691;
      genVar691="<batteryLevel>0</batteryLevel>";
      java.lang.String genVar692;
      genVar692="<batteryCharging>false</batteryCharging>";
      java.lang.String genVar693;
      genVar693="</deviceBattery>";
      java.lang.String genVar694;
      genVar694="</user>";
      String content;
      content=genVar675 + userName + genVar676+ genVar677+ genVar678+ genVar679+ genVar680+ genVar681+ genVar682+ genVar683+ genVar684+ genVar685+ userName+ PREFERENCES_SUFFIX+ genVar686+ genVar687+ userName+ PREFERENCES_SUFFIX+ genVar688+ genVar689+ genVar690+ genVar691+ genVar692+ genVar693+ genVar694;
      byte[] genVar695;
      genVar695=content.getBytes();
      java.io.ByteArrayInputStream genVar696;
      genVar696=new ByteArrayInputStream(genVar695);
      org.jdom2.Document genVar697;
      genVar697=sxb.build(genVar696);
      Element element;
      element=genVar697.getRootElement();
      java.lang.String genVar698;
      genVar698="";
      int genVar699;
      genVar699=userName.hashCode();
      java.lang.String genVar700;
      genVar700=genVar698 + genVar699;
      java.lang.String genVar701;
      genVar701="";
      int genVar702;
      genVar702=userName.hashCode();
      int genVar703;
      genVar703=1;
      int genVar704;
      genVar704=genVar702 - genVar703;
      int genVar705;
      genVar705=(genVar704);
      java.lang.String genVar706;
      genVar706=genVar701 + genVar705;
      newId=new CM_Ids(genVar700,genVar706);
      deconnectedMap.put(newId,element);
    }
 else {
      String cm_preferencesName;
      cm_preferencesName=userName + PREFERENCES_SUFFIX;
      java.lang.String genVar707;
      genVar707="<entity_timeout>";
      java.lang.String genVar708;
      genVar708="</entity_timeout>";
      java.lang.String genVar709;
      genVar709=genVar707 + TIMOUT_VALUE + genVar708;
      java.lang.String genVar710;
      genVar710="";
      String timout;
      timout=temp ? genVar709 : genVar710;
      java.lang.String genVar711;
      genVar711="<comet>";
      java.lang.String genVar712;
      genVar712="<op>insert</op>";
      java.lang.String genVar713;
      genVar713="<entity_type>user_preferences</entity_type>";
      java.lang.String genVar714;
      genVar714=genVar711 + genVar712 + genVar713;
      java.lang.String genVar715;
      genVar715="<entity_data>";
      java.lang.String genVar716;
      genVar716="<id type='xs:string'>";
      java.lang.String genVar717;
      genVar717="</id>";
      ContextManager genVar718;
      genVar718=this;
      java.lang.String genVar719;
      genVar719=genVar718.buildEntitiesData(values);
      java.lang.String genVar720;
      genVar720="</entity_data>";
      java.lang.String genVar721;
      genVar721="</comet>";
      String createPreferencesCmd;
      createPreferencesCmd=genVar714 + timout + genVar715+ genVar716+ cm_preferencesName+ genVar717+ genVar719+ genVar720+ genVar721;
      String response;
      response="";
      java.lang.String genVar722;
      genVar722="[^\\d]";
      java.lang.String genVar723;
      genVar723="";
      String preferencesId;
      preferencesId=response.replaceAll(genVar722,genVar723);
      java.lang.String genVar724;
      genVar724="<comet>";
      java.lang.String genVar725;
      genVar725="<op>insert</op>";
      java.lang.String genVar726;
      genVar726="<entity_type>user</entity_type>";
      java.lang.String genVar727;
      genVar727=genVar724 + genVar725 + genVar726;
      java.lang.String genVar728;
      genVar728="<entity_data>";
      java.lang.String genVar729;
      genVar729="<userid type='xs:string'>";
      java.lang.String genVar730;
      genVar730="</userid>";
      java.lang.String genVar731;
      genVar731="<preferences_";
      java.lang.String genVar732;
      genVar732=">";
      java.lang.String genVar733;
      genVar733="<entity_id type='xs:entity'>";
      java.lang.String genVar734;
      genVar734="</entity_id>";
      java.lang.String genVar735;
      genVar735="</preferences_";
      java.lang.String genVar736;
      genVar736=">";
      java.lang.String genVar737;
      genVar737="</entity_data>";
      java.lang.String genVar738;
      genVar738="</comet>";
      String createUserCmd;
      createUserCmd=genVar727 + timout + genVar728+ genVar729+ userName+ genVar730+ genVar731+ cm_preferencesName+ genVar732+ genVar733+ preferencesId+ genVar734+ genVar735+ cm_preferencesName+ genVar736+ genVar737+ genVar738;
      response="";
      java.lang.String genVar739;
      genVar739="[^\\d]";
      java.lang.String genVar740;
      genVar740="";
      String userId;
      userId=response.replaceAll(genVar739,genVar740);
      newId=new CM_Ids(userId,preferencesId);
    }
    java.lang.String genVar741;
    genVar741="user ";
    java.lang.String genVar742;
    genVar742=" created";
    java.lang.String genVar743;
    genVar743=genVar741 + userName + genVar742;
    System.out.println(genVar743);
    index.put(userName,newId);
    if (deconectedMode) {
      ContextManager genVar744;
      genVar744=this;
      genVar744.setValue(newId,values);
    }
 else {
      ;
    }
    return newId;
  }
  public String getValue(  String userName,  String key) throws JDOMException, IOException {
    ContextManager genVar745;
    genVar745=this;
    Element userElmt;
    userElmt=genVar745.getUser(userName);
    boolean genVar746;
    genVar746=userElmt == null;
    if (genVar746) {
      ContextManager genVar747;
      genVar747=this;
      genVar747.createUser(userName);
      ContextManager genVar748;
      genVar748=this;
      java.lang.String genVar749;
      genVar749=genVar748.getValue(userName,key);
      return genVar749;
    }
 else {
      ;
    }
    java.lang.String genVar750;
    genVar750="//preferences[contains(id, '";
    java.lang.String genVar751;
    genVar751="')]/preference/name[.='";
    java.lang.String genVar752;
    genVar752="']/following-sibling::*[1]";
    java.lang.String genVar753;
    genVar753=genVar750 + PREFERENCES_SUFFIX + genVar751+ key+ genVar752;
    XPath xpa;
    xpa=new JDOMXPath(genVar753);
    java.lang.Object genVar754;
    genVar754=xpa.selectSingleNode(userElmt);
    Element e;
    e=(Element)genVar754;
    boolean genVar755;
    genVar755=e == null;
    if (genVar755) {
      return null;
    }
 else {
      ;
    }
    java.lang.String genVar756;
    genVar756=e.getText();
    return genVar756;
  }
  public boolean setValue(  String userName,  CM_Value value) throws JDOMException, IOException {
    ContextManager genVar757;
    genVar757=this;
    ContextManager genVar758;
    genVar758=this;
    rulesEngine.manager.CM_Ids genVar759;
    genVar759=genVar758.getUserIds(userName);
    boolean genVar760;
    genVar760=genVar757.setValue(genVar759,value);
    return genVar760;
  }
  public boolean setValue(  String userName,  List<CM_Value> values) throws JDOMException, IOException {
    ContextManager genVar761;
    genVar761=this;
    ContextManager genVar762;
    genVar762=this;
    rulesEngine.manager.CM_Ids genVar763;
    genVar763=genVar762.getUserIds(userName);
    boolean genVar764;
    genVar764=genVar761.setValue(genVar763,values);
    return genVar764;
  }
  public boolean setValue(  CM_Ids ids,  CM_Value value) throws JDOMException, IOException {
    List<CM_Value> values;
    values=new ArrayList<CM_Value>();
    values.add(value);
    ContextManager genVar765;
    genVar765=this;
    boolean genVar766;
    genVar766=genVar765.setValue(ids,values);
    return genVar766;
  }
  public boolean setValue(  CM_Ids ids,  List<CM_Value> values) throws JDOMException, IOException {
    if (deconectedMode) {
      Element userElement;
      userElement=deconnectedMap.get(ids);
      for (      CM_Value value : values) {
        java.lang.String genVar767;
        genVar767="//preferences/*[contains(name(), '";
        java.lang.String genVar768;
        genVar768="')]/@*[name()='";
        java.lang.String genVar769;
        genVar769=value.getKey();
        java.lang.String genVar770;
        genVar770="']";
        java.lang.String genVar771;
        genVar771=genVar767 + PREFERENCES_SUFFIX + genVar768+ genVar769+ genVar770;
        XPath xpa;
        xpa=new JDOMXPath(genVar771);
        java.lang.Object genVar772;
        genVar772=xpa.selectSingleNode(userElement);
        Attribute attr;
        attr=(Attribute)genVar772;
        boolean genVar773;
        genVar773=attr != null;
        if (genVar773) {
          java.lang.String genVar774;
          genVar774=value.getValue();
          attr.setValue(genVar774);
        }
 else {
          java.lang.String genVar775;
          genVar775="//preferences/*[contains(name(), '";
          java.lang.String genVar776;
          genVar776="')]";
          java.lang.String genVar777;
          genVar777=genVar775 + PREFERENCES_SUFFIX + genVar776;
          xpa=new JDOMXPath(genVar777);
          java.lang.Object genVar778;
          genVar778=xpa.selectSingleNode(userElement);
          Element e;
          e=(Element)genVar778;
          java.lang.String genVar779;
          genVar779=value.getValue();
          boolean genVar780;
          genVar780=genVar779 != null;
          if (genVar780) {
            java.lang.String genVar781;
            genVar781=value.getKey();
            java.lang.String genVar782;
            genVar782=value.getValue();
            e.setAttribute(genVar781,genVar782);
          }
 else {
            ;
          }
        }
      }
      boolean genVar783;
      genVar783=true;
      return genVar783;
    }
 else {
      ;
    }
    userChanged=true;
    java.lang.String genVar784;
    genVar784="<comet>";
    java.lang.String genVar785;
    genVar785="<op>update</op>";
    java.lang.String genVar786;
    genVar786="<entity_id>";
    java.lang.String genVar787;
    genVar787=genVar784 + genVar785 + genVar786;
    java.lang.String genVar788;
    genVar788=ids.getIdPreferences();
    java.lang.String genVar789;
    genVar789="</entity_id>";
    java.lang.String genVar790;
    genVar790="<entity_data>";
    ContextManager genVar791;
    genVar791=this;
    java.lang.String genVar792;
    genVar792=genVar791.buildEntitiesData(values);
    java.lang.String genVar793;
    genVar793="</entity_data>";
    java.lang.String genVar794;
    genVar794="</comet>";
    String updateCmd;
    updateCmd=genVar787 + genVar788 + genVar789+ genVar790+ genVar792+ genVar793+ genVar794;
    String response;
    response="";
    java.lang.String genVar795;
    genVar795="FAILED";
    boolean genVar796;
    genVar796=response.contains(genVar795);
    boolean genVar797;
    genVar797=!genVar796;
    return genVar797;
  }
  private String buildEntitiesData(  List<CM_Value> values){
    String response;
    response="";
    for (    CM_Value value : values) {
      java.lang.String genVar798;
      genVar798="<";
      java.lang.String genVar799;
      genVar799=value.getKey();
      java.lang.String genVar800;
      genVar800=" type='";
      java.lang.String genVar801;
      genVar801=value.getType();
      java.lang.String genVar802;
      genVar802="'>";
      java.lang.String genVar803;
      genVar803=value.getValue();
      java.lang.String genVar804;
      genVar804="</";
      java.lang.String genVar805;
      genVar805=value.getKey();
      java.lang.String genVar806;
      genVar806=">";
      response+=genVar798 + genVar799 + genVar800+ genVar801+ genVar802+ genVar803+ genVar804+ genVar805+ genVar806;
    }
    return response;
  }
  public CM_Ids getUserIds(  String userName) throws JDOMException, IOException {
    boolean genVar807;
    genVar807=index.containsKey(userName);
    if (genVar807) {
      rulesEngine.manager.CM_Ids genVar808;
      genVar808=index.get(userName);
      return genVar808;
    }
 else {
      ;
    }
    if (deconectedMode) {
      ContextManager genVar809;
      genVar809=this;
      rulesEngine.manager.CM_Ids genVar810;
      genVar810=genVar809.createUser(userName);
      return genVar810;
    }
 else {
      ;
    }
    ContextManager genVar811;
    genVar811=this;
    Element userElement;
    userElement=genVar811.getUserElement(userName);
    boolean genVar812;
    genVar812=userElement == null;
    if (genVar812) {
      ContextManager genVar813;
      genVar813=this;
      rulesEngine.manager.CM_Ids genVar814;
      genVar814=genVar813.createUser(userName);
      return genVar814;
    }
 else {
      ;
    }
    ContextManager genVar815;
    genVar815=this;
    org.jdom2.Element genVar816;
    genVar816=genVar815.getUserElement(userName);
    java.lang.String genVar817;
    genVar817="id";
    String userId;
    userId=genVar816.getChildText(genVar817);
    ContextManager genVar818;
    genVar818=this;
    org.jdom2.Element genVar819;
    genVar819=genVar818.getUserElement(userName);
    java.lang.String genVar820;
    genVar820="entity_data";
    org.jdom2.Element genVar821;
    genVar821=genVar819.getChild(genVar820);
    java.lang.String genVar822;
    genVar822="sub_entities";
    org.jdom2.Element genVar823;
    genVar823=genVar821.getChild(genVar822);
    java.lang.String genVar824;
    genVar824="refValue";
    org.jdom2.Element genVar825;
    genVar825=genVar823.getChild(genVar824);
    java.lang.String genVar826;
    genVar826="entity_id";
    String preferencesId;
    preferencesId=genVar825.getChildText(genVar826);
    CM_Ids userIds;
    userIds=new CM_Ids(userId,preferencesId);
    index.put(userName,userIds);
    return userIds;
  }
  @Deprecated private Element getUserElement(  String userName) throws JDOMException, IOException {
    String response;
    response="";
    byte[] genVar827;
    genVar827=response.getBytes();
    java.io.ByteArrayInputStream genVar828;
    genVar828=new ByteArrayInputStream(genVar827);
    Document allQueries;
    allQueries=sxb.build(genVar828);
    java.lang.String genVar829;
    genVar829="//entity[type='user' and entity_data/attributes/value='";
    java.lang.String genVar830;
    genVar830="']";
    java.lang.String genVar831;
    genVar831=genVar829 + userName + genVar830;
    XPath xpa;
    xpa=new JDOMXPath(genVar831);
    java.lang.Object genVar832;
    genVar832=xpa.selectSingleNode(allQueries);
    org.jdom2.Element genVar833;
    genVar833=(Element)genVar832;
    return genVar833;
  }
  private Element getUser(  String userName) throws JDOMException, IOException {
    if (deconectedMode) {
      boolean genVar834;
      genVar834=index.containsKey(userName);
      if (genVar834) {
        ContextManager genVar835;
        genVar835=this;
        rulesEngine.manager.CM_Ids genVar836;
        genVar836=genVar835.getUserIds(userName);
        org.jdom2.Element genVar837;
        genVar837=deconnectedMap.get(genVar836);
        return genVar837;
      }
 else {
        ;
      }
      return null;
    }
 else {
      ;
    }
    Element response;
    response=null;
    try {
      String userResponse;
      userResponse="";
      byte[] genVar838;
      genVar838=userResponse.getBytes();
      java.io.ByteArrayInputStream genVar839;
      genVar839=new ByteArrayInputStream(genVar838);
      org.jdom2.Document genVar840;
      genVar840=sxb.build(genVar839);
      response=genVar840.getRootElement();
    }
 catch (    Exception uie) {
      java.lang.String genVar841;
      genVar841="the user ";
      java.lang.String genVar842;
      genVar842=" doesn't exist";
      java.lang.String genVar843;
      genVar843=genVar841 + userName + genVar842;
      System.out.println(genVar843);
    }
    return response;
  }
  public static String transformLeonardiId(  String id){
    java.lang.String genVar844;
    genVar844="\\\\";
    java.lang.String genVar845;
    genVar845="";
    java.lang.String genVar846;
    genVar846=id.replaceAll(genVar844,genVar845);
    java.lang.String genVar847;
    genVar847="_";
    java.lang.String genVar848;
    genVar848="";
    java.lang.String genVar849;
    genVar849=genVar846.replaceAll(genVar847,genVar848);
    return genVar849;
  }
  public Element getAllUser() throws JDOMException, IOException {
    if (deconectedMode) {
      Document d;
      d=new Document();
      java.lang.String genVar850;
      genVar850="user";
      Element userElement;
      userElement=new Element(genVar850);
      d.addContent(userElement);
      java.util.Set<java.util.Map.Entry<rulesEngine.manager.CM_Ids,org.jdom2.Element>> genVar851;
      genVar851=deconnectedMap.entrySet();
      for (      Entry<CM_Ids,Element> entry : genVar851) {
        org.jdom2.Element genVar852;
        genVar852=entry.getValue();
        List<Content> userContent;
        userContent=genVar852.getContent();
        for (        Content c : userContent) {
          org.jdom2.Content genVar853;
          genVar853=c.clone();
          userElement.addContent(genVar853);
        }
      }
      return userElement;
    }
 else {
      ;
    }
    if (userChanged) {
      java.io.ByteArrayInputStream genVar854;
      genVar854=new ByteArrayInputStream(null);
      org.jdom2.Document genVar855;
      genVar855=sxb.build(genVar854);
      allUser=genVar855.getRootElement();
      userChanged=false;
    }
 else {
      ;
    }
    return allUser;
  }
  public boolean isDeconectedMode(){
    return deconectedMode;
  }
}
