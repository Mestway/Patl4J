package rulesEngine.manager;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.xpath.XPath;
import org.jdom2.xpath.jaxen.JDOMXPath;
import rulesEngine.listener.FileListener;
import rulesEngine.utils.Logger;
public class AdaptationEngineWithServiceRepository extends AdaptationEngine {
  protected Map<String,ServiceRepository> serviceRepositories=new HashMap<String,ServiceRepository>();
  protected String currentUser;
  private String service_repository_uri;
  private String rulePath;
  @Override public void loadModels(  String user) throws JDOMException, IOException, URISyntaxException, ContextManagerParserException {
    AdaptationEngineWithServiceRepository genVar927;
    genVar927=this;
    ServiceRepository sr;
    sr=genVar927.getSR(user);
    Document rulesModel;
    rulesModel=sr.getAaldl();
    rulesRoot=rulesModel.getRootElement();
  }
  protected ServiceRepository getSR(  String user) throws JDOMException, IOException, ContextManagerParserException {
    ServiceRepository sr;
    sr=serviceRepositories.get(user);
    boolean genVar928;
    genVar928=sr == null;
    if (genVar928) {
      sr=new ServiceRepository(service_repository_uri,rulePath,currentUser,undefinedModelPrefix);
      serviceRepositories.put(currentUser,sr);
      currentUser=user;
    }
 else {
      ;
    }
    return sr;
  }
  public AdaptationEngineWithServiceRepository(  String rulePath,  String context_manager_uri,  String service_repository_uri,  boolean loadModels,  boolean executeRules,  String currentUser) throws JDOMException, IOException, ContextManagerParserException {
    rulesEngine.manager.AdaptationEngineWithServiceRepository genVar929;
    genVar929=this;
    genVar929.rulePath=rulePath;
    rulesEngine.manager.AdaptationEngineWithServiceRepository genVar930;
    genVar930=this;
    genVar930.service_repository_uri=service_repository_uri;
    rulesEngine.manager.AdaptationEngineWithServiceRepository genVar931;
    genVar931=this;
    genVar931.currentUser=currentUser;
    AdaptationEngineWithServiceRepository genVar932;
    genVar932=this;
    genVar932.getSR(currentUser);
    try {
      AdaptationEngineWithServiceRepository genVar933;
      genVar933=this;
      genVar933.init(context_manager_uri,loadModels,executeRules,currentUser);
      java.lang.String genVar934;
      genVar934="ae whith sr --> ok";
      Logger.log(genVar934);
    }
 catch (    Exception e) {
      e.printStackTrace();
      java.lang.String genVar935;
      genVar935="ae whith sr --> ko";
      Logger.log(genVar935);
    }
  }
  @Override public Element getModel(  AE_ModelId modelId) throws JDOMException, IOException, ContextManagerParserException {
    AdaptationEngineWithServiceRepository genVar936;
    genVar936=this;
    ServiceRepository sr;
    sr=genVar936.getSR(currentUser);
    Element model;
    model=sr.getModel(modelId);
    boolean genVar937;
    genVar937=model == null;
    if (genVar937) {
      org.jdom2.Element genVar938;
      genVar938=cm.getAllUser();
      return genVar938;
    }
 else {
      ;
    }
    return model;
  }
  @Override public void launchListeners(  String rulesPath,  FileListener listener){
  }
  public boolean isDeconnected() throws JDOMException, IOException, ContextManagerParserException {
    AdaptationEngineWithServiceRepository genVar939;
    genVar939=this;
    ServiceRepository sr;
    sr=genVar939.getSR(currentUser);
    boolean genVar940;
    genVar940=sr.isDeconectedMode();
    return genVar940;
  }
  @Override protected void replaceModel(  AE_Target modelToUpdate) throws JDOMException, IOException, ContextManagerParserException {
    AdaptationEngineWithServiceRepository genVar941;
    genVar941=this;
    ServiceRepository sr;
    sr=genVar941.getSR(currentUser);
    rulesEngine.manager.AE_ModelId genVar942;
    genVar942=modelToUpdate.getModelId();
    org.jdom2.Document genVar943;
    genVar943=modelToUpdate.getModel();
    org.jdom2.Document genVar944;
    genVar944=genVar943.getDocument();
    sr.updateModel(genVar942,genVar944);
  }
}
