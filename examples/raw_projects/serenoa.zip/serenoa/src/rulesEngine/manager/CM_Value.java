package rulesEngine.manager;
public class CM_Value {
  public CM_Value(  String deviceTypeParameter,  String deviceCategory){
  }
  public String getValue(){
    return null;
  }
  public String getKey(){
    return null;
  }
  public String getType(){
    return null;
  }
}
