package rulesEngine.manager;
public class SERENOA_CONSTANTES {
  public static final String LANGUAGE_PARAMETER=null;
  public static final String SERENOA_MODE_PREFIX=null;
  public static final String DEVICE_TYPE_PARAMETER=null;
  public static final String SERENOA_AE_PARAM=null;
  public static final String SERENOA_PARSER_NAME=null;
  public static final String SERENOA_HIDDEN_FIELDS=null;
}
