package rulesEngine.manager;
public class AE_ModelId {
  public AE_ModelId(  Object env){
  }
  public AE_ModelId(  String modelId,  boolean b){
  }
  public String getId(){
    return null;
  }
  public boolean isContextManager(){
    boolean genVar945;
    genVar945=false;
    return genVar945;
  }
}
