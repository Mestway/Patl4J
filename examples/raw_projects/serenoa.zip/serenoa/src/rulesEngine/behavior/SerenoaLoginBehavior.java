package rulesEngine.behavior;
import java.io.IOException;
import leon.app.LySession;
import leon.app.behavior.LyLoginBehavior;
import leon.control.LyLoginController;
import leon.data.LyObject;
import leon.view.event.LyParameterValues;
import leon.view.web.LyWebSession;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import rulesEngine.manager.AE_ModelId;
import rulesEngine.manager.AdaptationEngine;
import rulesEngine.manager.ContextManager;
import rulesEngine.manager.ContextManagerParserException;
import rulesEngine.manager.SERENOA_CONSTANTES;
public class SerenoaLoginBehavior extends LyLoginBehavior {
  @Override public void endLogin(  LyLoginController loginController,  LyParameterValues values){
    LySession session;
    session=loginController.getSession();
    java.lang.Object genVar0;
    genVar0=loginController.getStatus();
    boolean genVar1;
    genVar1=genVar0 == LyLoginController.Status.LOGIN_OK;
    if (genVar1) {
      SerenoaLoginBehavior genVar2;
      genVar2=this;
      LyObject user;
      user=genVar2.getUser(loginController,values);
      boolean genVar3;
      genVar3=user == null;
      if (genVar3) {
        return;
      }
 else {
        ;
      }
      java.lang.String genVar4;
      genVar4=user.getId();
      java.lang.String genVar5;
      genVar5=genVar4.toString();
      String userName;
      userName=ContextManager.transformLeonardiId(genVar5);
      rulesEngine.behavior.SerenoaSessionBehavior genVar6;
      genVar6=session.getSessionBehavior();
      rulesEngine.behavior.SerenoaSessionBehavior genVar7;
      genVar7=(SerenoaSessionBehavior)genVar6;
      SerenoaSessionBehavior genVar8;
      genVar8=(genVar7);
      AdaptationEngine ae;
      ae=genVar8.getAdaptationEngine();
      try {
        ContextManager cm;
        cm=ae.getCm();
        String serenoaLanguage;
        serenoaLanguage=cm.getValue(userName,SERENOA_CONSTANTES.LANGUAGE_PARAMETER);
        boolean genVar9;
        genVar9=serenoaLanguage != null;
        if (genVar9) {
          session.setLanguage(serenoaLanguage);
        }
 else {
          ;
        }
        boolean genVar10;
        genVar10=session instanceof LyWebSession;
        if (genVar10) {
          leon.app.LyEnvironment genVar11;
          genVar11=session.getEnvironment();
          java.lang.String genVar12;
          genVar12="daltonize";
          java.lang.String genVar13;
          genVar13=SERENOA_CONSTANTES.SERENOA_MODE_PREFIX + genVar12;
          java.lang.String genVar14;
          genVar14=genVar11.getEnv(genVar13);
          boolean daltonizeMode;
          daltonizeMode=new Boolean(genVar14);
          if (daltonizeMode) {
            java.lang.String genVar15;
            genVar15="aqualight";
            session.setSkin(genVar15);
          }
 else {
            leon.app.LyEnvironment genVar16;
            genVar16=session.getEnvironment();
            java.lang.String genVar17;
            genVar17="SERENOA_W4_CONFIG_ID";
            java.lang.String genVar18;
            genVar18=genVar16.getEnv(genVar17);
            rulesEngine.manager.AE_ModelId genVar19;
            genVar19=new AE_ModelId(genVar18);
            Element w4Model;
            w4Model=ae.getModel(genVar19);
            java.lang.String genVar20;
            genVar20="skin";
            String newSkin;
            newSkin=w4Model.getChildText(genVar20);
            boolean genVar21;
            genVar21=newSkin != null;
            if (genVar21) {
              session.setSkin(newSkin);
            }
 else {
              ;
            }
          }
          rulesEngine.behavior.SerenoaSessionBehavior genVar22;
          genVar22=session.getSessionBehavior();
          SerenoaSessionBehavior sessionBehavior;
          sessionBehavior=(SerenoaSessionBehavior)genVar22;
          sessionBehavior.updateSessionAndUser();
          sessionBehavior.updateModels();
        }
 else {
          ;
        }
      }
 catch (      JDOMException e) {
        e.printStackTrace();
      }
catch (      IOException e) {
        e.printStackTrace();
      }
catch (      ContextManagerParserException e) {
        e.printStackTrace();
      }
    }
 else {
      ;
    }
    super.endLogin(loginController,values);
  }
}
