package rulesEngine.behavior;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import leon.app.LyApplication;
import leon.app.LySession;
import leon.app.behavior.LySessionBehavior;
import leon.info.LyFieldInfo;
import leon.info.LyInfo;
import leon.info.LyInfoParser;
import leon.info.LyInfoParser.Type;
import leon.view.web.LyWebSession;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.xpath.XPath;
import org.jdom2.xpath.jaxen.JDOMXPath;
import rulesEngine.listener.SerenoaListener;
import rulesEngine.manager.AE_ModelId;
import rulesEngine.manager.AdaptationEngine;
import rulesEngine.manager.AdaptationEngineDeconected;
import rulesEngine.manager.AdaptationEngineWithServiceRepository;
import rulesEngine.manager.AdaptationEngineWithServiceRepositoryAndAE;
import rulesEngine.manager.CM_Ids;
import rulesEngine.manager.CM_Value;
import rulesEngine.manager.ContextManager;
import rulesEngine.manager.SERENOA_CONSTANTES;
import rulesEngine.utils.FileUtils;
import rulesEngine.utils.Logger;
public class SerenoaSessionBehavior extends LySessionBehavior {
  private LySession session;
  private AdaptationEngine ae;
  private Element w4Model;
  private HttpServletRequest request;
  private String currentUser;
  public SerenoaSessionBehavior(){
  }
  public void updateSessionAndUser(){
    LyWebSession webSession;
    webSession=(LyWebSession)session;
    request=webSession.getCurrentRequest();
    String user;
    leon.data.LyObject genVar23;
    genVar23=session.getUser();
    boolean genVar24;
    genVar24=genVar23 == null;
    if (genVar24) {
      java.lang.String genVar25;
      genVar25="w4";
      javax.servlet.http.HttpSession genVar26;
      genVar26=request.getSession();
      java.lang.String genVar27;
      genVar27=genVar26.getId();
      user=genVar25 + genVar27;
    }
 else {
      leon.data.LyObject genVar28;
      genVar28=session.getUser();
      java.lang.String genVar29;
      genVar29=genVar28.getId();
      java.lang.String genVar30;
      genVar30="\\\\";
      java.lang.String genVar31;
      genVar31="_";
      user=genVar29.replaceAll(genVar30,genVar31);
    }
    currentUser=user;
  }
  @Override public void start(  LySession session){
    rulesEngine.behavior.SerenoaSessionBehavior genVar32;
    genVar32=this;
    genVar32.session=session;
    boolean debug;
    debug=true;
    if (debug) {
      Logger.init(session);
    }
 else {
      ;
    }
    java.lang.String genVar33;
    genVar33="Start session behavior";
    Logger.log(genVar33);
    boolean genVar34;
    genVar34=session instanceof LyWebSession;
    boolean genVar35;
    genVar35=(genVar34);
    boolean genVar36;
    genVar36=!genVar35;
    if (genVar36) {
      java.lang.String genVar37;
      genVar37="Can't load rules when the session isn't a web session";
      Logger.log(genVar37);
      return;
    }
 else {
      ;
    }
    SerenoaSessionBehavior genVar38;
    genVar38=this;
    genVar38.updateSessionAndUser();
    leon.app.LyEnvironment genVar39;
    genVar39=session.getEnvironment();
    java.lang.String genVar40;
    genVar40="SERENOA_RULES_PATH";
    java.lang.String genVar41;
    genVar41=genVar39.getEnv(genVar40);
    String serenoaRulesPath;
    serenoaRulesPath=request.getRealPath(genVar41);
    try {
      java.lang.String genVar42;
      genVar42="AE + CM";
      Logger.log(genVar42);
      leon.app.LyEnvironment genVar43;
      genVar43=session.getEnvironment();
      java.lang.String genVar44;
      genVar44="SERENOA_CONTEXT_MANAGER_URI";
      java.lang.String genVar45;
      genVar45=genVar43.getEnv(genVar44);
      leon.app.LyEnvironment genVar46;
      genVar46=session.getEnvironment();
      java.lang.String genVar47;
      genVar47="SERENOA_SERVICE_REPOSITORY_URI";
      java.lang.String genVar48;
      genVar48=genVar46.getEnv(genVar47);
      boolean genVar49;
      genVar49=false;
      boolean genVar50;
      genVar50=false;
      leon.app.LyEnvironment genVar51;
      genVar51=session.getEnvironment();
      java.lang.String genVar52;
      genVar52="SERENOA_ADAPTATION_ENGINE_URI";
      java.lang.String genVar53;
      genVar53=genVar51.getEnv(genVar52);
      ae=new AdaptationEngineWithServiceRepositoryAndAE(serenoaRulesPath,genVar45,genVar48,genVar49,genVar50,currentUser,genVar53);
      java.lang.String genVar54;
      genVar54="AE + CM (success) ";
      Logger.log(genVar54);
      rulesEngine.manager.AdaptationEngineWithServiceRepository genVar55;
      genVar55=(AdaptationEngineWithServiceRepository)ae;
      AdaptationEngineWithServiceRepository genVar56;
      genVar56=(genVar55);
      boolean genVar57;
      genVar57=genVar56.isDeconnected();
      if (genVar57) {
        leon.app.LyEnvironment genVar58;
        genVar58=session.getEnvironment();
        java.lang.String genVar59;
        genVar59="SERENOA_CONTEXT_MANAGER_URI";
        java.lang.String genVar60;
        genVar60=genVar58.getEnv(genVar59);
        boolean genVar61;
        genVar61=false;
        boolean genVar62;
        genVar62=false;
        ae=new AdaptationEngineDeconected(serenoaRulesPath,genVar60,genVar61,genVar62,currentUser);
        java.lang.String genVar63;
        genVar63="Adaption engine ko ==> ! DECONNECTED MODE !";
        Logger.log(genVar63);
      }
 else {
        ;
      }
    }
 catch (    Exception e) {
      e.printStackTrace();
      java.lang.String genVar64;
      genVar64="Failed to load ae";
      Logger.log(genVar64);
    }
    ContextManager cm;
    cm=ae.getCm();
    java.lang.String genVar65;
    genVar65="User-Agent";
    java.lang.String genVar66;
    genVar66=request.getHeader(genVar65);
    String userAgent;
    userAgent=genVar66.toLowerCase();
    java.lang.String genVar67;
    genVar67="android";
    boolean genVar68;
    genVar68=userAgent.contains(genVar67);
    java.lang.String genVar69;
    genVar69="blackberry";
    boolean genVar70;
    genVar70=userAgent.contains(genVar69);
    java.lang.String genVar71;
    genVar71="iphone";
    boolean genVar72;
    genVar72=userAgent.contains(genVar71);
    java.lang.String genVar73;
    genVar73="ipad";
    boolean genVar74;
    genVar74=userAgent.contains(genVar73);
    java.lang.String genVar75;
    genVar75="ipod";
    boolean genVar76;
    genVar76=userAgent.contains(genVar75);
    java.lang.String genVar77;
    genVar77="iemobile";
    boolean genVar78;
    genVar78=userAgent.contains(genVar77);
    boolean mobile;
    mobile=genVar68 || genVar70 || genVar72|| genVar74|| genVar76|| genVar78;
    java.lang.String genVar79;
    genVar79="smartphone";
    java.lang.String genVar80;
    genVar80="desktop";
    String deviceCategory;
    deviceCategory=mobile ? genVar79 : genVar80;
    CM_Ids userIds;
    try {
      boolean genVar81;
      genVar81=true;
      userIds=cm.createUser(currentUser,genVar81);
      rulesEngine.manager.CM_Value genVar82;
      genVar82=new CM_Value(SERENOA_CONSTANTES.DEVICE_TYPE_PARAMETER,deviceCategory);
      cm.setValue(userIds,genVar82);
    }
 catch (    Exception e) {
      e.printStackTrace();
      java.lang.String genVar83;
      genVar83="Failed to create user";
      Logger.log(genVar83);
    }
    SerenoaSessionBehavior genVar84;
    genVar84=this;
    genVar84.updateModels();
    leon.app.LyEnvironment genVar85;
    genVar85=session.getEnvironment();
    java.lang.String genVar86;
    genVar86="SERENOA_RULES_PATH";
    java.lang.String genVar87;
    genVar87=genVar85.getEnv(genVar86);
    java.lang.String genVar88;
    genVar88=request.getRealPath(genVar87);
    rulesEngine.behavior.SerenoaSessionBehavior genVar89;
    genVar89=this;
    rulesEngine.listener.SerenoaListener genVar90;
    genVar90=new SerenoaListener(genVar89);
    ae.launchListeners(genVar88,genVar90);
    session.addValue(SERENOA_CONSTANTES.SERENOA_AE_PARAM,ae);
    super.start(session);
  }
  public void updateModels(){
    try {
      ae.loadModels(currentUser);
      ae.executeRules();
      leon.app.LyEnvironment genVar91;
      genVar91=session.getEnvironment();
      java.lang.String genVar92;
      genVar92="SERENOA_W4_CONFIG_ID";
      java.lang.String genVar93;
      genVar93=genVar91.getEnv(genVar92);
      rulesEngine.manager.AE_ModelId genVar94;
      genVar94=new AE_ModelId(genVar93);
      w4Model=ae.getModel(genVar94);
      boolean genVar95;
      genVar95=w4Model == null;
      if (genVar95) {
        return;
      }
 else {
        ;
      }
      String content;
      content="";
      SerenoaSessionBehavior genVar96;
      genVar96=this;
      java.lang.Class genVar97;
      genVar97=genVar96.getClass();
      java.lang.String genVar98;
      genVar98="/";
      leon.app.LyEnvironment genVar99;
      genVar99=session.getEnvironment();
      java.lang.String genVar100;
      genVar100="LY_PROJECT_FILE";
      java.lang.String genVar101;
      genVar101=genVar99.getEnv(genVar100);
      java.lang.String genVar102;
      genVar102="\\\\";
      java.lang.String genVar103;
      genVar103="/";
      java.lang.String genVar104;
      genVar104=genVar101.replaceAll(genVar102,genVar103);
      java.lang.String genVar105;
      genVar105=genVar98 + genVar104;
      InputStream file;
      file=genVar97.getResourceAsStream(genVar105);
      try {
        content=FileUtils.getInputStreamAsString(file);
      }
 catch (      IOException e) {
        e.printStackTrace();
        java.lang.String genVar106;
        genVar106="Failed to get project file";
        Logger.log(genVar106);
      }
      java.lang.String genVar107;
      genVar107="<!ENTITY\\s+([^\\s]*)\\s+[^>]*>";
      Pattern p;
      p=Pattern.compile(genVar107);
      Matcher m;
      m=p.matcher(content);
      boolean genVar108;
      genVar108=m.find();
      while (genVar108) {
        leon.app.LyEnvironment genVar109;
        genVar109=session.getEnvironment();
        java.lang.String genVar110;
        genVar110="SERENOA_ENTITY_TO_MODEL_ID#";
        int genVar111;
        genVar111=1;
        java.lang.String genVar112;
        genVar112=m.group(genVar111);
        java.lang.String genVar113;
        genVar113=genVar110 + genVar112;
        String replacement;
        replacement=genVar109.getEnv(genVar113);
        boolean genVar114;
        genVar114=replacement != null;
        if (genVar114) {
          java.lang.String genVar115;
          genVar115=".xml";
          String fileName;
          fileName=replacement + genVar115;
          leon.app.LyEnvironment genVar116;
          genVar116=session.getEnvironment();
          java.lang.String genVar117;
          genVar117="LY_APP_DIR";
          java.lang.String genVar118;
          genVar118=genVar116.getEnv(genVar117);
          java.lang.String genVar119;
          genVar119="/tmp/";
          String modelPath;
          modelPath=genVar118 + genVar119 + fileName;
          rulesEngine.manager.AE_ModelId genVar120;
          genVar120=new AE_ModelId(replacement);
          ae.printModel(modelPath,genVar120);
          java.lang.String genVar121;
          genVar121="(<!ENTITY\\s+";
          int genVar122;
          genVar122=1;
          java.lang.String genVar123;
          genVar123=m.group(genVar122);
          java.lang.String genVar124;
          genVar124="\\s+SYSTEM\\s+)[^>]*(\\s*>)";
          java.lang.String genVar125;
          genVar125=genVar121 + genVar123 + genVar124;
          java.lang.String genVar126;
          genVar126="$1'";
          java.lang.String genVar127;
          genVar127="'$2";
          java.lang.String genVar128;
          genVar128=genVar126 + fileName + genVar127;
          content=content.replaceFirst(genVar125,genVar128);
        }
 else {
          ;
        }
      }
      leon.app.LyEnvironment genVar129;
      genVar129=session.getEnvironment();
      java.lang.String genVar130;
      genVar130="LY_APP_DIR";
      java.lang.String genVar131;
      genVar131=genVar129.getEnv(genVar130);
      java.lang.String genVar132;
      genVar132="/tmp/w4root.xml";
      String rootPath;
      rootPath=genVar131 + genVar132;
      FileUtils.setFileFromString(rootPath,content);
      java.lang.String genVar133;
      genVar133="serenoa copy";
      LyApplication serenoaApp;
      serenoaApp=new LyApplication(genVar133);
      try {
        boolean genVar134;
        genVar134=true;
        LyInfoParser parser;
        parser=new LyInfoParser(serenoaApp,rootPath,Type.DEFAULT,genVar134);
        session.addValue(SERENOA_CONSTANTES.SERENOA_PARSER_NAME,parser);
      }
 catch (      Exception e) {
        java.lang.String genVar135;
        genVar135="impossible to complete the w4 parser";
        Logger.log(genVar135);
        e.printStackTrace();
      }
      java.lang.String genVar136;
      genVar136="Models updated";
      Logger.log(genVar136);
      SerenoaSessionBehavior genVar137;
      genVar137=this;
      genVar137.updateModes();
    }
 catch (    Exception e1) {
      e1.printStackTrace();
      java.lang.String genVar138;
      genVar138="error while updating the models";
      Logger.log(genVar138);
    }
  }
  private void updateModes(){
    try {
      List<String> fieldsToHide;
      fieldsToHide=new ArrayList<String>();
      boolean genVar139;
      genVar139=w4Model != null;
      if (genVar139) {
        java.lang.String genVar140;
        genVar140="//mode";
        XPath xpa;
        xpa=new JDOMXPath(genVar140);
        java.util.List genVar141;
        genVar141=xpa.selectNodes(w4Model);
        List<Element> elements;
        elements=(List<Element>)genVar141;
        for (        Element element : elements) {
          java.util.List<org.jdom2.Element> genVar142;
          genVar142=element.getChildren();
          int genVar143;
          genVar143=0;
          org.jdom2.Element genVar144;
          genVar144=genVar142.get(genVar143);
          java.lang.String genVar145;
          genVar145=genVar144.getName();
          java.lang.String genVar146;
          genVar146="true";
          boolean modeActive;
          modeActive=genVar145.equals(genVar146);
          java.lang.String genVar147;
          genVar147="type";
          String elementType;
          elementType=element.getAttributeValue(genVar147);
          leon.app.LyEnvironment genVar148;
          genVar148=session.getEnvironment();
          java.lang.String genVar149;
          genVar149=SERENOA_CONSTANTES.SERENOA_MODE_PREFIX + elementType;
          genVar148.putEnv(genVar149,modeActive);
        }
        java.lang.String genVar150;
        genVar150="//field_id";
        xpa=new JDOMXPath(genVar150);
        java.util.List genVar151;
        genVar151=xpa.selectNodes(w4Model);
        elements=(List<Element>)genVar151;
        for (        Element element : elements) {
          java.lang.String genVar152;
          genVar152=element.getText();
          fieldsToHide.add(genVar152);
        }
      }
 else {
        ;
      }
      session.addValue(SERENOA_CONSTANTES.SERENOA_HIDDEN_FIELDS,fieldsToHide);
    }
 catch (    JDOMException e) {
      java.lang.String genVar153;
      genVar153="Can't read w4client model cause by ";
      java.lang.String genVar154;
      genVar154=e.getMessage();
      java.lang.String genVar155;
      genVar155="  All modes set to false";
      java.lang.String genVar156;
      genVar156=genVar153 + genVar154 + genVar155;
      Logger.log(genVar156);
    }
  }
  public static LyFieldInfo getSerenoaFieldInfo(  LySession session,  LyFieldInfo fieldInfo){
    leon.info.LyFieldInfo genVar158;
    genVar158=fieldInfo.getId();
    leon.info.LyFieldInfo genVar159;
    genVar159=getSerenoaFieldInfo(session,genVar158);
    return genVar159;
  }
  public static LyFieldInfo getSerenoaFieldInfo(  LySession session,  String fieldInfoId){
    leon.info.LyInfoParser genVar160;
    genVar160=session.getValue(SERENOA_CONSTANTES.SERENOA_PARSER_NAME);
    LyInfoParser parser;
    parser=(LyInfoParser)genVar160;
    leon.info.LyInfoList<leon.info.LyInfo> genVar161;
    genVar161=parser.getResults();
    leon.info.LyInfo genVar162;
    genVar162=genVar161.getInfo(fieldInfoId);
    leon.info.LyFieldInfo genVar163;
    genVar163=(LyFieldInfo)genVar162;
    return genVar163;
  }
  public static LyInfo getSerenoaInfo(  LySession session,  String classInfoId){
    leon.info.LyInfoParser genVar164;
    genVar164=session.getValue(SERENOA_CONSTANTES.SERENOA_PARSER_NAME);
    LyInfoParser parser;
    parser=(LyInfoParser)genVar164;
    leon.info.LyInfoList<leon.info.LyInfo> genVar165;
    genVar165=parser.getResults();
    leon.info.LyInfo genVar166;
    genVar166=genVar165.getInfo(classInfoId);
    return genVar166;
  }
  public AdaptationEngine getAdaptationEngine(){
    return ae;
  }
}
