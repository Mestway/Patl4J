package leon.info;
public class LyInfoList<T> {
  public LyInfo getInfo(  String classInfoId){
    return null;
  }
}
