package leon.info;
public class LyFieldInfo extends LyInfo {
  public LyFieldInfo getId(){
    return null;
  }
}
