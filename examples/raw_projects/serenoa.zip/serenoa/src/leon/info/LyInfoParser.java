package leon.info;
import leon.app.LyApplication;
public class LyInfoParser {
  public LyInfoParser(  LyApplication serenoaApp,  String rootPath,  String default1,  boolean b){
  }
public static class Type {
    public static final String DEFAULT=null;
  }
  public LyInfoList<LyInfo> getResults(){
    return null;
  }
}
