package leon.info;
public class LyInfo {
}
