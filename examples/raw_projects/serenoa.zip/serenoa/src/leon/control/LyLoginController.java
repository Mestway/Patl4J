package leon.control;
import leon.app.LySession;
public class LyLoginController {
public static class Status {
    public static final Object LOGIN_OK=null;
  }
  public LySession getSession(){
    return null;
  }
  public Object getStatus(){
    return null;
  }
}
