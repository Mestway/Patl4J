package leon.app.behavior;
import leon.control.LyLoginController;
import leon.data.LyObject;
import leon.view.event.LyParameterValues;
public class LyLoginBehavior {
  public void endLogin(  LyLoginController loginController,  LyParameterValues values){
  }
  public LyObject getUser(  LyLoginController loginController,  LyParameterValues values){
    return null;
  }
}
