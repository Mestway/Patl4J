package leon.app.behavior;
import leon.app.LySession;
public class LySessionBehavior {
  public void start(  LySession session){
  }
}
