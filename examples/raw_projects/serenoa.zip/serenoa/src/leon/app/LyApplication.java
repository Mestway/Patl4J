package leon.app;
public class LyApplication {
  public LyApplication(  String string){
  }
}
