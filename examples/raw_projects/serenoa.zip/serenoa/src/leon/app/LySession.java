package leon.app;
import java.util.List;
import leon.data.LyObject;
import leon.info.LyInfoParser;
import rulesEngine.behavior.SerenoaSessionBehavior;
import rulesEngine.manager.AdaptationEngine;
public class LySession {
  public SerenoaSessionBehavior getSessionBehavior(){
    return null;
  }
  public void setLanguage(  String serenoaLanguage){
  }
  public LyEnvironment getEnvironment(){
    return null;
  }
  public void setSkin(  String string){
  }
  public LyObject getUser(){
    return null;
  }
  public void addValue(  String serenoaAeParam,  LyInfoParser parser){
  }
  public void addValue(  String serenoaAeParam,  AdaptationEngine ae){
  }
  public void addValue(  String serenoaHiddenFields,  List<String> fieldsToHide){
  }
  public LyInfoParser getValue(  String serenoaParserName){
    return null;
  }
}
