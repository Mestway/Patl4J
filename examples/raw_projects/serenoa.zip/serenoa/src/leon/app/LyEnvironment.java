package leon.app;
public class LyEnvironment {
  public String getEnv(  String string){
    return null;
  }
  public void putEnv(  String string,  boolean modeActive){
  }
}
