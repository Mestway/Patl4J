package leon.view.web;
import javax.servlet.http.HttpServletRequest;
import leon.app.LySession;
public class LyWebSession extends LySession {
  public HttpServletRequest getCurrentRequest(){
    return null;
  }
}
