package leon.data;
public class LyObject {
  public String getId(){
    return null;
  }
}
