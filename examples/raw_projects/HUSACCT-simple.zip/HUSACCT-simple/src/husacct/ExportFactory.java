package husacct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.jdom2.Element;
public class ExportFactory {
  public Element exportSeverities(  List<Severity> severities){
    return null;
  }
  public Element exportSeveritiesPerTypesPerProgrammingLanguages(  HashMap<String,HashMap<String,Severity>> allSeveritiesPerTypesPerProgrammingLanguages){
    return null;
  }
  public Element exportActiveViolationTypes(  Map<String,List<ActiveRuleType>> activeViolationTypes){
    return null;
  }
}
