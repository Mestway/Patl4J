package husacct;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Observer;
import java.util.Set;
import javax.xml.datatype.DatatypeConfigurationException;
import org.jdom2.Element;
public class TaskServiceImpl {
  public void importValidationWorkspace(  Element element) throws DatatypeConfigurationException {
  }
  public Element exportValidationWorkspace(){
    return null;
  }
}
