package husacct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.jdom2.Element;
public class AnalyseServiceStub {
  public Element getWorkspaceData(){
    return null;
  }
  public void loadWorkspaceData(  Element root){
  }
}
