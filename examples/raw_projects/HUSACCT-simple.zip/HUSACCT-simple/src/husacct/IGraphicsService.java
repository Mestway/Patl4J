package husacct;
import org.jdom2.Element;
public interface IGraphicsService {
  Element getWorkspaceData();
  void loadWorkspaceData(  Element workspaceData);
}
