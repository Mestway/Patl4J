package husacct;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.jdom2.Attribute;
import org.jdom2.Element;
public class ExportActiveViolationTypes {
  public Element exportActiveViolationTypes(){
    java.lang.String genVar748;
    genVar748="activeViolationTypes";
    Element activeViolationTypesElement;
    activeViolationTypesElement=new Element(genVar748);
    java.lang.String genVar749;
    genVar749="";
    activeViolationTypesElement.addContent(genVar749);
    return null;
  }
  private Element createActiveViolationTypeElement(){
    java.lang.String genVar750;
    genVar750="activeViolationType";
    Element activeViolationTypeElement;
    activeViolationTypeElement=new Element(genVar750);
    java.lang.String genVar751;
    genVar751="language";
    org.jdom2.Attribute genVar752;
    genVar752=new Attribute(genVar751,null);
    activeViolationTypeElement.setAttribute(genVar752);
    java.lang.String genVar753;
    genVar753="";
    activeViolationTypeElement.addContent(genVar753);
    return activeViolationTypeElement;
  }
  private Element createActiveRuleTypeElement(){
    java.lang.String genVar754;
    genVar754="ruleType";
    Element ruleTypeElement;
    ruleTypeElement=new Element(genVar754);
    java.lang.String genVar755;
    genVar755="type";
    java.lang.String genVar756;
    genVar756="";
    org.jdom2.Attribute genVar757;
    genVar757=new Attribute(genVar755,genVar756);
    ruleTypeElement.setAttribute(genVar757);
    java.lang.String genVar758;
    genVar758="violationTypes";
    Element violationTypesElement;
    violationTypesElement=new Element(genVar758);
    ruleTypeElement.addContent(violationTypesElement);
    java.lang.String genVar759;
    genVar759="violationType";
    Element violationTypeElement;
    violationTypeElement=new Element(genVar759);
    java.lang.String genVar760;
    genVar760="";
    violationTypeElement.addContent(genVar760);
    java.lang.String genVar761;
    genVar761="";
    violationTypeElement.addContent(genVar761);
    violationTypesElement.addContent(violationTypeElement);
    return ruleTypeElement;
  }
}
