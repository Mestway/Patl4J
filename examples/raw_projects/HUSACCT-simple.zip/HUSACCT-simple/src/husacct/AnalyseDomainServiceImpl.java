package husacct;
import org.jdom2.Element;
public class AnalyseDomainServiceImpl {
  private IModelPersistencyService persistencyService;
  public Element saveModel(){
    org.jdom2.Element genVar0;
    genVar0=persistencyService.saveModel();
    return genVar0;
  }
  public void loadModel(  Element analyseElement){
    persistencyService.loadModel(analyseElement);
  }
}
