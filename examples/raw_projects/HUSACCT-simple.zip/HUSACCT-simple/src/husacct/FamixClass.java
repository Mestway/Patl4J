package husacct;
public class FamixClass {
  public String uniqueName;
  public String name;
  public String belongsToPackage;
  public boolean isAbstract;
  public boolean isInnerClass;
}
