package husacct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.jdom2.Element;
public class ImportActiveViolationTypes {
  public Map<String,List<ActiveRuleType>> importActiveViolationTypes(  Element activeViolationTypesElement){
    Map<String,List<ActiveRuleType>> activeRuleTypesMap;
    activeRuleTypesMap=new HashMap<String,List<ActiveRuleType>>();
    java.util.List<org.jdom2.Element> genVar18;
    genVar18=activeViolationTypesElement.getChildren();
    for (    Element activeViolationTypeElement : genVar18) {
      List<ActiveRuleType> activeRuleTypes;
      activeRuleTypes=new ArrayList<ActiveRuleType>();
      java.util.List<org.jdom2.Element> genVar19;
      genVar19=activeViolationTypeElement.getChildren();
      for (      Element ruleTypeElement : genVar19) {
        java.lang.String genVar20;
        genVar20="type";
        String ruleTypeKey;
        ruleTypeKey=ruleTypeElement.getAttributeValue(genVar20);
        java.lang.String genVar21;
        genVar21="SuperClassInheritanceConvention";
        boolean genVar22;
        genVar22=ruleTypeKey.equals(genVar21);
        if (genVar22) {
          ruleTypeKey="InheritanceConvention";
        }
 else {
          ;
        }
        List<ActiveViolationType> activeViolationTypes;
        activeViolationTypes=new ArrayList<ActiveViolationType>();
        java.lang.String genVar23;
        genVar23="violationTypes";
        Element violationTypesElement;
        violationTypesElement=ruleTypeElement.getChild(genVar23);
        boolean genVar24;
        genVar24=violationTypesElement != null;
        if (genVar24) {
          java.lang.String genVar25;
          genVar25="violationType";
          java.util.List<org.jdom2.Element> genVar26;
          genVar26=violationTypesElement.getChildren(genVar25);
          for (          Element violationTypeElement : genVar26) {
            java.lang.String genVar27;
            genVar27="violationKey";
            String violationTypeKey;
            violationTypeKey=violationTypeElement.getChildText(genVar27);
            java.lang.String genVar28;
            genVar28="enabled";
            java.lang.String genVar29;
            genVar29=violationTypeElement.getChildText(genVar28);
            boolean enabled;
            enabled=Boolean.parseBoolean(genVar29);
            ActiveViolationType activeViolationType;
            activeViolationType=new ActiveViolationType(violationTypeKey,enabled);
            activeViolationTypes.add(activeViolationType);
          }
        }
 else {
          ;
        }
        java.lang.String genVar30;
        genVar30="InterfaceInheritanceConvention";
        boolean genVar31;
        genVar31=ruleTypeKey.equals(genVar30);
        boolean genVar32;
        genVar32=!genVar31;
        if (genVar32) {
          ActiveRuleType activeRuleType;
          activeRuleType=new ActiveRuleType(ruleTypeKey,activeViolationTypes);
          activeRuleTypes.add(activeRuleType);
        }
 else {
          ;
        }
      }
      java.lang.String genVar33;
      genVar33="language";
      java.lang.String genVar34;
      genVar34=activeViolationTypeElement.getAttributeValue(genVar33);
      activeRuleTypesMap.put(genVar34,activeRuleTypes);
    }
    return activeRuleTypesMap;
  }
}
