package husacct;
public class ModuleStrategy {
  public String getDescription(){
    return null;
  }
  public long getId(){
    int genVar726;
    genVar726=0;
    return genVar726;
  }
  public String getName(){
    return null;
  }
  public void set(  String moduleName,  String moduleDescription,  boolean fromStorage){
  }
  public void setId(  int moduleId){
  }
  public void addSUDefinition(  SoftwareUnitDefinition softwareUnitDefinitionFromXML){
  }
}
