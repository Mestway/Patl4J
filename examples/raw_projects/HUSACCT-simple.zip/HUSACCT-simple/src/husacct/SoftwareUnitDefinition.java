package husacct;
public class SoftwareUnitDefinition {
  public SoftwareUnitDefinition(  String text,  Object object){
  }
  public String getName(){
    return null;
  }
}
