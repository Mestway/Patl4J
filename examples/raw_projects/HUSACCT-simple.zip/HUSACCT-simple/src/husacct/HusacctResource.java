package husacct;
import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import org.jdom2.Document;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
public class HusacctResource {
  public Document load(  HashMap<String,Object> dataValues){
    java.lang.String genVar49;
    genVar49="file";
    java.lang.Object genVar50;
    genVar50=dataValues.get(genVar49);
    File file;
    file=(File)genVar50;
    SAXBuilder sax;
    sax=new SAXBuilder();
    Document doc;
    doc=new Document();
    try {
      doc=sax.build(file);
    }
 catch (    Exception e) {
    }
    return doc;
  }
  public boolean save(  Document doc,  HashMap<String,Object> dataValues){
    java.lang.String genVar51;
    genVar51="file";
    java.lang.Object genVar52;
    genVar52=dataValues.get(genVar51);
    File file;
    file=(File)genVar52;
    try {
      FileOutputStream outputStream;
      outputStream=new FileOutputStream(file);
      org.jdom2.output.Format genVar53;
      genVar53=Format.getPrettyFormat();
      XMLOutputter xout;
      xout=new XMLOutputter(genVar53);
      xout.output(doc,outputStream);
      outputStream.close();
      boolean genVar54;
      genVar54=true;
      return genVar54;
    }
 catch (    Exception e) {
      new RuntimeException(e);
    }
    boolean genVar55;
    genVar55=false;
    return genVar55;
  }
  public boolean save(  Document doc,  HashMap<String,Object> dataValues,  HashMap<String,Object> config){
    boolean genVar56;
    genVar56=false;
    return genVar56;
  }
}
