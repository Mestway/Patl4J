package husacct;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import org.jdom2.Attribute;
import org.jdom2.Content;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
public class resourceGatherer implements Runnable {
  public void run(){
    java.lang.String genVar787;
    genVar787="root";
    Element root;
    root=new Element(genVar787);
    String serviceName;
    serviceName="";
    Element container;
    container=new Element(serviceName);
    Element serviceData;
    serviceData=null;
    container.addContent(serviceData);
    root.addContent(container);
    new Document(root);
  }
  private int calculateNewNodeSize(  Document d){
    ByteArrayOutputStream os;
    os=new ByteArrayOutputStream();
    XMLOutputter xout;
    boolean genVar788;
    genVar788=true;
    if (genVar788) {
      org.jdom2.output.Format genVar789;
      genVar789=Format.getRawFormat();
      xout=new XMLOutputter(genVar789);
    }
 else {
      org.jdom2.output.Format genVar790;
      genVar790=Format.getPrettyFormat();
      xout=new XMLOutputter(genVar790);
    }
    try {
      xout.output(d,os);
      os.close();
      int genVar791;
      genVar791=os.size();
      int genVar792;
      genVar792=(genVar791);
      return genVar792;
    }
 catch (    Exception e) {
      e.printStackTrace();
    }
    int genVar793;
    genVar793=0;
    return genVar793;
  }
}
