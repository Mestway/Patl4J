package husacct;
import java.awt.Component;
import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeModel;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
public class HelpTreeModelLoader {
  public Document getXmlDocument() throws Exception {
    Reader reader;
    reader=new InputStreamReader(null);
    SAXBuilder sax;
    sax=new SAXBuilder();
    Document doc;
    doc=new Document();
    doc=sax.build(reader);
    return doc;
  }
  public DefaultMutableTreeNode getTreeModel() throws Exception {
    HelpTreeModelLoader genVar532;
    genVar532=this;
    org.jdom2.Document genVar533;
    genVar533=genVar532.getXmlDocument();
    Element root;
    root=genVar533.getRootElement();
    java.lang.String genVar534;
    genVar534=root.getName();
    DefaultMutableTreeNode parent;
    parent=new DefaultMutableTreeNode(genVar534);
    java.util.List<org.jdom2.Element> genVar535;
    genVar535=root.getChildren();
    for (    Element child : genVar535) {
      java.lang.String genVar536;
      genVar536="filename";
      java.lang.String genVar537;
      genVar537=child.getAttributeValue(genVar536);
      java.lang.String genVar538;
      genVar538="viewname";
      java.lang.String genVar539;
      genVar539=child.getAttributeValue(genVar538);
      java.lang.String genVar540;
      genVar540=child.getName();
      java.lang.String genVar541;
      genVar541="html";
      HelpTreeNode HelpNode;
      HelpNode=new HelpTreeNode(genVar537,genVar539,genVar540,genVar541);
      DefaultMutableTreeNode childNode;
      childNode=new DefaultMutableTreeNode(HelpNode);
      java.lang.Object genVar542;
      genVar542=HelpNode.getParent();
      boolean genVar543;
      genVar543=genVar542 == null;
      if (genVar543) {
        parent.add(childNode);
      }
 else {
        java.lang.Object genVar544;
        genVar544=HelpNode.getParent();
        java.lang.Object genVar545;
        genVar545=HelpNode.getParent();
        java.lang.Object genVar546;
        genVar546=HelpNode.getParent();
        java.lang.String genVar547;
        genVar547="folder";
        HelpTreeNode parentHelpNode;
        parentHelpNode=new HelpTreeNode(genVar544,genVar545,genVar546,genVar547);
        HelpTreeModelLoader genVar548;
        genVar548=this;
        DefaultMutableTreeNode parentNode;
        parentNode=genVar548.findNode(parent,parentHelpNode);
        parentNode.add(childNode);
        parent.add(parentNode);
      }
    }
    return parent;
  }
  private DefaultMutableTreeNode findNode(  DefaultMutableTreeNode parent,  HelpTreeNode parentHelpNode){
    return null;
  }
}
