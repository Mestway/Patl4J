package husacct;
public class FamixModel {
  public static FamixModel getInstance(){
    return null;
  }
}
