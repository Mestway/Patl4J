package husacct;
import java.util.ArrayList;
import org.jdom2.Element;
/** 
 * This class enabled the feature to have the domain stored in XML format
 */
public class PersistentDomain {
  public Element getWorkspaceData(){
    return null;
  }
  public void loadWorkspaceData(  Element workspaceData){
  }
}
