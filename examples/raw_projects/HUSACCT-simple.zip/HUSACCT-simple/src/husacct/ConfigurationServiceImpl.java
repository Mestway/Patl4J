package husacct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class ConfigurationServiceImpl {
  public List<Severity> getAllSeverities(){
    return null;
  }
  public HashMap<String,HashMap<String,Severity>> getAllSeveritiesPerTypesPerProgrammingLanguages(){
    return null;
  }
  public Map<String,List<ActiveRuleType>> getActiveViolationTypes(){
    return null;
  }
}
