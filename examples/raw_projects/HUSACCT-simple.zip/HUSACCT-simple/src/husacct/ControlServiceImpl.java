package husacct;
import java.awt.Component;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import javax.swing.JDialog;
import org.jdom2.Element;
public class ControlServiceImpl {
  public Element getWorkspaceData(){
    java.lang.String genVar727;
    genVar727="workspace";
    Element data;
    data=new Element(genVar727);
    java.lang.String genVar728;
    genVar728="name";
    java.lang.String genVar729;
    genVar729="";
    data.setAttribute(genVar728,genVar729);
    java.lang.String genVar730;
    genVar730="language";
    java.lang.String genVar731;
    genVar731="";
    data.setAttribute(genVar730,genVar731);
    return data;
  }
  public void loadWorkspaceData(  Element workspaceData){
    String languageName;
    languageName="en";
    try {
      java.lang.String genVar732;
      genVar732="name";
      String workspaceName;
      workspaceName=workspaceData.getAttributeValue(genVar732);
      java.lang.String genVar733;
      genVar733="language";
      languageName=workspaceData.getAttributeValue(genVar733);
    }
 catch (    Exception e) {
    }
    try {
    }
 catch (    Exception e) {
    }
  }
}
