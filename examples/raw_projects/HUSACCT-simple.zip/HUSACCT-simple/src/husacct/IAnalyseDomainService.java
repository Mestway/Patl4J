package husacct;
import java.util.HashMap;
import java.util.List;
import org.jdom2.Element;
public interface IAnalyseDomainService {
  public Element saveModel();
  public void loadModel(  Element analyseElement);
}
