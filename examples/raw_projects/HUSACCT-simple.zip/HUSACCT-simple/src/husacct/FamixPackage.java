package husacct;
public class FamixPackage {
  public String uniqueName;
  public String name;
  public String belongsToPackage;
}
