package husacct;
public class LogicalModules {
  public LogicalModules(  LogicalModule logicalModuleFrom,  LogicalModule logicalModuleTo){
  }
}
