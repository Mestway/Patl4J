package husacct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.xml.datatype.DatatypeConfigurationException;
import org.jdom2.Element;
public class ImportController {
  private List<Severity> severities;
  private ImportFactory importFactory;
  private ConfigurationServiceImpl configuration;
  public ImportController(  ConfigurationServiceImpl configuration){
    husacct.ImportController genVar645;
    genVar645=this;
    genVar645.configuration=configuration;
    husacct.ImportController genVar646;
    genVar646=this;
    genVar646.importFactory=new ImportFactory();
    husacct.ImportController genVar647;
    genVar647=this;
    genVar647.severities=new ArrayList<Severity>();
  }
  public void importWorkspace(  Element element) throws DatatypeConfigurationException {
    ImportController genVar648;
    genVar648=this;
    java.lang.String genVar649;
    genVar649="severities";
    org.jdom2.Element genVar650;
    genVar650=element.getChild(genVar649);
    genVar648.importSeverties(genVar650);
    ImportController genVar651;
    genVar651=this;
    java.lang.String genVar652;
    genVar652="severitiesPerTypesPerProgrammingLanguages";
    org.jdom2.Element genVar653;
    genVar653=element.getChild(genVar652);
    genVar651.importSeveritiesPerTypesPerProgrammingLanguages(genVar653);
    ImportController genVar654;
    genVar654=this;
    java.lang.String genVar655;
    genVar655="activeViolationTypes";
    org.jdom2.Element genVar656;
    genVar656=element.getChild(genVar655);
    genVar654.importActiveViolationTypes(genVar656);
  }
  private void importSeverties(  Element element){
  }
  private void importSeveritiesPerTypesPerProgrammingLanguages(  Element element){
  }
  private void importActiveViolationTypes(  Element element){
  }
}
