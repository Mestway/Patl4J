package husacct;
import java.io.File;
import java.util.HashMap;
import org.jdom2.Document;
import org.jdom2.Element;
public class ImportController2 {
  public void importArchitecture(  File file){
    Document doc;
    doc=null;
    Element logicalData;
    logicalData=doc.getRootElement();
  }
}
