package husacct;
public class Violation {
}
