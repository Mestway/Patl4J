package husacct;
public class FamixAttribute {
  public String uniqueName;
  public String name;
  public String belongsToClass;
  public String declareType;
}
