package husacct;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.jdom2.Element;
public class XMLDomain {
  private Element workspace;
  public XMLDomain(  Element workspaceData){
  }
  public Application createApplication(){
    try {
      List<Element> applicationProperties;
      applicationProperties=workspace.getChildren();
      int genVar257;
      genVar257=0;
      Element name;
      name=applicationProperties.get(genVar257);
      int genVar258;
      genVar258=1;
      Element version;
      version=applicationProperties.get(genVar258);
      int genVar259;
      genVar259=2;
      Element projects;
      projects=applicationProperties.get(genVar259);
      int genVar260;
      genVar260=3;
      Element architecture;
      architecture=applicationProperties.get(genVar260);
      XMLDomain genVar261;
      genVar261=this;
      ArrayList<Project> projectsList;
      projectsList=genVar261.getProjectsFromElement(projects);
    }
 catch (    Exception exe) {
    }
    return null;
  }
  private ArrayList<Project> getProjectsFromElement(  Element XMLElement){
    ArrayList<Project> projects;
    projects=new ArrayList<Project>();
    java.lang.String genVar262;
    genVar262="Project";
    java.util.List<org.jdom2.Element> genVar263;
    genVar263=XMLElement.getChildren(genVar262);
    for (    Element project : genVar263) {
      XMLDomain genVar264;
      genVar264=this;
      husacct.Project genVar265;
      genVar265=genVar264.getProjectFromElement(project);
      projects.add(genVar265);
    }
    return projects;
  }
  private Project getProjectFromElement(  Element XMLElement){
    Project project;
    project=new Project();
    java.lang.String genVar266;
    genVar266="name";
    org.jdom2.Element genVar267;
    genVar267=XMLElement.getChild(genVar266);
    java.lang.String genVar268;
    genVar268=genVar267.getText();
    project.setName(genVar268);
    java.lang.String genVar269;
    genVar269="programmingLanguage";
    org.jdom2.Element genVar270;
    genVar270=XMLElement.getChild(genVar269);
    java.lang.String genVar271;
    genVar271=genVar270.getText();
    project.setProgrammingLanguage(genVar271);
    java.lang.String genVar272;
    genVar272="version";
    org.jdom2.Element genVar273;
    genVar273=XMLElement.getChild(genVar272);
    java.lang.String genVar274;
    genVar274=genVar273.getText();
    project.setVersion(genVar274);
    java.lang.String genVar275;
    genVar275="description";
    org.jdom2.Element genVar276;
    genVar276=XMLElement.getChild(genVar275);
    java.lang.String genVar277;
    genVar277=genVar276.getText();
    project.setDescription(genVar277);
    ArrayList<String> projectPaths;
    projectPaths=new ArrayList<String>();
    java.lang.String genVar278;
    genVar278="paths";
    org.jdom2.Element genVar279;
    genVar279=XMLElement.getChild(genVar278);
    java.lang.String genVar280;
    genVar280="path";
    List<Element> pathElements;
    pathElements=genVar279.getChildren(genVar280);
    for (    Element path : pathElements) {
      java.lang.String genVar281;
      genVar281=path.getText();
      projectPaths.add(genVar281);
    }
    return project;
  }
  private void createArchitectureFromElement(  Element XMLElement){
    SoftwareArchitecture softwareArchitecture;
    softwareArchitecture=null;
    java.lang.String genVar282;
    genVar282="name";
    org.jdom2.Element genVar283;
    genVar283=XMLElement.getChild(genVar282);
    java.lang.String genVar284;
    genVar284=genVar283.getValue();
    softwareArchitecture.setName(genVar284);
    java.lang.String genVar285;
    genVar285="description";
    org.jdom2.Element genVar286;
    genVar286=XMLElement.getChild(genVar285);
    java.lang.String genVar287;
    genVar287=genVar286.getValue();
    softwareArchitecture.setDescription(genVar287);
    java.lang.String genVar288;
    genVar288="modules";
    org.jdom2.Element genVar289;
    genVar289=XMLElement.getChild(genVar288);
    java.util.List<org.jdom2.Element> genVar290;
    genVar290=genVar289.getChildren();
    int genVar291;
    genVar291=genVar290.size();
    int genVar292;
    genVar292=0;
    boolean genVar293;
    genVar293=genVar291 > genVar292;
    if (genVar293) {
      XMLDomain genVar294;
      genVar294=this;
      int genVar295;
      genVar295=0;
      long genVar296;
      genVar296=(long)genVar295;
      java.lang.String genVar297;
      genVar297="modules";
      org.jdom2.Element genVar298;
      genVar298=XMLElement.getChild(genVar297);
      genVar294.createModulesFromXML(genVar296,genVar298);
    }
 else {
      ;
    }
    java.lang.String genVar299;
    genVar299="rules";
    org.jdom2.Element genVar300;
    genVar300=XMLElement.getChild(genVar299);
    java.util.List<org.jdom2.Element> genVar301;
    genVar301=genVar300.getChildren();
    int genVar302;
    genVar302=genVar301.size();
    int genVar303;
    genVar303=0;
    boolean genVar304;
    genVar304=genVar302 > genVar303;
    if (genVar304) {
      XMLDomain genVar305;
      genVar305=this;
      java.lang.String genVar306;
      genVar306="rules";
      org.jdom2.Element genVar307;
      genVar307=XMLElement.getChild(genVar306);
      genVar305.createAppliedRulesFromXML(genVar307);
    }
 else {
      ;
    }
  }
  private void createModulesFromXML(  long parentId,  Element XMLElement){
    try {
      java.util.List<org.jdom2.Element> genVar308;
      genVar308=XMLElement.getChildren();
      for (      Element module : genVar308) {
        ModuleStrategy newModule;
        newModule=null;
        java.lang.String genVar309;
        genVar309="type";
        String moduleType;
        moduleType=module.getChildText(genVar309);
        java.lang.String genVar310;
        genVar310="description";
        String moduleDescription;
        moduleDescription=module.getChildText(genVar310);
        java.lang.String genVar311;
        genVar311="name";
        String moduleName;
        moduleName=module.getChildText(genVar311);
        java.lang.String genVar312;
        genVar312="SoftwareUnitDefinitions";
        Element SoftwareUnitDefinitions;
        SoftwareUnitDefinitions=module.getChild(genVar312);
        java.lang.String genVar313;
        genVar313="id";
        java.lang.String genVar314;
        genVar314=module.getChildText(genVar313);
        int moduleId;
        moduleId=Integer.parseInt(genVar314);
        boolean fromStorage;
        fromStorage=true;
        newModule.set(moduleName,moduleDescription,fromStorage);
        newModule.setId(moduleId);
        boolean genVar315;
        genVar315=SoftwareUnitDefinitions != null;
        if (genVar315) {
          java.lang.String genVar316;
          genVar316="SoftwareUnitDefinition";
          List<Element> SoftwareUnitDefinitionsList;
          SoftwareUnitDefinitionsList=SoftwareUnitDefinitions.getChildren(genVar316);
          Iterator SUDIterator;
          SUDIterator=SoftwareUnitDefinitionsList.iterator();
          boolean genVar317;
          genVar317=SUDIterator.hasNext();
          while (genVar317) {
            Object o;
            o=SUDIterator.next();
            boolean genVar318;
            genVar318=o instanceof Element;
            if (genVar318) {
              XMLDomain genVar319;
              genVar319=this;
              org.jdom2.Element genVar320;
              genVar320=(Element)o;
              husacct.SoftwareUnitDefinition genVar321;
              genVar321=genVar319.getSoftwareUnitDefinitionFromXML(genVar320);
              newModule.addSUDefinition(genVar321);
            }
 else {
              ;
            }
          }
        }
 else {
          ;
        }
        XMLDomain genVar322;
        genVar322=this;
        boolean genVar323;
        genVar323=genVar322.hasSubmodules(module);
        if (genVar323) {
          XMLDomain genVar324;
          genVar324=this;
          long genVar325;
          genVar325=newModule.getId();
          java.lang.String genVar326;
          genVar326="SubModules";
          org.jdom2.Element genVar327;
          genVar327=module.getChild(genVar326);
          genVar324.createModulesFromXML(genVar325,genVar327);
        }
 else {
          ;
        }
      }
    }
 catch (    Exception exe) {
    }
  }
  public SoftwareUnitDefinition getSoftwareUnitDefinitionFromXML(  Element e){
    java.lang.String genVar328;
    genVar328="name";
    Element SUDName;
    SUDName=e.getChild(genVar328);
    java.lang.String genVar329;
    genVar329="type";
    Element SUDType;
    SUDType=e.getChild(genVar329);
    java.lang.String genVar330;
    genVar330=SUDType.getValue();
    java.lang.String genVar331;
    genVar331=genVar330.toUpperCase();
    java.lang.String genVar332;
    genVar332="CLASS";
    boolean genVar333;
    genVar333=genVar331.equals(genVar332);
    if (genVar333) {
    }
 else {
      java.lang.String genVar334;
      genVar334=SUDType.getValue();
      java.lang.String genVar335;
      genVar335=genVar334.toUpperCase();
      java.lang.String genVar336;
      genVar336="INTERFACE";
      boolean genVar337;
      genVar337=genVar335.equals(genVar336);
      if (genVar337) {
      }
 else {
        java.lang.String genVar338;
        genVar338=SUDType.getValue();
        java.lang.String genVar339;
        genVar339=genVar338.toUpperCase();
        java.lang.String genVar340;
        genVar340="EXTERNALLIBRARY";
        boolean genVar341;
        genVar341=genVar339.equals(genVar340);
        if (genVar341) {
        }
 else {
          java.lang.String genVar342;
          genVar342=SUDType.getValue();
          java.lang.String genVar343;
          genVar343=genVar342.toUpperCase();
          java.lang.String genVar344;
          genVar344="LIBRARY";
          boolean genVar345;
          genVar345=genVar343.equals(genVar344);
          if (genVar345) {
          }
 else {
            java.lang.String genVar346;
            genVar346=SUDType.getValue();
            java.lang.String genVar347;
            genVar347=genVar346.toUpperCase();
            java.lang.String genVar348;
            genVar348="PACKAGE";
            boolean genVar349;
            genVar349=genVar347.equals(genVar348);
            if (genVar349) {
            }
 else {
              java.lang.String genVar350;
              genVar350=SUDType.getValue();
              java.lang.String genVar351;
              genVar351=genVar350.toUpperCase();
              java.lang.String genVar352;
              genVar352="SUBSYSTEM";
              boolean genVar353;
              genVar353=genVar351.equals(genVar352);
              if (genVar353) {
              }
 else {
              }
            }
          }
        }
      }
    }
    java.lang.String genVar354;
    genVar354=SUDName.getText();
    husacct.SoftwareUnitDefinition genVar355;
    genVar355=new SoftwareUnitDefinition(genVar354,null);
    return genVar355;
  }
  private boolean hasSubmodules(  Element XMLElement){
    java.lang.String genVar356;
    genVar356="SubModules";
    java.util.List<org.jdom2.Element> genVar357;
    genVar357=XMLElement.getChildren(genVar356);
    int genVar358;
    genVar358=genVar357.size();
    int genVar359;
    genVar359=0;
    boolean genVar360;
    genVar360=genVar358 > genVar359;
    if (genVar360) {
      boolean genVar361;
      genVar361=true;
      return genVar361;
    }
 else {
      ;
    }
    boolean genVar362;
    genVar362=false;
    return genVar362;
  }
  private void createAppliedRulesFromXML(  Element XMLElement){
    try {
      java.util.List<org.jdom2.Element> genVar363;
      genVar363=XMLElement.getChildren();
      for (      Element appliedRule : genVar363) {
        XMLDomain genVar364;
        genVar364=this;
        AppliedRuleStrategy rule;
        rule=genVar364.createRuleFromXML(appliedRule);
      }
    }
 catch (    Exception e) {
    }
  }
  private AppliedRuleStrategy createRuleFromXML(  Element appliedRule){
    AppliedRuleStrategy rule;
    rule=null;
    try {
      java.lang.String genVar365;
      genVar365="id";
      java.lang.String genVar366;
      genVar366=appliedRule.getChildText(genVar365);
      long ruleId;
      ruleId=Integer.parseInt(genVar366);
      java.lang.String genVar367;
      genVar367="type";
      String ruleTypeKey;
      ruleTypeKey=appliedRule.getChildText(genVar367);
      java.lang.String genVar368;
      genVar368="SuperClassInheritanceConvention";
      boolean genVar369;
      genVar369=ruleTypeKey.equals(genVar368);
      boolean genVar370;
      genVar370=(genVar369);
      java.lang.String genVar371;
      genVar371="InterfaceInheritanceConvention";
      boolean genVar372;
      genVar372=ruleTypeKey.equals(genVar371);
      boolean genVar373;
      genVar373=(genVar372);
      boolean genVar374;
      genVar374=genVar370 || genVar373;
      if (genVar374) {
        ruleTypeKey="InheritanceConvention";
      }
 else {
        ;
      }
      java.lang.String genVar375;
      genVar375="moduleFrom";
      java.lang.String genVar376;
      genVar376=appliedRule.getChildText(genVar375);
      long moduleFromId;
      moduleFromId=Integer.parseInt(genVar376);
      java.lang.String genVar377;
      genVar377="moduleTo";
      java.lang.String genVar378;
      genVar378=appliedRule.getChildText(genVar377);
      long moduleToId;
      moduleToId=Integer.parseInt(genVar378);
      java.lang.String genVar379;
      genVar379="enabled";
      java.lang.String genVar380;
      genVar380=appliedRule.getChildText(genVar379);
      boolean isEnabled;
      isEnabled=Boolean.parseBoolean(genVar380);
      java.lang.String genVar381;
      genVar381="description";
      String description;
      description=appliedRule.getChildText(genVar381);
      java.lang.String genVar382;
      genVar382="regex";
      String regex;
      regex=appliedRule.getChildText(genVar382);
      java.lang.String genVar383;
      genVar383="dependencies";
      Element dependencies;
      dependencies=appliedRule.getChild(genVar383);
      XMLDomain genVar384;
      genVar384=this;
      String[] dependencyTypes;
      dependencyTypes=genVar384.getDependencyTypesFromXML(dependencies);
      java.lang.String genVar385;
      genVar385="isException";
      java.lang.String genVar386;
      genVar386=appliedRule.getChildText(genVar385);
      boolean isException;
      isException=Boolean.parseBoolean(genVar386);
      int genVar387;
      genVar387=1;
      long parentRule;
      parentRule=-genVar387;
      if (isException) {
        java.lang.String genVar388;
        genVar388="parentAppliedRuleId";
        java.lang.String genVar389;
        genVar389=appliedRule.getChildText(genVar388);
        parentRule=Integer.parseInt(genVar389);
      }
 else {
        ;
      }
    }
 catch (    Exception e) {
    }
    return rule;
  }
  private String[] getDependencyTypesFromXML(  Element XMLElement){
    ArrayList<String> dependencies;
    dependencies=new ArrayList<String>();
    java.lang.String genVar390;
    genVar390="dependency";
    java.util.List<org.jdom2.Element> genVar391;
    genVar391=XMLElement.getChildren(genVar390);
    for (    Element dependency : genVar391) {
      java.lang.String genVar392;
      genVar392=dependency.getValue();
      dependencies.add(genVar392);
    }
    String[] returnValue;
    returnValue=null;
    java.lang.String[] genVar393;
    genVar393=new String[dependencies.size()];
    returnValue=dependencies.toArray(genVar393);
    return returnValue;
  }
}
