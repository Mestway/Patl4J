package husacct;
public class ActiveViolationType {
  public ActiveViolationType(  String violationTypeKey,  boolean enabled){
  }
}
