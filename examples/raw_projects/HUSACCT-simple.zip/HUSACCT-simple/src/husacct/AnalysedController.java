package husacct;
public class AnalysedController {
}
