package husacct;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.jdom2.Element;
public class ImportSeverities {
  public List<Severity> importSeverities(  Element element){
    List<Severity> severities;
    severities=new ArrayList<Severity>();
    java.util.List<org.jdom2.Element> genVar794;
    genVar794=element.getChildren();
    for (    Element severityElement : genVar794) {
      java.lang.String genVar795;
      genVar795="id";
      java.lang.String genVar796;
      genVar796=severityElement.getChildText(genVar795);
      UUID id;
      id=UUID.fromString(genVar796);
      java.lang.String genVar797;
      genVar797="severityKey";
      String severityKey;
      severityKey=severityElement.getChildText(genVar797);
      java.lang.String genVar798;
      genVar798="color";
      String rgbColor;
      rgbColor=severityElement.getChildText(genVar798);
    }
    return severities;
  }
}
