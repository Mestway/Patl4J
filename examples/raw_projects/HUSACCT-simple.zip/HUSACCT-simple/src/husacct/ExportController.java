package husacct;
import java.io.File;
import java.util.HashMap;
import java.util.Map;
import org.jdom2.Document;
import org.jdom2.Element;
public class ExportController {
  public void exportArchitecture(){
    Element logicalData;
    logicalData=null;
    Document doc;
    doc=new Document(logicalData);
  }
}
