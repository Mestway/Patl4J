package husacct;
import java.util.List;
import org.jdom2.Element;
public class ExportSeverities {
  public Element exportSeverities(  List<Severity> severities){
    java.lang.String genVar668;
    genVar668="severities";
    Element severitiesElement;
    severitiesElement=new Element(genVar668);
    Severity severity;
    severity=null;
    java.lang.String genVar669;
    genVar669="severity";
    Element severityElement;
    severityElement=new Element(genVar669);
    ExportSeverities genVar670;
    genVar670=this;
    java.lang.String genVar671;
    genVar671="severityKey";
    java.lang.String genVar672;
    genVar672=severity.getSeverityKey();
    genVar670.createElementWithContent(genVar671,genVar672,severityElement);
    ExportSeverities genVar673;
    genVar673=this;
    java.lang.String genVar674;
    genVar674="id";
    java.lang.String genVar675;
    genVar675="";
    java.lang.Object genVar676;
    genVar676=severity.getId();
    java.lang.String genVar677;
    genVar677=genVar676.toString();
    java.lang.String genVar678;
    genVar678=genVar675 + genVar677;
    genVar673.createElementWithContent(genVar674,genVar678,severityElement);
    ExportSeverities genVar679;
    genVar679=this;
    java.lang.String genVar680;
    genVar680="color";
    java.lang.String genVar681;
    genVar681="";
    java.lang.Object genVar682;
    genVar682=severity.getColor();
    java.lang.String genVar683;
    genVar683=genVar681 + genVar682;
    genVar679.createElementWithContent(genVar680,genVar683,severityElement);
    severitiesElement.addContent(severityElement);
    return severitiesElement;
  }
  private void createElementWithContent(  String name,  String content,  Element destination){
    Element element;
    element=new Element(name);
    element.setText(content);
    destination.addContent(element);
  }
}
