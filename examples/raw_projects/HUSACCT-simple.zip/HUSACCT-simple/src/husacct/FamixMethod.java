package husacct;
public class FamixMethod {
  public boolean isPureAccessor;
  public String belongsToClass;
  public boolean isConstructor;
  public boolean isAbstract;
  public boolean hasClassScope;
  public String name;
  public String uniqueName;
  public String accessControlQualifier;
  public String signature;
  public String declaredReturnType;
}
