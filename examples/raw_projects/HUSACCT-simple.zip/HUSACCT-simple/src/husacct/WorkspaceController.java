package husacct;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import org.jdom2.Document;
import org.jdom2.Element;
public class WorkspaceController {
  public boolean saveWorkspace(  String resourceIdentifier,  HashMap<String,Object> dataValues,  HashMap<String,Object> config){
    WorkspaceController genVar734;
    genVar734=this;
    Document document;
    document=genVar734.getWorkspaceData();
    boolean genVar735;
    genVar735=true;
    return genVar735;
  }
  public boolean loadWorkspace(  String resourceIdentifier,  HashMap<String,Object> dataValues){
    Document doc;
    doc=null;
    WorkspaceController genVar736;
    genVar736=this;
    boolean genVar737;
    genVar737=genVar736.loadWorkspace(doc);
    return genVar737;
  }
  public Document getWorkspaceData(){
    java.lang.String genVar738;
    genVar738="husacct";
    Element rootElement;
    rootElement=new Element(genVar738);
    java.lang.String genVar739;
    genVar739="version";
    java.lang.String genVar740;
    genVar740="3.4.1";
    rootElement.setAttribute(genVar739,genVar740);
    String serviceName;
    serviceName="";
    Element container;
    container=new Element(serviceName);
    Element serviceData;
    serviceData=null;
    container.addContent(serviceData);
    rootElement.addContent(container);
    Document doc;
    doc=new Document(rootElement);
    return doc;
  }
  public boolean loadWorkspace(  Document document){
    try {
      boolean genVar741;
      genVar741=document.hasRootElement();
      if (genVar741) {
        Element rootElement;
        rootElement=document.getRootElement();
        String serviceName;
        serviceName="";
        List<Element> elementQuery;
        elementQuery=rootElement.getChildren(serviceName);
        for (        Element serviceDataContainer : elementQuery) {
          java.util.List<org.jdom2.Element> genVar742;
          genVar742=serviceDataContainer.getChildren();
          int genVar743;
          genVar743=0;
          Element serviceData;
          serviceData=genVar742.get(genVar743);
        }
      }
 else {
        ;
      }
      boolean genVar744;
      genVar744=true;
      return genVar744;
    }
 catch (    Exception exception) {
      java.lang.String genVar745;
      genVar745="Unable to load workspacedata\n";
      java.lang.String genVar746;
      genVar746=exception.getMessage();
      String message;
      message=genVar745 + genVar746;
    }
    boolean genVar747;
    genVar747=false;
    return genVar747;
  }
}
