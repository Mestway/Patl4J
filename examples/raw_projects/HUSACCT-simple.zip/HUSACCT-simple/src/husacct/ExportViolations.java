package husacct;
import java.util.AbstractMap.SimpleEntry;
import java.util.Calendar;
import java.util.List;
import org.jdom2.Element;
public class ExportViolations {
  public Element getAllViolations(  SimpleEntry<Calendar,List<Violation>> allViolations){
    java.lang.String genVar641;
    genVar641="violations";
    Element root;
    root=new Element(genVar641);
    int i;
    i=0;
    for (; i < allViolations.getValue().size(); i++) {
      java.util.List<husacct.Violation> genVar642;
      genVar642=allViolations.getValue();
      husacct.Violation genVar643;
      genVar643=genVar642.get(i);
      java.lang.String genVar644;
      genVar644=genVar643.toString();
      System.out.println(genVar644);
    }
    return root;
  }
}
