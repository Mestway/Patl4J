package husacct;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.xml.datatype.DatatypeConfigurationException;
import org.jdom2.Element;
public class ImportViolations {
  public List<Violation> importViolations(  Element violationsElement,  List<Severity> severities) throws DatatypeConfigurationException {
    List<Violation> violations;
    violations=new ArrayList<Violation>();
    java.util.List<org.jdom2.Element> genVar710;
    genVar710=violationsElement.getChildren();
    for (    Element violationElement : genVar710) {
      Severity violationSeverity;
      violationSeverity=null;
      java.lang.String genVar711;
      genVar711="severityId";
      String severityId;
      severityId=violationElement.getChildText(genVar711);
      for (      Severity severity : severities) {
        java.lang.Object genVar712;
        genVar712=severity.getId();
        java.lang.String genVar713;
        genVar713=genVar712.toString();
        boolean genVar714;
        genVar714=severityId.equals(genVar713);
        if (genVar714) {
          violationSeverity=severity;
          break;
        }
 else {
          ;
        }
      }
      java.lang.String genVar715;
      genVar715="lineNumber";
      java.lang.String genVar716;
      genVar716=violationElement.getChildText(genVar715);
      int lineNumber;
      lineNumber=Integer.parseInt(genVar716);
      java.lang.String genVar717;
      genVar717="ruletypeKey";
      String ruleTypeKey;
      ruleTypeKey=violationElement.getChildText(genVar717);
      java.lang.String genVar718;
      genVar718="violationtypeKey";
      String violationTypeKey;
      violationTypeKey=violationElement.getChildText(genVar718);
      java.lang.String genVar719;
      genVar719="classPathFrom";
      String classPathFrom;
      classPathFrom=violationElement.getChildText(genVar719);
      java.lang.String genVar720;
      genVar720="classPathTo";
      String classPathTo;
      classPathTo=violationElement.getChildText(genVar720);
      java.lang.String genVar721;
      genVar721="logicalModules";
      violationElement.getChild(genVar721);
      java.lang.String genVar722;
      genVar722="message";
      violationElement.getChild(genVar722);
      java.lang.String genVar723;
      genVar723="isIndirect";
      java.lang.String genVar724;
      genVar724=violationElement.getChildText(genVar723);
      boolean isIndirect;
      isIndirect=Boolean.parseBoolean(genVar724);
      java.lang.String genVar725;
      genVar725="occured";
      String stringCalendar;
      stringCalendar=violationElement.getChildText(genVar725);
    }
    return violations;
  }
}
