package husacct;
import java.util.List;
public class ActiveRuleType {
  public ActiveRuleType(  String ruleTypeKey,  List<ActiveViolationType> activeViolationTypes){
  }
}
