package husacct;
import java.util.List;
import org.jdom2.Element;
public class AnalyseControlServiceImpl {
  private IAnalyseDomainService domainService;
  public Element saveModel(){
    org.jdom2.Element genVar604;
    genVar604=domainService.saveModel();
    return genVar604;
  }
  public void loadModel(  Element analyseElement){
    domainService.loadModel(analyseElement);
  }
}
