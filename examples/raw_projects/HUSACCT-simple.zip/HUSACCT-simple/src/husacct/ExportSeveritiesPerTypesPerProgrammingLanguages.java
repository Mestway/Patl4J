package husacct;
import java.util.HashMap;
import java.util.Map.Entry;
import org.jdom2.Attribute;
import org.jdom2.Element;
public class ExportSeveritiesPerTypesPerProgrammingLanguages {
  public Element exportSeveritiesPerTypesPerProgrammingLanguages(  HashMap<String,HashMap<String,Severity>> allSeveritiesPerTypesPerProgrammingLanguages){
    java.lang.String genVar515;
    genVar515="severitiesPerTypesPerProgrammingLanguages";
    Element severitiesPerTypesPerProgrammingLanguagesElement;
    severitiesPerTypesPerProgrammingLanguagesElement=new Element(genVar515);
    java.util.Set<java.util.Map.Entry<java.lang.String,java.util.HashMap<java.lang.String,husacct.Severity>>> genVar516;
    genVar516=allSeveritiesPerTypesPerProgrammingLanguages.entrySet();
    for (    Entry<String,HashMap<String,Severity>> programminglanguageEntry : genVar516) {
      ExportSeveritiesPerTypesPerProgrammingLanguages genVar517;
      genVar517=this;
      java.lang.String genVar518;
      genVar518="severityPerTypePerProgrammingLanguage";
      Element severityPerTypePerProgrammingLanguageElement;
      severityPerTypePerProgrammingLanguageElement=genVar517.createElementWithoutContent(genVar518,severitiesPerTypesPerProgrammingLanguagesElement);
      java.lang.String genVar519;
      genVar519="language";
      java.lang.String genVar520;
      genVar520=programminglanguageEntry.getKey();
      org.jdom2.Attribute genVar521;
      genVar521=new Attribute(genVar519,genVar520);
      severityPerTypePerProgrammingLanguageElement.setAttribute(genVar521);
      java.util.HashMap<java.lang.String,husacct.Severity> genVar522;
      genVar522=programminglanguageEntry.getValue();
      java.util.Set<java.util.Map.Entry<java.lang.String,husacct.Severity>> genVar523;
      genVar523=genVar522.entrySet();
      for (      Entry<String,Severity> severityPerType : genVar523) {
        ExportSeveritiesPerTypesPerProgrammingLanguages genVar524;
        genVar524=this;
        java.lang.String genVar525;
        genVar525="severityPerType";
        Element severityPerTypeElement;
        severityPerTypeElement=genVar524.createElementWithoutContent(genVar525,severityPerTypePerProgrammingLanguageElement);
        ExportSeveritiesPerTypesPerProgrammingLanguages genVar526;
        genVar526=this;
        java.lang.String genVar527;
        genVar527="typeKey";
        java.lang.String genVar528;
        genVar528=severityPerType.getKey();
        genVar526.createElementWithContent(genVar527,genVar528,severityPerTypeElement);
        ExportSeveritiesPerTypesPerProgrammingLanguages genVar529;
        genVar529=this;
        java.lang.String genVar530;
        genVar530="severityId";
        java.lang.String genVar531;
        genVar531="";
        genVar529.createElementWithContent(genVar530,genVar531,severityPerTypeElement);
      }
    }
    return severitiesPerTypesPerProgrammingLanguagesElement;
  }
  private void createElementWithContent(  String name,  String content,  Element destination){
    Element element;
    element=new Element(name);
    element.addContent(content);
    destination.addContent(element);
  }
  private Element createElementWithoutContent(  String name,  Element destination){
    Element element;
    element=new Element(name);
    destination.addContent(element);
    return element;
  }
}
