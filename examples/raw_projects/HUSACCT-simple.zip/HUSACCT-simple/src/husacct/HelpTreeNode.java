package husacct;
public class HelpTreeNode {
  public HelpTreeNode(  String attributeValue,  String attributeValue2,  String name,  String string){
  }
  public HelpTreeNode(  Object parent,  Object parent2,  Object parent3,  String string){
  }
  public Object getParent(){
    return null;
  }
}
