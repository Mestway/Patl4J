package husacct;
public class Application {
  public String getName(){
    return null;
  }
  public String getVersion(){
    return null;
  }
}
