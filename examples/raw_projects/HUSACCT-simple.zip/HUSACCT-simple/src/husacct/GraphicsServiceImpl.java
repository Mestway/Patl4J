package husacct;
import javax.swing.JInternalFrame;
import org.jdom2.Element;
public class GraphicsServiceImpl {
  private AnalysedController analysedController;
  private DefinedController definedController;
  public Element getWorkspaceData(){
    String workspaceServiceName;
    workspaceServiceName="";
    Element data;
    data=new Element(workspaceServiceName);
    java.lang.String genVar555;
    genVar555="";
    data.addContent(genVar555);
    java.lang.String genVar556;
    genVar556="";
    data.addContent(genVar556);
    return data;
  }
  private Element getWorkspaceDataForController(  String controllerName,  DrawingController controller){
    Element controllerElement;
    controllerElement=new Element(controllerName);
    java.lang.String genVar557;
    genVar557="";
    java.lang.String genVar558;
    genVar558="";
    controllerElement.setAttribute(genVar557,genVar558);
    java.lang.String genVar559;
    genVar559="";
    java.lang.String genVar560;
    genVar560="";
    controllerElement.setAttribute(genVar559,genVar560);
    java.lang.String genVar561;
    genVar561="";
    java.lang.String genVar562;
    genVar562="";
    controllerElement.setAttribute(genVar561,genVar562);
    java.lang.String genVar563;
    genVar563="";
    java.lang.String genVar564;
    genVar564="";
    controllerElement.setAttribute(genVar563,genVar564);
    java.lang.String genVar565;
    genVar565="";
    java.lang.String genVar566;
    genVar566="";
    controllerElement.setAttribute(genVar565,genVar566);
    return controllerElement;
  }
  private boolean isActive(  Element controllerElement,  String attribute){
    org.jdom2.Attribute genVar567;
    genVar567=controllerElement.getAttribute(attribute);
    java.lang.String genVar568;
    genVar568=genVar567.getValue();
    boolean genVar569;
    genVar569=Boolean.parseBoolean(genVar568);
    return genVar569;
  }
  public void loadWorkspaceData(  Element workspaceData){
    try {
      Element analysedControllerElement;
      analysedControllerElement=workspaceData.getChild(null);
    }
 catch (    Exception e) {
    }
    try {
      Element definedControllerElement;
      definedControllerElement=workspaceData.getChild(null);
    }
 catch (    Exception e) {
    }
  }
  private void loadWorkspaceDataForController(  DrawingController controller,  Element data){
  }
}
