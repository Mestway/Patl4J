package husacct;
import java.util.Date;
import java.util.List;
import org.jdom2.Element;
public class AnalyseServiceImpl {
  private IModelPersistencyService persistService;
  public Element getWorkspaceData(){
    java.lang.String genVar706;
    genVar706="rootElement";
    Element rootElement;
    rootElement=new Element(genVar706);
    org.jdom2.Element genVar707;
    genVar707=persistService.saveModel();
    rootElement.addContent(genVar707);
    return rootElement;
  }
  public void loadWorkspaceData(  Element rootElement){
    java.lang.String genVar708;
    genVar708="AnalysedApplication";
    org.jdom2.Element genVar709;
    genVar709=rootElement.getChild(genVar708);
    persistService.loadModel(genVar709);
  }
}
