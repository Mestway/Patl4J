package husacct;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.UUID;
import org.jdom2.Element;
public class ImportViolationsHistory {
  public void importViolationsHistory(  Element violationHistoriesElement){
    java.lang.String genVar394;
    genVar394="violationHistory";
    java.util.List<org.jdom2.Element> genVar395;
    genVar395=violationHistoriesElement.getChildren(genVar394);
    for (    Element violationHistoryElement : genVar395) {
      java.lang.String genVar396;
      genVar396="severities";
      org.jdom2.Element genVar397;
      genVar397=violationHistoryElement.getChild(genVar396);
      java.util.List<org.jdom2.Element> genVar398;
      genVar398=genVar397.getChildren();
      for (      Element severityElement : genVar398) {
        java.lang.String genVar399;
        genVar399="id";
        String stringUUID;
        stringUUID=severityElement.getChildText(genVar399);
        java.lang.String genVar400;
        genVar400="id";
        java.lang.String genVar401;
        genVar401=severityElement.getChildText(genVar400);
        java.util.UUID genVar402;
        genVar402=UUID.fromString(genVar401);
        java.lang.String genVar403;
        genVar403="severityKey";
        java.lang.String genVar404;
        genVar404=severityElement.getChildText(genVar403);
        java.lang.String genVar405;
        genVar405="color";
        java.lang.String genVar406;
        genVar406=severityElement.getChildText(genVar405);
        int genVar407;
        genVar407=Integer.parseInt(genVar406);
        java.awt.Color genVar408;
        genVar408=new Color(genVar407);
        Severity severity;
        severity=new Severity(genVar402,genVar404,genVar408);
      }
      java.lang.String genVar409;
      genVar409="date";
      String validationDateString;
      validationDateString=violationHistoryElement.getAttributeValue(genVar409);
      java.lang.String genVar410;
      genVar410="description";
      String description;
      description=violationHistoryElement.getChildText(genVar410);
      java.lang.String genVar411;
      genVar411="violations";
      org.jdom2.Element genVar412;
      genVar412=violationHistoryElement.getChild(genVar411);
      java.util.List<org.jdom2.Element> genVar413;
      genVar413=genVar412.getChildren();
      for (      Element violationElement : genVar413) {
        java.lang.String genVar414;
        genVar414="lineNumber";
        java.lang.String genVar415;
        genVar415=violationElement.getChildText(genVar414);
        int lineNumber;
        lineNumber=Integer.parseInt(genVar415);
        java.lang.String genVar416;
        genVar416="ruletypeKey";
        String ruleTypeKey;
        ruleTypeKey=violationElement.getChildText(genVar416);
        java.lang.String genVar417;
        genVar417="violationtypeKey";
        String violationTypeKey;
        violationTypeKey=violationElement.getChildText(genVar417);
        java.lang.String genVar418;
        genVar418="classPathFrom";
        String classPathFrom;
        classPathFrom=violationElement.getChildText(genVar418);
        java.lang.String genVar419;
        genVar419="classPathTo";
        String classPathTo;
        classPathTo=violationElement.getChildText(genVar419);
        java.lang.String genVar420;
        genVar420="logicalModules";
        violationElement.getChild(genVar420);
        java.lang.String genVar421;
        genVar421="message";
        violationElement.getChild(genVar421);
        java.lang.String genVar422;
        genVar422="isIndirect";
        java.lang.String genVar423;
        genVar423=violationElement.getChildText(genVar422);
        boolean isIndirect;
        isIndirect=Boolean.parseBoolean(genVar423);
        java.lang.String genVar424;
        genVar424="occured";
        String stringCalendar;
        stringCalendar=violationElement.getChildText(genVar424);
        java.lang.String genVar425;
        genVar425="severityId";
        String stringUUID;
        stringUUID=violationElement.getChildText(genVar425);
        boolean found;
        found=false;
      }
    }
  }
}
