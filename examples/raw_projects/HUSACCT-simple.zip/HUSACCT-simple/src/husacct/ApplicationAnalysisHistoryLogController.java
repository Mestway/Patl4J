package husacct;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import org.jdom2.Document;
import org.jdom2.Element;
public class ApplicationAnalysisHistoryLogController {
  public void getApplicationHistoryFromFile(  String workspace,  String application){
    try {
      Document doc;
      doc=null;
      Element xmlFileRootElement;
      xmlFileRootElement=doc.getRootElement();
      java.util.List<org.jdom2.Element> genVar605;
      genVar605=xmlFileRootElement.getChildren();
      for (      Element workspaceElement : genVar605) {
        java.lang.String genVar606;
        genVar606="name";
        java.lang.String genVar607;
        genVar607=workspaceElement.getAttributeValue(genVar606);
        boolean genVar608;
        genVar608=genVar607.equals(workspace);
        if (genVar608) {
          java.util.List<org.jdom2.Element> genVar609;
          genVar609=workspaceElement.getChildren();
          for (          Element applicationElement : genVar609) {
            java.lang.String genVar610;
            genVar610="name";
            java.lang.String genVar611;
            genVar611=applicationElement.getAttributeValue(genVar610);
            boolean genVar612;
            genVar612=genVar611.equals(application);
            if (genVar612) {
              java.util.List<org.jdom2.Element> genVar613;
              genVar613=applicationElement.getChildren();
              for (              Element projectElement : genVar613) {
                java.lang.String genVar614;
                genVar614="name";
                java.lang.String genVar615;
                genVar615=projectElement.getAttributeValue(genVar614);
                boolean genVar616;
                genVar616=genVar615.equals(null);
                if (genVar616) {
                  java.util.List<org.jdom2.Element> genVar617;
                  genVar617=projectElement.getChildren();
                  for (                  Element analysisElement : genVar617) {
                    HashMap<String,String> analysisInfo;
                    analysisInfo=new HashMap<String,String>();
                    java.lang.String genVar618;
                    genVar618="application";
                    java.lang.String genVar619;
                    genVar619="name";
                    java.lang.String genVar620;
                    genVar620=applicationElement.getAttributeValue(genVar619);
                    analysisInfo.put(genVar618,genVar620);
                    java.lang.String genVar621;
                    genVar621="project";
                    java.lang.String genVar622;
                    genVar622="name";
                    java.lang.String genVar623;
                    genVar623=projectElement.getAttributeValue(genVar622);
                    analysisInfo.put(genVar621,genVar623);
                    java.util.List<org.jdom2.Element> genVar624;
                    genVar624=analysisElement.getChildren();
                    for (                    Element analysisInfoElement : genVar624) {
                      java.lang.String genVar625;
                      genVar625=analysisInfoElement.getName();
                      java.lang.String genVar626;
                      genVar626=analysisInfoElement.getText();
                      analysisInfo.put(genVar625,genVar626);
                    }
                    java.lang.String genVar627;
                    genVar627="timestamp";
                    analysisElement.getAttributeValue(genVar627);
                  }
                }
 else {
                  ;
                }
              }
            }
 else {
              ;
            }
          }
        }
 else {
          ;
        }
      }
    }
 catch (    Exception e) {
    }
  }
  public int getNumberOfAnalyses(  String workspace,  String application){
    int output;
    output=0;
    try {
      Document doc;
      doc=null;
      Element xmlFileRootElement;
      xmlFileRootElement=doc.getRootElement();
      java.util.List<org.jdom2.Element> genVar628;
      genVar628=xmlFileRootElement.getChildren();
      for (      Element workspaceElement : genVar628) {
        java.lang.String genVar629;
        genVar629="name";
        java.lang.String genVar630;
        genVar630=workspaceElement.getAttributeValue(genVar629);
        boolean genVar631;
        genVar631=genVar630.equals(workspace);
        if (genVar631) {
          java.util.List<org.jdom2.Element> genVar632;
          genVar632=workspaceElement.getChildren();
          for (          Element applicationElement : genVar632) {
            java.lang.String genVar633;
            genVar633="name";
            java.lang.String genVar634;
            genVar634=applicationElement.getAttributeValue(genVar633);
            boolean genVar635;
            genVar635=genVar634.equals(application);
            if (genVar635) {
              java.util.List<org.jdom2.Element> genVar636;
              genVar636=applicationElement.getChildren();
              for (              Element projectElement : genVar636) {
                java.lang.String genVar637;
                genVar637="name";
                java.lang.String genVar638;
                genVar638=projectElement.getAttributeValue(genVar637);
                boolean genVar639;
                genVar639=genVar638.equals(null);
                if (genVar639) {
                  java.util.List<org.jdom2.Element> genVar640;
                  genVar640=projectElement.getChildren();
                  output+=genVar640.size();
                }
 else {
                  ;
                }
              }
            }
 else {
              ;
            }
          }
        }
 else {
          ;
        }
      }
    }
 catch (    Exception e) {
    }
    return output;
  }
}
