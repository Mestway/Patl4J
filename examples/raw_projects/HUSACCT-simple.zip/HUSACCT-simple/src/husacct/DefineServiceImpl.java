package husacct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import javax.swing.JInternalFrame;
import org.jdom2.Element;
public class DefineServiceImpl {
  public Element getLogicalArchitectureData(){
    return null;
  }
  public Element getWorkspaceData(){
    return null;
  }
  public void loadLogicalArchitectureData(  Element e){
  }
  public void loadWorkspaceData(  Element workspaceData){
  }
}
