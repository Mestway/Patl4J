package husacct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.jdom2.Element;
public class ImportFactory {
  private ImportSeverities importSeverities;
  private ImportSeveritiesPerTypesPerProgrammingLanguages importSeveritiesPerRuleTypesPerProgrammingLanguages;
  private ImportActiveViolationTypes importActiveViolationTypes;
  ImportFactory(){
    husacct.ImportFactory genVar549;
    genVar549=this;
    genVar549.importSeverities=new ImportSeverities();
    husacct.ImportFactory genVar550;
    genVar550=this;
    genVar550.importSeveritiesPerRuleTypesPerProgrammingLanguages=new ImportSeveritiesPerTypesPerProgrammingLanguages();
    husacct.ImportFactory genVar551;
    genVar551=this;
    genVar551.importActiveViolationTypes=new ImportActiveViolationTypes();
  }
  List<Severity> importSeverities(  Element element){
    java.util.List<husacct.Severity> genVar552;
    genVar552=importSeverities.importSeverities(element);
    return genVar552;
  }
  HashMap<String,HashMap<String,Severity>> importSeveritiesPerTypesPerProgrammingLanguages(  Element element,  List<Severity> severities){
    java.util.HashMap<java.lang.String,java.util.HashMap<java.lang.String,husacct.Severity>> genVar553;
    genVar553=importSeveritiesPerRuleTypesPerProgrammingLanguages.importSeveritiesPerTypesPerProgrammingLanguages(element,severities);
    return genVar553;
  }
  Map<String,List<ActiveRuleType>> importActiveViolationTypes(  Element activeViolationTypes){
    java.util.Map<java.lang.String,java.util.List<husacct.ActiveRuleType>> genVar554;
    genVar554=importActiveViolationTypes.importActiveViolationTypes(activeViolationTypes);
    return genVar554;
  }
}
