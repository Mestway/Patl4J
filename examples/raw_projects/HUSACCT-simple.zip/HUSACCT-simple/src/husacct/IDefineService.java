package husacct;
import java.util.ArrayList;
import java.util.HashSet;
import org.jdom2.Element;
public interface IDefineService {
  public Element getLogicalArchitectureData();
  public void loadLogicalArchitectureData(  Element e);
}
