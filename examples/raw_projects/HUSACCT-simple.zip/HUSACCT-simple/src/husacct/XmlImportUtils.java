package husacct;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import org.jdom2.Element;
public abstract class XmlImportUtils {
  protected Message getMessage(  Element messageElement){
    java.lang.String genVar684;
    genVar684="logicalModules";
    Element logicalModulesElement;
    logicalModulesElement=messageElement.getChild(genVar684);
    XmlImportUtils genVar685;
    genVar685=this;
    LogicalModules logicalModules;
    logicalModules=genVar685.getLogicalModules(logicalModulesElement);
    java.lang.String genVar686;
    genVar686="ruleKey";
    String ruleKey;
    ruleKey=messageElement.getChildText(genVar686);
    java.lang.String genVar687;
    genVar687="regex";
    String regex;
    regex=messageElement.getChildText(genVar687);
    java.lang.String genVar688;
    genVar688="violationTypeKeys";
    Element violationTypeKeys;
    violationTypeKeys=messageElement.getChild(genVar688);
    List<String> violationTypeKeysList;
    violationTypeKeysList=new ArrayList<String>();
    java.util.List<org.jdom2.Element> genVar689;
    genVar689=violationTypeKeys.getChildren();
    for (    Element violationTypeKey : genVar689) {
      java.lang.String genVar690;
      genVar690=violationTypeKey.getText();
      violationTypeKeysList.add(genVar690);
    }
    List<Message> exceptionMessages;
    exceptionMessages=new ArrayList<Message>();
    java.lang.String genVar691;
    genVar691="exceptionMessages";
    Element exceptionMessagesElement;
    exceptionMessagesElement=messageElement.getChild(genVar691);
    boolean genVar692;
    genVar692=exceptionMessagesElement != null;
    if (genVar692) {
      java.util.List<org.jdom2.Element> genVar693;
      genVar693=exceptionMessagesElement.getChildren();
      for (      Element exceptionMessageElement : genVar693) {
        XmlImportUtils genVar694;
        genVar694=this;
        husacct.Message genVar695;
        genVar695=genVar694.getMessage(exceptionMessageElement);
        exceptionMessages.add(genVar695);
      }
    }
 else {
      ;
    }
    Message message;
    message=new Message(logicalModules,ruleKey,violationTypeKeysList,regex,exceptionMessages);
    return message;
  }
  protected LogicalModules getLogicalModules(  Element logicalModulesElement){
    java.lang.String genVar696;
    genVar696="logicalModuleFrom";
    Element logicalModuleFromElement;
    logicalModuleFromElement=logicalModulesElement.getChild(genVar696);
    java.lang.String genVar697;
    genVar697="logicalModuleTo";
    Element logicalModuleToElement;
    logicalModuleToElement=logicalModulesElement.getChild(genVar697);
    java.lang.String genVar698;
    genVar698="logicalModulePath";
    java.lang.String genVar699;
    genVar699=logicalModuleFromElement.getChildText(genVar698);
    java.lang.String genVar700;
    genVar700="logicalModuleType";
    java.lang.String genVar701;
    genVar701=logicalModuleFromElement.getChildText(genVar700);
    LogicalModule logicalModuleFrom;
    logicalModuleFrom=new LogicalModule(genVar699,genVar701);
    java.lang.String genVar702;
    genVar702="logicalModulePath";
    java.lang.String genVar703;
    genVar703=logicalModuleToElement.getChildText(genVar702);
    java.lang.String genVar704;
    genVar704="logicalModuleType";
    java.lang.String genVar705;
    genVar705=logicalModuleToElement.getChildText(genVar704);
    LogicalModule logicalModuleTo;
    logicalModuleTo=new LogicalModule(genVar703,genVar705);
    LogicalModules logicalModules;
    logicalModules=new LogicalModules(logicalModuleFrom,logicalModuleTo);
    return logicalModules;
  }
}
