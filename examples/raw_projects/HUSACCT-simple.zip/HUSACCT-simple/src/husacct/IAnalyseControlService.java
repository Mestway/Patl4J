package husacct;
import java.util.List;
import org.jdom2.Element;
public interface IAnalyseControlService {
  public Element saveModel();
  public void loadModel(  Element analyseElement);
}
