package husacct;
import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.AbstractMap.SimpleEntry;
import javax.swing.JInternalFrame;
import javax.xml.datatype.DatatypeConfigurationException;
import org.jdom2.Element;
public final class ValidateServiceImpl {
  public Element getWorkspaceData(){
    return null;
  }
  public void loadWorkspaceData(  Element workspaceData){
  }
}
