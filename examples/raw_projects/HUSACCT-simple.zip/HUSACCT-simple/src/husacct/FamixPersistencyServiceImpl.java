package husacct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.Map;
import javax.naming.directory.InvalidAttributesException;
import org.jdom2.Element;
public class FamixPersistencyServiceImpl {
  private FamixModel theModel;
  private Element rootNode, packages, libraries, classes, methods, variables, associations;
  public Element saveModel(){
    java.lang.String genVar57;
    genVar57="EmptyAnalysedApplication";
    Element analysedProject;
    analysedProject=new Element(genVar57);
    boolean saveAnalysedData;
    saveAnalysedData=false;
    boolean genVar58;
    genVar58=!saveAnalysedData;
    if (genVar58) {
      return analysedProject;
    }
 else {
      theModel=FamixModel.getInstance();
      FamixPersistencyServiceImpl genVar59;
      genVar59=this;
      genVar59.initiateNodes();
      FamixPersistencyServiceImpl genVar60;
      genVar60=this;
      org.jdom2.Element genVar61;
      genVar61=genVar60.createXml();
      return genVar61;
    }
  }
  private void initiateNodes(){
    husacct.FamixPersistencyServiceImpl genVar62;
    genVar62=this;
    java.lang.String genVar63;
    genVar63="Root";
    genVar62.rootNode=new Element(genVar63);
    husacct.FamixPersistencyServiceImpl genVar64;
    genVar64=this;
    java.lang.String genVar65;
    genVar65="Packages";
    genVar64.packages=new Element(genVar65);
    husacct.FamixPersistencyServiceImpl genVar66;
    genVar66=this;
    java.lang.String genVar67;
    genVar67="Libraries";
    genVar66.libraries=new Element(genVar67);
    husacct.FamixPersistencyServiceImpl genVar68;
    genVar68=this;
    java.lang.String genVar69;
    genVar69="Classes";
    genVar68.classes=new Element(genVar69);
    husacct.FamixPersistencyServiceImpl genVar70;
    genVar70=this;
    java.lang.String genVar71;
    genVar71="Methods";
    genVar70.methods=new Element(genVar71);
    husacct.FamixPersistencyServiceImpl genVar72;
    genVar72=this;
    java.lang.String genVar73;
    genVar73="Variables";
    genVar72.variables=new Element(genVar73);
    husacct.FamixPersistencyServiceImpl genVar74;
    genVar74=this;
    java.lang.String genVar75;
    genVar75="Associations";
    genVar74.associations=new Element(genVar75);
  }
  private Element createXml(){
    java.lang.String genVar76;
    genVar76="AnalysedApplication";
    Element analysedProject;
    analysedProject=new Element(genVar76);
    java.lang.String genVar77;
    genVar77="Packages";
    Element ElemPackages;
    ElemPackages=new Element(genVar77);
    String famPackageKey;
    java.lang.String genVar78;
    genVar78="Package";
    Element ElemPackage;
    ElemPackage=new Element(genVar78);
    java.lang.String genVar79;
    genVar79="UniqueName";
    org.jdom2.Element genVar80;
    genVar80=new Element(genVar79);
    org.jdom2.Element genVar81;
    genVar81=genVar80.setText(null);
    ElemPackage.addContent(genVar81);
    java.lang.String genVar82;
    genVar82="Name";
    org.jdom2.Element genVar83;
    genVar83=new Element(genVar82);
    org.jdom2.Element genVar84;
    genVar84=genVar83.setText(null);
    ElemPackage.addContent(genVar84);
    java.lang.String genVar85;
    genVar85="BelongsToPackage";
    org.jdom2.Element genVar86;
    genVar86=new Element(genVar85);
    org.jdom2.Element genVar87;
    genVar87=genVar86.setText(null);
    ElemPackage.addContent(genVar87);
    ElemPackages.addContent(ElemPackage);
    java.lang.String genVar88;
    genVar88="";
    analysedProject.addContent(genVar88);
    java.lang.String genVar89;
    genVar89="Libraries";
    Element ElemLibraries;
    ElemLibraries=new Element(genVar89);
    java.lang.String genVar90;
    genVar90="Library";
    Element ElemLibrary;
    ElemLibrary=new Element(genVar90);
    java.lang.String genVar91;
    genVar91="UniqueName";
    org.jdom2.Element genVar92;
    genVar92=new Element(genVar91);
    java.lang.String genVar93;
    genVar93="";
    org.jdom2.Element genVar94;
    genVar94=genVar92.setText(genVar93);
    ElemLibrary.addContent(genVar94);
    java.lang.String genVar95;
    genVar95="Name";
    org.jdom2.Element genVar96;
    genVar96=new Element(genVar95);
    org.jdom2.Element genVar97;
    genVar97=genVar96.setText(null);
    ElemLibrary.addContent(genVar97);
    java.lang.String genVar98;
    genVar98="BelongsToPackage";
    org.jdom2.Element genVar99;
    genVar99=new Element(genVar98);
    org.jdom2.Element genVar100;
    genVar100=genVar99.setText(null);
    ElemLibrary.addContent(genVar100);
    ElemLibrary.addContent(ElemLibrary);
    analysedProject.addContent(ElemLibraries);
    java.lang.String genVar101;
    genVar101="Classes";
    Element elemClasses;
    elemClasses=new Element(genVar101);
    java.lang.String genVar102;
    genVar102="Class";
    Element elemClass;
    elemClass=new Element(genVar102);
    java.lang.String genVar103;
    genVar103="UniqueName";
    org.jdom2.Element genVar104;
    genVar104=new Element(genVar103);
    org.jdom2.Element genVar105;
    genVar105=genVar104.setText(null);
    elemClass.addContent(genVar105);
    java.lang.String genVar106;
    genVar106="Name";
    org.jdom2.Element genVar107;
    genVar107=new Element(genVar106);
    org.jdom2.Element genVar108;
    genVar108=genVar107.setText(null);
    elemClass.addContent(genVar108);
    java.lang.String genVar109;
    genVar109="BelongsToPackage";
    org.jdom2.Element genVar110;
    genVar110=new Element(genVar109);
    org.jdom2.Element genVar111;
    genVar111=genVar110.setText(null);
    elemClass.addContent(genVar111);
    java.lang.String genVar112;
    genVar112="IsAbstract";
    org.jdom2.Element genVar113;
    genVar113=new Element(genVar112);
    org.jdom2.Element genVar114;
    genVar114=genVar113.setText(null);
    elemClass.addContent(genVar114);
    java.lang.String genVar115;
    genVar115="IsInnerClass";
    org.jdom2.Element genVar116;
    genVar116=new Element(genVar115);
    org.jdom2.Element genVar117;
    genVar117=genVar116.setText(null);
    elemClass.addContent(genVar117);
    elemClasses.addContent(elemClass);
    analysedProject.addContent(elemClasses);
    java.lang.String genVar118;
    genVar118="Methods";
    Element elemMethods;
    elemMethods=new Element(genVar118);
    java.lang.String genVar119;
    genVar119="Method";
    Element elemMethod;
    elemMethod=new Element(genVar119);
    java.lang.String genVar120;
    genVar120="UniqueName";
    org.jdom2.Element genVar121;
    genVar121=new Element(genVar120);
    org.jdom2.Element genVar122;
    genVar122=genVar121.setText(null);
    elemMethod.addContent(genVar122);
    java.lang.String genVar123;
    genVar123="Name";
    org.jdom2.Element genVar124;
    genVar124=new Element(genVar123);
    org.jdom2.Element genVar125;
    genVar125=genVar124.setText(null);
    elemMethod.addContent(genVar125);
    java.lang.String genVar126;
    genVar126="accessControlQualifier";
    org.jdom2.Element genVar127;
    genVar127=new Element(genVar126);
    org.jdom2.Element genVar128;
    genVar128=genVar127.setText(null);
    elemMethod.addContent(genVar128);
    java.lang.String genVar129;
    genVar129="signature";
    org.jdom2.Element genVar130;
    genVar130=new Element(genVar129);
    org.jdom2.Element genVar131;
    genVar131=genVar130.setText(null);
    elemMethod.addContent(genVar131);
    java.lang.String genVar132;
    genVar132="declaredReturnType";
    org.jdom2.Element genVar133;
    genVar133=new Element(genVar132);
    org.jdom2.Element genVar134;
    genVar134=genVar133.setText(null);
    elemMethod.addContent(genVar134);
    elemMethods.addContent(elemMethod);
    analysedProject.addContent(elemMethods);
    java.lang.String genVar135;
    genVar135="Variables";
    Element elemVariables;
    elemVariables=new Element(genVar135);
    java.lang.String genVar136;
    genVar136="Variable";
    Element elemVariable;
    elemVariable=new Element(genVar136);
    java.lang.String genVar137;
    genVar137="UniqueName";
    org.jdom2.Element genVar138;
    genVar138=new Element(genVar137);
    org.jdom2.Element genVar139;
    genVar139=genVar138.setText(null);
    elemVariable.addContent(genVar139);
    java.lang.String genVar140;
    genVar140="Name";
    org.jdom2.Element genVar141;
    genVar141=new Element(genVar140);
    org.jdom2.Element genVar142;
    genVar142=genVar141.setText(null);
    elemVariable.addContent(genVar142);
    java.lang.String genVar143;
    genVar143="BelongsToClass";
    org.jdom2.Element genVar144;
    genVar144=new Element(genVar143);
    org.jdom2.Element genVar145;
    genVar145=genVar144.setText(null);
    elemVariable.addContent(genVar145);
    java.lang.String genVar146;
    genVar146="declareType";
    org.jdom2.Element genVar147;
    genVar147=new Element(genVar146);
    org.jdom2.Element genVar148;
    genVar148=genVar147.setText(null);
    elemVariable.addContent(genVar148);
    elemVariables.addContent(elemVariable);
    analysedProject.addContent(elemVariables);
    java.lang.String genVar149;
    genVar149="Associations";
    Element elemAssociations;
    elemAssociations=new Element(genVar149);
    String From;
    From="";
    String To;
    To="";
    String Type;
    Type="";
    String LineNr;
    LineNr="";
    java.lang.String genVar150;
    genVar150="Association";
    Element elemAssociation;
    elemAssociation=new Element(genVar150);
    java.lang.String genVar151;
    genVar151="From";
    org.jdom2.Element genVar152;
    genVar152=new Element(genVar151);
    org.jdom2.Element genVar153;
    genVar153=genVar152.setText(From);
    elemAssociation.addContent(genVar153);
    java.lang.String genVar154;
    genVar154="To";
    org.jdom2.Element genVar155;
    genVar155=new Element(genVar154);
    org.jdom2.Element genVar156;
    genVar156=genVar155.setText(To);
    elemAssociation.addContent(genVar156);
    java.lang.String genVar157;
    genVar157="Type";
    org.jdom2.Element genVar158;
    genVar158=new Element(genVar157);
    org.jdom2.Element genVar159;
    genVar159=genVar158.setText(Type);
    elemAssociation.addContent(genVar159);
    java.lang.String genVar160;
    genVar160="linenumber";
    org.jdom2.Element genVar161;
    genVar161=new Element(genVar160);
    org.jdom2.Element genVar162;
    genVar162=genVar161.setText(LineNr);
    elemAssociation.addContent(genVar162);
    elemAssociations.addContent(elemAssociation);
    analysedProject.addContent(elemAssociations);
    return analysedProject;
  }
  public void loadModel(  Element analyseElement){
    boolean saveAnalysedData;
    saveAnalysedData=false;
    boolean genVar163;
    genVar163=!saveAnalysedData;
    if (genVar163) {
      return;
    }
 else {
      theModel=FamixModel.getInstance();
      java.util.List<org.jdom2.Element> genVar164;
      genVar164=analyseElement.getChildren();
      for (      Element rootElem : genVar164) {
        java.util.List<org.jdom2.Element> genVar165;
        genVar165=rootElem.getChildren();
        for (        Element rootChild1Elem : genVar165) {
          java.lang.String genVar166;
          genVar166=rootChild1Elem.getName();
          java.lang.String genVar167;
          genVar167="Package";
          boolean genVar168;
          genVar168=genVar166.equalsIgnoreCase(genVar167);
          if (genVar168) {
            FamixPackage famTempPackage;
            famTempPackage=new FamixPackage();
            java.util.List<org.jdom2.Element> genVar169;
            genVar169=rootChild1Elem.getChildren();
            for (            Element rootChild1Attrs : genVar169) {
              java.lang.String genVar170;
              genVar170=rootChild1Attrs.getName();
              java.lang.String genVar171;
              genVar171="UniqueName";
              boolean genVar172;
              genVar172=genVar170.equalsIgnoreCase(genVar171);
              if (genVar172) {
                famTempPackage.uniqueName=rootChild1Attrs.getText();
              }
 else {
                java.lang.String genVar173;
                genVar173=rootChild1Attrs.getName();
                java.lang.String genVar174;
                genVar174="Name";
                boolean genVar175;
                genVar175=genVar173.equalsIgnoreCase(genVar174);
                if (genVar175) {
                  famTempPackage.name=rootChild1Attrs.getText();
                }
 else {
                  java.lang.String genVar176;
                  genVar176=rootChild1Attrs.getName();
                  java.lang.String genVar177;
                  genVar177="BelongsToPackage";
                  boolean genVar178;
                  genVar178=genVar176.equalsIgnoreCase(genVar177);
                  if (genVar178) {
                    famTempPackage.belongsToPackage=rootChild1Attrs.getText();
                  }
 else {
                    ;
                  }
                }
              }
            }
          }
 else {
            ;
          }
          java.lang.String genVar179;
          genVar179=rootChild1Elem.getName();
          java.lang.String genVar180;
          genVar180="Class";
          boolean genVar181;
          genVar181=genVar179.equalsIgnoreCase(genVar180);
          if (genVar181) {
            FamixClass famTempClass;
            famTempClass=new FamixClass();
            java.util.List<org.jdom2.Element> genVar182;
            genVar182=rootChild1Elem.getChildren();
            for (            Element rootChild1Attrs : genVar182) {
              java.lang.String genVar183;
              genVar183=rootChild1Attrs.getName();
              java.lang.String genVar184;
              genVar184="UniqueName";
              boolean genVar185;
              genVar185=genVar183.equalsIgnoreCase(genVar184);
              if (genVar185) {
                famTempClass.uniqueName=rootChild1Attrs.getText();
              }
 else {
                java.lang.String genVar186;
                genVar186=rootChild1Attrs.getName();
                java.lang.String genVar187;
                genVar187="Name";
                boolean genVar188;
                genVar188=genVar186.equalsIgnoreCase(genVar187);
                if (genVar188) {
                  famTempClass.name=rootChild1Attrs.getText();
                }
 else {
                  java.lang.String genVar189;
                  genVar189=rootChild1Attrs.getName();
                  java.lang.String genVar190;
                  genVar190="BelongsToPackage";
                  boolean genVar191;
                  genVar191=genVar189.equalsIgnoreCase(genVar190);
                  if (genVar191) {
                    famTempClass.belongsToPackage=rootChild1Attrs.getText();
                  }
 else {
                    java.lang.String genVar192;
                    genVar192=rootChild1Attrs.getName();
                    java.lang.String genVar193;
                    genVar193="IsAbstract";
                    boolean genVar194;
                    genVar194=genVar192.equalsIgnoreCase(genVar193);
                    if (genVar194) {
                      java.lang.String genVar195;
                      genVar195=rootChild1Attrs.getText();
                      java.lang.String genVar196;
                      genVar196="true";
                      boolean genVar197;
                      genVar197=genVar195.equalsIgnoreCase(genVar196);
                      if (genVar197) {
                        famTempClass.isAbstract=true;
                      }
 else {
                        famTempClass.isAbstract=false;
                      }
                    }
 else {
                      java.lang.String genVar198;
                      genVar198=rootChild1Attrs.getName();
                      java.lang.String genVar199;
                      genVar199="IsInnerClass";
                      boolean genVar200;
                      genVar200=genVar198.equalsIgnoreCase(genVar199);
                      if (genVar200) {
                        java.lang.String genVar201;
                        genVar201=rootChild1Attrs.getText();
                        java.lang.String genVar202;
                        genVar202="true";
                        boolean genVar203;
                        genVar203=genVar201.equalsIgnoreCase(genVar202);
                        if (genVar203) {
                          famTempClass.isInnerClass=true;
                        }
 else {
                          famTempClass.isInnerClass=false;
                        }
                      }
 else {
                        ;
                      }
                    }
                  }
                }
              }
            }
          }
 else {
            ;
          }
          java.lang.String genVar204;
          genVar204=rootChild1Elem.getName();
          java.lang.String genVar205;
          genVar205="Method";
          boolean genVar206;
          genVar206=genVar204.equalsIgnoreCase(genVar205);
          if (genVar206) {
            FamixMethod famixMethod;
            famixMethod=new FamixMethod();
            java.util.List<org.jdom2.Element> genVar207;
            genVar207=rootChild1Elem.getChildren();
            for (            Element rootChild1Attrs : genVar207) {
              famixMethod.isPureAccessor=false;
              famixMethod.belongsToClass="";
              famixMethod.isConstructor=false;
              famixMethod.isAbstract=false;
              famixMethod.hasClassScope=false;
              java.lang.String genVar208;
              genVar208=rootChild1Attrs.getName();
              java.lang.String genVar209;
              genVar209="Name";
              boolean genVar210;
              genVar210=genVar208.equalsIgnoreCase(genVar209);
              if (genVar210) {
                famixMethod.name=rootChild1Attrs.getText();
              }
 else {
                java.lang.String genVar211;
                genVar211=rootChild1Attrs.getName();
                java.lang.String genVar212;
                genVar212="UniqueName";
                boolean genVar213;
                genVar213=genVar211.equalsIgnoreCase(genVar212);
                if (genVar213) {
                  famixMethod.uniqueName=rootChild1Attrs.getText();
                }
 else {
                  java.lang.String genVar214;
                  genVar214=rootChild1Attrs.getName();
                  java.lang.String genVar215;
                  genVar215="accessControlQualifier";
                  boolean genVar216;
                  genVar216=genVar214.equalsIgnoreCase(genVar215);
                  if (genVar216) {
                    famixMethod.accessControlQualifier=rootChild1Attrs.getText();
                  }
 else {
                    java.lang.String genVar217;
                    genVar217=rootChild1Attrs.getName();
                    java.lang.String genVar218;
                    genVar218="signature";
                    boolean genVar219;
                    genVar219=genVar217.equalsIgnoreCase(genVar218);
                    if (genVar219) {
                      famixMethod.signature=rootChild1Attrs.getText();
                    }
 else {
                      java.lang.String genVar220;
                      genVar220=rootChild1Attrs.getName();
                      java.lang.String genVar221;
                      genVar221="declaredReturnType";
                      boolean genVar222;
                      genVar222=genVar220.equalsIgnoreCase(genVar221);
                      if (genVar222) {
                        famixMethod.declaredReturnType=rootChild1Attrs.getText();
                      }
 else {
                        ;
                      }
                    }
                  }
                }
              }
            }
          }
 else {
            ;
          }
          java.lang.String genVar223;
          genVar223=rootChild1Elem.getName();
          java.lang.String genVar224;
          genVar224="Variable";
          boolean genVar225;
          genVar225=genVar223.equalsIgnoreCase(genVar224);
          if (genVar225) {
            FamixAttribute famTempVariable;
            famTempVariable=new FamixAttribute();
            java.util.List<org.jdom2.Element> genVar226;
            genVar226=rootChild1Elem.getChildren();
            for (            Element rootChild1Attrs : genVar226) {
              java.lang.String genVar227;
              genVar227=rootChild1Attrs.getName();
              java.lang.String genVar228;
              genVar228="UniqueName";
              boolean genVar229;
              genVar229=genVar227.equalsIgnoreCase(genVar228);
              if (genVar229) {
                famTempVariable.uniqueName=rootChild1Attrs.getText();
              }
 else {
                java.lang.String genVar230;
                genVar230=rootChild1Attrs.getName();
                java.lang.String genVar231;
                genVar231="Name";
                boolean genVar232;
                genVar232=genVar230.equalsIgnoreCase(genVar231);
                if (genVar232) {
                  famTempVariable.name=rootChild1Attrs.getText();
                }
 else {
                  java.lang.String genVar233;
                  genVar233=rootChild1Attrs.getName();
                  java.lang.String genVar234;
                  genVar234="BelongsToClass";
                  boolean genVar235;
                  genVar235=genVar233.equalsIgnoreCase(genVar234);
                  if (genVar235) {
                    famTempVariable.belongsToClass=rootChild1Attrs.getText();
                  }
 else {
                    java.lang.String genVar236;
                    genVar236=rootChild1Attrs.getName();
                    java.lang.String genVar237;
                    genVar237="declareType";
                    boolean genVar238;
                    genVar238=genVar236.equalsIgnoreCase(genVar237);
                    if (genVar238) {
                      famTempVariable.declareType=rootChild1Attrs.getText();
                    }
 else {
                      ;
                    }
                  }
                }
              }
            }
          }
 else {
            ;
          }
          java.lang.String genVar239;
          genVar239=rootChild1Elem.getName();
          java.lang.String genVar240;
          genVar240="Association";
          boolean genVar241;
          genVar241=genVar239.equalsIgnoreCase(genVar240);
          if (genVar241) {
            FamixAssociation famTempAssociation;
            famTempAssociation=new FamixAssociation();
            java.util.List<org.jdom2.Element> genVar242;
            genVar242=rootChild1Elem.getChildren();
            for (            Element rootChild1Attrs : genVar242) {
              java.lang.String genVar243;
              genVar243=rootChild1Attrs.getName();
              java.lang.String genVar244;
              genVar244="From";
              boolean genVar245;
              genVar245=genVar243.equalsIgnoreCase(genVar244);
              if (genVar245) {
                famTempAssociation.from=rootChild1Attrs.getText();
              }
 else {
                java.lang.String genVar246;
                genVar246=rootChild1Attrs.getName();
                java.lang.String genVar247;
                genVar247="Type";
                boolean genVar248;
                genVar248=genVar246.equalsIgnoreCase(genVar247);
                if (genVar248) {
                  famTempAssociation.type=rootChild1Attrs.getText();
                }
 else {
                  java.lang.String genVar249;
                  genVar249=rootChild1Attrs.getName();
                  java.lang.String genVar250;
                  genVar250="linenumber";
                  boolean genVar251;
                  genVar251=genVar249.equalsIgnoreCase(genVar250);
                  if (genVar251) {
                    java.lang.String genVar252;
                    genVar252=rootChild1Attrs.getText();
                    famTempAssociation.lineNumber=Integer.parseInt(genVar252);
                  }
 else {
                    java.lang.String genVar253;
                    genVar253=rootChild1Attrs.getName();
                    java.lang.String genVar254;
                    genVar254="To";
                    boolean genVar255;
                    genVar255=genVar253.equalsIgnoreCase(genVar254);
                    if (genVar255) {
                      famTempAssociation.to=rootChild1Attrs.getText();
                    }
 else {
                      ;
                    }
                  }
                }
              }
            }
          }
 else {
            ;
          }
        }
      }
    }
  }
}
