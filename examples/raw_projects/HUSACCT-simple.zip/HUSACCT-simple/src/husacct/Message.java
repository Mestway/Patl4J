package husacct;
import java.util.List;
public class Message {
  public Message(  LogicalModules logicalModules,  String ruleKey,  List<String> violationTypeKeysList,  String regex,  List<Message> exceptionMessages){
  }
}
