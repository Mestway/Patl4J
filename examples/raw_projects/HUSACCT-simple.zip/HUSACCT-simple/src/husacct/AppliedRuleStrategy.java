package husacct;
public class AppliedRuleStrategy {
  public long getId(){
    int genVar256;
    genVar256=0;
    return genVar256;
  }
  public String getRuleTypeKey(){
    return null;
  }
  public AppliedRuleStrategy getModuleFrom(){
    return null;
  }
  public AppliedRuleStrategy getModuleTo(){
    return null;
  }
}
