package husacct;
import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import org.jdom2.Document;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
public class XmlResource {
  public Document load(  HashMap<String,Object> dataValues){
    java.lang.String genVar762;
    genVar762="file";
    java.lang.Object genVar763;
    genVar763=dataValues.get(genVar762);
    File file;
    file=(File)genVar763;
    SAXBuilder sax;
    sax=new SAXBuilder();
    Document doc;
    doc=new Document();
    try {
      doc=sax.build(file);
    }
 catch (    Exception ex) {
      String password;
      password="";
      java.lang.String genVar764;
      genVar764="";
      boolean genVar765;
      genVar765=password.equals(genVar764);
      while (genVar765) {
        java.lang.String genVar766;
        genVar766="";
        boolean genVar767;
        genVar767=password.equals(genVar766);
        if (genVar767) {
          break;
        }
 else {
          ;
        }
        try {
          doc=sax.build(file);
        }
 catch (        Exception e) {
          password="";
        }
      }
    }
    return doc;
  }
  public boolean save(  Document doc,  HashMap<String,Object> dataValues,  HashMap<String,Object> config){
    java.lang.String genVar768;
    genVar768="file";
    java.lang.Object genVar769;
    genVar769=dataValues.get(genVar768);
    File file;
    file=(File)genVar769;
    try {
      FileOutputStream outputStream;
      outputStream=new FileOutputStream(file);
      XMLOutputter xout;
      boolean genVar770;
      genVar770=true;
      if (genVar770) {
        java.lang.String genVar771;
        genVar771="compress";
        System.out.println(genVar771);
        org.jdom2.output.Format genVar772;
        genVar772=Format.getRawFormat();
        xout=new XMLOutputter(genVar772);
      }
 else {
        org.jdom2.output.Format genVar773;
        genVar773=Format.getPrettyFormat();
        xout=new XMLOutputter(genVar773);
      }
      xout.output(doc,outputStream);
      outputStream.close();
      boolean genVar774;
      genVar774=true;
      return genVar774;
    }
 catch (    Exception e) {
    }
    boolean genVar775;
    genVar775=false;
    return genVar775;
  }
  public boolean save(  Document doc,  HashMap<String,Object> dataValues){
    boolean genVar776;
    genVar776=false;
    return genVar776;
  }
}
