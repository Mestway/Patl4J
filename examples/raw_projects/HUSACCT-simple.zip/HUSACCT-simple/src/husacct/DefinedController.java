package husacct;
public class DefinedController {
}
