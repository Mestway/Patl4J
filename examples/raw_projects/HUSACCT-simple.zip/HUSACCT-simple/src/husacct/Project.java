package husacct;
public class Project {
  public String getName(){
    return null;
  }
  public void setName(  String text){
  }
  public void setProgrammingLanguage(  String text){
  }
  public void setVersion(  String text){
  }
  public void setDescription(  String text){
  }
}
