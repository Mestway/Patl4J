package husacct;
import java.awt.Color;
import java.util.UUID;
public class Severity {
  public Severity(  UUID fromString,  String childText,  Color color){
  }
  public String getSeverityKey(){
    return null;
  }
  public Object getId(){
    return null;
  }
  public Object getColor(){
    return null;
  }
}
