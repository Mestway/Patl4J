package husacct;
public class LogicalModule {
  public LogicalModule(  String childText,  String childText2){
  }
}
