package husacct;
public class SoftwareArchitecture {
  public void setName(  String value){
  }
  public void setDescription(  String value){
  }
}
