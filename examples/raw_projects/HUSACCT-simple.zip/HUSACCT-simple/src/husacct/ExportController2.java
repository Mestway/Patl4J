package husacct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.jdom2.Element;
public class ExportController2 {
  public Element exportAllData(  ConfigurationServiceImpl configuration){
    java.lang.String genVar777;
    genVar777="validate";
    Element rootValidateElement;
    rootValidateElement=new Element(genVar777);
    ExportController2 genVar778;
    genVar778=this;
    java.util.List<husacct.Severity> genVar779;
    genVar779=configuration.getAllSeverities();
    org.jdom2.Element genVar780;
    genVar780=genVar778.exportSeveritiesXML(genVar779);
    rootValidateElement.addContent(genVar780);
    ExportController2 genVar781;
    genVar781=this;
    java.util.HashMap<java.lang.String,java.util.HashMap<java.lang.String,husacct.Severity>> genVar782;
    genVar782=configuration.getAllSeveritiesPerTypesPerProgrammingLanguages();
    org.jdom2.Element genVar783;
    genVar783=genVar781.exportSeveritiesPerTypesPerProgrammingLanguagesXML(genVar782);
    rootValidateElement.addContent(genVar783);
    ExportController2 genVar784;
    genVar784=this;
    java.util.Map<java.lang.String,java.util.List<husacct.ActiveRuleType>> genVar785;
    genVar785=configuration.getActiveViolationTypes();
    org.jdom2.Element genVar786;
    genVar786=genVar784.exportActiveViolationTypesPerRuleTypes(genVar785);
    rootValidateElement.addContent(genVar786);
    return rootValidateElement;
  }
  private Element exportSeveritiesXML(  List<Severity> severities){
    return null;
  }
  private Element exportSeveritiesPerTypesPerProgrammingLanguagesXML(  HashMap<String,HashMap<String,Severity>> allSeveritiesPerTypesPerProgrammingLanguages){
    return null;
  }
  private Element exportActiveViolationTypesPerRuleTypes(  Map<String,List<ActiveRuleType>> activeViolationTypes){
    return null;
  }
}
