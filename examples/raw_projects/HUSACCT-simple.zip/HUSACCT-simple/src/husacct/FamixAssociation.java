package husacct;
public class FamixAssociation {
  public String from;
  public String type;
  public int lineNumber;
  public String to;
}
